package com.simbest.boot.uums.web.position;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.uums.api.position.UumsSysPositionApi;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 系统职位管理控制器
 * 提供职位相关的REST API接口：
 * - 职位基础信息管理
 * - 职位与用户关联
 * - 组织架构职位查询
 * - 职位树形结构
 * - 支持分页和条件查询
 */

@SuppressWarnings("All")
@Api(tags = {"2-统一用户管理", "职位管理"}, description = "提供职位相关的管理功能，包括职位信息的CRUD操作、职位与用户的关联管理、职位树结构的查询、职位权限的管理等")
@RestController
@RequestMapping(value = {"/uums/sys/position", "/sys/uums/position"})
public class UumsSysPositionController {

    @Autowired
    private UumsSysPositionApi uumsSysPositionApi;

    @ApiOperation(value = "新增职位信息", notes = "创建新的职位信息，包含职位基本属性")
    @PostMapping(value = {"/create","/create/sso","/api/create"})
    public JsonResponse create(@RequestBody(required = false) Map map) {
        return uumsSysPositionApi.create(map);
    }

    @ApiOperation(value = "修改职位信息", notes = "更新现有职位的基本信息")
    @PostMapping(value = {"/update","/update/sso","/api/update"})
    public JsonResponse update(@RequestBody(required = false) Map map) {
        return uumsSysPositionApi.update(map);
    }

    @ApiOperation(value = "删除职位", notes = "根据职位ID删除指定的职位信息")
    @PostMapping(value = {"/deleteByIdCustom","/deleteByIdCustom/sso"})
    @ApiImplicitParam(name = "id", value = "职位ID", dataType = "String", paramType = "query", required = true)
    public JsonResponse deleteByIdCustom(@RequestParam String id) {
        return uumsSysPositionApi.deleteByIdCustom(id);
    }

    @ApiOperation(value = "查询职位用户", notes = "根据职位ID查询该职位下的所有用户信息，支持分页和姓名模糊查询")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "page", value = "当前页码", dataType = "int", paramType = "query", required = true, defaultValue = "1"),
        @ApiImplicitParam(name = "size", value = "每页数量", dataType = "int", paramType = "query", required = true, defaultValue = "10"),
        @ApiImplicitParam(name = "positionId", value = "职位ID", dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "truename", value = "用户姓名", dataType = "String", paramType = "query")
    })
    @PostMapping(value = {"/findPositionAndUser", "/findPositionAndUser/sso"})
    public JsonResponse findPositionAndUser(@RequestParam(required = false, defaultValue = "1") int page,
                                          @RequestParam(required = false, defaultValue = "10") int size,
                                          @RequestParam(required = false) String positionId,
                                          @RequestParam(required = false) String truename) {
        return uumsSysPositionApi.findPositionAndUser(page, size, positionId, truename);
    }

    @ApiOperation(value = "查询职位详情", notes = "根据职位ID和应用编码查询职位的详细信息")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "id", value = "职位ID", dataType = "String", paramType = "query", required = true),
        @ApiImplicitParam(name = "appcode", value = "应用编码", dataType = "String", paramType = "query", required = true)
    })
    @PostMapping(value="/findById")
    public JsonResponse findById(@RequestParam String id, @RequestParam String appcode) {
        return JsonResponse.success(uumsSysPositionApi.findById(id, appcode));
    }

    @ApiOperation(value = "分页查询职位列表", notes = "获取职位信息列表，支持分页、排序和条件查询")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "page", value = "当前页码", dataType = "int", paramType = "query", required = true, defaultValue = "1"),
        @ApiImplicitParam(name = "size", value = "每页数量", dataType = "int", paramType = "query", required = true, defaultValue = "10"),
        @ApiImplicitParam(name = "direction", value = "排序方向", dataType = "String", paramType = "query", allowableValues = "asc,desc"),
        @ApiImplicitParam(name = "properties", value = "排序字段", dataType = "String", paramType = "query"),
        @ApiImplicitParam(name = "appcode", value = "应用编码", dataType = "String", paramType = "query", required = true),
        @ApiImplicitParam(name = "map", value = "查询条件", dataType = "object", paramType = "body")
    })
    @PostMapping("/findAll")
    public JsonResponse findAll(@RequestParam(required = false, defaultValue = "1") int page,
                              @RequestParam(required = false, defaultValue = "10") int size,
                              @RequestParam(required = false) String direction,
                              @RequestParam(required = false) String properties,
                              @RequestParam String appcode,
                              @RequestBody Map map) {
        return uumsSysPositionApi.findAll(page, size, direction, properties, appcode, map);
    }

    @ApiOperation(value = "查询用户职位", notes = "根据用户名查询该用户的所有职位信息")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "username", value = "用户名", dataType = "String", paramType = "query", required = true),
        @ApiImplicitParam(name = "appcode", value = "应用编码", dataType = "String", paramType = "query", required = true)
    })
    @PostMapping("/findPositionByUsername")
    public JsonResponse findPositionByUsername(@RequestParam String username, @RequestParam String appcode) {
        return JsonResponse.success(uumsSysPositionApi.findPositionByUsername(username, appcode));
    }

    @ApiOperation(value = "查询组织职位", notes = "查询指定组织下的所有用户职位信息")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "orgCode", value = "组织编码", dataType = "String", paramType = "query", required = true),
        @ApiImplicitParam(name = "appcode", value = "应用编码", dataType = "String", paramType = "query", required = true)
    })
    @PostMapping("/findPositionOrgcodeAndUsername")
    public JsonResponse findPositionOrgcodeAndUsername(@RequestParam String orgCode, @RequestParam String appcode) {
        return JsonResponse.success(uumsSysPositionApi.findPositionOrgcodeAndUsername(orgCode, appcode));
    }

    @ApiOperation(value = "查询职位树", notes = "获取所有职位的树形结构数据")
    @PostMapping("/findAllToTree")
    public JsonResponse findAllToTree() {
        return uumsSysPositionApi.findAllToTree();
    }

    @ApiOperation(value = "模糊查询职位", notes = "根据组织编码和公司类型查询职位信息，支持职位名称模糊查询")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "orgCode", value = "组织编码", dataType = "String", paramType = "query", required = true),
        @ApiImplicitParam(name = "companyTypeDictValue", value = "公司类型", dataType = "String", paramType = "query", required = true),
        @ApiImplicitParam(name = "map", value = "查询条件", dataType = "object", paramType = "body")
    })
    @PostMapping(value = {"/findPositionCustom", "/findPositionCustom/sso","/api/findPositionCustom"})
    public JsonResponse findPositionCustom(@RequestParam String orgCode,
                                         @RequestParam String companyTypeDictValue,
                                         @RequestBody(required = false) Map<String, Object> map) {
        return uumsSysPositionApi.findPositionCustom(orgCode, companyTypeDictValue, map);
    }
}