package com.simbest.boot.security.auth.authentication.wxma;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;

/**
 * 微信小程序绑定认证令牌
 * 
 * 主要功能：
 * 1. 实现微信小程序账号与手机号的绑定认证
 * 2. 继承自Spring Security的AbstractAuthenticationToken
 * 3. 支持认证前状态的令牌管理
 * 
 * 认证流程：
 * 1. 接收用户首选手机号
 * 2. 验证微信小程序凭据
 * 3. 完成账号绑定和认证
 * 
 * 应用场景：
 * - 新用户首次绑定手机号
 * - 已有用户关联微信小程序
 * - 多平台账号统一
 */
public class WxmaBindAuthenticationToken extends AbstractAuthenticationToken {

    /**
     * 认证主体
     * 存储用户首选手机号(preferredMobile)
     * 用于：
     * 1. 作为用户的唯一标识
     * 2. 账号绑定和关联
     * 3. 用户信息验证
     */
    @Setter
    @Getter
    private Object principal;

    /**
     * 认证凭据
     * 包含微信小程序认证所需的所有信息
     * 用于：
     * 1. 存储微信小程序登录信息
     * 2. 验证码和加密数据处理
     * 3. 应用标识和控制参数
     */
    @Setter @Getter
    private WxmaAuthenticationCredentials credentials;

    /**
     * 创建微信小程序绑定认证令牌
     * 
     * @param principal 用户首选手机号，作为认证主体
     * @param credentials 微信小程序认证凭据
     * 
     * 说明：
     * 1. 创建时使用空权限列表初始化
     * 2. 认证成功后需要重新设置对应的权限
     * 3. 用于账号绑定场景的认证处理
     */
    public WxmaBindAuthenticationToken(Object principal, WxmaAuthenticationCredentials credentials) {
        super(AuthorityUtils.NO_AUTHORITIES);
        this.principal = principal;
        this.credentials = credentials;
    }

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}