package com.simbest.boot.base.web.controller;

import com.simbest.boot.base.exception.GlobalExceptionRegister;
import com.simbest.boot.base.model.GenericModel;
import com.simbest.boot.base.repository.Condition;
import com.simbest.boot.base.service.IGenericService;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.util.CustomBeanUtil;
import com.simbest.boot.util.ObjectUtil;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Map;

/**
 * 通用实体控制器基类
 * 
 * 主要功能：
 * 1. 提供标准的CRUD（创建、查询、更新、删除）接口
 * 2. 支持多种查询方式：主键查询、条件查询、分页查询
 * 3. 支持单条和批量记录操作
 * 4. 统一的响应格式和异常处理
 * 5. 支持SSO和API多种访问方式
 * 6. 完整的Swagger接口文档
 * 7. 可被其他业务控制器继承复用
 *
 * @param <T> 实体类型，必须继承自GenericModel
 * @param <PK> 主键类型，必须实现Serializable接口
 */
@Slf4j
public class GenericController<T extends GenericModel, PK extends Serializable> {

    /**
     * 通用服务接口，提供数据操作功能
     */
    private IGenericService<T, PK> service;

    /**
     * 构造函数，注入通用服务接口
     *
     * @param service 通用服务接口实现
     */
    public GenericController(IGenericService<T, PK> service) {
        this.service = service;
    }

    /**
     * 根据主键ID查询单条记录
     * 支持标准访问、SSO访问和API访问三种方式
     *
     * @param id 记录的主键ID
     * @return 查询结果的JSON响应，包含实体对象数据
     */
    @PostMapping(value = {"/findById", "/sso/findById", "/api/findById"})
    public JsonResponse findById(@ApiParam(value = "主键ID", required = true) @RequestParam PK id) {
        return JsonResponse.success(service.findById(id));
    }

    /**
     * 根据实体对象的非空属性作为条件查询单条记录
     * 将对象的非空属性转换为相等条件进行查询
     *
     * @param o 包含查询条件的实体对象
     * @return 查询结果的JSON响应，包含符合条件的单条记录
     */
    @PostMapping(value = {"/findOne", "/sso/findOne", "/api/findOne"})
    public JsonResponse findOne(@ApiParam(value = "实体对象", required = true) @RequestBody T o) {
        // 获取查询条件
        Condition condition = new Condition();
        Map<String, Object> params = ObjectUtil.getEntityPersistentFieldValueExceptId(o);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            condition.eq(entry.getKey(), entry.getValue());
        }
        Specification<T> specification = service.getSpecification(condition);
        T data = service.findOne(specification);
        return JsonResponse.success(data);
    }

    /**
     * 根据实体对象的非空属性作为条件进行分页查询
     * 支持排序和分页参数设置
     *
     * @param page 当前页码，默认为1
     * @param size 每页记录数，默认为10
     * @param direction 排序方向，可选值为asc（升序）或desc（降序）
     * @param properties 排序字段名称
     * @param o 包含查询条件的实体对象
     * @return 分页查询结果的JSON响应，包含分页信息和数据列表
     */
    @PostMapping(value = {"/findAll", "/sso/findAll", "/api/findAll"})
    public JsonResponse findAll(
            @ApiParam(value = "当前页码", defaultValue = "1") @RequestParam(required = false, defaultValue = "1") int page, //
            @ApiParam(value = "每页数量", defaultValue = "10") @RequestParam(required = false, defaultValue = "10") int size, //
            @ApiParam(value = "排序规则(asc/desc)") @RequestParam(required = false) String direction, //
            @ApiParam(value = "排序字段") @RequestParam(required = false) String properties,
            @ApiParam(value = "实体对象", required = true) @RequestBody T o) {
        //获取分页规则, page第几页 size每页多少条 direction升序还是降序 properties排序规则（属性名称）
        Pageable pageable = service.getPageable(page, size, direction, properties);
        // 获取查询条件
        Condition condition = new Condition();
        Map<String, Object> params = ObjectUtil.getEntityPersistentFieldValueExceptId(o);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            condition.eq(entry.getKey(), entry.getValue());
        }
        Specification<T> specification = service.getSpecification(condition);
        // 获取查询结果
        Page<T> pages = service.findAll(specification, pageable);
        return JsonResponse.success(pages);
    }

    /**
     * 根据实体对象的非空属性作为条件查询所有记录（不分页）
     * 返回符合条件的所有记录，不进行分页处理
     *
     * @param o 包含查询条件的实体对象
     * @return 查询结果的JSON响应，包含符合条件的所有记录
     */
    @PostMapping(value = {"/findAllNoPage", "/sso/findAllNoPage", "/api/findAllNoPage"})
    public JsonResponse findAllNoPage(@ApiParam(value = "实体对象", required = true) @RequestBody T o) {
        // 获取查询条件
        Condition condition = new Condition();
        Map<String, Object> params = ObjectUtil.getEntityPersistentFieldValueExceptId(o);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            condition.eq(entry.getKey(), entry.getValue());
        }
        Specification<T> specification = service.getSpecification(condition);
        Iterable<T> datas = service.findAllNoPage(specification);
        return JsonResponse.success(datas);
    }

    /**
     * 根据实体对象的非空属性作为条件查询所有记录（带排序不分页）
     * 返回符合条件的所有记录，并按指定字段排序，不进行分页处理
     *
     * @param direction 排序方向，可选值为asc（升序）或desc（降序）
     * @param properties 排序字段名称
     * @param o 包含查询条件的实体对象
     * @return 查询结果的JSON响应，包含排序后的所有记录
     */
    @PostMapping(value = {"/findAllSortNoPage", "/sso/findAllSortNoPage", "/api/findAllSortNoPage"})
    public JsonResponse findAllSortNoPage(
            @ApiParam(value = "排序规则(asc/desc)") @RequestParam(required = false) String direction,
            @ApiParam(value = "排序字段") @RequestParam(required = false) String properties,
            @ApiParam(value = "实体对象", required = true) @RequestBody T o) {
        // 获取查询条件
        Condition condition = new Condition();
        Map<String, Object> params = ObjectUtil.getEntityPersistentFieldValueExceptId(o);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            condition.eq(entry.getKey(), entry.getValue());
        }
        Specification<T> specification = service.getSpecification(condition);
        Sort sort = Sort.by(Sort.Direction.fromString(direction), properties);
        Iterable<T> datas = service.findAllNoPage(specification, sort);
        return JsonResponse.success(datas);
    }

    /**
     * 创建一条新记录
     * 将实体对象插入数据库，并返回插入后的对象（包含自动生成的ID等信息）
     *
     * @param o 待创建的实体对象
     * @return 创建结果的JSON响应，包含创建成功的实体对象
     */
    @PostMapping(value = {"/create", "/sso/create", "/api/create"})
    public JsonResponse create(@ApiParam(value = "实体对象", required = true) @RequestBody T o) {
        try {
            o = service.insert(o);
            return JsonResponse.success(o);
        } catch (Exception e) {
            return GlobalExceptionRegister.returnErrorResponse(e);
        }
    }

    /**
     * 更新一条记录
     * 根据实体对象的ID查找原有记录，并用新对象的非空属性更新原有记录
     *
     * @param newObj 包含更新内容的新实体对象
     * @return 更新结果的JSON响应，包含更新后的实体对象
     */
    @PostMapping(value = {"/update", "/sso/update", "/api/update"})
    public JsonResponse update(@ApiParam(value = "实体对象", required = true) @RequestBody T newObj) {
        T oldObj = service.findById((PK) ObjectUtil.getEntityIdVaue(newObj));
        CustomBeanUtil.copyPropertiesIgnoreNull(newObj, oldObj);
        try {
            oldObj = service.update(oldObj);
            return JsonResponse.success(oldObj);
        } catch (Exception e) {
            return GlobalExceptionRegister.returnErrorResponse(e);
        }
    }

    /**
     * 根据主键ID删除一条记录
     * 物理删除指定ID的记录
     *
     * @param id 待删除记录的主键ID
     * @return 删除结果的JSON响应
     */
    @PostMapping(value = {"/deleteById", "/sso/deleteById", "/api/deleteById"})
    public JsonResponse deleteById(@ApiParam(value = "主键ID", required = true) @RequestParam PK id) {
        try {
            service.deleteById(id);
            return JsonResponse.defaultSuccessResponse();
        } catch (Exception e) {
            return GlobalExceptionRegister.returnErrorResponse(e);
        }
    }

    /**
     * 根据实体对象的非空属性作为条件删除符合条件的记录
     * 物理删除所有符合条件的记录
     *
     * @param o 包含删除条件的实体对象
     * @return 删除结果的JSON响应
     */
    @PostMapping(value = {"/delete", "/sso/delete", "/api/delete"})
    public JsonResponse delete(@ApiParam(value = "实体对象", required = true) @RequestBody T o) {
        try {
            service.delete(o);
            return JsonResponse.defaultSuccessResponse();
        } catch (Exception e) {
            return GlobalExceptionRegister.returnErrorResponse(e);
        }
    }

    /**
     * 根据主键ID数组批量删除记录
     * 物理删除多条指定ID的记录
     *
     * @param ids 待删除记录的主键ID数组
     * @return 删除结果的JSON响应
     */
    @PostMapping(value = {"/deleteAllByIds", "/sso/deleteAllByIds", "/api/deleteAllByIds"})
    public JsonResponse deleteAllByIds(@ApiParam(value = "主键ID数组", required = true) @RequestBody PK[] ids) {
        try {
            service.deleteAllByIds(Arrays.asList(ids));
            return JsonResponse.defaultSuccessResponse();
        } catch (Exception e) {
            return GlobalExceptionRegister.returnErrorResponse(e);
        }
    }
}