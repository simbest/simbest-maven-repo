package com.simbest.boot.uums.schedule;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChangeUserLog implements Serializable {

    @JsonProperty("CHANGETYPE")
    private String changeType;

    @JsonProperty("USERNAME")
    private String username;

    @JsonProperty("DISPLAYORDER")
    private Integer displayOrder;

    @JsonProperty("CURRENTORGCODE20")
    private String currentOrgCode20;

    @JsonProperty("EMPLOYEENUMBER")
    private String employeeNumber;

    @JsonProperty("POSITIONNAME")
    private String positionName;

    @JsonProperty("TRUENAME")
    private String truename;

    @JsonProperty("PREORGCODE")
    private String preOrgcode;

    @JsonProperty("CURRENTORGCODE")
    private String currentOrgcode;

    @JsonProperty("PREPOSITIONNAME")
    private String prePositionName;

    @JsonProperty("CURRENTPOSITIONNAME")
    private String currentPositionName;

    @JsonProperty("PREFERREDMOBILE")
    private String preferredMobile;

    @JsonProperty("EMAIL")
    private String email;

    //入参格式化注解
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    //出参格式化注解
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty("CREATEDATETIME")
    private Date createDatetime;    //add update delete 的三种变更时间戳

    @JsonProperty("IRESERVED_1")
    private String ireserved1;

    @JsonProperty("IRESERVED_2")
    private String ireserved2;

    @JsonProperty("IRESERVED_3")
    private String ireserved3;

    @JsonProperty("IRESERVED_4")
    private String ireserved4;

    @JsonProperty("IRESERVED_5")
    private String ireserved5;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}