package com.simbest.boot.util;

import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.constants.ApplicationConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.csource.common.MyException;
import org.csource.common.NameValuePair;
import org.csource.fastdfs.*;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.io.*;
import java.util.Properties;

/**
 * 用途：分布式FastDfs文件存储客户端
 * 提供文件上传、下载、删除等操作的封装
 * 参考文档：https://github.com/happyfish100/fastdfs
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "app.file.upload.location", havingValue = "fastdfs")
public class FastDfsClient {
    private static TrackerClient tracker = null;
//    @Getter
//    private static TrackerServer trackerServer = null;
//    private static StorageClient storageClient = null;

    /**
     * 初始化FastDFS客户端
     * 读取配置文件并初始化TrackerClient
     */
    @PostConstruct
    public void init() {
        try {
            BufferedReader bufferedReader = BootAppFileReader.getClasspathFile("fastdfs-client.properties");
            Properties props = new Properties();
            props.load(bufferedReader);
            log.info("FastDFS配置信息为【{}】", props.getProperty("fastdfs.tracker_servers"));
            ClientGlobal.initByProperties(props);
            if (tracker == null) {
                tracker = new TrackerClient();
            }
//            if (trackerServer == null) {
//                trackerServer = tracker.getConnection();
//                //给fastdfs发送一个消息,解决fastdfs第一次上传文件报错recv package size -1!=10。参考https://blog.qianxunclub.com/exception/fastdfs-recv-package-size/
//                ProtoCommon.activeTest(trackerServer.getSocket());
//            }
//            storageClient = new StorageClient(trackerServer, null);
            log.info("FastDFS StorageClient 客户端初始化成功!");
        } catch (Exception ex) {
            log.error("FastDFS StorageClient 客户端初始化失败!");
            Exceptions.printException(ex);
        }
    }

//    @PreDestroy
//    public void shutdown(){
//        if(null != trackerServer){
//            try {
//                trackerServer.close();
//                log.info("FASTDFS TrackerServer 关闭成功!");
//            } catch (IOException e) {
//                log.error("FASTDFS TrackerServer 关闭失败!");
//                Exceptions.printException(e);
//            }
//        }
//    }

    /**
     * 上传文件（简化方法）
     * 不指定文件名和扩展名的快速上传
     * 
     * @param fileContent 文件字节内容
     * @return 上传成功后的文件路径
     * @throws Exception 上传过程中的异常
     */
    public static String uploadFile(byte[] fileContent) throws Exception {
        return uploadFile(fileContent, null, String.valueOf(fileContent.length));
    }

    /**
     * 上传文件并指定文件名和扩展名
     * 
     * @param fileContent 文件字节内容
     * @param fileName 文件名
     * @param extName 文件扩展名
     * @return 上传成功后的文件路径
     * @throws Exception 上传过程中的异常
     */
    public static String uploadFile(byte[] fileContent, String fileName, String extName) throws Exception {
        String fileLength = String.valueOf(fileContent.length);
        log.debug("FastDfsClient upload fileName: {} extName: {} with length: {}", fileName, extName, fileLength);
        NameValuePair[] metas = new NameValuePair[3];
        metas[0] = new NameValuePair("fileName", fileName);
        metas[1] = new NameValuePair("extName", extName);
        metas[2] = new NameValuePair("fileSize", fileLength);
        String result = uploadFile(fileContent, extName, metas);
        log.debug("FastDfsClient 上传结果为【{}】", result);
        return result;
    }

    /**
     * 上传文件方法
     * 包含完整的元数据信息
     * 
     * @param fileContent 文件字节流
     * @param extName 文件后缀
     * @param metas 文件元数据
     * @return 上传成功后的文件路径（格式：group/path）
     * @throws Exception 上传过程中的异常
     */
    public static String uploadFile(byte[] fileContent, String extName, NameValuePair[] metas) throws Exception {
        log.debug("FastDfsClient upload file with extName: {} and metadata", extName);
        for(NameValuePair kv : metas){
            log.debug("metadata name: {} value: {}", kv.getName(), kv.getValue());
        }
        Assert.notNull(getStorageClient(), "请检查FasfDFS配置和服务运行状态");
        String[] result = getStorageClient().upload_file(fileContent, extName, metas);
        String group = result[0];
        String filePath = result[1];
        return group + ApplicationConstants.SLASH + filePath;
    }

    /**
     * 删除文件
     * 根据存储路径删除FastDFS上的文件
     * 
     * @param storagePath 文件存储路径（格式：group/path）
     * @return 删除结果，0表示成功，非0表示失败
     * @throws IOException IO异常
     * @throws MyException FastDFS异常
     */
    public static Integer deleteFile(String storagePath) throws IOException, MyException {
        String group = StringUtils.substringBefore(storagePath, ApplicationConstants.SLASH);
        String filename = StringUtils.substringAfter(storagePath, ApplicationConstants.SLASH);
        log.warn("Want remove file at group {}, filepath {}", group, filename);
        Assert.notNull(getStorageClient(), "请检查FasfDFS配置和服务运行状态");
        return getStorageClient().delete_file(group, filename);
    }

    /**
     * 上传本地文件
     * 将本地文件上传到FastDFS服务器
     * 
     * @param local_fileName 文件全路径
     * @param extName 文件扩展名，不包含（.）
     * @param metas 文件扩展信息
     * @return 上传成功后的文件路径（格式：group/path）
     * @throws Exception 上传过程中的异常
     */
    public static String uploadLocalFile(String local_fileName, String extName, NameValuePair[] metas) throws Exception {
        String[] result = getStorageClient().upload_file(local_fileName, extName, metas);
        String group = result[0];
        String filePath = result[1];
        return group + ApplicationConstants.SLASH + filePath;
    }

    /**
     * 上传本地文件（简化方法）
     * 不指定扩展名和元数据信息
     * 
     * @param local_fileName 本地文件路径
     * @return 上传成功后的文件路径
     * @throws Exception 上传过程中的异常
     */
    public static String uploadLocalFile(String local_fileName) throws Exception {
        return uploadLocalFile(local_fileName, null, null);
    }

    /**
     * 上传本地文件并指定扩展名
     * 不包含元数据信息
     * 
     * @param local_fileName 本地文件路径
     * @param extName 文件扩展名
     * @return 上传成功后的文件路径
     * @throws Exception 上传过程中的异常
     */
    public static String uploadLocalFile(String local_fileName, String extName) throws Exception {
        return uploadLocalFile(local_fileName, extName, null);
    }

    /**
     * 获取文件信息
     * 查询FastDFS中存储的文件信息，包括文件大小、创建时间等
     *
     * @param group 文件所在组名，如group1
     * @param path 文件路径，如M00/00/7F/ClcNWlt2PliAGyTyAAAClS5uADs678.txt
     * @return 文件信息对象，获取失败返回null
     */
    public static FileInfo getFileInfo(String group, String path){
        FileInfo fileInfo = null;
        try {
            Assert.notNull(getStorageClient(), "请检查FasfDFS配置和服务运行状态");
            fileInfo = getStorageClient().get_file_info(group, path);
        } catch (IOException e) {
            Exceptions.printException(e);
        } catch (MyException e) {
            Exceptions.printException(e);
        }
        return fileInfo;
    }

    /**
     * 获取文件元数据
     * 查询上传文件时设置的元数据信息
     * 
     * @param group 文件所在组名，如group1
     * @param path 文件路径，如M00/00/7F/ClcNWlt2PliAGyTyAAAClS5uADs678.txt
     * @return 元数据数组，获取失败返回null
     */
    public static NameValuePair[] getMetadata(String group, String path){
        NameValuePair[] metadata = null;
        try {
            Assert.notNull(getStorageClient(), "请检查FasfDFS配置和服务运行状态");
            metadata = getStorageClient().get_metadata(group, path);
        } catch (IOException e) {
            Exceptions.printException(e);
        } catch (MyException e) {
            Exceptions.printException(e);
        }
        return metadata;
    }

    /**
     * 获取存储服务器
     * 获取指定组的所有存储服务器信息
     * 
     * @param groupName 组名
     * @return 存储服务器数组
     * @throws IOException 连接异常
     */
    public static StorageServer[] getStoreStorages(String groupName) throws IOException {
        TrackerClient trackerClient = new TrackerClient();
        TrackerServer trackerServer = trackerClient.getConnection();
        return trackerClient.getStoreStorages(trackerServer, groupName);
    }

    /**
     * 获取提取存储服务器
     * 获取可用于下载文件的服务器信息
     * 
     * @param groupName 组名
     * @param remoteFileName 远程文件名
     * @return 服务器信息数组
     * @throws IOException 连接异常
     */
    public static ServerInfo[] getFetchStorages(String groupName, String remoteFileName) throws IOException {
        TrackerClient trackerClient = new TrackerClient();
        TrackerServer trackerServer = trackerClient.getConnection();
        return trackerClient.getFetchStorages(trackerServer, groupName, remoteFileName);
    }

    /**
     * 获取Tracker服务器URL
     * 用于构建完整的文件访问路径
     * 
     * @return Tracker服务器的HTTP访问URL
     * @throws IOException 连接异常
     */
    public static String getTrackerUrl() throws IOException {
        String url = "http://"+getTrackerServer().getInetSocketAddress().getHostString()+":"+ClientGlobal.getG_tracker_http_port()+"/";
        log.debug("TrackerServer 路径地址为【{}】", url);
        return url;
    }

    /**
     * 获取存储客户端
     * 创建并返回一个连接到Tracker服务器的存储客户端
     * 
     * @return 存储客户端对象
     * @throws IOException 连接异常
     */
    private static StorageClient getStorageClient() throws IOException {
        TrackerServer trackerServer = getTrackerServer();
        StorageClient storageClient = new StorageClient(trackerServer, null);
        return  storageClient;
    }

    /**
     * 获取Tracker服务器
     * 创建并返回一个连接到Tracker服务器的连接
     * 
     * @return Tracker服务器连接
     * @throws IOException 连接异常
     */
    public static TrackerServer getTrackerServer() throws IOException {
        TrackerClient trackerClient = new TrackerClient();
        TrackerServer trackerServer = trackerClient.getConnection();
        ProtoCommon.activeTest(trackerServer.getSocket());
        return  trackerServer;
    }

    /**
     * 测试方法
     * 用于测试FastDFS客户端配置和上传功能
     * 手动设置FastDFS的连接属性并初始化客户端
     * 
     * @param args 命令行参数
     * @throws Exception 连接或上传过程中的异常
     */
    public static void main(String[] args) throws Exception {
        Properties props = new Properties();
        props.setProperty("fastdfs.connect_timeout_in_seconds", "5");
        props.setProperty("fastdfs.network_timeout_in_seconds", "30");
        props.setProperty("fastdfs.charset", "UTF-8");
        props.setProperty("fastdfs.http_anti_steal_token", "false");
        props.setProperty("fastdfs.http_secret_key", "FastDFS1234567890");
        props.setProperty("fastdfs.http_tracker_http_port", "80");
        props.setProperty("fastdfs.tracker_servers", "10.87.13.90:22122, 10.87.13.91:22122");
        ClientGlobal.initByProperties(props);
//        if (tracker == null) {
//            tracker = new TrackerClient();
//        }
//        if (trackerServer == null) {
//            trackerServer = tracker.getConnection();
//        }
//        storageClient = new StorageClient(trackerServer, null);
//        FastDfsClient.storageClient = storageClient;

        //test upload
        File initialFile = new File("C:\\Users\\kynel\\Desktop\\url.txt");
        InputStream targetStream = new FileInputStream(initialFile);
        String uploadResult = FastDfsClient.uploadFile(IOUtils.toByteArray(targetStream),
                AppFileUtil.getFileName(initialFile.getAbsolutePath()), AppFileUtil.getFileSuffix(initialFile.getCanonicalPath()));
        System.out.println(uploadResult);

        //test query
        String group = StringUtils.substringBefore(uploadResult, "/");
        String path = StringUtils.substringAfter(uploadResult, "/");
        FileInfo fileInfo = FastDfsClient.getFileInfo(group, path);
        System.out.println(fileInfo);
        NameValuePair[] metadata =  FastDfsClient.getStorageClient().get_metadata(group, path);
        for(NameValuePair nv : metadata){
            System.out.println(nv.getName()+"----"+nv.getValue());
        }

        //test delete
        int ret = getStorageClient().delete_file(group, path);
        System.out.println(ret);

        System.out.println(getTrackerUrl());
    }
}