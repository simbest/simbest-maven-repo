package com.simbest.boot.base.annotations;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.type.AnnotatedTypeMetadata;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Map;

/**
 * 条件注解：用于判断配置属性是否已设置且不为空
 * 可以应用在类或方法级别，用于控制Bean的创建或方法的执行
 */
@Target({ ElementType.TYPE, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Conditional(ConditionalOnPropertyNotEmpty.OnPropertyNotEmptyCondition.class)
public @interface ConditionalOnPropertyNotEmpty {
    /**
     * 需要检查的配置属性名称
     * @return 属性名称
     */
    String value();

    /**
     * 属性非空条件判断实现类
     */
    class OnPropertyNotEmptyCondition implements Condition {

        /**
         * 判断条件是否满足
         * 检查指定的配置属性是否存在且不为空
         *
         * @param context 条件上下文
         * @param metadata 注解元数据
         * @return 如果属性存在且不为空返回true，否则返回false
         */
        @Override
        public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
            Map<String, Object> attrs = metadata.getAnnotationAttributes(ConditionalOnPropertyNotEmpty.class.getName());
            String propertyName = (String) attrs.get("value");
            String val = context.getEnvironment().getProperty(propertyName);
            return val != null && !val.trim().isEmpty();
        }
    }
}