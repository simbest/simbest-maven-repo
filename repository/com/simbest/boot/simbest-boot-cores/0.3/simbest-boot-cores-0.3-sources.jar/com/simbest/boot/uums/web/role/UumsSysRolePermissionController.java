package com.simbest.boot.uums.web.role;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.uums.api.role.UumsSysRolePermissionApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 系统角色权限管理控制器
 * 提供角色权限关联的REST API接口：
 * - 管理角色与权限的关联关系
 * - 支持批量更新角色的权限配置
 * - 提供权限分配和回收的功能
 */
@SuppressWarnings("All")
@Api(tags = {"2-统一用户管理", "角色权限管理"}, description = "提供角色与权限关联关系的管理功能，包括角色权限的分配和回收、批量更新角色权限、角色权限的查询和管理等")
@RestController
@RequestMapping(value = {"/uums/sys/role/permission", "/sys/uums/role/permission"})
public class UumsSysRolePermissionController {

    @Autowired
    private UumsSysRolePermissionApi uumsSysRolePermissionApi;

    @Autowired
    private AppConfig appConfig;

    @ApiOperation(value = "修修改角色权限信息，先删除角色所有权限，再重新添加", notes = "修改角色权限信息，先删除角色所有权限，再重新添加",tags={"角色权限API"})
    @PostMapping(value = {"/updateListByPermissionId","/updateListByPermissionId/sso","/api/updateListByPermissionId"})
    public JsonResponse updateListByPermissionId(@RequestParam String permissionId, @RequestBody List<String> roleCodes){
        return uumsSysRolePermissionApi.updateListByPermissionId(permissionId, roleCodes);
    }
}