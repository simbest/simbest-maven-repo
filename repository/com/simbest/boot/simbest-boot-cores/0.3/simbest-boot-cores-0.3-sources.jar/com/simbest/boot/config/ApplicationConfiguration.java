package com.simbest.boot.config;

import com.simbest.boot.security.auth.entryPoint.IAccessDeniedEntryPoint;
import com.simbest.boot.security.auth.entryPoint.RestAccessDeniedEntryPoint;
import com.simbest.boot.sys.service.IAppShutdownService;
import com.simbest.boot.sys.service.ISimpleSmsService;
import com.simbest.boot.sys.service.impl.CloopenSmsService;
import com.simbest.boot.sys.service.impl.GenericAppShutdownService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 用途：应用通用配置类
 * 主要提供以下功能：
 * 1. 短信服务配置
 * 2. 应用关闭钩子配置
 * 3. 无权限访问入口配置
 */
@Slf4j
@Configuration
public class ApplicationConfiguration {

    /**
     * 应用配置对象
     */
    @Autowired
    private AppConfig config;

    /**
     * 配置缺省的简单短信接口
     * 当容器中没有ISimpleSmsService的实现时，使用默认的容联云通讯短信服务
     * @return 短信服务实现类实例
     */
    @Bean
    @ConditionalOnMissingBean(value = ISimpleSmsService.class)
    public ISimpleSmsService cloopenSmsService() {
        return new CloopenSmsService(config.getSmsAccount(), config.getSmsToken(), config.getSmsAppId(), config.getSmsTemplateId());
    }

    /**
     * 配置缺省的简单应用关闭钩子
     * 当容器中没有IAppShutdownService的实现时，使用默认的应用关闭服务
     * @return 应用关闭服务实现类实例
     */
    @Bean
    @ConditionalOnMissingBean(value = IAppShutdownService.class)
    public IAppShutdownService genericAppShutdownService() {
        return new GenericAppShutdownService();
    }

    /**
     * 配置缺省的无权限访问入口
     * 当容器中没有IAccessDeniedEntryPoint的实现时，使用默认的REST风格无权限访问处理
     * @return 无权限访问入口实现类实例
     */
    @Bean
    @ConditionalOnMissingBean(value = IAccessDeniedEntryPoint.class)
    public IAccessDeniedEntryPoint accessDeniedEntryPoint() {
        return new RestAccessDeniedEntryPoint();
    }
}