package com.simbest.exclude.web;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.util.json.GetJsonRequestUtil;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ErrorProperties;
import org.springframework.boot.autoconfigure.web.servlet.error.AbstractErrorController;
import org.springframework.boot.autoconfigure.web.servlet.error.BasicErrorController;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorViewResolver;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import static org.springframework.http.HttpStatus.NOT_FOUND;

/**
 * 用途：统一异常处理 参考：https://blog.csdn.net/king_is_everyone/article/details/53080851
 *
 *
 */
/**
 * 全局错误处理控制器
 * 提供统一的异常处理和错误响应机制：
 * - 处理所有系统级别的错误和异常
 * - 支持HTML页面和JSON格式的错误响应
 * - 提供详细的错误日志记录
 * - 实现自定义的错误页面展示
 * - 支持不同类型的错误追踪和诊断
 * - 继承自Spring Boot的AbstractErrorController
 */
@Api(tags = {"8-排除功能", "全局错误处理"}, description = "提供全局错误处理功能，包括系统异常的统一处理、错误信息的格式化输出、错误日志的记录等")
@Slf4j
@Controller
@RequestMapping("${server.error.path:${error.path:/error}}")
public class GlobalErrorController extends AbstractErrorController {
    private final ErrorProperties errorProperties;
    private static final Logger LOGGER = LoggerFactory.getLogger(BasicErrorController.class);
    @Autowired
    private ApplicationContext applicationContext;

    /**
     * Create a new {@link org.springframework.boot.autoconfigure.web.servlet.error.BasicErrorController} instance.
     *
     * @param errorAttributes the error attributes
     * @param errorProperties configuration properties
     */
    public GlobalErrorController(ErrorAttributes errorAttributes,
                                ErrorProperties errorProperties) {
        this(errorAttributes, errorProperties,
                Collections.<ErrorViewResolver>emptyList());
    }

    /**
     * Create a new {@link org.springframework.boot.autoconfigure.web.servlet.error.BasicErrorController} instance.
     *
     * @param errorAttributes    the error attributes
     * @param errorProperties    configuration properties
     * @param errorViewResolvers error view resolvers
     */
    public GlobalErrorController(ErrorAttributes errorAttributes,
                                ErrorProperties errorProperties, List<ErrorViewResolver> errorViewResolvers) {
        super(errorAttributes, errorViewResolvers);
        Assert.notNull(errorProperties, "ErrorProperties must not be null");
        this.errorProperties = errorProperties;
    }

    @Override
    public String getErrorPath() {
        return this.errorProperties.getPath();
    }

    /**
     * 处理错误页面
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(produces = "text/html")
    public ModelAndView errorHtml(HttpServletRequest request,
                                  HttpServletResponse response) {
        logErrorInformation(request);
        HttpStatus status = getStatus(request);
        Map<String, Object> model = getErrorAttributes(
                request, isIncludeStackTrace(request, MediaType.TEXT_HTML));
        model.put("errcode", JsonResponse.ERROR_CODE);
        response.setStatus(status.value());
        ModelAndView modelAndView = resolveErrorView(request, response, status, model);
        return modelAndView == null ? new ModelAndView("error", model) : modelAndView;
    }

    /**
     * 处理Restful请求Json数据
     * @param request
     * @return
     */
    @RequestMapping
    @ResponseBody
    public ResponseEntity<Map<String, Object>> error(HttpServletRequest request) {
        logErrorInformation(request);
        Map<String, Object> body = getErrorAttributes(request,
                isIncludeStackTrace(request, MediaType.ALL));
        body.put("errcode", JsonResponse.ERROR_CODE);
        HttpStatus status = getStatus(request);
        return new ResponseEntity(body, status);
    }

    /**
     * Determine if the stacktrace attribute should be included.
     *
     * @param request  the source request
     * @param produces the media type produced (or {@code MediaType.ALL})
     * @return if the stacktrace attribute should be included
     */
    protected boolean isIncludeStackTrace(HttpServletRequest request,
                                          MediaType produces) {
        ErrorProperties.IncludeStacktrace include = getErrorProperties().getIncludeStacktrace();
        if (include == ErrorProperties.IncludeStacktrace.ALWAYS) {
            return true;
        }
        if (include == ErrorProperties.IncludeStacktrace.ON_TRACE_PARAM) {
            return getTraceParameter(request);
        }
        return false;
    }

    /**
     * Provide access to the error properties.
     *
     * @return the error properties
     */
    protected ErrorProperties getErrorProperties() {
        return this.errorProperties;
    }

    public void logErrorInformation(HttpServletRequest request){
        HttpStatus status = getStatus(request);
        log.error("Access Error Attention, httpstatus name 【{}】 code 【{}】 url 【{}】, AEA请注意,请求响应发生异常!!!",
                status.name(), status.value(), null == request.getRequestURL() ? request.getRequestURI() : request.getRequestURL().toString());
        Map<String, Object> body = getErrorAttributes(request, isIncludeStackTrace(request, MediaType.ALL));
        if(NOT_FOUND.equals(status)){
            log.warn("请注意所访问URL【{}】发生404错误，资源地址不存在！", body.get("path"));
        }
        log.error("HTTP请求错误发生时的请求信息如下：$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        printErrorRequest(request);
        log.error("\r\n");
        log.error("HTTP请求错误发生后的响应信息如下：@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (Map.Entry<String, Object> entry : body.entrySet()) {
            log.error("Error body key 【{}】 value 【{}】", entry.getKey(), entry.getValue());
        }

    }

    public static void printErrorRequest(HttpServletRequest request){
        if (null != request.getCookies() && request.getCookies().length > 0) {
            for (int i = 0; i < request.getCookies().length; i++) {
                log.error("Cookie 名称【{}】 值【{}】", i, request.getCookies()[i]);
            }
        }
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String header = headerNames.nextElement();
            log.error("Header 参数【{}】 值【{}】", header, request.getHeader(header));
        }
        log.error("\r\n");
        Enumeration<String> parameterNames = request.getParameterNames();
        while (parameterNames.hasMoreElements()) {
            String parameter = parameterNames.nextElement();
            log.error("URL 参数【{}】 值 【{}】", parameter, request.getParameter(parameter));
        }
        log.error("\r\n");
        try {
            final String requestJsonString = GetJsonRequestUtil.getRequestJsonString(request);
            log.error("JSON 参数【{}】", requestJsonString);
        } catch (IOException e) {
        }

    }
}