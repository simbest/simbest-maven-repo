package com.simbest.boot.security.acl.config;

import com.simbest.boot.security.MySimpleGrantedAuthority;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.context.annotation.Bean;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.acls.AclPermissionEvaluator;
import org.springframework.security.acls.domain.AclAuthorizationStrategy;
import org.springframework.security.acls.domain.AclAuthorizationStrategyImpl;
import org.springframework.security.acls.domain.ConsoleAuditLogger;
import org.springframework.security.acls.domain.SpringCacheBasedAclCache;
import org.springframework.security.acls.jdbc.BasicLookupStrategy;
import org.springframework.security.acls.jdbc.JdbcMutableAclService;
import org.springframework.security.acls.jdbc.LookupStrategy;

import javax.sql.DataSource;

/**
 * Spring Security ACL（访问控制列表）配置类
 * 
 * 主要功能：
 * 1. 配置基于数据库的ACL服务
 * 2. 设置ACL缓存策略
 * 3. 配置权限评估和授权策略
 * 
 * 核心组件：
 * 1. JdbcMutableAclService - 提供ACL的数据库操作服务
 * 2. BasicLookupStrategy - 实现ACL权限查找策略
 * 3. SpringCacheBasedAclCache - 提供ACL信息的缓存支持
 * 4. AclAuthorizationStrategy - 实现ACL的授权策略
 * 
 * 使用说明：
 * 1. 需要配置数据源以支持数据库操作
 * 2. 通过@EnableGlobalMethodSecurity启用方法级安全
 * 3. 配合MethodSecurityConfig使用实现基于策略的ACL鉴权
 * 
 * 注意事项：
 * 1. 确保数据库中存在必要的ACL相关表
 * 2. 当前 @Configuration 已注释，本配置类未生效；启用前须先解决 identity query 的数据库方言问题（见第 4 条）
 * 3. 默认使用内存缓存，生产环境建议配置分布式缓存
 * 4. identity query（setClassIdentityQuery/setSidIdentityQuery）目前为 Oracle 序列方言，仅 Oracle 可用；
 *    启用前须按目标数据库调整——Oracle: SELECT XXX_SEQ.currval FROM dual；
 *    PostgreSQL: SELECT currval('XXX_SEQ')（PG 无 dual 表）；MySQL: SELECT LAST_INSERT_ID()
 */
@Slf4j
//@Configuration
public class ACLConfiguration {

    private final DataSource dataSource;

    public ACLConfiguration(@Qualifier("dataSource") DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * 配置ACL数据库服务
     * 用于管理ACL的创建、更新、删除等操作
     */
    @Bean
    public JdbcMutableAclService aclService() {
        JdbcMutableAclService jdbcMutableAclService = new JdbcMutableAclService(dataSource, lookupStrategy(), cache());
        // 以下 identity query 为 Oracle 序列方言，PostgreSQL/MySQL 下无法执行；
        // 启用本配置类前请按目标数据库调整（详见类注释注意事项第 4 条）
        jdbcMutableAclService.setClassIdentityQuery("SELECT ACL_CLASS_SEQ.currval FROM dual");
        jdbcMutableAclService.setSidIdentityQuery("SELECT ACL_SID_SEQ.currval FROM dual");
        return jdbcMutableAclService;
    }

    /**
     * 配置ACL查找策略
     * 用于在数据库中查找和加载ACL信息
     */
    @Bean
    public LookupStrategy lookupStrategy() {
        return new BasicLookupStrategy(dataSource, cache(), aclAuthorizationStrategy(), consoleAuditLogger());
    }

    /**
     * 配置ACL缓存
     * 使用内存缓存提高ACL查询性能
     */
    @Bean
    public SpringCacheBasedAclCache cache() {
        return new SpringCacheBasedAclCache(
                new ConcurrentMapCache("cache"),
                new BaseOnStrategyPermissionGranting(consoleAuditLogger()),
                aclAuthorizationStrategy()
        );
    }

    /**
     * 配置ACL授权策略
     * 定义ACL操作的权限控制规则
     */
    @Bean
    public AclAuthorizationStrategy aclAuthorizationStrategy() {
        return new AclAuthorizationStrategyImpl(new MySimpleGrantedAuthority("ADMIN"));
    }

    /**
     * 配置ACL审计日志
     * 记录ACL相关操作的审计信息
     */
    @Bean
    public ConsoleAuditLogger consoleAuditLogger() {
        return new ConsoleAuditLogger();
    }

    /**
     * 配置方法安全表达式处理器
     * 支持在方法级别使用ACL表达式进行权限控制
     */
    @Bean
    public MethodSecurityExpressionHandler defaultMethodSecurityExpressionHandler() {
        DefaultMethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
        AclPermissionEvaluator permissionEvaluator = new AclPermissionEvaluator(aclService());
        expressionHandler.setPermissionEvaluator(permissionEvaluator);
        return expressionHandler;
    }
}