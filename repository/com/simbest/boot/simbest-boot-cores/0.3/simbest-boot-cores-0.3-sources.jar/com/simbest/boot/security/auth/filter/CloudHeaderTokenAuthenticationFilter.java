package com.simbest.boot.security.auth.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.simbest.boot.base.exception.Exceptions;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth0.jwt.JWT;
import com.simbest.boot.constants.CloudAuthConstants;
import com.simbest.boot.security.IAuthService;
import com.simbest.boot.security.IUser;
import com.simbest.boot.security.util.AccessTokenUtils;
import com.simbest.boot.util.ApplicationContextProvider;
import com.simbest.boot.util.encrypt.RsaEncryptor;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CloudHeaderTokenAuthenticationFilter extends OncePerRequestFilter {

    /**
     * 创建匿名认证对象 用于在JWT令牌验证失败时设置匿名用户身份
     *
     * @return 匿名认证对象
     */
    private Authentication createAnonymousAuthentication() {
        List<SimpleGrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_ANONYMOUS"));
        return new AnonymousAuthenticationToken("anonymous", "anonymousUser", authorities);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String authHeader = request.getHeader(CloudAuthConstants.AUTHORIZATION);
        RsaEncryptor rsaEncryptor = ApplicationContextProvider.getBean(RsaEncryptor.class);
        if (authHeader != null && authHeader.startsWith(CloudAuthConstants.AUTHORIZATION_PREFIX)) {
            String token = authHeader.substring(7);
            // 这里调用 Token 验证逻辑
            boolean verifyResult = AccessTokenUtils.verifyAccessToken(token);
            log.debug("令牌验证结果: {}", verifyResult);
            // 如果验签成功，则返回一个OAuth2Authentication对象
            if (verifyResult) {
                String username = JWT.decode(token).getClaim(CloudAuthConstants.SUB).asString();
                username = rsaEncryptor.decrypt(username);
                log.debug("当前用户: {}", username);
                try {
                    // 标记是否需要执行后续的认证逻辑
                    boolean needAuthentication = true;
                    // 获取当前的安全上下文
                    Authentication existingAuth = SecurityContextHolder.getContext().getAuthentication();
                    if (existingAuth != null && existingAuth.isAuthenticated()
                            && existingAuth.getPrincipal() instanceof IUser) {
                        IUser existingUser = (IUser) existingAuth.getPrincipal();
                        if (existingUser.getUsername().equals(username)) {
                            log.debug("用户 {} 已经认证，不需要重新认证", username);
                            // 如果用户已经认证，跳过后续的会话清理和重新认证逻辑，但不返回，继续执行过滤器链
                            needAuthentication = false;
                        }
                    }

                    // 只有在需要认证时才执行后续的认证逻辑
                    if (needAuthentication) {
                        // 使用同步块确保会话操作的原子性
                        synchronized (this) {
                            // 获取用户信息
                            IAuthService authService = ApplicationContextProvider.getBean(IAuthService.class);
                            IUser user = authService.findByKey(username, IAuthService.KeyType.username);
                            if (user == null) {
                                log.error("找不到用户: {}", username);
                                SecurityContextHolder.getContext().setAuthentication(createAnonymousAuthentication());
                                // 如果找不到用户，跳过后续的会话清理和重新认证逻辑，但不返回，继续执行过滤器链
                            } else {
                                // 获取会话注册表
                                SessionRegistry sessionRegistry = ApplicationContextProvider
                                        .getBean(SessionRegistry.class);

                                // 先检查用户是否已经有活跃会话，如果有，使其失效
                                List<SessionInformation> sessions = sessionRegistry.getAllSessions(user, false);
                                log.warn("清理当前用户 {} 的会话数量: {}", username, sessions.size());

                                // 强制使所有会话失效
                                if (sessions.size() > 0) {
                                    for (SessionInformation sessionInfo : sessions) {
                                        try {
                                            String sessionId = sessionInfo.getSessionId();
                                            sessionInfo.expireNow();
                                            log.debug("已使会话失效: {}", sessionId);
                                        } catch (Exception e) {
                                            log.error("使会话失效时出错: {}", e.getMessage(), e);
                                        }
                                    }

                                    // 给系统一些时间来处理会话失效
                                    try {
                                        Thread.sleep(200);
                                    } catch (InterruptedException e) {
                                        Thread.currentThread().interrupt();
                                    }

                                    // 再次检查会话是否已清理
                                    sessions = sessionRegistry.getAllSessions(user, false);
                                    log.debug("清理后用户 {} 的会话数量: {}", username, sessions.size());
                                }

                                // 创建新的会话
                                HttpSession newSession = request.getSession(true);
                                log.debug("创建新会话: {}", newSession.getId());

                                // 使用可继承的线程本地策略，支持多线程环境
                                SecurityContextHolder
                                        .setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);

                                // 创建新的认证对象
                                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                                        user, username, user.getAuthorities());
                                authentication.setDetails(new WebAuthenticationDetails(request));

                                // 设置到安全上下文
                                SecurityContextHolder.getContext().setAuthentication(authentication);

                                // 将安全上下文保存到会话中
                                newSession.setAttribute("SPRING_SECURITY_CONTEXT", SecurityContextHolder.getContext());

                                // 注册会话
                                sessionRegistry.registerNewSession(newSession.getId(), user);

                                // 验证认证是否成功设置
                                Authentication currentAuth = SecurityContextHolder.getContext().getAuthentication();
                                if (currentAuth == null || !currentAuth.isAuthenticated()) {
                                    log.error("认证对象设置失败");
                                } else {
                                    log.debug("认证成功设置到安全上下文");
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error("处理认证时发生异常: {}", e.getMessage(), e);
                    SecurityContextHolder.clearContext();
                    SecurityContextHolder.getContext().setAuthentication(createAnonymousAuthentication());
                    // 如果处理认证时发生异常，也要继续执行过滤器链，不要中断请求
                }
            } else {
                // 如果Token验证失败，将当前会话置为匿名用户
                log.warn("无效的JWT令牌，将用户置为匿名访问状态");
                // 清除当前的认证信息
                SecurityContextHolder.clearContext();
                // 设置为匿名认证对象
                SecurityContextHolder.getContext().setAuthentication(createAnonymousAuthentication());
            }
        }

        try {
            filterChain.doFilter(request, response);
        } catch (Exception e) {
            log.error("过滤器链执行异常: {}", e.getMessage(), e);
            Exceptions.printException(e);
            throw e;
        }
    }

}