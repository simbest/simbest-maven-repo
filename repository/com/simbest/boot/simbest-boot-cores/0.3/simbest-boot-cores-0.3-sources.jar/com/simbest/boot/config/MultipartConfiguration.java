package com.simbest.boot.config;

import com.simbest.boot.base.exception.Exceptions;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.MultipartConfigElement;
import java.io.File;
import java.io.IOException;

/**
 * 文件上传配置类
 * 主要功能：
 * 1. 配置文件上传的临时目录，用于存储上传过程中的临时文件
 * 2. 临时目录位置由AppConfig中的uploadTmpFileLocation属性指定
 * 3. 如果临时目录不存在，会自动创建
 * 4. 支持大文件上传和多文件同时上传
 */
@Slf4j
@Configuration
public class MultipartConfiguration {
    
    /**
     * 应用配置，用于获取文件上传临时目录路径
     */
    @Autowired
    private AppConfig appConfig;

    /**
     * 配置文件上传的MultipartConfigElement
     * 主要设置文件上传的临时存储位置
     * 
     * @return MultipartConfigElement 文件上传配置对象
     */
    @Bean
    MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        //配置为用户部署目录下的指定临时目录
        String location = appConfig.getUploadTmpFileLocation();
        try {
            File tmpUploadDirectroy = new File(location);
            FileUtils.forceMkdir(tmpUploadDirectroy);
            log.debug("创建文件上传临时目录成功，临时路径地址：【{}】", tmpUploadDirectroy.getAbsolutePath());
        } catch (IOException e) {
            log.error("创建文件上传临时目录发生异常【{}】", e.getMessage());
            Exceptions.printException(e);
        }
        factory.setLocation(location);
        return factory.createMultipartConfig();
    }
}