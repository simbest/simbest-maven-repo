package com.simbest.boot.component.distributed.lock;

import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 分布式锁模板工厂
 * 
 * 功能说明：
 * 1. 工厂职责：
 *    - 创建分布式锁模板实例
 *    - 管理锁模板的生命周期
 *    - 确保锁模板的单例性
 * 
 * 2. 支持的锁模式：
 *    - SINGLE：单机模式，使用单个Redis实例
 *    - 预留其他模式扩展空间
 * 
 * 3. 配置方式：
 *    - 通过redisson.mode配置项指定锁模式
 *    - 支持Spring配置自动注入
 * 
 * 4. 实现特点：
 *    - 基于Redisson实现
 *    - 支持Spring容器管理
 *    - 懒加载模式创建实例
 */
@Slf4j
public class DistributedLockFactoryBean implements FactoryBean<DistributedLockTemplate> {

    /**
     * 锁实例模式
     * 当前支持SINGLE（单机模式）
     */
    private LockInstanceMode mode;

    /**
     * 分布式锁模板实例
     * 懒加载方式创建
     */
    private DistributedLockTemplate distributedLockTemplate;

    /**
     * Redisson客户端
     * 用于创建和管理分布式锁
     */
    @Autowired
    private RedissonClient redisson;

    /**
     * 获取分布式锁模板实例
     * 
     * 创建流程：
     * 1. 根据配置的模式创建对应的模板实例
     * 2. 目前仅支持SINGLE模式
     * 3. 确保单例模式
     *
     * @return 分布式锁模板实例
     * @throws Exception 创建过程中的异常
     */
    @Override
    public DistributedLockTemplate getObject() throws Exception {
        switch (mode) {
            case SINGLE:
                distributedLockTemplate = new SingleDistributedLockTemplate(redisson);
                break;
        }
        return distributedLockTemplate;
    }

    /**
     * 获取工厂创建的对象类型
     *
     * @return DistributedLockTemplate类
     */
    @Override
    public Class<?> getObjectType() {
        return DistributedLockTemplate.class;
    }

    /**
     * 指定工厂创建的对象是否为单例
     *
     * @return true-使用单例模式
     */
    @Override
    public boolean isSingleton() {
        return true;
    }

    /**
     * 设置锁实例模式
     * 
     * 配置规则：
     * 1. 不允许为空
     * 2. 必须是支持的模式（目前仅支持SINGLE）
     * 3. 大小写不敏感
     *
     * @param mode 锁实例模式（如：single）
     * @throws IllegalArgumentException 当mode为空或不支持的模式时抛出
     */
    public void setMode(String mode) {
        if (mode==null||mode.length()<=0||mode.equals("")) {
            throw new IllegalArgumentException("未找到redisson.mode配置项");
        }
        this.mode = LockInstanceMode.parse(mode);
        if (this.mode == null) {
            throw new IllegalArgumentException("不支持的分布式锁模式");
        }
    }

    /**
     * 锁实例模式枚举
     * 
     * 当前支持的模式：
     * - SINGLE：单机模式，使用单个Redis实例
     */
    private enum LockInstanceMode {
        SINGLE;

        /**
         * 解析模式字符串
         * 
         * @param name 模式名称（大小写不敏感）
         * @return 对应的模式枚举值，如果不支持则返回null
         */
        public static LockInstanceMode parse(String name) {
            for (LockInstanceMode modeIns : LockInstanceMode.values()) {
                if (modeIns.name().equals(name.toUpperCase())) {
                    return modeIns;
                }
            }
            return null;
        }
    }
}