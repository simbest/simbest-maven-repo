package com.simbest.boot.base.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 数据库实体中文名称注解
 * 用于标注实体类的中文名称，便于在系统中显示和管理
 * 该注解只能应用在类级别
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface EntityCnName {
    /**
     * 实体类的中文名称
     * @return 返回实体类的中文名称
     */
    String name();
}