package com.simbest.boot.security.acl.model;

import com.simbest.boot.base.annotations.EntityIdPrefix;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * ACL安全标识实体
 * 
 * 主要功能：
 * 1. 存储系统中的安全标识信息
 * 2. 支持两种类型的安全标识：
 *    - PrincipalSid: 基于用户的安全标识
 *    - GrantedAuthoritySid: 基于授权的安全标识
 * 
 * 数据结构：
 * 1. id: 唯一标识符
 * 2. principal: 是否为用户类型的安全标识
 * 3. sId: 安全标识的具体值（用户名或权限字符串）
 * 
 * 使用场景：
 * 1. 用户身份标识：存储实际用户的用户名
 * 2. 权限标识：存储角色或权限的字符串表示
 */
@Entity
@Table(name = "acl_sid", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"sid", "principal"})
})
@Data
public class ACLSId implements Serializable {

    /**
     * 主键ID
     * 使用雪花算法生成，前缀为AS
     */
    @Id
    @Column(name = "id", length = 40)
//    @SequenceGenerator(name = "ACL_SID_SEQ", sequenceName = "ACL_SID_SEQ")
//    @GeneratedValue(strategy = GenerationType.AUTO, generator = "ACL_SID_SEQ")
    @GeneratedValue(generator = "snowFlakeId")
    @GenericGenerator(name = "snowFlakeId", strategy = "com.simbest.boot.util.distribution.id.SnowflakeId")
    @EntityIdPrefix(prefix = "AS") //主键前缀，此为可选项注解
    private String id;

    /**
     * 是否为用户类型的安全标识
     * true表示PrincipalSid（用户标识）
     * false表示GrantedAuthoritySid（权限标识）
     */
    @Column(name = "principal", nullable = false)
    private boolean principal;

    /**
     * 安全标识的具体值
     * 如果principal为true，存储用户名
     * 如果principal为false，存储权限/角色名称
     */
    @Column(name = "sid", nullable = false)
    private String sId;

    /**
     * 判断是否为用户类型的安全标识
     * @return true表示是用户标识，false表示是权限标识
     */
    public boolean isPrincipal() {
        return principal;
    }

}