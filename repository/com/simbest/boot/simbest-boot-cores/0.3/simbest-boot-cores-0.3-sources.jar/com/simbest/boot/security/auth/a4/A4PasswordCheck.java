package com.simbest.boot.security.auth.a4;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.simbest.boot.base.web.response.JsonResponse.SUCCESS_CODE;

/**
 * 4A密码校验服务
 * 
 * 主要功能：
 * 1. 提供4A系统的密码校验服务
 * 2. 支持用户身份认证的集中管理
 * 3. 实现与4A系统的集成对接
 * 
 * 使用场景：
 * 1. 统一身份认证
 * 2. 单点登录集成
 * 3. 密码校验和管理
 */
@Slf4j
@Api(tags = {"4-安全认证", "4A密码校验"}, description = "提供4A系统的密码校验服务，支持用户身份认证的集中管理，实现与4A系统的集成对接，包括密码校验、令牌验证等功能")
@RestController
@RequestMapping(value = "/anonymous/cas")
public class A4PasswordCheck {

    /**
     * 从主数据查询用户信息的URL模板
     */
    public static final String URL_UUMS_GET_USER_INFO = "/action/user/user/findByUsername/sso?loginuser=%s&username=%s&appcode=%s";

    /**
     * 查询4A认证开关状态的URL
     */
    public static final String URL_A4_SWITCH = "/action/a4/a4switch/getA4switchValue/anonymous";

    /**
     * 4A密码校验的URL
     */
    public static final String URL_A4_CHECK_PASSWORD = "/action/a4/a4Password/loginCheckPass/anonymous";

    /**
     * 4A凭证校验的URL
     */
    public static final String URL_A4_TOKEN_SSON = "/action/a4/a4Ticket/checkA4Ticket/anonymous";

    /**
     * 4A认证标识参数名
     */
    public static final String PARAM_AUTH4A = "auth4A";

    /**
     * 4A认证Token参数名
     */
    public static final String PARAM_AUTH4A_TOKEN = "auth4AToken";

    /**
     * 4A账号ID参数名
     */
    public static final String PARAM_AUTH4A_ACCID = "auth4AAccid";

    /**
     * 需要4A认证的提示信息模板
     */
    public static final String A4_AUTH_NEED = "#################用户【%s】需要通过4A进行认证#################";

    /**
     * 不需要4A认证的提示信息模板
     */
    public static final String A4_AUTH_NO_NEED = "@@@@@@@@@@@@@@@@@@@用户【%s】不需要通过4A进行认证@@@@@@@@@@@@@@@@@@@";

    /**
     * 4A认证成功的提示信息模板
     */
    public static final String A4_AUTH_SUCCESS = "@@@@@@@@@@@@@@@@@@@通过4A认证方式用户【%s】通过密码【%s】访问【%s】时在4A校验密码成功";

    /**
     * 4A认证失败的提示信息模板
     */
    public static final String A4_AUTH_FAIL = "######################通过4A认证方式用户【%s】通过密码【%s】访问【%s】时在4A校验密码失败";

    /**
     * 4A认证异常的提示信息模板
     */
    public static final String A4_AUTH_EXCEPTION = "######################通过4A认证方式用户【%s】通过密码【%s】访问【%s】时在4A校验密码发生异常";

    /**
     * 应用配置信息
     */
    @Autowired
    private AppConfig appConfig;

    /**
     * RSA加密工具
     */
    @Autowired
    private RsaEncryptor rsaEncryptor;

    /**
     * 检查用户是否需要通过4A系统进行认证
     * 
     * @param username 用户名
     * @return true表示需要4A认证，false表示不需要
     */
    @ApiOperation(value = "检查是否应该通过4A验证", notes = "确定指定用户是否应该通过4A系统进行身份验证")
    public boolean shouldCheckFrom4A(@ApiParam(value = "用户名", required = true) String username) {
        Boolean shouldAuthFrom4A = HttpClient.post(appConfig.getUumsAddress()+URL_A4_SWITCH)
                .param("username", rsaEncryptor.encrypt(username))
                .asBean(Boolean.class);
        return shouldAuthFrom4A;
    }

    /**
     * 通过4A系统验证用户密码
     * 
     * @param username 明文账号
     * @param rsapassword RSA加密的密码
     * @param appCode 应用标识
     * @param noteKey 短信验证码（可选）
     * @return true表示验证通过，false表示验证失败
     * @throws BadCredentialsException 当4A认证失败时抛出
     */
    @ApiOperation(value = "通过4A验证密码", notes = "通过4A系统验证用户的密码凭证")
    public boolean passwordCheckFrom4A(
            @ApiParam(value = "用户名", required = true) String username,
            @ApiParam(value = "RSA加密的密码", required = true) String rsapassword,
            @ApiParam(value = "应用代码", required = true) String appCode,
            @ApiParam(value = "短信验证码", required = false) String noteKey) {
        JsonResponse jsonResponse = HttpClient.post(appConfig.getUumsAddress() + URL_A4_CHECK_PASSWORD)
                .param("username", rsaEncryptor.encrypt(username))
                .param("password", rsapassword)
                .param("appCode", appCode)
                .param("noteKey", noteKey)
                .asBean(JsonResponse.class);
        if(jsonResponse.getErrcode().equals(SUCCESS_CODE) && Boolean.valueOf(jsonResponse.getData().toString())) {
            return true;
        } else {
            log.error("用户【{}】访问【{}】通过4A认证失败", username, appCode);
            throw new BadCredentialsException("账号通过4A认证失败");
        }
    }
}