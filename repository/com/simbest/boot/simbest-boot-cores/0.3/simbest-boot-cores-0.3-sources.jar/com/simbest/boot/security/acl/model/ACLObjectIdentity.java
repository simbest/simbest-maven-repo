package com.simbest.boot.security.acl.model;

import com.simbest.boot.base.annotations.EntityIdPrefix;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * ACL对象身份实体
 * 
 * 主要功能：
 * 1. 存储需要进行访问控制的对象信息
 * 2. 维护对象的所有权和继承关系
 * 3. 支持基于对象层级的权限继承
 * 
 * 数据结构：
 * 1. id: 唯一标识符
 * 2. aclClass: 对象类型
 * 3. objectIdIdentity: 对象的业务主键
 * 4. parentObject: 父对象引用
 * 5. ownerSId: 对象拥有者
 * 6. entriesInheriting: 是否继承父对象权限
 * 
 * 权限继承示例：
 * 当用户对父对象有某权限，且子对象的entriesInheriting为true时，
 * 用户自动获得对子对象的相同权限。
 */
@Entity
@Table(name = "acl_object_identity", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"object_id_class", "object_id_identity"})
})
@Data
public class ACLObjectIdentity implements Serializable {

    /**
     * 主键ID
     * 使用雪花算法生成，前缀为AO
     */
    @Id
    @Column(name = "id", length = 40)
//    @SequenceGenerator(name = "ACL_OBJECT_IDENTITY_SEQ", sequenceName = "ACL_OBJECT_IDENTITY_SEQ")
//    @GeneratedValue(strategy = GenerationType.AUTO, generator = "ACL_OBJECT_IDENTITY_SEQ")
    @GeneratedValue(generator = "snowFlakeId")
    @GenericGenerator(name = "snowFlakeId", strategy = "com.simbest.boot.util.distribution.id.SnowflakeId")
    @EntityIdPrefix(prefix = "AO") //主键前缀，此为可选项注解
    private String id;

    /**
     * 对象类型
     * 关联acl_class表，标识受保护对象的类型
     */
    @ManyToOne
    @JoinColumn(name = "object_id_class", nullable = false)
    private ACLClass aclClass;

    /**
     * 对象的业务主键
     * 用于唯一标识业务对象
     */
    @Column(name = "object_id_identity", nullable = false)
    private String objectIdIdentity;

    /**
     * 父对象引用
     * 关联acl_object_identity表，用于构建对象层级关系
     */
    @ManyToOne
    @JoinColumn(name = "parent_object")
    private ACLObjectIdentity parentObject;

    /**
     * 对象拥有者
     * 关联acl_sid表，标识对象的所有者
     */
    @ManyToOne
    @JoinColumn(name = "owner_sid")
    private ACLSId ownerSId;

    /**
     * 是否继承父对象的权限
     * 当为true时，如果用户对父对象有某权限，则自动获得对本对象的相同权限
     */
    @Column(name = "entries_inheriting", nullable = false)
    private boolean entriesInheriting;

    /**
     * 获取是否继承父对象权限的标志
     * @return true表示继承父对象权限，false表示不继承
     */
    public boolean isEntriesInheriting() {
        return entriesInheriting;
    }

}