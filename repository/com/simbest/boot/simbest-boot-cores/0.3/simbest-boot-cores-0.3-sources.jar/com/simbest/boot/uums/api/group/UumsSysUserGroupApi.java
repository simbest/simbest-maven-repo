package com.simbest.boot.uums.api.group;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 系统用户群组管理API接口
 * 
 * 提供以下功能：
 * 1. 用户与群组关联关系的管理
 * 2. 支持批量创建群组用户
 * 3. 提供群组成员的查询功能
 * 4. 实现群组用户的删除操作
 * 5. 支持基于组织代码的群组用户管理
 * 6. 提供用户业务配置的关联管理
 * 7. 实现与UUMS系统的用户群组同步
 */
@SuppressWarnings("ALL")
@Component
@Slf4j
public class UumsSysUserGroupApi {

    private static final String USER_MAPPING = "/action/user/group/";

    private static final String SSO = "/sso";
    private static final String NEW_SSO = "sso/";

    @Autowired
    private AppConfig config;


    @Autowired
    private RsaEncryptor encryptor;

    /**
     * 新增人员群组信息
     *
     * @param username
     * @param groupId
     * @param appcode
     * @return
     */
    public JsonResponse create(String username, String groupId, String appcode) {
        Map sysUserGorupmap = new LinkedHashMap<>();
        sysUserGorupmap.put("username", username);
        sysUserGorupmap.put("groupId", groupId);

        String loginUser = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by loginUser: {}", loginUser);
        String json0 = JacksonUtils.obj2json(sysUserGorupmap);
        String username1 = encryptor.encrypt(loginUser);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "create" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode)
                .json(json0)
                .asBean(JsonResponse.class);
        return response;
    }

    public JsonResponse findByGroupId(String sid) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findByGroupId" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .param("sid", sid)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 根据群组人员关联表中的ID删除关联信息
     *
     * @param sysUserGroup
     * @return
     */
    public JsonResponse delete(Map sysUserGroup) {
        String loginUser = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by loginUser: {}", loginUser);
        String json0 = JacksonUtils.obj2json(sysUserGroup);
        String username1 = encryptor.encrypt(loginUser);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + NEW_SSO + "deleteById" + "?loginuser=" + username2 + "&appcode=" + config.getAppcode())
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    public JsonResponse createGroupUsers(String groupSid, String orgCodes, String groupSids, String usernames, String userBussinessConfig) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "createGroupUsers" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .param("groupSid", groupSid)
                .param("orgCodes", orgCodes)
                .param("groupSids", groupSids)
                .param("usernames", usernames)
                .param("userBussinessConfig", userBussinessConfig)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    public JsonResponse deleteById(String id) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + NEW_SSO + "deleteById")
                .param("id", id)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }
}