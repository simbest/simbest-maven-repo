package com.simbest.boot.base.repository;

import static com.simbest.boot.constants.ApplicationConstants.ONE;
import static com.simbest.boot.constants.ApplicationConstants.ZERO;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.Table;
import javax.persistence.TypedQuery;
import javax.persistence.UniqueConstraint;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.JpaEntityInformationSupport;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.google.common.base.CaseFormat;
import com.google.common.collect.Lists;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.util.ObjectUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 逻辑删除仓库实现类
 * LogicRepository接口的具体实现，提供业务实体的数据持久层操作：
 * - 继承Spring Data JPA的SimpleJpaRepository，扩展其基础功能
 * - 实现LogicRepository接口，支持基于removedTime字段的逻辑删除
 * - 重写所有查询方法，自动过滤已被逻辑删除的记录
 * - 提供即时逻辑删除和计划逻辑删除功能
 * - 实现自动设置修改人和修改时间的功能
 *
 * @param <T> 实体类型
 * @param <ID> 实体ID类型
 */
@Slf4j
public class LogicDeleteRepositoryImpl <T, ID extends Serializable> extends SimpleJpaRepository<T, ID>
        implements LogicRepository<T, ID> {

    /**
     * JPA实体信息，用于获取实体元数据
     */
    private final JpaEntityInformation<T, ?> entityInformation;
    
    /**
     * JPA实体管理器，用于执行持久化操作
     */
    private final EntityManager em;
    
    /**
     * 实体类型
     */
    private final Class<T> domainClass;
    
    /**
     * 逻辑删除时间字段名
     */
    private static final String DELETED_FIELD = "removedTime";
    
    /**
     * 修改人字段名
     */
    private static final String MODIFIER_FIELD = "modifier";
    
    /**
     * 修改时间字段名
     */
    private static final String MODIFIEDTIME_FIELD = "modifiedTime";
    
    /**
     * 启用状态字段名
     */
    private static final String ENABLED_FIELD = "enabled";
    
    /**
     * 表示不存在ID的值
     */
    private static final Object NOT_EXIST_ID_VALUE = null;

    /**
     * 构造函数
     * 
     * @param domainClass 实体类型
     * @param em JPA实体管理器
     */
    public LogicDeleteRepositoryImpl(Class<T> domainClass, EntityManager em) {
        super(domainClass, em);
        this.em = em;
        this.domainClass = domainClass;
        this.entityInformation = JpaEntityInformationSupport.getEntityInformation(domainClass, em);
    }

    /**
     * 统计所有未逻辑删除的记录数量
     * 
     * @return 活跃记录数量
     */
    @Override
    public long countActive() {
        return super.count(notDeleted());
    }

    /**
     * 根据条件统计未逻辑删除的记录数量
     * 
     * @param conditions 查询条件
     * @return 符合条件的活跃记录数量
     */
    @Override
    public long countActive(Specification<T> conditions){
        return super.count(conditions.and(notDeleted()));
    }

    /**
     * 判断指定ID的记录是否存在且未被逻辑删除
     * 
     * @param id 记录ID
     * @return 是否存在且活跃
     */
    @Override
    public boolean existsActive(ID id) {
        Assert.notNull(id, "实体ID不能为空");
        return findOneActive(id) != null ? true : false;
    }

    /**
     * 根据ID查询未逻辑删除的记录
     * 
     * @param id 记录ID
     * @return 活跃的记录对象
     */
    @Override
    public T findByIdActive(ID id) {
        return findOneActive(id);
    }

    /**
     * 根据ID查询未逻辑删除的记录
     * 
     * @param id 记录ID
     * @return 活跃的记录对象
     */
    @Override
    public T findOneActive(ID id) {
        return super.findOne(Specification.where(new ByIdSpecification<T, ID>(entityInformation, id)).and(notDeleted())).orElse(null);
    }

    /**
     * 根据条件查询单个未逻辑删除的记录
     * 
     * @param conditions 查询条件
     * @return 符合条件的单个活跃记录
     * @throws IncorrectResultSizeDataAccessException 当结果集大小不为1时抛出
     */
    @Override
    public T findOneActive(Specification<T> conditions) {
        List<T> list = super.findAll(conditions.and(notDeleted()));
        if(list.size() > ONE){
            throw new IncorrectResultSizeDataAccessException(ONE);
        }
        return list.isEmpty() ? null : list.get(ZERO);
    }

    @Override
    public Page<T> findAllActive() {
        return super.findAll(notDeleted(), PageRequest.of(ApplicationConstants.DEFAULT_PAGE, ApplicationConstants.DEFAULT_SIZE));
    }

    @Override
    public Page<T> findAllActive(Sort sort) {
        return super.findAll(notDeleted(), PageRequest.of(ApplicationConstants.DEFAULT_PAGE, ApplicationConstants.DEFAULT_SIZE, sort));
    }

    @Override
    public Page<T> findAllActive(Pageable pageable) {
        return super.findAll(notDeleted(), pageable);
    }

    @Override
    public List<T> findAllActiveNoPage() {
        return super.findAll(notDeleted());
    }

    @Override
    public List<T> findAllActiveNoPage(Sort sort) {
        return super.findAll(notDeleted(), sort);
    }

    @Override
    public List<T> findAllActive(Iterable<ID> ids) {
        if (ids == null || !ids.iterator().hasNext())
            return Collections.emptyList();
        if (entityInformation.hasCompositeId()) {
            List<T> results = new ArrayList<T>();
            for (ID id : ids)
                results.add(findOneActive(id));
            return results;
        }
        ByIdsSpecification<T> specification = new ByIdsSpecification<T>(entityInformation);
        TypedQuery<T> query = getQuery(Specification.where(specification).and(notDeleted()), Sort.unsorted());
        return query.setParameter(specification.parameter, ids).getResultList();
    }

    @Override
    public List<T> findAllActive(Specification<T> conditions) {
        return super.findAll(conditions.and(notDeleted()));
    }

    @Override
    public List<T> findAllActive(Specification<T> conditions, Sort sort) {
        return super.findAll(conditions.and(notDeleted()), sort);
    }

    @Override
    public Page<T> findAllActive(Specification<T> conditions, Pageable pageable) {
        return super.findAll(conditions.and(notDeleted()), pageable);
    }

    @Override
    @Transactional
    @SuppressWarnings("unchecked")
    public <S extends T> S save(S entity) {
        Set<ConstraintViolation<S>> constraintViolations = Validation.buildDefaultValidatorFactory().getValidator()
                .validate(entity);
        if (constraintViolations.size() > 0)
            throw new ConstraintViolationException(constraintViolations.toString(), constraintViolations);
        Class<?> entityClass = entity.getClass();
        CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Object> criteriaQuery = criteriaBuilder.createQuery();
        Root<?> root = criteriaQuery.from(entityClass);
        List<Predicate> predicates = new ArrayList<Predicate>();


        //判断是否有联合主键，通过联合主键能够查询数据result，则将现有实体entity的值拷贝至result，对result进行更新操作
        if (entityInformation.hasCompositeId()) {
            for (String s : entityInformation.getIdAttributeNames())
                predicates.add(criteriaBuilder.equal(root.<ID>get(s),
                        entityInformation.getCompositeIdAttributeValue(entityInformation.getId(entity), s)));
            //无论是逻辑删除，还是物理删除，联合主键都必须满足唯一性
//            predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get(DELETED_FIELD), LocalDateTime.now()));
            criteriaQuery.select(root).where(predicates.toArray(new Predicate[predicates.size()]));
            TypedQuery<Object> typedQuery = em.createQuery(criteriaQuery);
            List<Object> resultSet = typedQuery.getResultList();
            if (resultSet.size() > 0) {
                S result = (S) resultSet.get(0);
                log.debug("对象具有联合主键，即将更新对象【{}】", ToStringBuilder.reflectionToString(result));
                BeanUtils.copyProperties(entity, result, getNullPropertyNames(entity));
                result = super.save(result);
                log.debug("对象具有联合主键，更新对象后为【{}】", ToStringBuilder.reflectionToString(result));
                return result;
            }
        }
        //判断是否有联合索引，通过联合索引能够查询数据result，则将现有实体entity的值拷贝至result，对result进行更新操作
        if (entity.getClass().isAnnotationPresent(Table.class)) {
            Annotation a = entity.getClass().getAnnotation(Table.class);
            try {
                UniqueConstraint[] uniqueConstraints = (UniqueConstraint[]) a.annotationType()
                        .getMethod("uniqueConstraints").invoke(a);
                if (uniqueConstraints != null) {
                    for (UniqueConstraint uniqueConstraint : uniqueConstraints) {
                        Map<String, Object> uniqueConstraintNames = new HashMap<>();
                        for (String name : uniqueConstraint.columnNames()) {
                            //name = CaseFormat.LOWER_UNDERSCORE.to( CaseFormat.LOWER_CAMEL, name );
                            //name = CaseFormat.LOWER_CAMEL.to(CaseFormat.UPPER_CAMEL, name);
                            PropertyDescriptor pd = new PropertyDescriptor(name, entityClass);
                            Object value = pd.getReadMethod().invoke(entity);
                            if (value == null) {
                                //联合索引，一个属性如果为空，曾不做联合索引约束，即可重复插入（数据库底层的约定）
                                uniqueConstraintNames.clear();
                                break;
                            }
                            uniqueConstraintNames.put(name, value);
                        }
                        if (!uniqueConstraintNames.isEmpty()) {
                            for (Map.Entry<String, Object> entry : uniqueConstraintNames.entrySet()) {
                                predicates.add(criteriaBuilder.equal(root.get(entry.getKey()), entry.getValue()));
                            }
                        }
                    }
                    //联合索引，一个属性如果为空，曾不做联合索引约束，即可重复插入（数据库底层的约定）
                    if (predicates.isEmpty()) {
                        return super.save(entity);
                    }
                    //无论是逻辑删除，还是物理删除，联合索引都必须满足唯一性
//                    predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get(DELETED_FIELD), LocalDateTime.now()));
                    criteriaQuery.select(root).where(predicates.toArray(new Predicate[predicates.size()]));
                    TypedQuery<Object> typedQuery = em.createQuery(criteriaQuery);
                    List<Object> resultSet = typedQuery.getResultList();
                    if (resultSet.size() > 0) {
                        S result = (S) resultSet.get(0);
                        log.debug("对象具有联合索引，即将更新对象【{}】", ToStringBuilder.reflectionToString(result));
                        BeanUtils.copyProperties(entity,
                                result, Stream
                                        .concat(Arrays.stream(getNullPropertyNames(entity)),
                                                Arrays.stream(
                                                        new String[] { entityInformation.getIdAttribute().getName() }))
                                        .toArray(String[]::new));
                        result = super.save(result);
                        log.debug("对象具有联合索引，更新对象后为【{}】", ToStringBuilder.reflectionToString(result));
                        return result;
                    }
                }
            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
                    | NoSuchMethodException | SecurityException | IntrospectionException e) {
                e.printStackTrace();
            }
        }
        //没有联合主键、没有联合索引，直接保存
        log.debug("对象没有联合索引和联合主键，即将更新对象【{}】", ToStringBuilder.reflectionToString(entity));
        entity = super.save(entity);
        log.debug("对象没有联合索引和联合主键，更新对象后为【{}】", ToStringBuilder.reflectionToString(entity));
        return entity;
    }


    @Override
    @Transactional
    public <S extends T> S saveAndFlush(S entity) {
        S result = this.save(entity);
        flush();
        return result;
    }

    @Override
    @Transactional
    public <S extends T> List<S> saveAll(Iterable<S> entities) {
        List<S> result = new ArrayList<S>();
        if (entities == null) {
            return result;
        }
        for (S entity : entities) {
            //超类SimpleJpaRepository同样具有upsert的功能，即会向上面的save检查联合主键和联合索引
            result.add(super.save(entity));
        }
        return result;
    }

    public static String[] getNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        PropertyDescriptor[] pds = src.getPropertyDescriptors();

        Set<String> propertyNames = new HashSet<String>();
        for (PropertyDescriptor pd : pds)
            if (!pd.getName().equals(DELETED_FIELD) && src.getPropertyValue(pd.getName()) == null)
                propertyNames.add(pd.getName());

        return propertyNames.toArray(new String[propertyNames.size()]);
    }

    @Override
    @Transactional
    public void logicDelete(ID id) {
        Assert.notNull(id, "The given id must not be null!");
        logicDelete(id, LocalDateTime.now());
    }

    @Override
    @Transactional
    public void logicDelete(T entity) {
        Assert.notNull(entity, "The entity must not be null!");
        logicDelete(entity, LocalDateTime.now());
    }

    @Override
    @Transactional
    public void logicDelete(Iterable<? extends T> entities) {
        Assert.notNull(entities, "The given Iterable of entities not be null!");
        for (T entity : entities) {
            logicDelete(entity);
        }
    }

    @Override
    @Transactional
    public void logicDeleteAll() {
        for (T entity : findAllActive()) {
            logicDelete(entity);
        }
    }

    @Override
    public void deleteAllByIds(Iterable<? extends ID> ids) {
        for(ID id: ids) {
            logicDelete(id);
        }
    }


    @Override
    @Transactional
    public void scheduleLogicDelete(ID id, LocalDateTime localDateTime) {
        logicDelete(id, localDateTime);
    }

    @Override
    @Transactional
    public void scheduleLogicDelete(T entity, LocalDateTime localDateTime) {
        logicDelete(entity, localDateTime);
    }

    private void logicDelete(ID id, LocalDateTime localDateTime) {
        Assert.notNull(id, "The given id must not be null!");

        T entity = findOneActive(id);

        if (entity == null)
            throw new EmptyResultDataAccessException(
                    String.format("No %s entity with id %s exists!", entityInformation.getJavaType(), id), 1);

        logicDelete(entity, localDateTime);
    }

    private void logicDelete(T entity, LocalDateTime localDateTime) {
        Assert.notNull(entity, "The entity must not be null!");

        CriteriaBuilder cb = em.getCriteriaBuilder();

        CriteriaUpdate<T> update = cb.createCriteriaUpdate((Class<T>) domainClass);

        Root<T> root = update.from((Class<T>) domainClass);

        update.set(DELETED_FIELD, localDateTime); //设置删除时间
        Map<String, Object> params = ObjectUtil.getEntityPersistentFieldValueExceptId(entity);
        update.set(MODIFIER_FIELD, params.get(MODIFIER_FIELD)); //设置删除人
        update.set(MODIFIEDTIME_FIELD, localDateTime);
        update.set(ENABLED_FIELD, false); //删除数据后，设置为不可用

        final List<Predicate> predicates = new ArrayList<Predicate>();

        if (entityInformation.hasCompositeId()) {
            for (String s : entityInformation.getIdAttributeNames())
                predicates.add(cb.equal(root.<ID>get(s),
                        entityInformation.getCompositeIdAttributeValue(entityInformation.getId(entity), s)));
            update.where(cb.and(predicates.toArray(new Predicate[predicates.size()])));
        } else if(null != entityInformation.getId(entity)) {
            update.where(cb.equal(root.<ID>get(entityInformation.getIdAttribute().getName()),
                    entityInformation.getId(entity)));
        } else {
            List<Predicate> predicateList = Lists.newArrayList();
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                //删除人和可用性字段不作为参数
                if(!MODIFIER_FIELD.equals(entry.getKey()) && !ENABLED_FIELD.equals(entry.getKey())) {
                    predicateList.add(cb.equal(root.get(entry.getKey()), entry.getValue()));
                }
            }
            if(!predicateList.isEmpty()){
                update.where(predicateList.toArray(new Predicate[]{}));
            } else{
                //无条件不允许删除
                update.where(cb.equal(root.<ID>get(entityInformation.getIdAttribute().getName()), NOT_EXIST_ID_VALUE));
            }
        }

        em.createQuery(update).executeUpdate();
    }

    /**
     * 创建未被逻辑删除的规范查询条件
     * <p>根据不同的业务需求，返回对应的查询条件</p>
     * 
     * @param <T> 实体类型
     * @return 未删除的规范查询条件
     */
    private static final <T> Specification<T> notDeleted() {
        return Specification.where(new DeletedIsNull<T>()).or(new DeletedTimeGreatherThanNow<T>());
    }

    /**
     * 根据ID构建的规范查询条件
     * 
     * @param <T> 实体类型
     * @param <ID> ID类型
     */
    private static final class ByIdSpecification<T, ID extends Serializable> implements Specification<T> {

        private final JpaEntityInformation<T, ?> entityInformation;
        private final ID id;

        public ByIdSpecification(JpaEntityInformation<T, ?> entityInformation, ID id) {
            this.entityInformation = entityInformation;
            this.id = id;
        }

        @Override
        public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
            final List<Predicate> predicates = new ArrayList<Predicate>();
            if (entityInformation.hasCompositeId()) {
                for (String s : entityInformation.getIdAttributeNames())
                    predicates.add(cb.equal(root.<ID>get(s), entityInformation.getCompositeIdAttributeValue(id, s)));

                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            }
            return cb.equal(root.<ID>get(entityInformation.getIdAttribute().getName()), id);
        }
    }

    /**
     * 根据ID集合构建的规范查询条件
     * 
     * @param <T> 实体类型
     */
    @SuppressWarnings("rawtypes")
    private static final class ByIdsSpecification<T> implements Specification<T> {

        private final JpaEntityInformation<T, ?> entityInformation;

        ParameterExpression<Iterable> parameter;

        public ByIdsSpecification(JpaEntityInformation<T, ?> entityInformation) {
            this.entityInformation = entityInformation;
        }

        @Override
        public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
            Path<?> path = root.get(entityInformation.getIdAttribute());
            parameter = cb.parameter(Iterable.class);
            return path.in(parameter);
        }
    }

    /**
     * 检查removedTime字段为空的规范查询条件
     * <p>用于过滤未被逻辑删除的记录</p>
     */
    private static final class DeletedIsNull<T> implements Specification<T> {
        @Override
        public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
            return cb.isNull(root.get(DELETED_FIELD));
        }
    }

    /**
     * 检查removedTime字段大于当前时间的规范查询条件
     * <p>用于实现计划逻辑删除</p>
     */
    private static final class DeletedTimeGreatherThanNow<T> implements Specification<T> {
        @Override
        public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
            return cb.greaterThan(root.get(DELETED_FIELD), LocalDateTime.now());
        }
    }

    public static void main ( String[] args ) {
        System.out.println(  CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL,"permission_code") );
        System.out.println(  CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL,"permissionCode") );
    }
}