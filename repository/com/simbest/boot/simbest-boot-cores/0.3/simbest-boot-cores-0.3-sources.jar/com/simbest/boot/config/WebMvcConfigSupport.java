package com.simbest.boot.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.simbest.boot.component.converter.StringToDateConverter;
import com.simbest.boot.constants.ApplicationConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.HttpMethod;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.resource.ContentVersionStrategy;
import org.springframework.web.servlet.resource.VersionResourceResolver;

import java.util.List;

import static org.springframework.web.cors.CorsConfiguration.ALL;

/**
 * Spring MVC全局配置类
 * 
 * 主要功能：
 * 1. 配置HTTP消息转换器，统一使用Jackson进行JSON处理
 * 2. 添加自定义的类型转换器，如String到Date的转换
 * 3. 配置跨域访问(CORS)支持
 * 4. 配置静态资源处理和缓存策略
 * 
 * 配置说明：
 * 1. JSON处理：使用统一配置的ObjectMapper，确保JSON序列化的一致性
 * 2. 类型转换：支持自定义日期格式的转换
 * 3. 跨域配置：支持配置允许的源、方法和头部信息
 * 4. 静态资源：
 *    - 支持版本化的资源管理，通过内容哈希实现
 *    - 配置多种静态资源路径，包括CSS、JS、图片等
 *    - 支持Swagger UI资源访问
 *    - 可通过Nginx实现更细粒度的缓存控制
 * 
 * 缓存策略：
 * 1. 默认禁用浏览器缓存(cachePeriod=-1)
 * 2. 使用ContentVersionStrategy进行资源版本管理
 * 3. 建议在生产环境通过Nginx配置静态资源缓存：
 *    location ~* \.(gif|jpg|jpeg|bmp|png|ico|js|css)$ {
 *        root static;
 *        expires 30d;
 *    }
 */
@Configuration
public class WebMvcConfigSupport extends WebMvcConfigurationSupport {

    @Autowired
    private AppConfig appConfig;

    /**
     * 使用统一配置的Jackson ObjectMapper进行JSON处理
     */
    @Autowired
    private ObjectMapper objectMapper;

    @Bean
    public MappingJackson2HttpMessageConverter customJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
        jsonConverter.setObjectMapper(objectMapper);
        return jsonConverter;
    }

    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        converters.add(customJackson2HttpMessageConverter());
        super.addDefaultHttpMessageConverters(converters);
    }

    /**
     * 配置自定义类型转换器
     * - 主要用于处理表单参数到Java对象的转换
     * - 当前支持String到Date类型的自定义转换
     */
    @Override
    protected void addFormatters(FormatterRegistry registry) {
        registry.addConverter(new StringToDateConverter());
    }

    /**
     * 配置跨域资源共享(CORS)
     * - 支持配置允许的源、HTTP方法和请求头
     * - 允许携带认证信息（cookies等）
     * - 预检请求缓存时间为1小时
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins(StringUtils.split(appConfig.getAllowedOrigins(), ApplicationConstants.COMMA))
                .allowedMethods(HttpMethod.OPTIONS.name(), HttpMethod.GET.name(), HttpMethod.POST.name())
                .allowedHeaders(ALL)
                .allowCredentials(true)
                .maxAge(3600);
    }

    /**
     * 配置静态资源处理
     * 
     * 主要特性：
     * 1. 支持资源版本化，通过内容哈希自动更新资源路径
     * 2. 配置多种静态资源路径映射
     * 3. 支持Swagger UI资源访问
     * 4. 默认禁用浏览器缓存，建议通过Nginx实现缓存控制
     * 
     * 资源路径说明：
     * - /css/**：样式文件
     * - /js/**：JavaScript文件
     * - /html/**：HTML文件
     * - /fonts/**：字体文件
     * - /img/**, /images/**：图片资源
     * - swagger-ui.html：Swagger UI界面
     * - /webjars/**：Web依赖库
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        VersionResourceResolver versionResourceResolver = new VersionResourceResolver()
                .addVersionStrategy(new ContentVersionStrategy(), "/**");

        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");

        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");

        registry.addResourceHandler("/css/**").addResourceLocations("classpath:/static/css/")
                .setCachePeriod(-1).resourceChain(true).addResolver(versionResourceResolver);

        registry.addResourceHandler("/js/**").addResourceLocations("classpath:/static/js/")
                .setCachePeriod(-1).resourceChain(true).addResolver(versionResourceResolver);

        registry.addResourceHandler("/html/**").addResourceLocations("classpath:/static/html/")
                .setCachePeriod(-1).resourceChain(true).addResolver(versionResourceResolver);

        registry.addResourceHandler("/fonts/**").addResourceLocations("classpath:/static/fonts/")
                .setCachePeriod(-1).resourceChain(true).addResolver(versionResourceResolver);

        registry.addResourceHandler("/img/**", "/images/**", "/favicon.ico")
                .addResourceLocations("classpath:/static/img/", "classpath:/static/images/")
                .setCachePeriod(-1).resourceChain(true).addResolver(versionResourceResolver);

        registry.addResourceHandler("/**").addResourceLocations("classpath:/static/", "classpath:/public/")
                .setCachePeriod(-1).resourceChain(true).addResolver(versionResourceResolver);

        super.addResourceHandlers(registry);
    }
}