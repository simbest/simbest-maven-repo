package com.simbest.boot.base.web.controller;

import com.simbest.boot.base.model.SystemModel;
import com.simbest.boot.base.service.ISystemService;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * 系统实体控制器基类
 * 
 * 主要功能：
 * 1. 继承GenericController，具备通用实体的基础操作能力
 * 2. 适用于系统级基础实体的管理
 * 3. 提供创建时间和修改时间的自动维护
 * 4. 作为业务实体控制器的基础类
 * 5. 统一的响应格式和异常处理
 * 6. 完整的Swagger接口文档
 * 7. 可被其他系统控制器继承复用
 *
 * @param <T> 系统实体类型，必须继承自SystemModel
 * @param <PK> 主键类型，必须实现Serializable接口
 */
@Slf4j
public class SystemController<T extends SystemModel, PK extends Serializable> extends GenericController<T, PK>{

    /**
     * 系统实体服务接口，提供系统级实体的业务逻辑处理功能
     */
    private ISystemService<T, PK> service;

    /**
     * 构造函数，注入系统实体服务接口
     *
     * @param service 系统实体服务接口实现
     */
    public SystemController(ISystemService<T, PK> service) {
        super(service);
        this.service = service;
    }



}