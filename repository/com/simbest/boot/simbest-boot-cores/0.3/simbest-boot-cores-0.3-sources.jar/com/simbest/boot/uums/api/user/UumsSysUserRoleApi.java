package com.simbest.boot.uums.api.user;

import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @version <strong>V1.0.0</strong><br>
 */
@Component
@Slf4j
@SuppressWarnings("All")
public class UumsSysUserRoleApi {

    private static final String USER_MAPPING = "/action/user/role/";

    private static final String SSO = "/sso";

    @Autowired
    private AppConfig config;
    //private String uumsAddress="http://localhost:8080/uums";

    @Autowired
    private RsaEncryptor encryptor;

    /**
     * 更新应用下的角色里的人
     * @param mapParam
     * @param appcode
     * @return
     */
    public Integer updateRoleUser( Map<String,Object> mapParam,String appcode){
        String loginUser = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", loginUser);
        String json0=JacksonUtils.obj2json(mapParam);
        String username1=encryptor.encrypt(loginUser);
        String username2=username1.replace("+","%2B");
        JsonResponse response= HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "updateRoleUser"+SSO+"?loginuser="+username2+"&appcode="+appcode)
                .json( json0 )
                .asBean(JsonResponse.class );
        if(response==null){
            log.error("--response对象为空!--");
            return 0;
        }
        Double returnParam = null;
        try{
            returnParam = (Double)response.getData();
        }catch ( Exception e ){
            Exceptions.printException( e );
            return 0;
        }
        if(returnParam==null){
            return 0;
        }
        return returnParam.intValue();
    }

    /**
     * 删除用户角色信息
     * @param id
     * @return
     */
    public JsonResponse deleteByIdCustom(String id) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING +SSO+ "/deleteByIdCustom")
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,config.getAppcode())
                .param("id",id)
                .asBean(JsonResponse.class);
        if(response == null){
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 指定角色新增人员
     * @param roleId
     * @param usernames
     * @return
     */
    public JsonResponse createRoleUsers(String roleId,String usernames) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "createRoleUsers"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,config.getAppcode())
                .param("roleId",roleId)
                .param("usernames",usernames)
                .asBean(JsonResponse.class);
        if(response == null){
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }
}