package com.simbest.boot.base.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 数据库实体主键前缀注解
 * 用于标注实体类主键字段的前缀标识
 * 该注解只能应用在字段级别
 * 主要用于生成业务主键时添加前缀标识
 */
@Retention(RetentionPolicy.RUNTIME)
@Target( { ElementType.FIELD })
public @interface EntityIdPrefix {
    /**
     * 主键字段的前缀标识
     * @return 返回主键字段的前缀标识
     */
    String prefix();
}