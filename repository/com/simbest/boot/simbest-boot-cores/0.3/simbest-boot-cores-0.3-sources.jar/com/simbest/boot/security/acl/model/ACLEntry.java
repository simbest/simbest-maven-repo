package com.simbest.boot.security.acl.model;

import com.simbest.boot.base.annotations.EntityIdPrefix;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * ACL访问控制条目实体
 * 
 * 主要功能：
 * 1. 存储具体的权限信息
 * 2. 定义主体(Sid)对特定对象的访问权限
 * 3. 支持权限的顺序控制和审计功能
 * 
 * 权限掩码说明（来自BasePermission）：
 * - READ(1): 读取权限
 * - WRITE(2): 写入权限
 * - CREATE(4): 创建权限
 * - DELETE(8): 删除权限
 * - ADMINISTRATION(16): 管理权限
 * 
 * 数据结构：
 * 1. id: 唯一标识符
 * 2. aclObjectIdentity: 关联的ACL对象身份
 * 3. aceOrder: 权限条目的优先顺序
 * 4. aclsId: 安全标识（主体）
 * 5. mask: 权限掩码
 * 6. granting: 是否授予权限
 * 7. auditSuccess/auditFailure: 审计标志
 */
@Entity
@Table(name = "acl_entry", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"acl_object_identity", "ace_order"})
})
@Data
public class ACLEntry {

    /**
     * 主键ID
     * 使用雪花算法生成，前缀为AE
     */
    @Id
    @Column(name = "id", length = 40)
    @GeneratedValue(generator = "snowFlakeId")
    @GenericGenerator(name = "snowFlakeId", strategy = "com.simbest.boot.util.distribution.id.SnowflakeId")
    @EntityIdPrefix(prefix = "AE")
    private String id;

    /**
     * ACL对象身份
     * 表示该权限条目所关联的受保护对象
     */
    @ManyToOne
    @JoinColumn(name = "acl_object_identity", nullable = false)
    private ACLObjectIdentity aclObjectIdentity;

    /**
     * 权限条目的顺序
     * 数值越小优先级越高，用于控制权限判断的顺序
     */
    @Column(name = "ace_order", nullable = false)
    private int aceOrder;

    /**
     * 安全标识（主体）
     * 表示权限的所有者（用户或角色）
     */
    @ManyToOne
    @JoinColumn(name = "sid", nullable = false)
    private ACLSId aclsId;

    /**
     * 权限掩码
     * 使用位运算表示不同的权限组合
     */
    @Column(name = "mask", nullable = false)
    private int mask;

    /**
     * 是否授予权限
     * true表示授予权限，false表示拒绝权限
     */
    @Column(name = "granting", nullable = false)
    private boolean granting;

    /**
     * 是否记录授权成功的审计日志
     */
    @Column(name = "audit_success", nullable = false)
    private boolean auditSuccess;

    /**
     * 是否记录授权失败的审计日志
     */
    @Column(name = "audit_failure", nullable = false)
    private boolean auditFailure;

    /**
     * 获取是否授予权限
     * @return true表示授予权限，false表示拒绝权限
     */
    public boolean isGranting() {
        return granting;
    }

    /**
     * 获取是否记录授权成功的审计日志
     * @return true表示记录，false表示不记录
     */
    public boolean isAuditSuccess() {
        return auditSuccess;
    }

    /**
     * 获取是否记录授权失败的审计日志
     * @return true表示记录，false表示不记录
     */
    public boolean isAuditFailure() {
        return auditFailure;
    }
}