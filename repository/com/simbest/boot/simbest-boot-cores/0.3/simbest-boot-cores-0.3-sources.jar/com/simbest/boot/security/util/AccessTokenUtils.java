package com.simbest.boot.security.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.CloudAuthConstants;
import com.simbest.boot.util.ApplicationContextProvider;
import com.simbest.boot.util.DateUtil;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.redis.RedisJwtValidator;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.DependsOn;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.util.Date;

import static com.simbest.boot.constants.CloudAuthConstants.*;

/**
 * 验签工具类
 */
@Slf4j
@Component
@DependsOn(value = {"restClientConfiguration"})
public class AccessTokenUtils {

    private static AccessTokenUtils accessTokenUtils;

    @Autowired
//    @LoadBalanced
    private RestTemplate nacosRestTemplate;

    @Autowired
    @Getter
    private RsaEncryptor rsaEncryptor;

    @PostConstruct
    public void init() {
        accessTokenUtils = this;
        accessTokenUtils.nacosRestTemplate = this.nacosRestTemplate;
        accessTokenUtils.rsaEncryptor = this.rsaEncryptor;
    }

    /**
     * AccessToken 验签
     *
     * @param authorizationToken
     * @return
     */
    public static boolean verifyAccessToken(String authorizationToken) {
        boolean verifyResult = false;
        String accessToken = authorizationToken.replace(CloudAuthConstants.AUTHORIZATION_PREFIX, "");
        String[] parts = authorizationToken.split("\\.");
        if(parts.length != 3) {
            return false;
        }
        try {
            Date now = new Date();
            DecodedJWT jwt = JWT.decode(accessToken);
            String jwtId = jwt.getId();
            AppConfig appConfig = ApplicationContextProvider.getBean(AppConfig.class);
            String localAppcode = appConfig.getAppcode();
            String jwtAppcode = jwt.getClaim(CloudAuthConstants.AUD).asString();
            Date before = Date.from(jwt.getNotBefore().toInstant());
            String rsausername = jwt.getClaim(CloudAuthConstants.SUB).asString();
            String username = accessTokenUtils.rsaEncryptor.decrypt(rsausername);
            if(StringUtils.hasText(username)) {
                Long expiryCache = RedisJwtValidator.getJwtExpiryDate(username, jwtId);
                //非本应用，如果本地缓存没有，则到具体应用远程调用获取
                if(null == expiryCache && !localAppcode.equals(jwtAppcode)) {
                    HttpHeaders headers = new HttpHeaders();
                    headers.setContentType(MediaType.APPLICATION_JSON);
                    headers.set(HttpHeaders.AUTHORIZATION, CloudAuthConstants.AUTHORIZATION_PREFIX + authorizationToken);
                    HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(headers);
                    MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();
                    paramMap.set(OAUTH21_SUBJECT, username);
                    paramMap.set(OAUTH21_JWTID, jwtId);
                    String requestUrl = String.format(appConfig.getGatewayAddress() + OAUTH21_CHECK_JWT_EXPIRE_DATETIME, jwtAppcode);
                    JsonResponse jsonResponse = InvokeGatewayRequest(requestUrl, jwtAppcode, HttpMethod.POST, httpEntity, paramMap);
                    log.debug("远程向应用【{}】查询令牌到期时间结果为【{}】", jwtAppcode, jsonResponse);
                    if(null != jsonResponse && null != jsonResponse.getData() && jsonResponse.getData() instanceof Long){
                        expiryCache = (Long) jsonResponse.getData();
                    }
                    else{
                        log.error("应用【{}】账号【{}】调用远程服务获取令牌到期时间失败，远程接口响应【{}】，令牌【{}】", jwtAppcode, username, jsonResponse, jwt);
                    }
                }

                //本地缓存+远程调用均没有过期时间，则以令牌携带的过期时间为准（Date.from确保了按照中国时区计算时间）
                Date expiry = expiryCache == null ? Date.from(jwt.getExpiresAt().toInstant()) : new Date(expiryCache);
                if (now.after(expiry)) {
                    //令牌不能太晚
                    log.error("应用【{}】账号【{}】当前时间为【{}】令牌过期时间为【{}】，无效访问！", jwtAppcode, username, DateUtil.getTimestamp(now), DateUtil.getTimestamp(expiry));
                }
                else if (now.before(before)) {
                    //令牌不能太早
                    log.error("应用【{}】账号【{}】当前时间为【{}】令牌生效时间为【{}】，无效访问！", jwtAppcode, username, DateUtil.getTimestamp(now), DateUtil.getTimestamp(before));
                }
                else{
                    HttpHeaders headers = new HttpHeaders();
                    headers.setContentType(MediaType.APPLICATION_JSON);
                    HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(headers);
                    MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();
                    String requestUrl = String.format(appConfig.getGatewayAddress() + OAUTH21_GET_JWT_TOKEN_EXPIRE_SECOND, jwtAppcode);
                    JsonResponse jsonResponse = InvokeGatewayRequest(requestUrl, jwtAppcode, HttpMethod.GET, httpEntity, paramMap);
                    log.debug("远程向应用【{}】查询令牌续长秒数结果为【{}】", jwtAppcode, jsonResponse);
                    if(null != jsonResponse && null != jsonResponse.getData() && jsonResponse.getData() instanceof Integer){
                        Integer seconds = (Integer) jsonResponse.getData();
                        //在当前时间基础上，根据配置，再进行续签延长
                        now = DateUtils.addSeconds(now, seconds);
                        RedisJwtValidator.setJwtExpiryDate(username, jwtId, now.getTime(), seconds);
                        verifyResult = true;
                    }
                    else{
                        log.error("应用【{}】账号【{}】调用远程服务获取令牌续长秒数失败，远程接口响应【{}】，令牌【{}】", jwtAppcode, username, jsonResponse, jwt);
                    }
                }
            }
            else{
                log.error("应用【{}】账号密文【{}】获取账号明文失败，令牌【{}】", jwtAppcode, rsausername, jwt);
            }
        }
        catch (Exception e) {
            Exceptions.printException(e);
        }
        return verifyResult;
    }


    private static JsonResponse InvokeGatewayRequest(String url, String appcode, HttpMethod httpMethod, HttpEntity<MultiValueMap<String, String>> httpEntity, MultiValueMap<String, String> paramMap){
        JsonResponse jsonResponse = null;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url).queryParams(paramMap);
        try {
            ResponseEntity<JsonResponse> jsonResponseEntity = accessTokenUtils.nacosRestTemplate.exchange(builder.build().encode().toUri(), httpMethod, httpEntity, JsonResponse.class);
            jsonResponse = jsonResponseEntity.getBody();
            log.debug("应用【{}】请求【{}】响应结果为【{}】", appcode, url, jsonResponse);
        }
        catch (HttpClientErrorException e) {
            if(HttpStatus.UNAUTHORIZED.equals(e.getStatusCode())) {
                log.error("应用【{}】请求【{}】权限不足，异常信息【{}】", appcode, url, e.getMessage());
            }
            else{
                log.error("应用【{}】请求【{}】发生异常，异常信息【{}】", appcode, url, e.getMessage());
                Exceptions.printException(e);
            }
        }
        return jsonResponse;
    }

}