package com.simbest.boot.config;

import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;

/**
 * 用途：Druid数据源监控配置类
 * 主要提供以下功能：
 * 1. Druid监控统计功能
 * 2. 监控页面访问控制
 * 3. 监控数据过滤规则
 */
//@Configuration
public class DruidConfiguration {

    /**
     * 配置Druid监控统计视图Servlet
     * 提供监控信息展示的Web界面
     * @return ServletRegistrationBean Druid监控Servlet注册对象
     */
    @Bean
    public ServletRegistrationBean DruidStatViewServle(){
        //注册Druid的StatViewServlet，提供监控视图
        ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean(new StatViewServlet(),"/druid/*");
        
        //配置监控页面访问控制参数
        //设置IP白名单，多个IP用逗号分隔
        servletRegistrationBean.addInitParameter("allow","127.0.0.1,10.92.81.163,10.92.82.44");
        //设置IP黑名单，优先级高于白名单
        //servletRegistrationBean.addInitParameter("deny","127.0.0.1");
        
        //设置监控页面的用户名和密码
        servletRegistrationBean.addInitParameter("loginUsername","hadmin");
        servletRegistrationBean.addInitParameter("loginPassword","111.com");
        
        //是否允许重置监控数据
        servletRegistrationBean.addInitParameter("resetEnable","false");
        return servletRegistrationBean;
    }

    /**
     * 配置Druid监控统计过滤器
     * 用于采集web-jdbc关联监控的数据
     * @return FilterRegistrationBean Druid过滤器注册对象
     */
    @Bean
    public FilterRegistrationBean druidStatFilter(){
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean(new WebStatFilter());
        
        //配置需要监控的URL
        filterRegistrationBean.addUrlPatterns("/*");
        
        //配置不需要监控的资源
        filterRegistrationBean.addInitParameter("exclusions","*.js,*.gif,*.jpg,*.png,*.css,*.ico,/druid/*");
        return filterRegistrationBean;
    }
}