package com.simbest.boot.component.repeat.lock;

import com.alibaba.cloud.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.connection.RedisStringCommands;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.types.Expiration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.lang.reflect.Method;

/**
 * Redis请求防重复提交切面
 * 
 * 主要功能：
 * 1. 基于Redis实现分布式请求防重复提交机制
 * 2. 通过AOP拦截带有@RequestLock注解的方法
 * 3. 使用Redis的原子操作实现请求锁定
 * 4. 支持自定义锁的过期时间和时间单位
 * 5. 支持通过配置动态开启/关闭功能
 * 
 * 实现原理：
 * 1. 使用Redis的SET命令的NX（不存在才设置）选项实现锁定
 * 2. 通过Redis的过期机制自动释放锁，避免死锁
 * 3. 结合会话ID和方法信息生成唯一的锁键
 * 
 * 使用场景：
 * 1. 防止表单重复提交
 * 2. 防止重复下单
 * 3. 限制接口调用频率
 * 4. 需要防止重复操作的业务场景
 * 
 * 配置说明：
 * 1. app.request.lock.switch: 功能开关，默认开启
 * 2. 通过@RequestLock注解配置具体的锁定参数
 * 
 * 注意事项：
 * 1. 确保Redis服务的可用性
 * 2. 合理设置锁的过期时间
 * 3. 注意处理锁获取失败的情况
 * 4. 在集群环境下需要使用相同的Redis实例
 */
@Aspect
@Configuration
@Order(2)
public class RedisRequestLockAspect {

    /**
     * Redis字符串操作模板
     * 
     * 功能：
     * 1. 提供Redis的基础操作能力
     * 2. 实现分布式锁的获取和释放
     * 3. 支持Redis的原子操作
     * 
     * 注意：
     * 1. 确保Redis连接配置正确
     * 2. 建议使用Spring注入管理生命周期
     */
    private final StringRedisTemplate stringRedisTemplate;

    /**
     * HTTP请求对象
     * 
     * 功能：
     * 1. 获取当前请求的会话信息
     * 2. 用于生成请求相关的锁键
     * 
     * 注意：
     * 1. 在Web环境中使用
     * 2. 需要正确配置会话管理
     */
    private final HttpServletRequest request;

    /**
     * 请求锁定功能开关
     * 
     * 配置项：
     * - 配置键：app.request.lock.switch
     * - 默认值：true（开启）
     * - 可选值：true/false
     * 
     * 使用说明：
     * 1. true：启用请求锁定功能
     * 2. false：禁用请求锁定功能
     * 3. 可通过配置文件动态调整
     */
    @Value("${app.request.lock.switch:true}")
    private Boolean requestLockSwitch;

    /**
     * 构造函数
     * 
     * @param stringRedisTemplate Redis操作模板，用于实现分布式锁
     * @param request HTTP请求对象，用于获取会话信息
     * 
     * 注入说明：
     * 1. 通过Spring自动注入所需依赖
     * 2. 确保所需组件已在Spring容器中注册
     */
    public RedisRequestLockAspect(StringRedisTemplate stringRedisTemplate , HttpServletRequest request) {
        this.stringRedisTemplate = stringRedisTemplate;
        this.request = request;
    }

    /**
     * 请求防重复提交的环绕通知
     * 
     * 执行流程：
     * 1. 检查功能开关状态
     * 2. 获取当前会话ID
     * 3. 生成唯一的锁键
     * 4. 尝试获取分布式锁
     * 5. 执行目标方法
     * 6. 通过Redis过期机制自动释放锁
     * 
     * 锁定机制：
     * 1. 使用Redis的SET NX命令实现原子性操作
     * 2. 设置锁的过期时间，避免死锁
     * 3. 基于会话ID和方法信息确保锁的唯一性
     * 
     * 异常处理：
     * 1. 锁键生成失败时抛出异常
     * 2. 获取锁失败时提示用户稍后重试
     * 3. 目标方法执行异常时抛出运行时异常
     *
     * @param joinPoint 切入点，包含被拦截的方法信息
     * @return Object 目标方法的执行结果
     * @throws RuntimeException 当锁获取失败或执行异常时抛出
     */
    @Around("execution(public * * (..)) && @annotation(com.simbest.boot.component.repeat.lock.RequestLock)")
    public Object interceptor(ProceedingJoinPoint joinPoint) {
        if (requestLockSwitch) {
            MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
            Method method = methodSignature.getMethod();
            RequestLock requestLock = method.getAnnotation(RequestLock.class);
            String sessionId = null;
            HttpSession session = request.getSession(false);
            if (session != null) {
                sessionId = session.getId();
            }
            //获取自定义key
            final String lockKey = RequestLockKeyGenerator.getLockKey(sessionId, joinPoint);
            if (StringUtils.isEmpty(lockKey)) {
                throw new RuntimeException("lockKey值生成异常！");
            }
            // 使用RedisCallback接口执行set命令，设置锁键；设置额外选项：过期时间和SET_IF_ABSENT选项
            final Boolean success = stringRedisTemplate.execute(
                    (RedisCallback<Boolean>) connection -> connection.set(lockKey.getBytes(), new byte[0],
                            Expiration.from(requestLock.expire(), requestLock.timeUnit()),
                            RedisStringCommands.SetOption.SET_IF_ABSENT));
            if (!success) {
                throw new RuntimeException("您的操作太快了,请稍后重试");
            }
        }
        try {
            return joinPoint.proceed();
        } catch (Throwable throwable) {
            throw new RuntimeException("系统异常！");
        }
    }
}