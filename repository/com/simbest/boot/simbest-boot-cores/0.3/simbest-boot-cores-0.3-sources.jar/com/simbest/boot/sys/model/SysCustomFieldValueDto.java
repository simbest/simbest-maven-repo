package com.simbest.boot.sys.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 用途：实体自定义字段值
 *
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class SysCustomFieldValueDto implements Serializable {

    private List<SysCustomFieldValue> sysfieldvalue;

}