package com.simbest.boot.security.auth.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * 用途：Spring Boot Actuator监控端点安全配置
 * 
 * 主要功能：
 * 1. 配置Actuator监控端点的访问安全规则
 * 2. 实现基于角色的访问控制
 * 3. 支持HTTP Basic认证
 * 
 * 配置说明：
 * 1. 所有/actuator/**路径的请求需要进行认证
 * 2. 只有具有SUPER角色的用户才能访问监控端点
 * 3. 使用HTTP Basic方式进行认证
 * 4. 配置优先级为30（@Order(30)）
 */
@Configuration
@Order(30)
public class MonitorSecurityConfigurer extends WebSecurityConfigurerAdapter {

    /**
     * 配置Actuator监控端点的安全访问规则
     * 
     * 配置内容：
     * 1. 指定安全规则适用于/actuator/**路径
     * 2. 启用HTTP Basic认证
     * 3. 要求访问用户具有SUPER角色
     * 4. 注释部分展示了允许所有访问的替代配置方案
     *
     * @param http HttpSecurity配置对象
     * @throws Exception 配置过程中的异常
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .antMatcher("/actuator/**")
                .httpBasic()
                .and()
                .authorizeRequests().antMatchers("/actuator/**").hasRole("SUPER");
//        http
//                .requestMatchers()
//                .antMatchers("actuator/**")
//                .and()
//                .authorizeRequests()
//                .antMatchers("actuator/**").permitAll();
    }
}