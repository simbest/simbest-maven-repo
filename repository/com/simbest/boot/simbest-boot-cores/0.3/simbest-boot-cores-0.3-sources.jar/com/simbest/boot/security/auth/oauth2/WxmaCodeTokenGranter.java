package com.simbest.boot.security.auth.oauth2;

import com.simbest.boot.security.auth.authentication.wxma.WxmaAuthenticationCredentials;
import com.simbest.boot.security.auth.authentication.wxma.WxmaCodeAuthenticationToken;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.provider.*;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 用途：基于微信小程序的认证OAUTH2方式提交的认证主体(Token失效时使用)
 * 参考：ResourceOwnerPasswordTokenGranter http://www.voidcn.com/article/p-kkszxmkr-bqq.html
 *
 *
 *
 * 请求URL：http://10.87.57.23:6004/ischool/oauth/token?grant_type=wxmacode&scope=all&client_id=wxma_client&client_secret=e10adc3949ba59abbe56e057f20f883e&appcode=ischool&appid=wxa0d10b26a0d997c1&wxcode=微信换取的code
 */
@Slf4j
public class WxmaCodeTokenGranter extends Oauth2ExtendTokenGranter {

    private static final String GRANT_TYPE = "wxmacode";

    private final AuthenticationManager authenticationManager;

    public WxmaCodeTokenGranter(AuthenticationManager authenticationManager,
                                AuthorizationServerTokenServices tokenServices, ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory) {
        this(authenticationManager, tokenServices, clientDetailsService, requestFactory, GRANT_TYPE);
    }

    protected WxmaCodeTokenGranter(AuthenticationManager authenticationManager, AuthorizationServerTokenServices tokenServices,
                                   ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory, String grantType) {
        super(tokenServices, clientDetailsService, requestFactory, grantType);
        this.authenticationManager = authenticationManager;
        super.setAuthenticationManager(authenticationManager);
    }

    @Override
    protected OAuth2Authentication getOAuth2Authentication(ClientDetails client, TokenRequest tokenRequest) {
        Map<String, String> parameters = new LinkedHashMap<String, String>(tokenRequest.getRequestParameters());
        String appcode = parameters.get("appcode");
        String appid = parameters.get("appid");
        String wxcode = parameters.get("wxcode");
        Boolean forceCreate = StringUtils.isNotEmpty(parameters.get("forceCreate")) ? Boolean.parseBoolean(parameters.get("forceCreate")): false;
        log.debug("OAUTH2即将通过微信小程序WxmaCodeTokenGranter进行认证，appcode【{}】appid【{}】wxcode【{}】",
                appcode, appid, wxcode);
        Authentication userAuth = new WxmaCodeAuthenticationToken(appid, WxmaAuthenticationCredentials.builder()
                .appcode(appcode).appid(appid).wxcode(wxcode).forceCreate(forceCreate).build());
        ((AbstractAuthenticationToken) userAuth).setDetails(parameters);
        return this.genericOAuth2Authentication(userAuth, client, tokenRequest);
    }

}