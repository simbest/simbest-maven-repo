package com.simbest.boot.sys.service.impl;

import com.simbest.boot.sys.service.IAppShutdownService;
import lombok.extern.slf4j.Slf4j;

import static com.simbest.boot.component.GracefulShutdown.SHUTDOWN_FLAG;

/**
 * 用途：完美关闭应用的钩子
 *
 *
 */
@Slf4j
public class GenericAppShutdownService implements IAppShutdownService {

    @Override
    public void gracefulShutdown() {
        log.debug("应用即将关闭，I will do nothing！ ".concat(SHUTDOWN_FLAG));
    }

}