package com.simbest.boot.sys.repository;

import com.simbest.boot.base.repository.SystemRepository;
import com.simbest.boot.sys.model.SysTaskExecutedLog;
import org.springframework.stereotype.Repository;

/**
 * 用途：定时任务执行日志持久层
 *
 *
 */
@Repository
public interface SysTaskExecutedLogRepository extends SystemRepository<SysTaskExecutedLog, String> {


}