package com.simbest.boot.security.auth.authentication.principal;

import com.simbest.boot.security.IAuthService;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.security.Principal;

/**
 * 基于关键字类型的认证主体
 * 
 * 主要功能：
 * 1. 实现基于关键字类型的SSO认证
 * 2. 支持多种类型的关键字认证
 * 3. 实现Principal和Serializable接口
 * 
 * 认证流程：
 * 1. 根据关键字类型确定认证方式
 * 2. 使用关键字进行身份验证
 * 3. 生成对应的认证主体
 * 
 * 应用场景：
 * - 用户名认证
 * - 手机号认证
 * - 邮箱认证
 * - 其他自定义类型认证
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class KeyTypePrincipal implements Principal, Serializable {

    /**
     * 关键字类型
     * 用于：
     * 1. 标识认证方式（如用户名、手机号、邮箱等）
     * 2. 决定认证策略
     * 3. 支持系统扩展新的认证类型
     */
    private IAuthService.KeyType keyType;

    /**
     * 关键字值
     * 用于：
     * 1. 存储具体的认证标识（如具体的用户名、手机号等）
     * 2. 作为认证的唯一标识
     * 3. 用于后续的用户信息查询
     */
    private String keyword;

    /**
     * 获取认证主体名称
     * 实现Principal接口的方法
     * 
     * @return 返回关键字值作为认证主体的名称
     */
    @Override
    public String getName() {
        return keyword;
    }
}