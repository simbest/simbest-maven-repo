package com.simbest.boot.component.distributed.lock;

import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;

import java.util.concurrent.TimeUnit;

/**
 * 单机模式的分布式锁模板实现类
 * 
 * 主要功能：
 * 1. 实现DistributedLockTemplate接口，提供分布式锁的标准实现
 * 2. 基于Redisson的RLock实现可靠的分布式锁操作
 * 3. 支持自动释放锁机制，防止死锁
 * 4. 提供默认和自定义超时时间的锁操作
 * 
 * 实现特点：
 * 1. 使用Redisson的可重入锁（RLock）
 * 2. 支持锁的自动续期，适合长时间任务
 * 3. 保证锁的正确释放，即使在异常情况下
 * 4. 支持灵活的超时时间设置
 * 
 * 使用场景：
 * 1. 单机部署的分布式应用
 * 2. 需要保证业务操作互斥性
 * 3. 需要防止并发访问的场景
 * 
 * 注意事项：
 * 1. 确保Redisson客户端正确配置和初始化
 * 2. 合理设置锁的超时时间，避免锁长期占用
 * 3. 在高并发场景下注意性能影响
 */
public class SingleDistributedLockTemplate implements DistributedLockTemplate {

    /**
     * Redisson客户端实例
     * 
     * 功能：
     * 1. 提供分布式锁的底层实现
     * 2. 管理与Redis的连接
     * 3. 处理锁的获取、释放和续期
     * 
     * 注意：
     * 1. 必须在使用前正确初始化
     * 2. 建议通过Spring容器管理生命周期
     */
    private RedissonClient redisson;

    /**
     * 默认构造函数
     * 
     * 注意：
     * 1. 使用此构造函数后必须通过setRedisson方法设置客户端实例
     * 2. 主要用于Spring等容器的依赖注入
     */
    public SingleDistributedLockTemplate() {
    }

    /**
     * 带Redisson客户端的构造函数
     * 
     * @param redisson Redisson客户端实例，用于创建和管理分布式锁
     * 
     * 使用场景：
     * 1. 手动创建模板实例
     * 2. 需要立即使用分布式锁功能
     */
    public SingleDistributedLockTemplate(RedissonClient redisson) {
        this.redisson = redisson;
    }

    /**
     * 使用分布式锁执行回调方法（默认配置）
     * 
     * 执行流程：
     * 1. 获取指定名称的分布式锁
     * 2. 执行回调方法中的业务逻辑
     * 3. 自动释放锁资源
     * 
     * 特点：
     * 1. 使用默认的锁配置
     * 2. 自动管理锁的生命周期
     * 3. 确保锁的正确释放
     *
     * @param callback 分布式锁回调接口，封装需要加锁执行的业务逻辑
     * @return <T> 回调方法的执行结果
     * @throws RuntimeException 当获取锁或执行回调过程中发生异常
     */
    @Override
    public <T> T lock(DistributedLockCallback<T> callback) {
        RLock lock = null;
        try {
            lock = redisson.getLock(callback.getLockName());
            lock.lock();
            return callback.process();
        } finally {
            if (lock != null) {
                lock.unlock();
            }
        }
    }

    /**
     * 使用分布式锁执行回调方法（自定义超时）
     * 
     * 执行流程：
     * 1. 获取指定名称的分布式锁
     * 2. 设置自定义的超时时间
     * 3. 执行回调方法中的业务逻辑
     * 4. 自动释放锁资源
     * 
     * 特点：
     * 1. 支持自定义锁的超时时间
     * 2. 超时后自动释放锁，防止死锁
     * 3. 适合需要精确控制锁定时间的场景
     *
     * @param callback 分布式锁回调接口，封装需要加锁执行的业务逻辑
     * @param leaseTime 锁的超时时间，超过此时间自动释放
     * @param timeUnit 时间单位，如秒、毫秒等
     * @return <T> 回调方法的执行结果
     * @throws RuntimeException 当获取锁或执行回调过程中发生异常
     */
    @Override
    public <T> T lock(DistributedLockCallback<T> callback, long leaseTime, TimeUnit timeUnit) {
        RLock lock = null;
        try {
            lock = redisson.getLock(callback.getLockName());
            lock.lock(leaseTime, timeUnit);
            return callback.process();
        } finally {
            if (lock != null) {
                lock.unlock();
            }
        }
    }

    /**
     * 设置Redisson客户端实例
     * 
     * 使用场景：
     * 1. 在使用默认构造函数后设置客户端
     * 2. 需要更换Redisson客户端实例时
     * 
     * 注意事项：
     * 1. 确保传入的客户端实例已正确初始化
     * 2. 建议在应用启动时完成设置
     * 
     * @param redisson Redisson客户端实例
     */
    public void setRedisson(RedissonClient redisson) {
        this.redisson = redisson;
    }
}