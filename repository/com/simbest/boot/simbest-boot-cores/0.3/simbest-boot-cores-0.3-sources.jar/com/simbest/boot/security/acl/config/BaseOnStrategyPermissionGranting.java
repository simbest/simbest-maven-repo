package com.simbest.boot.security.acl.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.acls.domain.AuditLogger;
import org.springframework.security.acls.model.*;

import java.util.List;
import java.util.Objects;

/**
 * 基于策略的ACL权限授予实现
 * 
 * 主要功能：
 * 1. 实现Spring Security ACL的权限授予策略
 * 2. 基于访问控制条目（ACE）进行权限判断
 * 3. 支持权限继承和审计日志记录
 * 
 * 工作原理：
 * 1. 遍历所有请求的权限和安全标识（SID）
 * 2. 检查每个访问控制条目是否匹配当前请求
 * 3. 支持权限掩码比较和继承关系处理
 * 
 * 特点：
 * 1. 采用策略模式实现灵活的权限控制
 * 2. 支持权限的精确匹配和范围匹配
 * 3. 实现了权限继承机制
 * 4. 集成审计日志功能
 * 
 * 使用场景：
 * 1. 需要细粒度访问控制的系统
 * 2. 要求支持权限继承的应用
 * 3. 需要权限审计追踪的场合
 * 
 * 参考：
 * https://github.com/lordlothar99/strategy-spring-security-acl
 */
@Slf4j
public class BaseOnStrategyPermissionGranting implements PermissionGrantingStrategy {

    /**
     * 审计日志记录器
     * 用于记录权限判定的结果和相关信息
     */
    private final transient AuditLogger auditLogger;

    /**
     * 构造函数
     * 
     * @param auditLogger 审计日志记录器，用于记录权限判定结果
     * @throws NullPointerException 如果auditLogger为null
     */
    public BaseOnStrategyPermissionGranting(AuditLogger auditLogger) {
        this.auditLogger = Objects.requireNonNull(auditLogger, "AuditLogger cannot be null");
    }

    /**
     * 判断是否授予权限
     * 
     * @param acl 访问控制列表，包含所有的访问控制条目
     * @param permission 请求的权限列表，需要验证的权限集合
     * @param sids 安全标识列表，请求主体的身份标识集合
     * @param administrativeMode 是否为管理模式（管理模式下不记录审计日志）
     * @return 如果授予权限返回true，否则返回false
     * @throws NotFoundException 当找不到匹配的访问控制条目时抛出
     */
    @Override
    public boolean isGranted(Acl acl, List<Permission> permission, List<Sid> sids, boolean administrativeMode) {
        List<AccessControlEntry> aces = acl.getEntries();
        AccessControlEntry firstRejection = null;
        for (Permission p : permission) {
            for (Sid sid : sids) {
                boolean scanNextSid = true;
                for (AccessControlEntry ace : aces) {
                    if (ace.getPermission().getMask() >= p.getMask() && ace.getSid().equals(sid)) {
                        if (ace.isGranting()) {
                            if (!administrativeMode) {
                                this.auditLogger.logIfNeeded(true, ace);
                            }
                            return true;
                        }
                        if (firstRejection == null) {
                            firstRejection = ace;
                        }
                        scanNextSid = false;
                        break;
                    }
                }
                if (!scanNextSid) {
                    break;
                }
            }
        }

        if (firstRejection != null) {
            if (!administrativeMode) {
                this.auditLogger.logIfNeeded(false, firstRejection);
            }
            return false;
        } else if (acl.isEntriesInheriting() && acl.getParentAcl() != null) {
            return acl.getParentAcl().isGranted(permission, sids, false);
        } else {
            throw new NotFoundException("Unable to locate a matching ACE for passed permissions and SIDs");
        }
    }
}