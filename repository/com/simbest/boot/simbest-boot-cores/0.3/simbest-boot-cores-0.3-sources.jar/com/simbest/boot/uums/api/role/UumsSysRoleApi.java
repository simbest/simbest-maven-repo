package com.simbest.boot.uums.api.role;

import com.fasterxml.jackson.core.type.TypeReference;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.SimpleRole;
import com.simbest.boot.util.ObjectUtil;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.uums.api.ApiRequestHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @version <strong>V1.0.0</strong><br>
 */

/**
 * 系统角色管理API接口
 * 提供角色管理相关的远程调用接口：
 * - 角色信息的基础CRUD操作
 * - 支持按用户名和职位名查询角色
 * - 提供角色代码校验功能
 * - 实现角色与权限的关联管理
 * - 支持分页和条件查询
 * - 提供角色状态管理功能
 */
@Component
@Slf4j
@SuppressWarnings("All")
public class UumsSysRoleApi {

    private static final String USER_MAPPING = "/action/sys/role/";
    private static final String SSO = "/sso";
    @Autowired
    private AppConfig config;
    //private String uumsAddress="http://localhost:8080/uums";
    @Autowired
    private RsaEncryptor encryptor;
    @Autowired
    private ApiRequestHandle<List<SimpleRole>> simpleRoleApiHandle;


    /**
     * 根据ID查询角色信息
     * 
     * @param id 角色ID
     * @param appcode 应用代码
     * @return 角色信息对象
     */
    public SimpleRole findById(String id, String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findById" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("id", String.valueOf(id))
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleRole auth = JacksonUtils.json2obj(json, SimpleRole.class);
        return auth;
    }


    /**
     * 获取角色信息列表并分页
     * 
     * @param page 当前页码
     * @param size 每页大小
     * @param direction 排序方向
     * @param properties 排序属性
     * @param appcode 应用代码
     * @param sysRoleMap 查询条件
     * @return 分页的角色信息列表
     */
    public JsonResponse findAll(int page, int size, String direction, String properties, String appcode, Map sysRoleMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysRoleMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAll" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode
                        + "&page=" + page + "&size=" + size + "&direction=" + direction + "&properties=" + properties)
                .json(json0)
                .asBean(JsonResponse.class);
        return response;
    }

    /**
     * 根据角色名和业务角色标识进行模糊查询
     * 
     * @param page 当前页码
     * @param size 每页大小
     * @param direction 排序方向
     * @param properties 排序属性
     * @param map 包含roleName和roleCode的查询条件
     * @return 符合条件的角色列表
     */
    public JsonResponse findRoleNameIsARoleDim(int page, int size, String direction, String properties, Map map) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findRoleNameIsARoleDim" + SSO + "?loginuser=" + username2 + "&appcode=" + config.getAppcode()
                        + "&page=" + page + "&size=" + size + "&direction=" + direction + "&properties=" + properties)
                .json(JacksonUtils.obj2json(map))
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 校验角色代码是否已存在
     * 
     * @param appcode 应用代码
     * @param roleCode 角色代码
     * @return true表示已存在，false表示不存在
     */
    public Boolean isHaveCode(String appcode, String roleCode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "isHaveCode" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("roleCode", roleCode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof Boolean)) {
            log.error("--uums接口返回的类型不为Boolean--");
            return null;
        }
        return (Boolean) response.getData();
    }

    /**
     * 查询指定用户的所有角色
     * 
     * @param mapParam 包含username的参数映射
     * @param appcode 应用代码
     * @return 用户的角色列表
     */
    public List<SimpleRole> findRoleAppointByUsername(Map<String, Object> mapParam, String appcode) {
        String username = (String) mapParam.get("username");
        return findRoleByUsernameNormal(username, appcode);
    }

    /**
     * 查询当前用户的所有角色
     * 
     * @param appcode 应用代码
     * @return 当前用户的角色列表
     */
    public List<SimpleRole> findRoleByUsername(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        return findRoleByUsernameNormal(username, appcode);
    }

    /**
     * 通用的用户角色查询方法
     * 
     * @param username 用户名
     * @param appcode 应用代码
     * @return 用户的角色列表
     */
    private List<SimpleRole> findRoleByUsernameNormal(String username, String appcode) {
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findRoleByUsername" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("username", username)
                .asBean(JsonResponse.class);
        return simpleRoleApiHandle.handRemoteTypeReferenceResponse(response, new TypeReference<List<SimpleRole>>() {
        });
    }


    /**
     * 查询指定职位的所有角色
     * 
     * @param appcode 应用代码
     * @param positionName 职位名称
     * @return 职位关联的角色列表
     */
    public List<SimpleRole> findRoleByPositionName(String appcode, String positionName) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findRoleByPositionName" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("positionName", positionName)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleRole> roleList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleRole>>() {
        });
        return roleList;
    }

    /**
     * 根据角色代码查询角色信息
     * 
     * @param appcode 应用代码
     * @param roleCode 角色代码
     * @return 角色信息对象
     */
    public SimpleRole findRoleByRoleCode(String appcode, String roleCode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findRoleByRoleCode" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("roleCode", roleCode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleRole auth = JacksonUtils.json2obj(json, SimpleRole.class);
        return auth;
    }

    /**
     * 创建新的角色
     * 
     * @param appcode 应用代码
     * @param simpleRole 角色信息对象
     * @return 创建的角色信息
     */
    public SimpleRole addRole(String appcode, SimpleRole simpleRole) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {},appcode:{}", username, appcode);
        JsonResponse jsonResponse = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "create" + SSO + "?"
                        + AuthoritiesConstants.SSO_API_USERNAME + ApplicationConstants.EQUAL + encryptor.encrypt(username) + "&"
                        + AuthoritiesConstants.SSO_API_APP_CODE + ApplicationConstants.EQUAL + appcode)
                .json(JacksonUtils.obj2json(simpleRole))
                .asBean(JsonResponse.class);
        if (ObjectUtil.isEmpty(jsonResponse)) {
            log.error("--新增角色接口调用失败!--");
            return null;
        }
        String json = JacksonUtils.obj2json(jsonResponse.getData());
        SimpleRole simpleRoleTmp = JacksonUtils.json2obj(json, SimpleRole.class);
        return simpleRoleTmp;
    }

    /**
     * 删除角色
     * 
     * @param appcode 应用代码
     * @param simpleRole 要删除的角色信息
     * @return 删除结果
     */
    public boolean delRole(String appcode, SimpleRole simpleRole) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {},appcode:{}", username, appcode);
        JsonResponse jsonResponse = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "delete" + SSO + "?"
                        + AuthoritiesConstants.SSO_API_USERNAME + ApplicationConstants.EQUAL + encryptor.encrypt(username) + "&"
                        + AuthoritiesConstants.SSO_API_APP_CODE + ApplicationConstants.EQUAL + appcode)
                .json(JacksonUtils.obj2json(simpleRole))
                .asBean(JsonResponse.class);
        if (ObjectUtil.isEmpty(jsonResponse)) {
            log.error("--删除角色接口调用失败!--");
            return false;
        }
        return ObjectUtil.isNotEmpty(jsonResponse) ? true : false;
    }

    /**
     * 更新角色信息
     * 
     * @param appcode 应用代码
     * @param simpleRole 更新的角色信息
     * @return 更新后的角色信息
     */
    public SimpleRole updateRole(String appcode, SimpleRole simpleRole) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {},appcode:{}", username, appcode);
        JsonResponse jsonResponse = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "update" + SSO + "?"
                        + AuthoritiesConstants.SSO_API_USERNAME + ApplicationConstants.EQUAL + encryptor.encrypt(username) + "&"
                        + AuthoritiesConstants.SSO_API_APP_CODE + ApplicationConstants.EQUAL + appcode)
                .json(JacksonUtils.obj2json(simpleRole))
                .asBean(JsonResponse.class);
        if (ObjectUtil.isEmpty(jsonResponse)) {
            log.error("--修改角色接口调用失败!--");
            return null;
        }
        String json = JacksonUtils.obj2json(jsonResponse.getData());
        SimpleRole simpleRoleTmp = JacksonUtils.json2obj(json, SimpleRole.class);
        return simpleRoleTmp;
    }

    /**
     * 根据权限ID查询关联的角色
     * 
     * @param permissionId 权限ID
     * @return 关联的角色列表
     */
    public JsonResponse queryRoleByPermissionId(String permissionId) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "queryRoleByPermissionId" + SSO + "?loginuser=" + username1 + "&appcode=" + config.getAppcode())
                .param("permissionId", permissionId)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 更新角色状态
     * 
     * @param id 角色ID
     * @param status 新的状态值
     * @return 更新结果
     */
    public JsonResponse updateSysRole(String id, String status) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "updateSysRole" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .param("id", id)
                .param("status", status)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }
}