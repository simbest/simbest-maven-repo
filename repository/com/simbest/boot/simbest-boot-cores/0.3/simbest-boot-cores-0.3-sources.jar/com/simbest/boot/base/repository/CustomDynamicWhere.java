package com.simbest.boot.base.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 自定义动态SQL查询执行器
 * 提供原生SQL查询和更新操作的封装：
 * - 支持执行自定义的SQL语句，绕过JPA的限制
 * - 提供普通参数和命名参数两种方式的SQL执行
 * - 适用于复杂查询场景，如多表关联、复杂条件等
 * - 支持查询和更新操作，满足不同业务需求
 */
@Slf4j
@Repository
public class CustomDynamicWhere implements Serializable {

    /**
     * 标准JDBC模板，用于执行普通SQL语句
     * 支持使用?作为参数占位符
     */
    @Autowired
    @Qualifier("jdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    /**
     * 命名参数JDBC模板，用于执行带命名参数的SQL语句
     * 支持使用:paramName作为参数占位符
     */
    @Autowired
    @Qualifier("namedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * 执行无参数的原生SQL查询
     * <p>直接执行SQL语句，不需要传入任何参数</p>
     * 
     * @param sql 需要执行的SQL查询语句
     * @return 查询结果列表，每行数据为一个Map
     */
    public List<Map<String, Object>> queryForList(String sql){
        log.warn("自定义查询SQL输出为：【{}】",sql );
        return jdbcTemplate.queryForList(sql);
    }

    /**
     * 执行带参数的原生SQL查询
     * <p>使用?作为参数占位符，参数按顺序绑定</p>
     * 
     * @param sql 需要执行的SQL查询语句，使用?作为参数占位符
     * @param params 查询参数数组，按顺序对应SQL中的占位符
     * @return 查询结果列表，每行数据为一个Map
     */
    public List<Map<String, Object>> queryForList(String sql,Object[] params){
        log.warn("自定义查询SQL输出为：【{}】",sql );
        return jdbcTemplate.queryForList(sql,params);
    }

    /**
     * 执行带命名参数的原生SQL查询
     * <p>使用:paramName作为参数占位符，参数通过名称绑定</p>
     * 
     * @param sql 需要执行的SQL查询语句，使用:paramName作为参数占位符
     * @param paramMap 参数名称和值的映射，键为参数名，值为参数值
     * @return 查询结果列表，每行数据为一个Map
     */
    public List<Map<String, Object>> queryNamedParameterForList(String sql,Map<String, ?> paramMap){
        log.warn("自定义查询SQL输出为：【{}】",sql );
        return namedParameterJdbcTemplate.queryForList(sql, paramMap);
    }
    
    /**
     * 执行无参数的原生SQL更新操作
     * <p>可用于执行INSERT、UPDATE、DELETE等更新操作</p>
     * 
     * @param sql 需要执行的SQL更新语句
     * @return 受影响的行数
     */
    public int updateData(String sql) {
    	log.warn("自定义更新SQL输出为：【{}】",sql );
    	return jdbcTemplate.update(sql);
    }
    
    /**
     * 执行带参数的原生SQL更新操作
     * <p>使用?作为参数占位符，参数按顺序绑定</p>
     * <p>可用于执行INSERT、UPDATE、DELETE等更新操作</p>
     * 
     * @param sql 需要执行的SQL更新语句，使用?作为参数占位符
     * @param params 更新参数数组，按顺序对应SQL中的占位符
     * @return 受影响的行数
     */
    public int updateDataWithParam(String sql,Object[] params) {
    	log.warn("自定义更新SQL输出为：【{}】",sql );
        return jdbcTemplate.update(sql,params);
    }
}