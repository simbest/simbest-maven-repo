package com.simbest.boot.security.auth.authentication.wxma;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;

import java.util.Collection;

/**
 * 微信小程序Code认证令牌
 * 
 * 主要功能：
 * 1. 实现基于微信小程序code的认证
 * 2. 继承自Spring Security的AbstractAuthenticationToken
 * 3. 支持认证前状态的令牌管理
 * 
 * 认证流程：
 * 1. 接收微信小程序的appid
 * 2. 验证微信登录code
 * 3. 处理加密数据和验证码
 * 
 * 应用场景：
 * - 微信小程序登录
 * - 小程序用户身份验证
 * - 微信开放能力接入
 */
public class WxmaCodeAuthenticationToken extends AbstractAuthenticationToken {

    /**
     * 认证主体
     * 存储微信小程序的appid
     * 用于：
     * 1. 标识具体的微信小程序
     * 2. 调用微信开放接口
     * 3. 验证请求的合法性
     */
    @Setter
    @Getter
    private Object principal;

    /**
     * 认证凭据
     * 包含微信小程序认证所需的所有信息
     * 用于：
     * 1. 存储登录code和加密数据
     * 2. 验证码和应用标识
     * 3. 控制用户创建策略
     */
    @Setter @Getter
    private WxmaAuthenticationCredentials credentials;

    /**
     * 创建微信小程序Code认证令牌
     * 
     * @param principal 微信小程序appid，作为认证主体
     * @param credentials 微信小程序认证凭据
     * 
     * 说明：
     * 1. 创建时使用空权限列表初始化
     * 2. 认证成功后需要重新设置对应的权限
     * 3. 用于微信小程序登录场景
     */
    public WxmaCodeAuthenticationToken(Object principal, WxmaAuthenticationCredentials credentials) {
        super(AuthorityUtils.NO_AUTHORITIES);
        this.principal = principal;
        this.credentials = credentials;
    }

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}