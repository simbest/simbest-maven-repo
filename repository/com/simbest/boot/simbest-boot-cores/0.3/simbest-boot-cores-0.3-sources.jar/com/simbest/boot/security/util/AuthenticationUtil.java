package com.simbest.boot.security.util;

import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.security.auth.authentication.GenericAuthentication;
import com.simbest.boot.security.auth.authentication.SsoUsernameAuthentication;
import com.simbest.boot.security.auth.authentication.UumsAuthentication;
import com.simbest.boot.security.auth.authentication.UumsAuthenticationCredentials;
import com.simbest.boot.util.ApplicationContextProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import static com.simbest.boot.constants.ApplicationConstants.COMMA;
import static com.simbest.boot.constants.ApplicationConstants.STAR;

/**
 * 用途：Authentication 工具类
 *
 *
 */
@Slf4j
public class AuthenticationUtil {

    /**
     * 判断单点用户名是否需要验证
     */
    public static boolean authenticationIsRequired(Authentication existingAuth, String username, String appCode) {
        boolean needAuth = false;
        try {
            //基本校验
            if (existingAuth == null || !existingAuth.isAuthenticated()) {
                needAuth = true;
            }

            //SSO校验
            else if (existingAuth instanceof SsoUsernameAuthentication) {
                if (!existingAuth.getName().equals(username)) {
                    needAuth = true;
                }
                if (existingAuth.getName().equals(username) && !existingAuth.getCredentials().equals(appCode)) {
                    needAuth = true;
                }
            }

            //封装后的账号密码校验
            else if (existingAuth instanceof UumsAuthentication) {
                if (!existingAuth.getName().equals(username)) {
                    needAuth = true;
                }
                if (existingAuth.getName().equals(username) && !existingAuth.getCredentials().equals(appCode)) {
                    needAuth = true;
                }
            } else if (existingAuth instanceof GenericAuthentication) {
                if (!existingAuth.getName().equals(username)) {
                    needAuth = true;
                }
                if (existingAuth.getName().equals(username) && !((UumsAuthenticationCredentials) existingAuth.getCredentials()).getAppcode().equals(appCode)) {
                    needAuth = true;
                }
            }

            //原生账号密码校验
            else if (existingAuth instanceof UsernamePasswordAuthenticationToken
                    && !existingAuth.getName().equals(username)) {
                needAuth = true;
            } else if (existingAuth instanceof OAuth2Authentication
                    && !existingAuth.getName().equals(username)) {
                needAuth = true;
            }
        }
        catch (Exception e){
            log.error("判断身份是否需要鉴权发生异常账号【{}】使用【{}】身份访问【{}】", username, existingAuth, appCode);
            Exceptions.printException(e);
        }
        log.debug("Authentication认证类型为【{}】，认证主体为【{}】，判断是否需要进行认证结果为【{}】", existingAuth, username, needAuth);
        return needAuth;
    }

    /**
     * 检查当前请求的IP地址是否是合法运维IP地址
     * @return
     */
    public static CheckIpIsDevOpsResult checkIpIsDevOps(String clientIp){
        boolean checkFlag;
        AppConfig appConfig = ApplicationContextProvider.getBean(AppConfig.class);
        //  app.login.ip.white.list=* (IP地址合法)
        if(!appConfig.getLoginWhiteIplist().isEmpty() && appConfig.getLoginWhiteIplist().size() == 1 && appConfig.getLoginWhiteIplist().get(0).equals(STAR)){
            checkFlag = true;
        }
        // app.login.ip.white.list=10.87.57.23,10.87.57.46, 10.87.57.68 (IP地址合法)
        else if(appConfig.getLoginWhiteIplist().contains(clientIp)){
            checkFlag = true;
        }
        else{
            checkFlag = false;
        }
        CheckIpIsDevOpsResult result = CheckIpIsDevOpsResult.builder().checkRet(checkFlag).whiteIps(String.join(COMMA, appConfig.getLoginWhiteIplist())).currentIp(clientIp).build();
        return result;
    }



}