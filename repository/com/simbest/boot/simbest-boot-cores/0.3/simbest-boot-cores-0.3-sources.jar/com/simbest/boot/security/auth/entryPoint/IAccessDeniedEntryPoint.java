package com.simbest.boot.security.auth.entryPoint;

import org.springframework.security.web.AuthenticationEntryPoint;

/**
 * 用途：无权限认证入口，如果没有自定义，将使用RestAccessDeniedEntryPoint
 *
 *
 */
public interface IAccessDeniedEntryPoint extends AuthenticationEntryPoint {

}