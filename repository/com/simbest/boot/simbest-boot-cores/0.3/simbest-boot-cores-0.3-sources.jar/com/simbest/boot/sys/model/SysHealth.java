package com.simbest.boot.sys.model;

import io.swagger.annotations.ApiModel;
import lombok.*;

/**
 * 用途：系统健康检查模型
 *
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "系统管理-系统健康检查模型")
public class SysHealth {

    private Boolean result;

    private String message;

    //应用主机
    private String hostIp;

    //应用主机端口
    private Integer hostPort;

}