package com.simbest.boot.uums.web.role;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.uums.api.user.UumsSysUserRoleApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 系统用户角色管理控制器
 * 提供用户与角色关联的REST API接口：
 * - 管理用户与角色的关联关系
 * - 支持批量分配和移除用户角色
 * - 提供角色成员管理功能
 */
@SuppressWarnings("ALL")
@Api(tags = {"2-统一用户管理", "用户角色管理"}, description = "提供用户与角色关联关系的管理功能，包括用户角色的分配和回收、批量更新用户角色、用户角色的查询和管理等")
@RestController
@RequestMapping(value = {"/uums/sys/user/role", "/sys/uums/user/role"})
public class UumsSysUserRoleController {

    @Autowired
    private UumsSysUserRoleApi uumsSysUserRoleApi;

    @PostMapping(value = {"/deleteByIdCustom", "/sso/deleteByIdCustom", "/api/deleteByIdCustom"})
    @ApiOperation(value = "删除用户角色信息", notes = "删除用户角色信息",tags={"角色人员API"})
    @ApiImplicitParam(name = "id", value = "用户角色ID",  dataType = "String", paramType = "query")
    public JsonResponse deleteByIdCustom(@RequestParam String id) {
        return uumsSysUserRoleApi.deleteByIdCustom(id);
    }

    /**
     * 指定角色新增人员
     * @return
     */
    @PostMapping(value = {"/createRoleUsers","/createRoleUsers/sso","/api/createRoleUsers"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", dataType = "String",paramType = ""),
            @ApiImplicitParam(name = "usernames", value = "OA账，多个逗号分隔", dataType = "String",paramType = "query")
    })
    @ApiOperation(value = "指定角色新增人员", notes = "指定角色新增人员",tags={"角色人员API"})
    public JsonResponse createRoleUsers(@RequestParam(required = false) String roleId,
                                        @RequestParam(required = false) String usernames){
        return uumsSysUserRoleApi.createRoleUsers(roleId,usernames);
    }
}