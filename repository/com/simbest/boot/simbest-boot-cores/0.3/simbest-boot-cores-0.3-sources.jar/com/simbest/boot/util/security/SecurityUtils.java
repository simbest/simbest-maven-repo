package com.simbest.boot.util.security;

import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.IUser;
import com.simbest.boot.util.ApplicationContextProvider;
import com.simbest.boot.util.DateUtil;
import com.simbest.boot.util.encrypt.AesEncryptor;
import com.simbest.boot.util.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.Assert;

import java.util.Date;

/**
 * 用途：安全工具类
 * 提供用户认证、鉴权和密码管理等安全相关功能
 */
@Slf4j
public final class SecurityUtils {

    public static AppConfig appConfig = ApplicationContextProvider.getBean(AppConfig.class);
    private SecurityUtils() {

    }

    /**
     * 更新当前用户信息
     * 在用户信息发生变更时更新当前认证上下文中的用户信息
     * 
     * @param newuser 新的用户信息对象
     */
    public static void updateCurrentUser(IUser newuser) {
        Assert.notNull(newuser, "变更的用户信息不可为空！");
        Authentication existingAuth = SecurityContextHolder.getContext().getAuthentication();
        Assert.notNull(existingAuth, "当前认证信息不能为空！");
        UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(
                newuser, existingAuth.getCredentials(), existingAuth.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(existingAuth);

//        if (authentication != null) {
//            if (authentication.getPrincipal() instanceof IUser) {
//                IUser currentUser = (IUser) authentication.getPrincipal();
//                if(currentUser.getUsername().equals(newuser.getUsername())){
//                    currentUser.setCurrentBloc(newuser.getCurrentBloc());
//                    currentUser.setCurrentCorp(newuser.getCurrentCorp());
//                    currentUser.setBelongCompanyCode(newuser.getBelongCompanyCode());
//                    currentUser.setBelongCompanyName(newuser.getBelongCompanyName());
//                    currentUser.setBelongCompanyTypeDictDesc(newuser.getBelongCompanyTypeDictDesc());
//                    currentUser.setBelongCompanyTypeDictValue(newuser.getBelongCompanyTypeDictValue());
//                    currentUser.setBelongDepartmentCode(newuser.getBelongDepartmentCode());
//                    currentUser.setBelongDepartmentName(newuser.getBelongDepartmentName());
//                    currentUser.setBelongOrgCode(newuser.getBelongOrgCode());
//                    currentUser.setBelongOrgName(newuser.getBelongOrgName());
//                    SecurityContextHolder.getContext().setAuthentication(authentication);
//                }
//            }
//        }
    }

    /**
     * 获取当前登录用户信息
     * 从Spring Security上下文中获取当前用户，如果未认证则返回null
     * 
     * @return 当前登录的用户对象，如果未登录则返回null
     */
    public static IUser getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            if (authentication.getPrincipal() instanceof IUser) {
                return (IUser) authentication.getPrincipal();
            }
            else {
                if(authentication.getPrincipal() != null) {
                    log.warn("SecurityContextHolder包含Authentication信息，但返回认证主体Principal不是IUser，请检查Redis缓存，目前返回的Principal类型为【{}】,toString后为【{}】", authentication.getPrincipal().getClass(), authentication.getPrincipal().toString());
                }
                else{
                    log.warn("SecurityContextHolder包含Authentication信息，但返回认证主体Principal为空，请检查Redis缓存，目前返回的Principal为空，authentication是【{}】", authentication.toString());
                }
                return null;
            }
        }
        log.warn("SecurityContextHolder的Authentication为空，无法获取认证主体Principal，请检查代码Session或API的access_token");
        return null;
    }

    /**
     * 获取当前登录用户的用户名
     * 从当前用户对象中获取用户名，如果未登录则返回null
     *
     * @return 当前用户的用户名，未登录则返回null
     */
    public static String getCurrentUserName() {
        String userName = null;
        IUser authUser = getCurrentUser();
        if(null != authUser){
            userName = authUser.getUsername();
        }
        return userName;
    }


    /**
     * 检查当前用户是否已认证
     * 通过检查用户权限确定是否已完成身份验证
     *
     * @return 如果用户已认证返回true，否则返回false
     */
    public static boolean isAuthenticated() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        if (authentication != null) {
            return authentication.getAuthorities()
                    .stream()
                    .noneMatch(grantedAuthority -> grantedAuthority.getAuthority()
                            .equals(AuthoritiesConstants.ANONYMOUS));
        }
        return false;
    }

    /**
     * 检查当前用户是否具有指定权限
     * 方法名来自Servlet API中的isUserInRole()
     *
     * @param authority 需要检查的权限
     * @return 如果当前用户具有该权限返回true，否则返回false
     */
    public static boolean hasPermission(String authority) {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        if (authentication != null) {
            return authentication.getAuthorities()
                    .stream()
                    .anyMatch(grantedAuthority -> grantedAuthority.getAuthority()
                            .equals(authority));
        }
        return false;
    }

    /**
     * 检查用户是否具有任一指定权限
     * 只要具有参数数组中的任一权限即判定为通过
     * 
     * @param authorities 需要检查的权限数组
     * @return 如果用户具有任一指定权限则返回true，否则返回false
     */
    public static boolean hasAnyPermission(String[] authorities) {
        for(String authority : authorities){
            if(hasPermission(authority)){
                return true;
            }
        }
        return false;
    }

    /**
     * 获取通用授权密码
     * 根据用户名和当前时间生成授权密钥，并从Redis获取对应的授权密码
     * 
     * @param authUsername 授权用户名
     * @return 授权密码，如果不存在则返回null
     */
    public static String getRefinePassword(String authUsername){
        String currDateHour = DateUtil.getDateStr("yyyyMMddHH");
        String anyPasswordKey = String.format(ApplicationConstants.REFINE_ANY_PASSWORD, currDateHour, authUsername);
        return RedisUtil.getGlobal(anyPasswordKey);
    }

    /**
     * 获取加密后的授权密码
     * 返回AES加密的密文，并进行MD5再次编码，便于密码比对
     * 
     * @param authUsername 授权用户名
     * @return 经过MD5编码的授权密码，如果授权密码不存在则返回null
     */
    public static String getRefinePasswordMd5(String authUsername){
        String asePassword = getRefinePassword(authUsername);
        return null == asePassword ? null : DigestUtils.md5Hex(asePassword);
    }

    /**
     * 获取授权码中申请人的OA账号信息
     * 从AES加密的授权码中提取申请人的账号
     * 
     * @param authUsername 授权用户名
     * @return 申请人的OA账号，如果解析失败则返回null
     */
    public static String getRefinePasswordApplyUsername(String authUsername){
        String asePassword = getRefinePassword(authUsername);
        String appAuthCodeValue = AesEncryptor.staticDecrypt(asePassword);
        String applyUsername = StringUtils.substringAfterLast(appAuthCodeValue,":");
        return null == applyUsername ? null : applyUsername;
    }


    /**
     * 检查单点登录访问权限
     * 验证单点登录请求的合法性，确保在有效时间内且未被重复使用
     * 前后1分钟内，未作单点认证，返回true，可进行单点；否则返回false，不可认证。
     *
     * @param url 访问的URL
     * @param username 用户名
     * @param ts 13位时间戳
     * @param tk username+appConfig.getSsoSalt()+ts进行32位MD5计数
     * @param appcode 应用代码
     * @return 如果检查通过返回true，否则返回false
     */
    public static boolean nssoAccessCheck(String url, String username, String ts, String tk, String appcode){
        boolean checkResult = false;
        Assert.notNull(username, "新单点认证username不可为空");
        Assert.notNull(appcode, "新单点认证appcode不可为空");
        // ts/tk 缺失或为字面量"null"时，按鉴权失败处理（返回false，由调用方抛出BadCredentials），避免抛异常导致500
        if(StringUtils.isEmpty(ts) || "null".equalsIgnoreCase(ts)){
            log.error("NEWSSO-attemptAuthentication-ERROR-TS-【{}】，账号【{}】时间【{}】应用【{}】，时间戳缺失或非法！", url, username, ts, appcode);
            return false;
        }
        if(StringUtils.isEmpty(tk) || "null".equalsIgnoreCase(tk)){
            log.error("NEWSSO-attemptAuthentication-ERROR-TOKEN-【{}】，账号【{}】时间【{}】应用【{}】，令牌缺失或非法！", url, username, ts, appcode);
            return false;
        }
        long tsTime;
        try {
            tsTime = Long.parseLong(ts);
        } catch (NumberFormatException e) {
            log.error("NEWSSO-attemptAuthentication-ERROR-TS-FORMAT-【{}】，账号【{}】时间【{}】应用【{}】，时间戳格式非法！", url, username, ts, appcode);
            return false;
        }
        Date requestTime = new Date(tsTime);
        Date currentTime = new Date();
        Date lastTime = DateUtil.subMinutes(currentTime, appConfig.getSsoTime());
        Date nextTime = DateUtil.addMinutes(currentTime, appConfig.getSsoTime());
        if(tk.equalsIgnoreCase(nssoTkGet(username,ts))) {
            //请求发生在前后1分钟内，允许认证
            if (DateUtil.compareTimestamp(requestTime, lastTime) > 0 && DateUtil.compareTimestamp(nextTime, requestTime) > 0) {
                String nssoUserAccessKey = String.format(ApplicationConstants.NSSO_USER_ACCESS, username, DateUtil.getDate(requestTime, "yyyyMMddHHmmss"), tk);
                //两分钟内认证过，不可再次使用相同单点加密串进行认证
                if (StringUtils.isEmpty(RedisUtil.getGlobal(nssoUserAccessKey))) {
                    checkResult = true;
                    RedisUtil.setGlobal(nssoUserAccessKey, nssoUserAccessKey, 120); // 2分钟内时效
                }
                else{
                    log.error("NEWSSO-attemptAuthentication-ERROR-REUSED-【{}】，账号【{}】时间【{}】令牌【{}】应用【{}】，重复调用！", url, username, ts, tk, appcode);
                }
            }
            else{
                log.error("NEWSSO-attemptAuthentication-ERROR-TIME-【{}】，账号【{}】时间【{}】令牌【{}】应用【{}】，时间非法！", url, username, ts, tk, appcode);
            }
        }
        else {
            log.error("NEWSSO-attemptAuthentication-ERROR-TOKEN-【{}】，账号【{}】时间【{}】令牌【{}】应用【{}】，令牌非法！", url, username, ts, tk, appcode);
        }
        return checkResult;
    }

    /**
     * 生成单点登录认证令牌
     * 根据账号明文和13位时间戳获取单点登录的tk令牌
     * 
     * @param username 用户名
     * @param ts 13位时间戳
     * @return 生成的单点登录认证令牌
     */
    public static String nssoTkGet(String username, String ts){
        return DigestUtils.md5Hex(username+appConfig.getSsoSalt()+ts);
    }
}