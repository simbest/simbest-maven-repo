package com.simbest.boot.security.auth.authentication.wxmp;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;

/**
 * 微信公众号认证令牌
 * 
 * 主要功能：
 * 1. 实现微信公众号的身份认证
 * 2. 继承自Spring Security的AbstractAuthenticationToken
 * 3. 支持认证前状态的令牌管理
 * 
 * 认证流程：
 * 1. 接收微信公众号的appid和认证凭据
 * 2. 创建未认证状态的令牌
 * 3. 通过认证提供者完成身份验证
 * 
 * 应用场景：
 * - 微信公众号OAuth2登录
 * - 用户身份验证
 * - 支持自动创建新用户
 */
public class WxmpCodeAuthenticationToken extends AbstractAuthenticationToken {

    /**
     * 认证主体
     * 存储微信公众号的appid
     * 用于：
     * 1. 标识具体的微信公众号
     * 2. 调用微信开放接口
     * 3. 验证请求的合法性
     */
    @Setter
    @Getter
    private Object principal;

    /**
     * 认证凭据
     * 包含微信公众号认证所需的各项信息
     * 包括：
     * 1. 应用代码(appcode)
     * 2. 公众号ID(appid)
     * 3. 登录code
     * 4. 自动创建用户标志
     */
    @Setter @Getter
    private WxmpAuthenticationCredentials credentials;

    /**
     * 创建认证前状态的认证令牌
     * 
     * @param principal 认证主体，微信公众号的appid
     * @param credentials 认证凭据，包含认证所需的各项信息
     */
    public WxmpCodeAuthenticationToken(Object principal, WxmpAuthenticationCredentials credentials) {
        super(AuthorityUtils.NO_AUTHORITIES);
        this.principal = principal;
        this.credentials = credentials;
    }

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}