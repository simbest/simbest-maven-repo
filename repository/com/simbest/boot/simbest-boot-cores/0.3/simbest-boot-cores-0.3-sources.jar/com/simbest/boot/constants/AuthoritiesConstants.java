package com.simbest.boot.constants;

/**
 * 权限和认证相关常量定义类
 * 
 * 包含以下类别的常量：
 * 1. 角色常量：
 *    - 超级管理员、管理员、普通用户、匿名用户等角色定义
 *    - 角色前缀和通用角色标识
 * 
 * 2. 权限常量：
 *    - 基本权限类型：更新、删除等
 *    - 特殊权限：创建者、修改者等
 * 
 * 3. SSO（单点登录）相关常量：
 *    - UUMS认证参数：用户名、密码等
 *    - API认证参数：关键字、令牌等
 *    - 应用标识和认证信息
 * 
 * 4. 密码和登录安全：
 *    - 密码重置和加密相关
 *    - 登录尝试次数限制
 *    - 登录失败处理
 * 
 * 5. 错误消息常量：
 *    - 权限不足提示
 *    - 账户状态提示
 *    - 认证错误提示
 *    - OAuth2相关错误
 * 
 * 注意事项：
 * 1. 所有常量均为public static final，不可修改
 * 2. 错误消息应当清晰明确，便于用户理解
 * 3. 登录安全参数可根据实际需求调整
 */
public class AuthoritiesConstants {

    // 角色常量
    public static final String SUPER_ADMIN = "ROLE_SUPER";
    public static final String ROLE_ADMIN = "ROLE_ADMIN";
    public static final String USER = "ROLE_USER";
    public static final String ANONYMOUS = "ROLE_ANONYMOUS";
    public static final String ROLE_PREFIX = "ROLE_";
    public static final String ROLE = "role";

    // 权限常量
    public static final String PERMISSION = "permission";
    public static final String PERMISSION_UPDATE = "PERMISSION_UPDATE";
    public static final String PERMISSION_DELETE = "PERMISSION_DELETE";
    public static final String PERMISSION_CREATOR = "creator";
    public static final String PERMISSION_MODIFIER = "modifier";

    // SSO认证参数
    public static final String SSO_UUMS_USERNAME = "username";
    public static final String SSO_UUMS_PASSWORD = "password";
    public static final String SSO_API_KEYWORD = "keyword";
    public static final String SSO_API_KEYTYPE = "keytype";
    public static final String SSO_API_USERNAME = "loginuser";
    public static final String SSO_API_APP_CODE = "appcode";
    public static final String SSO_API_UID = "uid";
    public static final String SSO_API_TIME = "ts";
    public static final String SSO_API_TOKEN = "tk";
    public static final String SSO_AUTH_HADMIN = "hadmin";

    // 密码重置相关
    public static final String USER_RESET_PASSWORD_TYPE = "USER_RESET_PASSWORD";
    public static final String USER_RESET_PASSWORD_NAME = "默认密码";
    public static final int PASSWORD_SALT_LENGTH = 12;

    // 登录安全配置
    public static final int ATTEMPT_LOGIN_INIT_TIMES = 1;
    public static final int ATTEMPT_LOGIN_MAX_TIMES = 5;
    public static final int ATTEMPT_LOGIN_FAILED_WAIT_SECONDS = 60 * 5;
    public static final String LOGIN_FAILED_KEY = "LOGIN_FAILED:";

    // 权限和访问控制提示
    public static final String ACCESS_FORBIDDEN = "权限不足，禁止访问!";
    public static final String BUSINESS_FORBIDDEN = "业务禁止访问!";

    // 认证错误提示
    public static final String UsernameNotFoundException = "账号或密码错误!";
    public static final String BadCredentialsException = "账号或密码错误";
    public static final String AccountExpiredException = "账户已到期";
    public static final String DisabledException = "账号已禁用";
    public static final String LockedException = "账号已锁定";
    public static final String CredentialsExpiredException = "账户密码已到期";
    public static final String InsufficientAuthenticationException = "账户密码或验证码错误";
    public static final String AttempMaxLoginFaildException = "错误登录超过"+ATTEMPT_LOGIN_MAX_TIMES+"次，锁定"+ATTEMPT_LOGIN_FAILED_WAIT_SECONDS/60+"分钟";
    public static final String InternalAuthenticationServiceException = "权限认证错误";

    // OAuth2错误提示
    public static final String OAUTH2_UNKNOW_CLIENT = "错误的客户端：";
}