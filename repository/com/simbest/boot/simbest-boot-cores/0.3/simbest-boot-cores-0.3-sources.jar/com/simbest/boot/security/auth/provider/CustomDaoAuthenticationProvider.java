package com.simbest.boot.security.auth.provider;

import com.simbest.boot.config.AppConfig;
import com.simbest.boot.security.auth.a4.A4PasswordCheck;
import com.simbest.boot.security.auth.authentication.LoginPreWebAuthenticationDetails;
import com.simbest.boot.security.auth.authentication.UumsAuthentication;
import com.simbest.boot.security.auth.authentication.UumsAuthenticationCredentials;
import com.simbest.boot.security.util.AuthenticationUtil;
import com.simbest.boot.security.util.CheckIpIsDevOpsResult;
import com.simbest.boot.util.ApplicationContextProvider;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.security.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;

import static com.simbest.boot.constants.ApplicationConstants.COMMA;
import static com.simbest.boot.constants.ErrorCodeConstants.LOGIN_ERROR_INVALIDATE_USERNAME_PASSWORD;
import static com.simbest.boot.constants.ErrorCodeConstants.LOGIN_ERROR_OPT_IP;
import static com.simbest.boot.security.auth.a4.A4PasswordCheck.*;

/**
 * 用途：自定义密码认证器
 *
 *
 */
@Slf4j
public class CustomDaoAuthenticationProvider extends DaoAuthenticationProvider {

    private GenericAuthenticationChecker genericAuthenticationChecker;

    private RsaEncryptor rsaEncryptor;

    public CustomDaoAuthenticationProvider(GenericAuthenticationChecker genericAuthenticationChecker, RsaEncryptor rsaEncryptor){
        this.genericAuthenticationChecker = genericAuthenticationChecker;
        this.rsaEncryptor = rsaEncryptor;
    }

    /**
     * 主数据、公文、预警平台等自有组织+人员信息的应用，CustomDaoAuthenticationProvider执行一次
     * 车辆、协配等依靠主数据应用除UumsHttpValidationAuthenticationProvider执行认证外，CustomDaoAuthenticationProvider也会执行一次
     * @param userDetails
     * @param authentication
     * @throws AuthenticationException
     */
    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
        if (authentication.getCredentials() == null) {
            log.error("Authentication failed: 密码不能为空");
            throw new BadCredentialsException(messages.getMessage(
                    "AbstractUserDetailsAuthenticationProvider.badCredentials",
                    "密码不能为空----Bad credentials"));
        }
        //只有主数据中是UsernamePasswordAuthenticationToken。其他应用都是UumsAuthentication
        String userSubmitPasswordEncode = null;
        String userSubmitPasswordDecode = null;
        String a4Password = null;
        String appcode = null;
        if(authentication instanceof UumsAuthentication) {
            UumsAuthenticationCredentials credentials = (UumsAuthenticationCredentials) authentication.getCredentials();
            userSubmitPasswordEncode = credentials.getPassword();
            userSubmitPasswordDecode = rsaEncryptor.decrypt(userSubmitPasswordEncode);
            a4Password = userSubmitPasswordEncode;
            appcode = credentials.getAppcode();
        }
        else if(authentication instanceof UsernamePasswordAuthenticationToken) {
            userSubmitPasswordEncode = authentication.getCredentials().toString();
            userSubmitPasswordDecode = userSubmitPasswordEncode;
            a4Password = rsaEncryptor.encrypt(userSubmitPasswordEncode);
            AppConfig appConfig = ApplicationContextProvider.getBean(AppConfig.class);
            appcode = appConfig.getAppcode();
        }
        else{
            log.warn("CustomDaoAuthenticationProvider不支持此认证令牌【{}】，无法通过认证！", authentication);
            throw new BadCredentialsException(LOGIN_ERROR_INVALIDATE_USERNAME_PASSWORD);
        }


        if(StringUtils.isEmpty(userSubmitPasswordEncode)){
            log.error("用户加密密码不能为空！");
            throw new BadCredentialsException(LOGIN_ERROR_INVALIDATE_USERNAME_PASSWORD);
        }
        else if(StringUtils.isEmpty(userSubmitPasswordDecode)){
            log.error("用户解密密码不能为空！");
            throw new BadCredentialsException(LOGIN_ERROR_INVALIDATE_USERNAME_PASSWORD);
        }
        //比对维护授权码
        String anyPassword = SecurityUtils.getRefinePasswordMd5(userDetails.getUsername());
        if(StringUtils.isEmpty(anyPassword) || !(DigestUtils.md5Hex(userSubmitPasswordDecode)).equalsIgnoreCase(anyPassword)){
            log.debug("AnyPassword【{}】与用户密码【{}】不匹配", anyPassword, userSubmitPasswordDecode);
            //判断是否启用4A认证
            A4PasswordCheck a4PasswordCheck = ApplicationContextProvider.getBean(A4PasswordCheck.class);
            //4A认证
            if(a4PasswordCheck.shouldCheckFrom4A(userDetails.getUsername())){
                log.info(String.format(A4_AUTH_NEED, userDetails.getUsername()));
                try {
                    boolean a4CheckRet = a4PasswordCheck.passwordCheckFrom4A(userDetails.getUsername(), a4Password, appcode, null);
                    if(a4CheckRet){
                        log.debug("4A认证主体【{}】凭证所提供的密码【{}】校验通过！", userDetails.getUsername(), userSubmitPasswordDecode);
                        log.info(String.format(A4_AUTH_SUCCESS, userDetails.getUsername(), userSubmitPasswordDecode, appcode));
                        return;
                    }
                    else {
                        log.error(String.format(A4_AUTH_FAIL, userDetails.getUsername(), userSubmitPasswordDecode, appcode));
                        throw new BadCredentialsException(String.format(A4_AUTH_FAIL, userDetails.getUsername(), userSubmitPasswordDecode, appcode));
                    }
                }
                catch (Exception e ){
                    log.error(String.format(A4_AUTH_EXCEPTION, userDetails.getUsername(), userSubmitPasswordDecode, appcode));
                    throw new BadCredentialsException(String.format(A4_AUTH_EXCEPTION, userDetails.getUsername(), userSubmitPasswordDecode, appcode));
                }
            }
            //OA认证
            else {
                log.info(String.format(A4_AUTH_NO_NEED, userDetails.getUsername()));
                //不是维护授权码，则比对输入的密码和（数据库中）密码，实际是由UserDetailsService接口的loadUserByUsername的实现提供的，可以是物理数据库，当然也可以是主数据
                if (!getPasswordEncoder().matches(userSubmitPasswordDecode, userDetails.getPassword())) {
                    log.warn("CustomDaoAuthenticationProvider认证用户【{}】密码【{}】加密密码【{}】解密密码【{}】认证失败",
                            userDetails.getUsername(), userDetails.getPassword(), userSubmitPasswordEncode, userSubmitPasswordDecode);
                    throw new BadCredentialsException(LOGIN_ERROR_INVALIDATE_USERNAME_PASSWORD);
                } else {
                    log.debug("认证主体【{}】凭证所提供的密码【{}】校验通过！", userDetails.getUsername(), userSubmitPasswordDecode);
                    return;
                }
            }
        }
        //授权码认证
        else {
            LoginPreWebAuthenticationDetails preDetail = (LoginPreWebAuthenticationDetails) authentication.getDetails();
            CheckIpIsDevOpsResult checkDevOpsResult = AuthenticationUtil.checkIpIsDevOps(preDetail.getRemoteAddress());
            if(checkDevOpsResult.isCheckRet()){
                log.debug("维护授权码认证主体【{}】通过AnyPassword校验通过", userDetails.getUsername());
            }
            else{
                log.error(String.format(LOGIN_ERROR_OPT_IP, String.join(COMMA, checkDevOpsResult.getWhiteIps()) , checkDevOpsResult.getCurrentIp()));
                throw new BadCredentialsException(LOGIN_ERROR_INVALIDATE_USERNAME_PASSWORD);
            }
        }
    }


    /**
     * 注释下面代码，因为应用验证userDetails.getPassword()用于在Http请求为空，不可能进行createSuccessAuthentication。
     * 而UUMS验证，Authentication不可能为UumsAuthentication，这是在UumsHttpValidationAuthenticationController组装成了UsernamePasswordAuthenticationToken，在数据库进行验证
     */
//    @Override
//    protected Authentication createSuccessAuthentication(Object principal, Authentication authentication, UserDetails user) {
//        authentication = super.createSuccessAuthentication(principal, authentication, user);
//        if(null != authentication.getCredentials() && authentication.getCredentials() instanceof UumsAuthenticationCredentials) {
//            UumsAuthenticationCredentials credentials = (UumsAuthenticationCredentials) authentication.getCredentials();
//            return genericAuthenticationChecker.authChek(authentication, credentials.getAppcode());
//        }
//        else {
//            return authentication;
//        }
//    }

}