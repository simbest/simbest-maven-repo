package com.simbest.boot.uums.api.app;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.SimpleConfig;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 应用配置管理API接口
 * 
 * 提供以下功能：
 * 1. 应用配置信息的查询操作
 * 2. 支持基于接口类型的配置检索
 * 3. 实现应用配置的安全访问控制
 * 4. 提供配置信息的格式化输出
 * 5. 实现与UUMS系统的配置同步
 */
@Component
@Slf4j
public class UumsSysAppConfigApi {
    private static final String USER_MAPPING = "/action/app/config/";
    private static final String SSO = "/sso";
    @Autowired
    private AppConfig config;
    //private String uumsAddress="http://localhost:8080/uums";
    @Autowired
    private RsaEncryptor encryptor;

    /**
     * 根据接口类型获取app配置信息
     * @param interfaceStyle
     * @param username
     * @param appcode
     * @return
     */
    public SimpleConfig findAppConfigByStyle( String interfaceStyle, String username, String appcode){
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findAppConfigByStyle"+SSO)
                .param( AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param( AuthoritiesConstants.SSO_API_APP_CODE,appcode )
                .param("interfaceStyle", String.valueOf(interfaceStyle))
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleConfig auth = JacksonUtils.json2obj(json, SimpleConfig.class);
        return auth;
    }
}