package com.simbest.boot.security.auth.provider.sso.service;


/**
 * 用途：单点登录验证服务
 * 
 * 
 */
public interface SsoAuthenticationService extends Comparable<SsoAuthenticationService> {

    Integer ORDER_RSA = 1;
    Integer ORDER_MOCHA = 2;
    Integer ORDER_3DES = 3;

    /**
     * 解密请求中的用户名
     * @param encodeKeyword 加密关键字
     * @return String 用户名
     */
    String decryptKeyword(String encodeKeyword);

    Integer getOrder();

}