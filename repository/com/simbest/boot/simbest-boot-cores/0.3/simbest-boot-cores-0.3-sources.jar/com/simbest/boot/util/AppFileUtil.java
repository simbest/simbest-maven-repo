package com.simbest.boot.util;


import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.simbest.boot.base.enums.StoreLocation;
import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.sys.model.SysFile;
import com.simbest.boot.util.encrypt.UrlEncryptor;
import com.simbest.boot.util.json.JacksonUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;
import javax.imageio.stream.ImageOutputStream;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.simbest.boot.constants.ApplicationConstants.*;
import static com.simbest.boot.sys.web.SysFileController.*;
import static com.simbest.boot.util.encrypt.AbstractEncryptor.DEFAULT_URL_ENCODING;

/**
 * <strong>Title : AppFileUtil</strong><br>
 * <strong>Description : 文件处理工具类</strong><br>
 * <strong>功能包括：</strong><br>
 * 1. 文件上传与下载处理<br>
 * 2. 文件类型校验与过滤<br>
 * 3. 文件名称处理与路径解析<br>
 * 4. 文件存储（本地磁盘、FTP/SFTP、FastDFS等）<br>
 * 5. 图片压缩与处理<br>
 * 6. 临时文件与目录管理<br>
 * 7. URL文件下载与处理<br>
 */
@Slf4j
@Component
@SuppressWarnings("ALL")
public class AppFileUtil {

//    private static final String UPLOAD_FILE_PATTERN =
//            "(jpg|jpeg|png|gif|bmp|doc|docx|xls|xlsx|pdf|ppt|pptx|txt|rar|zip|7z|ogg|swf|webm" +
//                    "|html|htm|mov|flv|mp4|mp3|amr|csv|bpmn|apk|asf|wps|gw|xlsb|xlsm|tif|mht|ai|et|ett|xml|dif|xla|uof|ofd|dbf|rtf)$";
//    private static Pattern pattern = Pattern.compile(UPLOAD_FILE_PATTERN);

    /**
     * 允许上传的文件格式正则表达式
     * 默认支持图片、文档、压缩包、音视频等常用文件格式
     */
    @Value("${app.file.util.upload.pattern:(jpg|jpeg|png|gif|bmp|doc|docx|xls|xlsx|pdf|ppt|pptx|txt|rar|zip|7z|ogg|swf|webm|html|htm|mov|flv|mp4|mp3|amr|csv|bpmn|apk|asf|wps|gw|xlsb|xlsm|tif|mht|ai|et|ett|xml|dif|xla|uof|ofd|dbf|rtf)$}")
    private String UPLOAD_FILE_PATTERN;

    /**
     * 文件格式匹配模式
     */
    private static Pattern pattern = null;

    /**
     * Nginx静态文件存储路径
     */
    public static final String NGINX_STATIC_FILE_LOCATION = "/uploadFiles";

    /**
     * 应用配置信息
     */
    @Autowired
    private AppConfig config;

    /**
     * Spring上下文工具
     */
    @Autowired
    private SpringContextUtil springContextUtil;

    /**
     * URL加密解密工具
     */
    @Autowired
    private UrlEncryptor urlEncryptor;

    /**
     * SFTP文件传输工具
     */
    private AppFileSftpUtil sftpUtil;

    /**
     * 服务器文件存储位置
     */
    @Getter
    public StoreLocation serverUploadLocation;

    /**
     * 默认压缩图片宽度像素
     */
    private String DEFAULT_COMPRESS_IMAGE_WIDTH = "2000";    //默认分辨率图片像素宽

    /**
     * 默认压缩图片输出格式
     */
    private String DEFAULT_COMPRESS_IMAGE_SUFFIX = "jpg";    //默认分辨率压缩图片后缀

    /**
     * 初始化方法
     * 初始化文件格式匹配模式、存储位置以及SFTP工具
     */
    @PostConstruct
    public void init() {
        this.pattern = Pattern.compile(UPLOAD_FILE_PATTERN);
        serverUploadLocation = Enum.valueOf(StoreLocation.class, config.getUploadLocation());
        try {
            sftpUtil = springContextUtil.getBean(AppFileSftpUtil.class);
        }
        catch (NoSuchBeanDefinitionException e) {
        }
        finally {
            if(null == sftpUtil){
                log.info("请注意应用没有配置SFTP，请检查配置是否需要，如不需要，则忽略该条警告信息！");
            }
        }
    }

    /**
     * 判断是否允许上传指定的文件类型
     * 通过文件后缀名与配置的允许上传的文件格式正则表达式进行匹配
     *
     * @param fileName 文件名
     * @return 如果文件类型允许上传返回true，否则返回false
     */
    public static boolean validateUploadFileType(String fileName) {
        String fileSuffix = getFileSuffix(fileName).toLowerCase();
        if(StringUtils.isNotEmpty(fileSuffix)) {
            Matcher matcher = pattern.matcher(fileSuffix);
            boolean ret = matcher.matches();
            log.debug("判断文件【{}】是否合法结果为【{}】", fileName, ret);
            return ret;
        }
        //没有后缀的文件，也允许上传
        else{
            return true;
        }
    }

    /**
     * 将文件名称进行MD5编码
     * 解决文件保存服务器时的乱码问题，并进行XSS防护
     *
     * @param fileName 原始文件名
     * @return MD5编码后的文件名（保留原扩展名）
     */
    public String getFileNameMd5(String fileName) {
        //文件名称通过URL解码
        fileName = urlEncryptor.decrypt(fileName);
        //特殊字符过滤，防止XSS漏洞
        fileName = JacksonUtils.escapeString(fileName);
        String fileBaseName = getFileBaseName(fileName);
        String fileSuffix = getFileSuffix(fileName);
        fileName = DigestUtils.md5Hex(fileBaseName) + DOT + fileSuffix;
        return fileName;
    }

    /**
     * 根据路径提取文件名
     * 支持URL路径和本地文件路径
     *
     * @param fileUrl 文件URL或本地路径
     * @return 文件名（带扩展名）
     */
    public static String getFileName(String fileUrl) {
        Assert.notNull(fileUrl, fileUrl+"文件URL路径不能为空");
        String fileName = null;
        String suffix = null;
        try {
            suffix = FilenameUtils.getExtension(new URL(fileUrl).getPath());
            if(StringUtils.isEmpty(suffix)){
                fileName = getFileNameByContentDisposition(fileUrl);
            }
            else{
                fileName = FilenameUtils.getName(new URL(fileUrl).getPath());
            }
        } catch (MalformedURLException e) {
            fileName = FilenameUtils.getName(fileUrl);
            log.warn("文件URL路径【{}】无法通过URL获取路径，直接通过工具类提取文件全称为【{}】", fileUrl, fileName);
        }
        try {
            fileName = URLDecoder.decode(fileName, DEFAULT_URL_ENCODING);
        }catch (UnsupportedEncodingException e1){
            log.warn("文件URL路径【{}】无法通过URL获取路径，直接通过工具类提取文件全称为【{}】", fileUrl, fileName);
            Exceptions.printException(e1);
        }
        return fileName;
    }

    /**
     * 根据路径提取文件基本名称（不含扩展名）
     * 支持URL路径和本地文件路径
     *
     * @param fileUrl 文件URL或本地路径
     * @return 文件基本名称（不含扩展名）
     */
    public static String getFileBaseName(String fileUrl) {
        Assert.notNull(fileUrl, fileUrl+"文件URL路径不能为空");
        String fileBaseName = null;
        String suffix = null;
        try {
            suffix = FilenameUtils.getExtension(new URL(fileUrl).getPath());
            if(StringUtils.isEmpty(suffix)){
                String fileName = getFileNameByContentDisposition(fileUrl);
                fileBaseName = FilenameUtils.getBaseName(fileName);
            }
            else{
                fileBaseName = FilenameUtils.getBaseName(new URL(fileUrl).getPath());
            }
        } catch (MalformedURLException e) {
            fileBaseName = FilenameUtils.getBaseName(fileUrl);
            log.warn("文件URL路径【{}】无法通过URL获取路径，直接通过工具类提取文件名称为【{}】", fileUrl, fileBaseName);
        }
        return fileBaseName;
    }

    /**
     * 根据路径提取文件扩展名
     * 支持URL路径和本地文件路径
     *
     * @param fileUrl 文件URL或本地路径
     * @return 文件扩展名（不含点）
     */
    public static String getFileSuffix(String fileUrl) {
        Assert.notNull(fileUrl, fileUrl+"文件URL路径不能为空");
        String suffix = null;
        try {
            suffix = FilenameUtils.getExtension(new URL(fileUrl).getPath());
            if(StringUtils.isEmpty(suffix)) {
                String fileName = getFileNameByContentDisposition(fileUrl);
                suffix = FilenameUtils.getExtension(fileName);
            }
        } catch (MalformedURLException e) {
            suffix = FilenameUtils.getExtension(fileUrl);
            log.warn("文件URL路径【{}】无法通过URL获取路径，直接通过工具类提取文件后缀为【{}】", fileUrl, suffix);
        }
        return suffix;
    }

    /**
     * 通过URL连接头信息获取文件名称
     * 从HTTP响应的Content-Disposition头中提取文件名
     *
     * @param fileUrl 文件URL
     * @return 从Content-Disposition头中提取的文件名
     */
    public static String getFileNameByContentDisposition(String fileUrl) {
        String fileName = null;
        HttpURLConnection urlConnection = null;
        try {
//            URL connUrl = new URL(fileUrl);
            //引入galimatias,解决不规范文件名导致文件下载异常
            URL connUrl = io.mola.galimatias.URL.parse(fileUrl).toJavaURL();
            urlConnection = (HttpURLConnection) connUrl.openConnection();
            String fieldValue = urlConnection.getHeaderField("Content-Disposition");
            fieldValue = StringUtils.replaceIgnoreCase(fieldValue, "filename=", "filename=");
            fileName = StringUtils.substringAfter(fieldValue, "filename=");
            fileName = StringUtils.remove(fileName, "\"");
            fileName = StringUtils.remove(fileName, "\'");
            fileName = new String(fileName.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
        } catch (Exception e) {
            if (urlConnection != null) {
                urlConnection.disconnect();
                urlConnection = null;
            }
            Exceptions.printException(e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
                urlConnection = null;
            }
        }
        return fileName;
    }

    /**
     * 返回 text/plain image/jpeg image/png video/mp4  application/vnd.openxmlformats-officedocument.wordprocessingml.document 等文件类型
     * @param file
     * @return
     */
    public static String getFileType(File file) {
        try {
            return Files.probeContentType(file.toPath());
        } catch (IOException e) {
            return null;
        }
    }

    public static boolean isImage(File file) {
        Assert.notNull(file, "图片文件不能为空");
        boolean ret = false;
        try {
            Image image = ImageIO.read(file);
            if (image != null) {
                ret = true;
            }
        } catch(Exception ex) {
        }
        log.debug("判断文件【{}】是否为图片结果为【{}】", file.getName(), ret);
        return ret;
    }

    public static String replaceSlash(String directory) {
        directory = StringUtils.replace(directory, "\\", SLASH);
        directory = StringUtils.replace(directory, "//", SLASH);
        return directory;
    }

    private String diskUpload(byte[] uploadFileBytes, File targetFileDirectory, String fileName) throws IOException {
        if (!targetFileDirectory.exists()) {
            FileUtils.forceMkdir(targetFileDirectory);
            log.debug("目录不存在，即将强制创建路径【{}】", targetFileDirectory.getPath());
        }
        String pathTmp = targetFileDirectory.getPath() + ApplicationConstants.SLASH + getFileNameMd5(fileName);
        pathTmp = replaceSlash(pathTmp);
        Path path = Paths.get(pathTmp);
        Files.write(path, uploadFileBytes);
        String filePath = path.toString();
        log.debug("通过Disk方式上传文件，返回路径为：【{}】", filePath);
        return filePath;
    }

    private String fastDfsUpload(byte[] uploadFileBytes, String fileName) throws Exception {
        String filePath = FastDfsClient.uploadFile(uploadFileBytes, fileName, getFileSuffix(fileName));
        log.debug("通过FastDFS方式上传文件，返回路径为：【{}】", filePath);
        return filePath;
    }

    private String ftpSftpUpload(byte[] uploadFileBytes, String directory, String fileName) {
        directory = replaceSlash(directory);
        String filePath = sftpUtil.upload(directory, fileName, uploadFileBytes);
        log.debug("通过ftpSftp方式上传文件，返回路径为：【{}】", filePath);
        return filePath;
    }

    private SysFile buildSysFile(String filePath, String fileName, Long fileSize){
        SysFile sysFile = SysFile.builder().fileName(fileName).fileType(getFileSuffix(fileName)).storeLocation(serverUploadLocation)
                .filePath(StringUtils.replace(filePath, ApplicationConstants.SEPARATOR, ApplicationConstants.SLASH)).fileSize(fileSize)
                .downLoadUrl(DOWNLOAD_FULL_URL).apiFilePath(DOWNLOAD_FULL_URL_API).anonymousFilePath(DOWNLOAD_FULL_URL_ANONYMOUS).build();
        return sysFile;
    }

    /**
     * 将文件在远程URL读取后，再上传到指定存储位置
     * 支持多种存储方式：本地磁盘、FastDFS、FTP/SFTP
     * 
     * @param fileUrl   远程文件URL地址
     * @param directory 存储的相对路径
     * @return 上传后的文件信息对象
     * @throws Exception 如果读取或上传过程中发生错误
     */
    public SysFile uploadFromUrl(String fileUrl, String directory) throws Exception {
        String filePath = null;
        String fileName = null;
        Long fileSize = null;
        HttpURLConnection urlConnection = null;
        UrlFile urlFile = null;
        try {
            urlFile = openAndConnectUrl(fileUrl);
            urlConnection = urlFile.getConn();
            if(StringUtils.isEmpty(urlFile.getFileName())){
                //URL连接上面没有文件名
                fileName = CodeGenerator.systemUUID();
            }
            fileName = fileName + DOT + urlFile.getFileSuffix();
            switch (serverUploadLocation) {
                case disk:
                    File targetFileDirectory = createAutoUploadDirFile(directory);
                    File storeFile = new File(targetFileDirectory.getAbsolutePath() + ApplicationConstants.SLASH + getFileNameMd5(fileName));
                    FileUtils.touch(storeFile); //覆盖文件
                    FileUtils.copyURLToFile(urlFile.getConnUrl(), storeFile);
                    filePath = storeFile.getAbsolutePath();
                    fileSize = storeFile.length();
                    break;
                case fastdfs:
                    File tmpFile = createTempFile();
                    FileUtils.copyURLToFile(urlFile.getConnUrl(), tmpFile);
                    filePath = FastDfsClient.uploadFile(IOUtils.toByteArray(new FileInputStream(tmpFile)),
                            fileName, getFileSuffix(fileName));
                    fileSize = tmpFile.length();
                    break;
                case ftp:
                    log.debug("基于ftp，方式同sftp");
                case sftp:
                    File tmpFile1 = createTempFile();
                    FileUtils.copyURLToFile(urlFile.getConnUrl(), tmpFile1);
                    sftpUtil.upload(createAutoUploadDirPath(directory), fileName, tmpFile1);
                    filePath = config.getUploadPath() + createAutoUploadDirPath(directory) + ApplicationConstants.SLASH + getFileNameMd5(fileName);
                    break;
            }
            urlConnection.disconnect();
        } catch (Exception e) {
            if (urlConnection != null) {
                urlConnection.disconnect();
                urlConnection = null;
            }
            Exceptions.printException(e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
                urlConnection = null;
            }
        }
        SysFile sysFile = SysFile.builder().fileName(fileName).fileType(urlFile.getFileSuffix()).storeLocation(serverUploadLocation)
                .filePath(filePath).fileSize(fileSize).downLoadUrl(DOWNLOAD_FULL_URL).apiFilePath(DOWNLOAD_FULL_URL_API)
                .anonymousFilePath(DOWNLOAD_FULL_URL_ANONYMOUS).build();
        log.debug("上传文件成功，具体信息如下： {}", sysFile.toString());
        return sysFile;
    }

    /**
     * 上传单个MultipartFile文件到指定目录
     * 
     * @param directory 相对存储目录
     * @param multipartFile 待上传的MultipartFile对象
     * @return 上传成功后的文件信息对象
     * @throws Exception 如果上传过程中发生错误
     */
    public SysFile uploadFile(String directory, MultipartFile multipartFile) throws Exception {
        return uploadFile(directory, multipartFile, null);
    }

    /**
     * 上传单个MultipartFile文件到指定目录，可自定义文件名
     * 
     * @param directory 相对存储目录
     * @param multipartFile 待上传的MultipartFile对象
     * @param fileName 自定义的文件名(为null时使用原文件名)
     * @return 上传成功后的文件信息对象
     * @throws Exception 如果上传过程中发生错误
     */
    public SysFile uploadFile(String directory, MultipartFile multipartFile, String fileName) throws Exception {
        Assert.notNull(multipartFile, "上传文件不能为空");
        List<SysFile> sysFileList = uploadFiles(directory, Arrays.asList(multipartFile), fileName);
        if(sysFileList.size() > ZERO){
            return sysFileList.get(ZERO);
        }
        else{
            return null;
        }
    }


    /**
     * 批量上传多个MultipartFile文件到指定目录
     * 使用系统自动创建的年月日格式目录结构
     * 
     * @param directory 相对存储目录
     * @param multipartFiles 待上传的MultipartFile集合
     * @return 上传成功的文件信息对象列表
     * @throws Exception 如果上传过程中发生错误
     */
    public List<SysFile> uploadFiles(String directory, Collection<MultipartFile> multipartFiles) throws Exception {
        return uploadFiles(directory, multipartFiles,null);
    }

    /**
     * 批量上传多个MultipartFile文件到指定目录，可自定义文件名
     * 使用系统自动创建的年月日格式目录结构
     * 
     * @param directory 相对存储目录
     * @param multipartFiles 待上传的MultipartFile集合
     * @param fileName 自定义文件名(为空时使用原文件名)
     * @return 上传成功的文件信息对象列表
     * @throws Exception 如果上传过程中发生错误
     */
    public List<SysFile> uploadFiles(String directory, Collection<MultipartFile> multipartFiles, String fileName) throws Exception {
        Assert.notEmpty(multipartFiles, "上传文件不能为空");
        List<SysFile> fileModels = Lists.newArrayList();
        for (MultipartFile multipartFile : multipartFiles) {
            long fileSize = multipartFile.getSize();
            if (multipartFile.isEmpty()) {
                log.warn("上传文件流为空，继续循环处理上传文件");
                continue;
            } else if (fileSize == 0L){
                log.warn("上传文件流大小为空，继续循环处理上传文件");
                continue;
            }
            String uploadFilePath = null;
            String uploadFileName = null;
            if(StrUtil.isNotEmpty(fileName)){
                uploadFileName = urlEncryptor.decrypt(fileName);
            }
            else{
                uploadFileName = getFileName(multipartFile.getOriginalFilename());
            }
            //特殊字符过滤，防止XSS漏洞
            uploadFileName = JacksonUtils.escapeString(uploadFileName);
            if(validateUploadFileType(uploadFileName)) {
                log.debug("即将以【{}】方式上传【{}】文件", serverUploadLocation, uploadFileName);
                //File tempFile = File.createTempFile("tmp", null);
                //multipartFile.transferTo(tempFile);
                //置为null是为了告诉gc此块内存可以回收
                //multipartFile = null;
                switch (serverUploadLocation) {
                    case disk:
//                        uploadFilePath = diskUpload(multipartFile.getBytes(), createAutoUploadDirFile(directory), uploadFileName);
//                        uploadFilePath = diskUpload(IOUtils.toByteArray(multipartFile.getInputStream()), createAutoUploadDirFile(directory), uploadFileName);
//                        解决java.lang.OutOfMemoryError: Java heap space
                        File saveFile = new File(createAutoUploadDirFile(directory).getPath().concat(ApplicationConstants.SEPARATOR).concat(getFileNameMd5(uploadFileName)));
                        InputStream sourceInput = multipartFile.getInputStream();
                        FileOutputStream outTarget = new FileOutputStream(saveFile);
                        IOUtils.copy(sourceInput, outTarget);
                        outTarget.close();
                        IOUtils.closeQuietly(sourceInput);
                        uploadFilePath = saveFile.getPath();
                        log.debug("文件保存路径"+uploadFilePath);
                        break;
                    case fastdfs:
                        uploadFilePath = fastDfsUpload(multipartFile.getBytes(), uploadFileName);
                        //uploadFilePath = fastDfsUpload(FileUtil.readBytes(tempFile), uploadFileName);
                        break;
                    case ftp:
                        log.debug("基于ftp，方式同sftp");
                    case sftp:
                        uploadFilePath = ftpSftpUpload(multipartFile.getBytes(), createAutoUploadDirPath(directory), uploadFileName);
                        //uploadFilePath = ftpSftpUpload(FileUtil.readBytes(tempFile), createAutoUploadDirPath(directory), uploadFileName);
                        break;
                }
                Assert.notNull(uploadFilePath, String.format("文件以【%s】方式上传失败", serverUploadLocation));
                SysFile sysFile = buildSysFile(uploadFilePath, uploadFileName, fileSize);
                log.debug("【{}】上传成功，具体信息如下: 【{}】", uploadFileName, sysFile.toString());
                fileModels.add(sysFile);
            } else {
                log.warn("【{}】文件类型受限，不允许上传！", uploadFileName);
                throw new RuntimeException(uploadFileName+"文件类型受限，不允许上传！");
            }
        }
        return fileModels;
    }

    /**
     * 批量上传多个MultipartFile文件到自定义目录
     * 使用指定的目录路径，不进行年月日自动分类
     * 
     * @param customDirectory 自定义的目录路径
     * @param multipartFiles 待上传的MultipartFile集合
     * @return 上传成功的文件信息对象列表
     * @throws Exception 如果上传过程中发生错误
     */
    public List<SysFile> customUploadFiles(String customDirectory, Collection<MultipartFile> multipartFiles) throws Exception {
        return customUploadFiles(customDirectory, multipartFiles, null);
    }

    /**
     * 批量上传多个MultipartFile文件到自定义目录，可自定义文件名
     * 使用指定的目录路径，不进行年月日自动分类
     * 
     * @param customDirectory 自定义的目录路径
     * @param multipartFiles 待上传的MultipartFile集合
     * @param fileName 自定义文件名(为空时使用原文件名)
     * @return 上传成功的文件信息对象列表
     * @throws Exception 如果上传过程中发生错误
     */
    public List<SysFile> customUploadFiles(String customDirectory, Collection<MultipartFile> multipartFiles, String fileName) throws Exception {
        Assert.notEmpty(multipartFiles, "上传文件不能为空");
        List<SysFile> fileModels = Lists.newArrayList();
        for (MultipartFile multipartFile : multipartFiles) {
            if (multipartFile.isEmpty()) {
                log.warn("上传文件流为空，继续循环处理上传文件");
                continue;
            } else if (multipartFile.getSize() == 0L){
                log.warn("上传文件流大小为空，继续循环处理上传文件");
                continue;
            }
            String uploadFilePath = null;
            String uploadFileName = StrUtil.isEmpty(fileName) ? getFileName(multipartFile.getOriginalFilename()) : fileName;
            if(validateUploadFileType(uploadFileName)) {
                log.debug("即将以【{}】方式上传【{}】文件", serverUploadLocation, uploadFileName);
                switch (serverUploadLocation) {
                    case disk:
                        uploadFilePath = diskUpload(multipartFile.getBytes(), forceCreateCustomUploadDirectory(customDirectory), uploadFileName);
                        break;
                    case fastdfs:
//                        String filePath = FastDfsClient.uploadFile(IOUtils.toByteArray(multipartFile.getInputStream()), fileName, getFileSuffix(fileName));
//                        filePath = FastDfsClient.uploadFile(FileUtil.readBytes(uploadFile), filename, getFileSuffix(filename));
                        uploadFilePath = fastDfsUpload(multipartFile.getBytes(), uploadFileName);
                        break;
                    case ftp:
                        log.debug("基于ftp，方式同sftp");
                    case sftp:
                        uploadFilePath = ftpSftpUpload(multipartFile.getBytes(), customDirectory, uploadFileName);
                        break;
                }
                Assert.notNull(uploadFilePath, String.format("文件以【%s】方式上传失败", serverUploadLocation));
                SysFile sysFile = buildSysFile(uploadFilePath, uploadFileName, multipartFile.getSize());
                log.debug("【{}】上传成功，具体信息如下: 【{}】", uploadFileName, sysFile.toString());
                fileModels.add(sysFile);
            } else {
                log.warn("【{}】文件类型受限，不允许上传！", uploadFileName);
                throw new RuntimeException(uploadFileName+"文件类型受限，不允许上传！");
            }
        }
        return fileModels;
    }

    /**
     * 上传本地文件，并保存在系统默认的年月日目录下
     * 根据当前日期自动创建年/月/日目录结构
     * 
     * @param directory 基础目录
     * @param localFile 本地文件对象
     * @param fileName 自定义文件名(为空时使用原文件名)
     * @return 上传成功后的文件信息对象
     * @throws Exception 如果上传过程中发生错误
     */
    public SysFile uploadFromLocalAutoDirectory(String directory, File localFile, String fileName) throws Exception {
        return uploadFromLocal(createAutoUploadDirPath(directory), localFile, fileName);
    }

    /**
     * 上传本地文件，并保存在指定远程服务器路径
     * 直接使用指定路径，不做年月日目录处理
     * 
     * @param customDirectory 自定义目录路径
     * @param localFile 本地文件对象
     * @param fileName 自定义文件名(为空时使用原文件名)
     * @return 上传成功后的文件信息对象
     * @throws Exception 如果上传过程中发生错误
     */
    public SysFile uploadFromLocalCustomDirectory(String customDirectory, File localFile, String fileName) throws Exception {
        return uploadFromLocal(customDirectory, localFile, fileName);
    }

    /**
     * 上传本地文件的内部实现方法
     * 支持多种存储方式：本地磁盘、FastDFS、FTP/SFTP
     * 
     * @param directory 存储目录
     * @param uploadFile 待上传的本地文件
     * @param fileName 自定义文件名(为空时使用原文件名)
     * @return 上传成功后的文件信息对象
     * @throws Exception 如果上传过程中发生错误
     */
    private SysFile uploadFromLocal(String directory, File uploadFile, String fileName) throws Exception {
        SysFile sysFile = null;
        String uploadFilePath = null;
        String uploadFileName = StrUtil.isEmpty(fileName) ? getFileName(uploadFile.getName()) : fileName;
        //特殊字符过滤，防止XSS漏洞
        uploadFileName = JacksonUtils.escapeString(uploadFileName);
        if(validateUploadFileType(uploadFileName)) {
            log.debug("即将以【{}】方式上传【{}】文件", serverUploadLocation, uploadFileName);
            switch (serverUploadLocation) {
                case disk:
                    uploadFilePath = diskUpload(FileUtil.readBytes(uploadFile), forceCreateCustomUploadDirectory(directory), uploadFileName);
                    break;
                case fastdfs:
                    uploadFilePath = fastDfsUpload(FileUtil.readBytes(uploadFile), uploadFileName);
                    break;
                case ftp:
                    log.debug("基于ftp，方式同sftp");
                case sftp:
                    uploadFilePath = ftpSftpUpload(FileUtil.readBytes(uploadFile), directory, uploadFileName);
                    break;
            }
            Assert.notNull(uploadFilePath, String.format("文件以【%s】方式上传失败", serverUploadLocation));
            sysFile = buildSysFile(uploadFilePath, uploadFileName, uploadFile.length());
            log.debug("【{}】上传成功，具体信息如下: 【{}】", uploadFileName, sysFile.toString());

        } else {
            log.warn("【{}】文件类型受限，不允许上传！", uploadFileName);
            throw new RuntimeException(uploadFileName+"文件类型受限，不允许上传！");
        }
        return sysFile;
    }


    private BufferedImage toBufferedImage(Image image) {
        if (image instanceof BufferedImage) {
            return (BufferedImage) image;
        }
        // This code ensures that all the pixels in the image are loaded
        image = new ImageIcon(image).getImage();
        BufferedImage bimage = null;
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        try {
            int transparency = Transparency.OPAQUE;
            GraphicsDevice gs = ge.getDefaultScreenDevice();
            GraphicsConfiguration gc = gs.getDefaultConfiguration();
            bimage = gc.createCompatibleImage(image.getWidth(null), image.getHeight(null), transparency);
        } catch (HeadlessException e) {
            // The system does not have a screen
        }
        if (bimage == null) {
            // Create a buffered image using the default color model
            int type = BufferedImage.TYPE_INT_RGB;
            bimage = new BufferedImage(image.getWidth(null), image.getHeight(null), type);
        }
        // Copy image to buffered image
        Graphics g = bimage.createGraphics();
        // Paint the image onto the buffered image
        g.drawImage(image, 0, 0, null);
        g.dispose();
        return bimage;
    }

    /**
     * 图片压缩上传
     * 按指定质量压缩图片并上传到存储位置
     * 
     * @param imageFile 原始图片文件
     * @param quality 压缩质量(0-1之间的浮点数)
     * @param directory 存储目录
     * @return 上传成功后的文件信息对象
     */
    public SysFile uploadCompressImage(File imageFile, float quality, String directory) {
        String filePath = null;
        String fileName = imageFile.getName();
        ByteArrayOutputStream baos = null;
        ImageOutputStream ios = null;
        ByteArrayInputStream bais = null;
        ImageWriter writer;
        try {
            BufferedImage image = null;
            if(getFileSuffix(imageFile.getName()).equalsIgnoreCase("bmp")){
                image = ImageIO.read(imageFile);
            } else {
//            java上传图片，压缩、更改尺寸等导致变色（表层蒙上一层红色）
//            https://blog.csdn.net/qq_25446311/article/details/79140008?tdsourcetag=s_pctim_aiomsg
                Image bufferedImage = Toolkit.getDefaultToolkit().getImage(imageFile.getAbsolutePath());
                image = this.toBufferedImage(bufferedImage);// Image to BufferedImage
            }
            Iterator<ImageWriter> writers = ImageIO.getImageWritersBySuffix("jpg");
            if (!writers.hasNext())
                throw new IllegalStateException("No writers found");
            writer = (ImageWriter) writers.next();
            ImageWriteParam param = writer.getDefaultWriteParam();
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            param.setCompressionQuality(quality);
            baos = new ByteArrayOutputStream(32768);
            switch (serverUploadLocation) {
                case disk:
                    File targetFileDirectory = createAutoUploadDirFile(directory);
                    File compressedFile = new File(targetFileDirectory.getAbsolutePath() + ApplicationConstants.SLASH + getFileNameMd5(fileName));
                    log.debug("压缩图片保存路径为 :" + compressedFile.getPath());
                    ios = ImageIO.createImageOutputStream(baos);
                    FileImageOutputStream output = new FileImageOutputStream(compressedFile);
                    writer.setOutput(output);
                    writer.write(null, new IIOImage(image, null, null), param);
                    output.flush();
                    writer.dispose();
                    ios.flush();
                    ios.close();
                    baos.close();
                    output = null;
                    writer = null;
                    ios = null;
                    baos = null;
                    filePath = compressedFile.getAbsolutePath();
                    break;
                case fastdfs:
                    ios = ImageIO.createImageOutputStream(baos);
                    File tmpFile = createTempFile(getFileSuffix(imageFile.getName()));
                    output = new FileImageOutputStream(tmpFile);
                    writer.setOutput(output);
                    writer.write(null, new IIOImage(image, null, null), param);
                    output.flush();
                    writer.dispose();
                    ios.flush();
                    ios.close();
                    baos.close();
                    output = null;
                    writer = null;
                    ios = null;
                    baos = null;
                    filePath = FastDfsClient.uploadLocalFile(tmpFile.getAbsolutePath());
                    tmpFile.deleteOnExit();
                    break;
                case ftp:
                    log.debug("基于ftp，方式同sftp");
                case sftp:
                    ios = ImageIO.createImageOutputStream(baos);
                    tmpFile = createTempFile(getFileSuffix(imageFile.getName()));
                    output = new FileImageOutputStream(tmpFile);
                    writer.setOutput(output);
                    writer.write(null, new IIOImage(image, null, null), param);
                    output.flush();
                    writer.dispose();
                    ios.flush();
                    ios.close();
                    baos.close();
                    output = null;
                    writer = null;
                    ios = null;
                    baos = null;
                    sftpUtil.upload(createAutoUploadDirPath(directory), fileName, tmpFile);
                    filePath = createAutoUploadDirPath(directory) + ApplicationConstants.SLASH + fileName;
                    tmpFile.deleteOnExit();
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            Exceptions.printException(e);
        } finally {
            if (baos != null)
                try {
                    baos.close();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
        }
        SysFile sysFile = SysFile.builder().fileName(fileName).fileType(getFileSuffix(imageFile.getAbsolutePath())).storeLocation(serverUploadLocation)
                .filePath(filePath).fileSize(imageFile.length()).downLoadUrl(DOWNLOAD_FULL_URL).apiFilePath(DOWNLOAD_FULL_URL_API)
                .anonymousFilePath(DOWNLOAD_FULL_URL_ANONYMOUS).build();
        log.debug("上传文件成功，具体信息为【{}】", sysFile.toString());
        return sysFile;
    }

    /**
     * 图片压缩上传（按宽度等比压缩）
     * 根据指定宽度等比例压缩图片并上传到存储位置
     * 
     * @param imageFile 原始图片文件
     * @param compressWidth 压缩后的目标宽度
     * @param directory 存储目录
     * @param fileSuffix 输出文件后缀名
     * @return 上传成功后的文件信息对象
     */
    public SysFile uploadCompressImage2(File imageFile, String compressWidth, String directory, String fileSuffix) {
        Integer realCompressWidth = StringUtils.isEmpty(compressWidth) ? Integer.parseInt(DEFAULT_COMPRESS_IMAGE_WIDTH) : Integer.parseInt(compressWidth);
        String realFileSuffix = StringUtils.isEmpty(fileSuffix) ? DEFAULT_COMPRESS_IMAGE_SUFFIX : fileSuffix;
        String filePath = null;
        long  compressImageLength=0;
        String fileName = imageFile.getName();
        ImageWriter writer;
        try {
            BufferedImage image = null;
            if(getFileSuffix(fileName).equalsIgnoreCase("bmp")){
                image = ImageIO.read(imageFile);
            } else {
//            java上传图片，压缩、更改尺寸等导致变色（表层蒙上一层红色）
                Image bufferedImage = Toolkit.getDefaultToolkit().getImage(imageFile.getAbsolutePath());
                image = this.toBufferedImage(bufferedImage);// Image to BufferedImage
            }
            int width = image.getWidth(); //原始分辨率宽
            int height= image.getHeight(); //原始分辨率高
            long size = imageFile.length();
            log.debug("文件【{}】后缀【{}】大小【{}】分辨率宽【{}】分辨率高【{}】", fileName, realFileSuffix, size, width, height);
            float scale = width < realCompressWidth ? 1 : (float) realCompressWidth/width;  //计算压缩比例
            int dowithWidth = (int) (scale * width);    //计算分辨率宽
            int doWithHeight = (int) (scale * height);  //计算分辨率高
            BufferedImage finalImage = null;
            finalImage = new BufferedImage(dowithWidth, doWithHeight, BufferedImage.TYPE_INT_RGB);
            //重新绘制图片
            finalImage.getGraphics().drawImage(image.getScaledInstance(dowithWidth, doWithHeight, java.awt.Image.SCALE_SMOOTH), 0, 0, null);
            switch (serverUploadLocation) {
                case disk:
                    File targetFileDirectory = createAutoUploadDirFile(directory);
                    File compressedFile = new File(targetFileDirectory.getAbsolutePath() + ApplicationConstants.SLASH + getFileNameMd5(fileName));
                    log.debug("压缩图片保存路径为 :" + compressedFile.getPath());
                    FileOutputStream output = new FileOutputStream(compressedFile);
                    ImageIO.createImageOutputStream(output);
                    ImageIO.write(finalImage, realFileSuffix, output);
                    output.flush();
                    long fileSize = compressedFile.length();
                    compressImageLength = fileSize;
                    output = null;
                    writer = null;
                    filePath = compressedFile.getAbsolutePath();
                    break;
                case fastdfs:
                    File tmpFile = createTempFile(getFileSuffix(fileName));
                    output = null;
                    writer = null;
                    filePath = FastDfsClient.uploadLocalFile(tmpFile.getAbsolutePath());
                    tmpFile.deleteOnExit();
                    break;
                case ftp:
                    log.debug("基于ftp，方式同sftp");
                case sftp:
                    tmpFile = createTempFile(getFileSuffix(fileName));
                    output = null;
                    writer = null;
                    sftpUtil.upload(createAutoUploadDirPath(directory), fileName, tmpFile);
                    filePath = createAutoUploadDirPath(directory) + ApplicationConstants.SLASH + fileName;
                    tmpFile.deleteOnExit();
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            Exceptions.printException(e);
        } finally {
        }

        SysFile sysFile = SysFile.builder().fileName(fileName).fileType(getFileSuffix(imageFile.getAbsolutePath())).storeLocation(serverUploadLocation)
                .filePath(filePath).fileSize(compressImageLength).downLoadUrl(DOWNLOAD_FULL_URL).apiFilePath(DOWNLOAD_FULL_URL_API)
                .anonymousFilePath(DOWNLOAD_FULL_URL_ANONYMOUS).build();
        log.debug("上传文件成功，具体信息为【{}】", sysFile.toString());
        return sysFile;
    }

    /**
     * 通过URL下载图片并压缩上传
     * 
     * @param imageUrl 图片URL地址
     * @param quality 压缩质量(0-1之间的浮点数)
     * @param directory 存储目录
     * @return 上传成功后的文件信息对象
     */
    public SysFile uploadCompressImageFromUrl(String imageUrl, float quality, String directory) {
        File imageFile = downloadFileFromUrl(imageUrl);
        return uploadCompressImage(imageFile, quality, directory);
    }

    /**
     * 创建自动分类的上传目录路径
     * 根据当前日期自动创建年/月/日格式的目录结构
     * 
     * @param directory 基础目录
     * @return 包含年月日结构的完整目录路径
     */
    public String createAutoUploadDirPath(String directory) {
        StringBuffer dir = new StringBuffer();
        if (Boolean.valueOf(config.getFileDirYmdFlag())){
            dir.append(config.getUploadPath()).append(SLASH).append(DateUtil.getDateStr("yyyy"));
            dir.append(SLASH).append(DateUtil.getDateStr("MM"));
            dir.append(SLASH).append(config.getAppcode());
            dir.append(SLASH).append(directory);
        }else{
            dir.append(directory);
        }
        return replaceSlash(dir.toString());
    }

    /**
     * 创建自动分类的上传目录文件对象
     * 根据当前日期自动创建年/月/日格式的目录结构，并返回File对象
     * 
     * @param directory 基础目录
     * @return 创建好的目录File对象
     * @throws IOException 如果目录创建失败
     */
    public File createAutoUploadDirFile(String directory) throws IOException {
        String storePath = createAutoUploadDirPath(directory);
        File targetFileDirectory = new File(storePath);
        if (!targetFileDirectory.exists()) {
            FileUtils.forceMkdir(targetFileDirectory);
            log.debug("目录不存在，即将强制创建路径【{}】", storePath);
        }
        return targetFileDirectory;
    }

    /**
     * 强制创建自定义上传目录
     * 如果目录不存在则创建，存在则跳过
     * 
     * @param directory 自定义目录路径
     * @return 创建好的目录File对象
     * @throws IOException 如果目录创建失败
     */
    public File forceCreateCustomUploadDirectory(String directory) throws IOException {
        String storePath = directory;
        File targetFileDirectory = new File(storePath);
        if (!targetFileDirectory.exists()) {
            FileUtils.forceMkdir(targetFileDirectory);
            log.debug("目录不存在，即将强制创建路径【{}】", storePath);
        }
        return targetFileDirectory;
    }

    /**
     * 创建临时目录
     * 在系统临时目录下创建指定名称的子目录
     * 
     * @param dir 临时目录名称
     * @return 创建好的临时目录File对象
     */
    public File createTempDirectory(String dir){
        File tempDirectory = new File(config.getUploadTmpFileLocation().concat(ApplicationConstants.SEPARATOR)
                .concat(CodeGenerator.systemUUID()).concat(ApplicationConstants.SEPARATOR).concat(dir));
        try {
            FileUtils.forceMkdir(tempDirectory);
        } catch (IOException e) {
            Exceptions.printException(e);
            return null;
        }
        log.debug("创建的临时目录为【{}】", tempDirectory.getAbsolutePath());
        return tempDirectory;
    }


    /**
     * 创建临时文件
     * 在系统临时目录下创建一个带随机名称的临时文件
     * 
     * @return 创建好的临时文件File对象
     */
    public File createTempFile(){
        return createTempFile(CodeGenerator.randomChar(4));
    }

    /**
     * 创建指定名称的临时文件
     * 在系统临时目录下创建指定名称的临时文件
     * 
     * @param filename 临时文件名称
     * @return 创建好的临时文件File对象
     */
    public File createTempFileWithName(String filename){
        File tempFile = null;
        try {
//            tempFile = File.createTempFile("tmp", DOT+getFileSuffix(filename));
            tempFile = new File(config.getUploadTmpFileLocation().concat(ApplicationConstants.SEPARATOR)
                    .concat(CodeGenerator.systemUUID()).concat(ApplicationConstants.SEPARATOR)
                    .concat(filename));
            FileUtils.forceDeleteOnExit(tempFile);
            FileUtils.touch(tempFile);
        } catch (IOException e) {
            Exceptions.printException(e);
        }
        log.debug("创建的临时文件路径为【{}】", tempFile.getAbsolutePath());
        return tempFile;
    }

    /**
     * 在指定目录创建指定名称的临时文件
     * 
     * @param dir 临时目录
     * @param filename 临时文件名称
     * @return 创建好的临时文件File对象
     */
    public File createTempFile(String dir, String filename){
        File tempFile = null;
        try {
            tempFile = new File(config.getUploadTmpFileLocation().concat(ApplicationConstants.SEPARATOR)
                    .concat(CodeGenerator.systemUUID()).concat(ApplicationConstants.SEPARATOR)
                    .concat(dir).concat(ApplicationConstants.SEPARATOR).concat(filename));
            FileUtils.forceDeleteOnExit(tempFile);
            FileUtils.touch(tempFile);
        } catch (IOException e) {
            Exceptions.printException(e);
        }
        log.debug("创建的临时文件路径为【{}】", tempFile.getAbsolutePath());
        return tempFile;
    }


    /**
     * 创建指定后缀的临时文件
     * A convenience method to create a temporary file with specific suffix
     * 
     * @param suffix 文件后缀（不含点号）
     * @return 创建好的临时文件File对象
     */
    public File createTempFile(String suffix){
        File tempFile = null;
        try {
            tempFile = new File(config.getUploadTmpFileLocation().concat(ApplicationConstants.SEPARATOR)
                    .concat(CodeGenerator.systemUUID() + DOT + suffix));
            FileUtils.forceDeleteOnExit(tempFile);
            FileUtils.touch(tempFile);
        } catch (IOException e) {
            Exceptions.printException(e);
        }
        log.debug("创建的临时文件路径为【{}】", tempFile.getAbsolutePath());
        return tempFile;
    }

    /**
     * 从系统存储位置获取文件
     * 根据文件信息对象获取对应的实际文件
     * 
     * @param sysFile 文件信息对象
     * @return 实际存储的文件对象
     */
    public File getFileFromSystem(SysFile sysFile){
        if(null == sysFile.getStoreLocation()){
            log.debug("文件记录的存储位置为空，将通过【{}】方式下载文件【{}】", serverUploadLocation, sysFile.getFilePath());
            return getFileFromSystem(serverUploadLocation, sysFile);
        }
        else{
            log.debug("将通过【{}】方式下载文件【{}】", sysFile.getStoreLocation(), sysFile.getFilePath());
            return getFileFromSystem(sysFile.getStoreLocation(), sysFile);
        }
    }

    /**
     * 从指定存储位置获取文件
     * 根据存储位置和文件信息对象获取对应的实际文件
     * 
     * @param serverUploadLocation 服务器存储位置（disk/fastdfs/ftp/sftp）
     * @param sysFile 文件信息对象
     * @return 实际存储的文件对象
     */
    public File getFileFromSystem(StoreLocation serverUploadLocation, SysFile sysFile){
        Assert.notNull(serverUploadLocation, "文件保存位置不能为空!");
        Assert.notNull(serverUploadLocation, "文件路径不能为空!");
        File realFile = null;
        log.debug("即将以【{}】方式读取文件【{}】",serverUploadLocation, sysFile.getFilePath());
        switch (serverUploadLocation) {
            case disk:
                realFile = new File(sysFile.getFilePath());
                if(!realFile.exists()){
                    realFile = null;
                }
                break;
            case fastdfs:
                realFile = downloadFileFromUrl(config.getAppHostPort() + ApplicationConstants.SLASH + sysFile.getFilePath());
                break;
            case ftp:
                log.debug("基于ftp，方式同sftp");
            case sftp:
                //下载文件时每次打开-关闭FTP太费资源。因此，隐藏下面代码，改为配置Nginx的虚拟目录，直接提供URL进行下载
                //Nginx的虚拟目录参考
//                location  /uploadFiles/ {
//                        alias ${app.file.upload.path};
//                        autoindex on;
//                }
                if(config.isNgEnable()){
                    String nginxFileUrl;
                    if (BooleanUtil.toBoolean( config.getNgCustomUploadFlag()) ){
                        //自定义了Nginx映射目录
                        nginxFileUrl = StringUtils.replace(sysFile.getFilePath(), config.getNgCustomUploadPath(), config.getAppHostPort().concat(NGINX_STATIC_FILE_LOCATION));
                    }
                    else{
                        nginxFileUrl = StringUtils.replace(sysFile.getFilePath(), config.getUploadPath(), config.getAppHostPort().concat(NGINX_STATIC_FILE_LOCATION));
                    }
                    nginxFileUrl = StringUtils.replace(nginxFileUrl, "\\", SLASH);
                    log.debug("即将通过Nginx以【{}】方式通过URL【{}】下载文件【{}】", serverUploadLocation, nginxFileUrl, sysFile.getFileName());
                    realFile = downloadFileFromUrl(nginxFileUrl);
                }
                else {
                    log.warn("即将以【{}】方式通过路径【{}】下载文件【{}】", serverUploadLocation, sysFile.getFilePath(), sysFile.getFileName());
                    String directory = StringUtils.removeEnd(sysFile.getFilePath(), sysFile.getFileName());
                    realFile = sftpUtil.download2File(directory, sysFile.getFileName(), createTempFileWithName(sysFile.getFileName()));
                }
                break;
        }
        return realFile;
    }

    /**
     * 从指定目录下载文件
     * 根据目录和文件名获取文件对象
     * 
     * @param directory 文件所在目录
     * @param fileName 文件名
     * @return 下载的文件对象
     */
    public File downloadFileFromDir(String directory, String fileName){
        Assert.notNull(directory, "文件路径不能为空!");
        Assert.notNull(fileName, "文件名称不能为空!");
        File realFile = null;
        switch (serverUploadLocation) {
            case ftp:
                log.debug("基于ftp，方式同sftp");
            case sftp:
                realFile = createTempFile(getFileSuffix(fileName));
                sftpUtil.download2File(directory, fileName, realFile);
                break;
        }
        return realFile;
    }

    /**
     * 从指定目录下载文件并返回字节数组
     * 根据目录和文件名获取文件内容
     * 
     * @param directory 文件所在目录
     * @param fileName 文件名
     * @return 文件内容的字节数组
     */
    public byte[] downloadByteFromDir(String directory, String fileName){
        Assert.notNull(directory, "文件路径不能为空!");
        Assert.notNull(fileName, "文件名称不能为空!");
        byte[] realFileByte = null;
        switch (serverUploadLocation) {
            case ftp:
                log.debug("基于ftp，方式同sftp");
            case sftp:
                realFileByte = sftpUtil.download2Byte(directory, fileName);
                break;
        }
        return realFileByte;
    }

    /**
     * 从URL下载文件
     * 将远程URL指向的文件下载到本地临时目录
     * 
     * @param fileUrl 文件URL地址
     * @return 下载后的文件对象
     */
    public File downloadFileFromUrl(String fileUrl) {
        Assert.notNull(fileUrl, "下载链接地址不可为空");
        File targetFile = null;
        HttpURLConnection urlConnection = null;
        try {
            UrlFile urlFile = openAndConnectUrl(fileUrl);
            urlConnection = urlFile.getConn();
            if (null != urlConnection && urlConnection.getContentLengthLong() != 0) {
                try {
                    targetFile = createTempFileWithName(urlFile.getFileName());
                    FileUtils.copyURLToFile(urlFile.getConnUrl(), targetFile);
                    log.debug("即将从路径【{}】 下载文件保存至【{}】", fileUrl, targetFile.getAbsolutePath());
                }catch (FileNotFoundException e){
                    log.warn("URL目标文件不存在【{}】，错误信息为【{}】", urlFile.getConnUrl(), e.getMessage());
                    targetFile = null;
                }
            } else {
                log.error("从路径【{}】下载文件发生异常", fileUrl);
            }
        } catch (Exception e) {
            if (urlConnection!= null) {
                urlConnection.disconnect();
                urlConnection = null;
            }
            Exceptions.printException(e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
        return targetFile;
    }

    /**
     * 打开并连接URL
     * 处理URL连接并返回URL文件信息
     * 
     * @param remoteFileUrl 远程文件URL地址
     * @return URL文件信息对象
     * @throws Exception 如果连接过程中发生错误
     */
    private UrlFile openAndConnectUrl(String remoteFileUrl) throws Exception {
        //URL路径中有/分割的文件名，进行URL编码处理中文，否则不做处理
        String fileName = getFileName(remoteFileUrl);
        String suffix = getFileSuffix(remoteFileUrl);
        URL connUrl = null;
        HttpURLConnection urlConnection = null;
        try {
            //connUrl = new URL(remoteFileUrl);
            //引入galimatias,解决不规范文件名导致文件下载异常
            connUrl = io.mola.galimatias.URL.parse(remoteFileUrl).toJavaURL();
            urlConnection = (HttpURLConnection) connUrl.openConnection();
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod(ApplicationConstants.HTTPGET);
            urlConnection.connect();

        } catch (MalformedURLException e){
            log.warn("URL地址错误【{}】，错误信息为【{}】", remoteFileUrl, e.getMessage());
        }
        return UrlFile.builder().remoteFileUrl(remoteFileUrl).conn(urlConnection).connUrl(connUrl).fileName(fileName).fileSuffix(suffix).build();
    }

    /**
     * 删除系统文件
     * 根据文件信息对象删除实际存储的文件
     * 
     * @param sysFile 文件信息对象
     * @return 删除成功返回true，否则返回false
     */
    public boolean deleteFile(SysFile sysFile) {
        if(null == sysFile.getStoreLocation()){
            return deleteFile(serverUploadLocation, sysFile.getFilePath());
        }
        else{
            return deleteFile(sysFile.getStoreLocation(), sysFile.getFilePath());
        }
    }

    /**
     * 删除指定存储位置的文件
     * 根据存储位置和文件路径删除文件
     * 
     * @param serverUploadLocation 服务器存储位置（disk/fastdfs/ftp/sftp）
     * @param filePath 文件完整路径
     * @return 删除成功返回true，否则返回false
     */
    public boolean deleteFile(StoreLocation serverUploadLocation, String filePath) {
        Assert.notNull(serverUploadLocation, "文件保存位置不能为空!");
        Assert.notNull(serverUploadLocation, "文件路径不能为空!");
        boolean result = ApplicationConstants.TRUE;
        log.debug("即将以【{}】方式删除文件【{}】",serverUploadLocation, filePath);
        switch (serverUploadLocation) {
            case disk:
                try {
                    FileUtils.forceDelete(new File(filePath));
                } catch (Exception e) {
                    result = ApplicationConstants.FALSE;
                    Exceptions.printException(e);
                }
                break;
            case fastdfs:
                try {
                    FastDfsClient.deleteFile(filePath);
                } catch (Exception e) {
                    result = ApplicationConstants.FALSE;
                    Exceptions.printException(e);
                }
                break;
            case ftp:
                log.debug("基于ftp，方式同sftp");
            case sftp:
                try {
                    sftpUtil.deleteFile(filePath);
                } catch (Exception e) {
                    result = ApplicationConstants.FALSE;
                    Exceptions.printException(e);
                }
                break;
            default:
                break;
        }
        return result;
    }

    /**
     * 获取文件字节内容
     * 将文件内容读取为字节数组
     * 
     * @param filePath 文件路径
     * @return 文件内容的字节数组
     */
    public static byte[] getFileByte(String filePath){
        byte[] fileByte = null;
        try {
            if ( StringUtils.isEmpty( filePath ) ){
                return null;
            }
            ClassPathResource classPathResource = new ClassPathResource( filePath );
            BufferedInputStream bufferedInputStream = new BufferedInputStream( classPathResource.getInputStream() );
            fileByte = new byte[bufferedInputStream.available()];
            bufferedInputStream.read(fileByte);
            bufferedInputStream.close();
        } catch ( IOException e ) {
            Exceptions.printException(e);
        }
        return fileByte;
    }

    /**
     * Java获取文件类型的5种方法 https://www.163.com/dy/article/GBKUQ1GV0538NIYQ.html
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        String fileUrl1 = "http://10.92.81.163:8088/group1/M00/00/00/ClxQR1uWKAyAM4c4AAAyAsyPzjY83.docx";
        String fileUrl2 = "http://10.87.42.136:8088/maipdocument/夏季防洪防汛.doc";
        String fileUrl3 = "http://10.88.178.226:8088/bpsAttachment/ntxl/uploadedImg/zhengxiaolei.jpg?t=975";
        String fileUrl4 = "http://10.92.82.161:8088/anddoc/sys/file/download/anonymous?id=F504966687264677888";
        String fileUrl5 = "http://10.87.61.20:9090/cdp/sys/docFile/download?id=c04d5da9ecea4f5bbdbb24205eeb141f&fileName=2022年9月16日驻马店因铁路局施工导致一干驻马店-漯河主用光缆中断故障报告.doc";
        String fileUrl6 = "http://10.88.178.222:8080/entry/waittask/attachment?id=1952";

        String fileUrl7 = "C:\\Users\\admin\\Desktop\\授权码.jar";

//        AppFileUtil appFileUtil = new AppFileUtil();
//        //在downloadFileFromUrl时，createTempFile不能使用注入的config，否则会发生空指针报错
//        File downloadFile = appFileUtil.downloadFileFromUrl(fileUrl1);
//        System.out.println(downloadFile.getAbsolutePath());

        print(fileUrl1);
        print(fileUrl2);
        print(fileUrl3);
        print(fileUrl4);
        print(fileUrl5);
        print(fileUrl6);
        print(fileUrl7);
    }


    private static void print(String str1) throws MalformedURLException {
        System.out.println("#############################################################################");
        System.out.println(getFileName(str1));
        System.out.println(getFileBaseName(str1));
        System.out.println(getFileSuffix(str1));
    }

}