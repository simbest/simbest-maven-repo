package com.simbest.boot.component.repeat.lock;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.TimeUnit;

/**
 * 请求防重复提交注解
 * 
 * 主要功能：
 * 1. 标注需要防止重复提交的方法
 * 2. 支持自定义锁定时长和时间单位
 * 3. 支持自定义锁定键的生成策略
 * 4. 支持基于会话的请求控制
 * 
 * 应用场景：
 * 1. 表单提交防重复
 * 2. 支付操作防重复
 * 3. 敏感操作防重复
 * 4. 需要控制提交频率的接口
 * 
 * 使用方式：
 * ```java
 * @RequestLock(expire = 10, timeUnit = TimeUnit.SECONDS)
 * public void submitOrder(OrderDTO order) {
 *     // 业务逻辑
 * }
 * ```
 * 
 * 工作原理：
 * 1. 通过AOP拦截带有此注解的方法
 * 2. 根据方法信息和配置生成唯一的锁键
 * 3. 使用Redis实现分布式锁定
 * 4. 超时自动解锁，避免死锁
 * 
 * 注意事项：
 * 1. 合理设置锁定时间，避免影响正常业务
 * 2. 考虑是否需要启用会话校验
 * 3. 确保Redis服务的可用性
 * 4. 在分布式环境下使用相同的Redis实例
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RequestLock {

    /**
     * 锁定时长
     * 
     * 功能说明：
     * 1. 指定请求锁定的持续时间
     * 2. 在锁定期间，相同的请求将被拒绝
     * 3. 超过锁定时间后自动解锁
     * 
     * 配置建议：
     * 1. 根据业务操作的预期完成时间设置
     * 2. 考虑网络延迟和系统处理时间
     * 3. 避免设置过长，以免影响用户体验
     * 
     * @return long 锁定的时长，默认5个时间单位
     */
    long expire() default 5;

    /**
     * 锁定时长的时间单位
     * 
     * 功能说明：
     * 1. 指定expire()值的时间单位
     * 2. 支持秒、毫秒、分钟等多种时间单位
     * 3. 提供灵活的时间控制
     * 
     * 可选值：
     * - SECONDS：秒（默认）
     * - MILLISECONDS：毫秒
     * - MINUTES：分钟
     * - HOURS：小时
     * 
     * 使用建议：
     * 1. 短时操作建议使用秒或毫秒
     * 2. 长时操作可以使用分钟
     * 3. 根据业务需求选择合适的单位
     * 
     * @return TimeUnit 时间单位，默认为秒
     */
    TimeUnit timeUnit() default TimeUnit.SECONDS;

    /**
     * 锁定键的拼接字符
     * 
     * 功能说明：
     * 1. 用于生成锁定键时连接各个组成部分
     * 2. 确保生成的键的可读性和唯一性
     * 3. 支持自定义分隔符
     * 
     * 使用场景：
     * 1. 需要自定义锁键格式
     * 2. 特殊字符要求
     * 3. 调试和日志分析
     * 
     * 示例：
     * 默认使用"-"生成的键格式：
     * "sessionId-className-methodName-param1-param2"
     * 
     * @return String 拼接字符，默认为"-"
     */
    String splitStr() default "-";

    /**
     * 是否启用会话校验
     * 
     * 功能说明：
     * 1. 控制是否使用会话ID作为锁定键的一部分
     * 2. 影响锁定的粒度和范围
     * 3. 决定是否区分不同用户的请求
     * 
     * 应用场景：
     * 1. true：用户级别的重复提交控制
     *    - 适用于表单提交
     *    - 个人操作防重复
     *    - 需要区分用户的场景
     * 
     * 2. false：全局级别的重复提交控制
     *    - 适用于系统级操作
     *    - 不需要区分用户的场景
     *    - 全局唯一性控制
     * 
     * 注意事项：
     * 1. 启用会话校验需要确保会话管理的正确性
     * 2. 考虑分布式环境下的会话一致性
     * 3. 根据业务需求选择合适的模式
     * 
     * @return boolean 是否启用会话校验，默认为true
     */
    boolean hasSession() default true;
}