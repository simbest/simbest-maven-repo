package com.simbest.boot.uums.web.app;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.uums.api.app.UumsSysAppApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 应用管理控制器
 * 提供移动端应用相关的API接口：
 * - 支持根据应用编码查询应用信息
 * - 提供应用决策群组相关功能
 * - 专门用于移动端应用的接口实现
 */
@Api(tags = {"2-统一用户管理", "移动端应用管理"}, description = "提供移动端应用相关的API接口，包括移动端应用信息的查询、应用决策群组的管理、移动端特定的功能实现等")
@RestController
@RequestMapping("/sys/uums/app")
public class UumsSysAppToMinController {

    @Autowired
    private UumsSysAppApi uumsSysAppApi;

    /**
     * 根据appCode查询应用信息
     * 提供应用基本信息的查询功能：
     * - 支持通过应用编码查询
     * - 可选择性地指定用户名进行权限过滤
     * 
     * @param appcode 应用编码
     * @param username 用户名（可选）
     * @return 应用信息的JSON响应
     */
    @ApiOperation(value = "根据appCode查询应用的消息", notes = "根据appCode查询应用的消息")
    @ApiImplicitParams({ //
            @ApiImplicitParam(name = "appcode", value = "应用编码", dataType = "String", paramType = "query"), //
            @ApiImplicitParam(name = "username", value = "用户名", dataType = "String", paramType = "query")
    })
    @PostMapping("/findAppByAppCode")
    public JsonResponse findById(@RequestParam(required = false)  String appcode,@RequestParam(required = false)  String username) {
        return JsonResponse.success(uumsSysAppApi.findAppByAppCode( appcode ,username));
    }
}