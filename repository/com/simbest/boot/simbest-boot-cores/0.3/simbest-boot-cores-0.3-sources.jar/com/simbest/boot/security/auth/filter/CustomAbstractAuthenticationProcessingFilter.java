package com.simbest.boot.security.auth.filter;

import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.RequestMatcher;

/**
 * 用途：抽象过滤器，用于第三方认证扩展
 *
 *
 */
public abstract class CustomAbstractAuthenticationProcessingFilter extends AbstractAuthenticationProcessingFilter {

    public CustomAbstractAuthenticationProcessingFilter(RequestMatcher requiresAuthenticationRequestMatcher) {
        super(requiresAuthenticationRequestMatcher);
    }
}