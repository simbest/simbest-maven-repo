package com.simbest.boot.component.distributed.lock;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.redisson.api.RLock;

/**
 * Redisson分布式锁的包装类，提供更友好的锁操作接口
 * 
 * 主要功能：
 * 1. 封装Redisson的RLock对象，简化分布式锁的使用
 * 2. 提供锁状态的跟踪机制，便于业务层面的逻辑控制
 * 3. 支持Builder模式创建实例，使代码更加简洁优雅
 * 
 * 使用场景：
 * 1. 需要在业务层面判断锁是否获取成功
 * 2. 需要更灵活地控制锁的获取和释放
 * 3. 需要在分布式环境下确保业务的互斥执行
 * 
 * 使用示例：
 * ```java
 * DistributedRedissonLock lock = DistributedRedissonLock.builder()
 *     .rLock(redissonClient.getLock("lockKey"))
 *     .isLocked(false)
 *     .build();
 * 
 * if (lock.isLocked()) {
 *     try {
 *         // 执行业务逻辑
 *     } finally {
 *         lock.getRLock().unlock();
 *     }
 * }
 * ```
 * 
 * 注意事项：
 * 1. 使用完锁后必须手动释放，建议在finally块中进行
 * 2. 确保在持有锁的线程中进行解锁操作
 * 3. 注意处理锁获取失败的情况
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DistributedRedissonLock {

    /**
     * Redisson的分布式锁对象
     * 
     * 功能：
     * 1. 提供底层的分布式锁实现
     * 2. 支持可重入锁、公平锁等多种锁类型
     * 3. 自动处理锁的续期，防止业务执行时间过长导致锁失效
     * 
     * 注意：
     * 1. 不要直接操作此对象，优先使用DistributedRedisLock类提供的方法
     * 2. 如果必须直接使用，请确保了解Redisson的锁机制
     */
    private RLock rLock;

    /**
     * 锁的状态标志
     * 
     * 值含义：
     * - true：表示已成功获取锁，可以执行业务逻辑
     * - false：表示未获取锁或获取锁失败，需要等待或重试
     * 
     * 使用场景：
     * 1. 在业务代码中判断是否获取到锁
     * 2. 控制业务逻辑的执行流程
     * 3. 实现锁获取失败后的降级处理
     */
    private boolean isLocked;

}