package com.simbest.boot.util;

import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.OutputStream;
import java.util.Hashtable;
import java.util.Random;

/**
 * 用途：二维码工具类
 * 提供二维码的生成、解析和定制化处理功能
 */
public class QrCodeUtil {
    private static final String CHARSET = "utf-8";
    private static final String FORMAT = "JPG";
    // 二维码尺寸
    private static final int QRCODE_SIZE = 300;
    // LOGO宽度
    private static final int LOGO_WIDTH = 60;
    // LOGO高度
    private static final int LOGO_HEIGHT = 60;

    /**
     * 创建二维码图片
     * 生成包含指定内容的二维码图片，可选择是否包含Logo
     * 
     * @param content 二维码包含的内容
     * @param logoPath logo图片路径，可为null
     * @param needCompress 是否需要压缩logo图片
     * @return 生成的二维码图片
     * @throws Exception 生成二维码过程中的异常
     */
    private static BufferedImage createImage(String content, String logoPath, boolean needCompress) throws Exception {
        Hashtable<EncodeHintType, Object> hints = new Hashtable<EncodeHintType, Object>();
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hints.put(EncodeHintType.CHARACTER_SET, CHARSET);
        hints.put(EncodeHintType.MARGIN, 1);
        BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, QRCODE_SIZE, QRCODE_SIZE,
                hints);
        int width = bitMatrix.getWidth();
        int height = bitMatrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                image.setRGB(x, y, bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
            }
        }
        if (logoPath == null || "".equals(logoPath)) {
            return image;
        }
        // 插入图片
        QrCodeUtil.insertImage(image, logoPath, needCompress);
        return image;
    }

    /**
     * 插入LOGO图片到二维码中
     * 将指定的Logo图片插入到二维码中心位置
     *
     * @param source 二维码图片
     * @param logoPath LOGO图片地址
     * @param needCompress 是否需要压缩Logo
     * @throws Exception 读取Logo或处理图片过程中的异常
     */
    private static void insertImage(BufferedImage source, String logoPath, boolean needCompress) throws Exception {
        File file = new File(logoPath);
        if (!file.exists()) {
            throw new Exception("logo file not found.");
        }
        Image src = ImageIO.read(new File(logoPath));
        int width = src.getWidth(null);
        int height = src.getHeight(null);
        if (needCompress) { // 压缩LOGO
            if (width > LOGO_WIDTH) {
                width = LOGO_WIDTH;
            }
            if (height > LOGO_HEIGHT) {
                height = LOGO_HEIGHT;
            }
            Image image = src.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            BufferedImage tag = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            Graphics g = tag.getGraphics();
            g.drawImage(image, 0, 0, null); // 绘制缩小后的图
            g.dispose();
            src = image;
        }
        // 插入LOGO
        Graphics2D graph = source.createGraphics();
        int x = (QRCODE_SIZE - width) / 2;
        int y = (QRCODE_SIZE - height) / 2;
        graph.drawImage(src, x, y, width, height, null);
        Shape shape = new RoundRectangle2D.Float(x, y, width, width, 6, 6);
        graph.setStroke(new BasicStroke(3f));
        graph.draw(shape);
        graph.dispose();
    }

    /**
     * 生成二维码(内嵌LOGO)
     * 二维码文件名随机生成，可能会有重复
     *
     * @param content 二维码内容
     * @param logoPath LOGO图片地址
     * @param destPath 存放目标目录
     * @param needCompress 是否压缩LOGO
     * @return 生成的二维码文件名
     * @throws Exception 生成过程中的异常
     */
    public static String encode(String content, String logoPath, String destPath, boolean needCompress) throws Exception {
        BufferedImage image = QrCodeUtil.createImage(content, logoPath, needCompress);
        mkdirs(destPath);
        String fileName = new Random().nextInt(99999999) + "." + FORMAT.toLowerCase();
        ImageIO.write(image, FORMAT, new File(destPath + "/" + fileName));
        return fileName;
    }

    /**
     * 生成二维码(内嵌LOGO)
     * 使用指定的文件名保存二维码图片
     *
     * @param content 二维码内容
     * @param logoPath LOGO图片地址
     * @param destPath 存放目标目录
     * @param fileName 指定的二维码文件名
     * @param needCompress 是否压缩LOGO
     * @return 生成的二维码文件名
     * @throws Exception 生成过程中的异常
     */
    public static String encode(String content, String logoPath, String destPath, String fileName, boolean needCompress) throws Exception {
        BufferedImage image = QrCodeUtil.createImage(content, logoPath, needCompress);
        mkdirs(destPath);
        fileName = fileName.substring(0, fileName.indexOf(".")>0?fileName.indexOf("."):fileName.length())
                + "." + FORMAT.toLowerCase();
        ImageIO.write(image, FORMAT, new File(destPath + "/" + fileName));
        return fileName;
    }

    /**
     * 创建目录
     * 当文件夹不存在时，mkdirs会自动创建多层目录
     * 区别于mkdir(如果父目录不存在则会抛出异常)
     * 
     * @param destPath 存放目录
     */
    public static void mkdirs(String destPath) {
        File file = new File(destPath);
        if (!file.exists() && !file.isDirectory()) {
            file.mkdirs();
        }
    }

    /**
     * 生成二维码(内嵌LOGO)
     * 使用默认参数，不压缩LOGO
     *
     * @param content 二维码内容
     * @param logoPath LOGO图片地址
     * @param destPath 存储目录
     * @return 生成的二维码文件名
     * @throws Exception 生成过程中的异常
     */
    public static String encode(String content, String logoPath, String destPath) throws Exception {
        return QrCodeUtil.encode(content, logoPath, destPath, false);
    }

    /**
     * 生成二维码
     * 不包含LOGO，可选择是否压缩
     *
     * @param content 二维码内容
     * @param destPath 存储目录
     * @param needCompress 是否压缩文件
     * @return 生成的二维码文件名
     * @throws Exception 生成过程中的异常
     */
    public static String encode(String content, String destPath, boolean needCompress) throws Exception {
        return QrCodeUtil.encode(content, null, destPath, needCompress);
    }

    /**
     * 生成二维码
     * 不包含LOGO，不压缩
     *
     * @param content 二维码内容
     * @param destPath 存储目录
     * @return 生成的二维码文件名
     * @throws Exception 生成过程中的异常
     */
    public static String encode(String content, String destPath) throws Exception {
        return QrCodeUtil.encode(content, null, destPath, false);
    }

    /**
     * 生成二维码(内嵌LOGO)并输出到流
     * 适用于web应用中直接输出二维码图片
     *
     * @param content 二维码内容
     * @param logoPath LOGO图片地址
     * @param output 输出流
     * @param needCompress 是否压缩LOGO
     * @throws Exception 生成过程中的异常
     */
    public static void encode(String content, String logoPath, OutputStream output, boolean needCompress)
            throws Exception {
        BufferedImage image = QrCodeUtil.createImage(content, logoPath, needCompress);
        ImageIO.write(image, FORMAT, output);
    }

    /**
     * 生成二维码并输出到流
     * 不包含LOGO，适用于web应用
     *
     * @param content 二维码内容
     * @param output 输出流
     * @throws Exception 生成过程中的异常
     */
    public static void encode(String content, OutputStream output) throws Exception {
        QrCodeUtil.encode(content, null, output, false);
    }

    /**
     * 解析二维码图片文件
     * 识别图片中的二维码内容
     *
     * @param file 二维码图片文件
     * @return 解析得到的二维码文本内容，如果解析失败返回null
     * @throws Exception 解析过程中的异常
     */
    public static String decode(File file) throws Exception {
        BufferedImage image;
        image = ImageIO.read(file);
        if (image == null) {
            return null;
        }
        BufferedImageLuminanceSource source = new BufferedImageLuminanceSource(image);
        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
        Result result;
        Hashtable<DecodeHintType, Object> hints = new Hashtable<DecodeHintType, Object>();
        hints.put(DecodeHintType.CHARACTER_SET, CHARSET);
        result = new MultiFormatReader().decode(bitmap, hints);
        String resultStr = result.getText();
        return resultStr;
    }

    /**
     * 解析二维码图片
     * 通过图片路径解析二维码内容
     *
     * @param path 二维码图片地址
     * @return 解析得到的二维码文本内容
     * @throws Exception 解析过程中的异常
     */
    public static String decode(String path) throws Exception {
        return QrCodeUtil.decode(new File(path));
    }

    /**
     * 测试方法
     * 演示二维码的生成与解析功能
     * 支持不含Logo、含Logo且指定或不指定二维码图片名称的情况
     * 
     * @param args 命令行参数
     * @throws Exception 二维码处理过程中的异常
     */
    public static void main(String[] args) throws Exception {
        String text = "https://m.ha.chinamobile.com:8001/download.html";
        //不含Logo
        //QrCodeUtil.encode(text, null, "e:\\", true);
        //含Logo，不指定二维码图片名
        //QrCodeUtil.encode(text, "e:\\csdn.jpg", "e:\\", true);
        //含Logo，指定二维码图片名
        QrCodeUtil.encode(text, "C:\\Users\\lenovo\\Desktop\\pic01.png", "C:\\Users\\lenovo\\Desktop\\", "maip", true);
        String result = QrCodeUtil.decode("C:\\Users\\lenovo\\Desktop\\maip.jpg");
        System.out.println(result);
    }
}