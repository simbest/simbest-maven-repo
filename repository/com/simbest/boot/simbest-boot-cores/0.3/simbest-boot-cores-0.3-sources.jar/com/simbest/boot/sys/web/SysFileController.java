package com.simbest.boot.sys.web;

import static com.simbest.boot.constants.ApplicationConstants.EMPTY;
import static com.simbest.boot.util.AppFileUtil.NGINX_STATIC_FILE_LOCATION;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.simbest.boot.util.encrypt.Md5Encryptor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.simbest.boot.base.enums.StoreLocation;
import com.simbest.boot.base.web.controller.LogicController;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.sys.model.SysFile;
import com.simbest.boot.sys.model.UploadFileResponse;
import com.simbest.boot.sys.service.ISysFileService;
import com.simbest.boot.util.AppFileUtil;
import com.simbest.boot.util.UrlEncoderUtils;
import com.simbest.boot.util.encrypt.UrlEncryptor;
import com.simbest.boot.util.encrypt.WebOffice3Des;
import com.simbest.boot.util.http.BrowserUtil;
import com.simbest.boot.util.json.JacksonUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 用途：统一系统文件管理控制器
 * https://www.mkyong.com/spring-boot/spring-boot-file-upload-example-ajax-and-rest/
 *
 */
@Api(tags = { "3-系统管理", "系统文件管理" }, description = "提供系统文件管理功能，支持文件上传、下载、预览、删除等操作，支持多种文件类型，支持文件加密和权限控制，支持与流程系统集成")
@Slf4j
@Controller
@RequestMapping("/sys/file")
public class SysFileController extends LogicController<SysFile, String> {

    public final static String UPLOAD_PROCESS_FILES_URL = "/uploadProcessFiles";
    public final static String UPLOAD_PROCESS_FILES_URL_SSO = "/uploadProcessFiles/sso";
    public final static String UPLOAD_PROCESS_FILES_URL_API = "/uploadProcessFiles/api";
    public final static String UPLOAD_PROCESS_FILES_URL_REST = "/uploadProcessFiles/rest";
    public final static String UPLOAD_PROCESS_FILES_URL_REST_SSO = "/uploadProcessFiles/rest/sso";
    public final static String UPLOAD_PROCESS_FILES_URL_REST_API = "/uploadProcessFiles/rest/api";
    public final static String DOWNLOAD_URL = "/download";
    public final static String DOWNLOAD_URL_SSO = "/download/sso";
    public final static String DOWNLOAD_URL_API = "/download/api";
    public final static String DOWNLOAD_URL_ANONYMOUSI = "/download/anonymous";
    public final static String DOWNLOAD_FULL_URL = "/sys/file/download";
    public final static String DOWNLOAD_FULL_URL_API = "/sys/file/download/api";
    public final static String DOWNLOAD_FULL_URL_ANONYMOUS = "/sys/file/download/anonymous";
    public final static String OPEN_URL = "/open";
    public final static String OPEN_URL_SSO = "/open/sso";
    public final static String OPEN_URL_API = "/open/api";
    public final static String OPEN_URL_ANONYMOUS = "/open/anonymous";
    public final static String DELETE_URL = "/deleteById";

    @Autowired
    private ISysFileService fileService;

    @Autowired
    private UrlEncryptor urlEncryptor;

    @Autowired
    private AppFileUtil appFileUtil;

    @Setter
    @Autowired
    private AppConfig config;

    @Autowired
    public SysFileController(ISysFileService fileService) {
        super(fileService);
        this.fileService = fileService;
    }

    @PostMapping(value = { "/uploadFile", "/uploadFile/sso", "/uploadFile/api" })
    @ResponseBody
    public JsonResponse uploadFile(@RequestParam("file") MultipartFile file,
            @RequestParam(value = "pmInsType", required = false) String pmInsType,
            @RequestParam(value = "pmInsId", required = false) String pmInsId,
            @RequestParam(value = "pmInsTypePart", required = false) String pmInsTypePart) {
        SysFile sysFile = fileService.uploadProcessFile(file, pmInsType, pmInsId, pmInsTypePart);
        JsonResponse jsonResponse;
        if (null != sysFile) {
            UploadFileResponse uploadFileResponse = new UploadFileResponse();
            uploadFileResponse.setSysFiles(ImmutableList.of(sysFile));
            jsonResponse = JsonResponse.success(uploadFileResponse);
        } else {
            jsonResponse = JsonResponse.defaultErrorResponse();
        }
        return jsonResponse;
    }

    @PostMapping(value = { "/updateFile", "/updateFile/sso", "/updateFile/api" })
    @ResponseBody
    public JsonResponse updateFile(@RequestParam("file") MultipartFile file,
            @RequestParam(value = "pmInsId", required = false) String pmInsId, @RequestParam(value = "id") String id) {
        SysFile sysFile = fileService.updateProcessFile(file, pmInsId, id);
        JsonResponse jsonResponse;
        if (null != sysFile) {
            UploadFileResponse uploadFileResponse = new UploadFileResponse();
            uploadFileResponse.setSysFiles(ImmutableList.of(sysFile));
            jsonResponse = JsonResponse.success(uploadFileResponse);
        } else {
            jsonResponse = JsonResponse.defaultErrorResponse();
        }
        return jsonResponse;
    }

    @PostMapping(value = { "/getFilesByPmInsId", "/getFilesByPmInsId/sso", "/getFilesByPmInsId/api" })
    @ResponseBody
    public JsonResponse getFilesByPmInsId(@RequestParam(value = "pmInsId") String pmInsId,
            @RequestParam(value = "appCode") String appCode) {
        List<SysFile> sysFiles = fileService.getFilesByPmInsId(pmInsId);
        JsonResponse jsonResponse = null != sysFiles ? JsonResponse.success(sysFiles)
                : JsonResponse.defaultErrorResponse();
        return jsonResponse;
    }

    @PostMapping(value = { "/getFilesByProcessInsId", "/getFilesByProcessInsId/sso", "/getFilesByProcessInsId/api" })
    @ResponseBody
    public JsonResponse getFilesByProcessInsId(@RequestParam(value = "processInsId") String processInsId,
            @RequestParam(value = "appCode") String appCode) {
        List<SysFile> sysFiles = fileService.getFilesByProcessInsId(processInsId);
        JsonResponse jsonResponse = null != sysFiles ? JsonResponse.success(sysFiles)
                : JsonResponse.defaultErrorResponse();
        return jsonResponse;
    }

    @ApiOperation(value = "传统方式上传附件（支持IE8）,支持关联流程", notes = "会保存到数据库SYS_FILE")
    @PostMapping(value = { UPLOAD_PROCESS_FILES_URL, UPLOAD_PROCESS_FILES_URL_SSO, UPLOAD_PROCESS_FILES_URL_API })
    @ResponseBody
    public void uploadFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JsonResponse jsonResponse = doUploadFile(request, response);
        String result = "<script type=\"text/javascript\">parent.result=" + JacksonUtils.obj2json(jsonResponse)
                + "</script>";
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println(result);
        out.close();
    }

    @ApiOperation(value = "REST方式上传附件,支持关联流程", notes = "会保存到数据库SYS_FILE")
    @PostMapping(value = { UPLOAD_PROCESS_FILES_URL_REST, UPLOAD_PROCESS_FILES_URL_REST_SSO,
            UPLOAD_PROCESS_FILES_URL_REST_API })
    @ResponseBody
    public ResponseEntity<?> uploadFileRest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JsonResponse jsonResponse = doUploadFile(request, response);
        return new ResponseEntity(jsonResponse, HttpStatus.OK);
    }

    @ApiOperation(value = "传统方式分辨率压缩图片（支持IE8）,支持关联流程", notes = "会保存到数据库SYS_FILE")
    @PostMapping(value = { "/uploadCompressImages2", "/uploadCompressImages2/sso", "/uploadCompressImages2/api" })
    public void uploadCompressImages2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JsonResponse jsonResponse = doUploadCompressImages2(request, response);
        String result = "<script type=\"text/javascript\">parent.result=" + JacksonUtils.obj2json(jsonResponse)
                + "</script>";
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println(result);
        out.close();
    }

    @ApiOperation(value = "REST方式分辨率压缩图片,支持关联流程", notes = "会保存到数据库SYS_FILE")
    @PostMapping(value = { "/uploadCompressImages2/rest", "/uploadCompressImages2/rest/sso",
            "/uploadCompressImages2/rest/api" })
    @ResponseBody
    public ResponseEntity<?> uploadCompressImages2Rest(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        JsonResponse jsonResponse = doUploadCompressImages2(request, response);
        return new ResponseEntity(jsonResponse, HttpStatus.OK);
    }

    /**
     * 上传文件,支持关联流程
     */
    private JsonResponse doUploadFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Set<MultipartFile> uploadingFileSet = Sets.newHashSet();
        MultipartHttpServletRequest mureq = (MultipartHttpServletRequest) request;
        // 优先通过指定参数名称file获取文件
        Collection<MultipartFile> uploadingFileList = mureq.getFiles("file");
        uploadingFileList.forEach(f -> uploadingFileSet.add(f));
        // 再通过不指定参数名称获取文件
        Map<String, MultipartFile> multipartFiles = mureq.getFileMap();
        multipartFiles.values().forEach(f -> uploadingFileSet.add(f));
        List<SysFile> sysFiles = fileService.uploadProcessFiles(uploadingFileSet, request.getParameter("pmInsType"),
                request.getParameter("pmInsId"), request.getParameter("pmInsTypePart"));
        JsonResponse jsonResponse;
        if (!sysFiles.isEmpty()) {
            UploadFileResponse uploadFileResponse = new UploadFileResponse();
            uploadFileResponse.setSysFiles(sysFiles);
            jsonResponse = JsonResponse.success(uploadFileResponse);
        } else {
            jsonResponse = JsonResponse.defaultErrorResponse();
        }
        return jsonResponse;
    }

    /**
     * 上传按照分辨率压缩图片
     */
    private JsonResponse doUploadCompressImages2(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        Set<MultipartFile> uploadingFileSet = Sets.newHashSet();
        MultipartHttpServletRequest mureq = (MultipartHttpServletRequest) request;
        // 优先通过指定参数名称file获取文件
        Collection<MultipartFile> uploadingFileList = mureq.getFiles("file");
        uploadingFileList.forEach(f -> uploadingFileSet.add(f));
        // 再通过不指定参数名称获取文件
        Map<String, MultipartFile> multipartFiles = mureq.getFileMap();
        multipartFiles.values().forEach(f -> uploadingFileSet.add(f));
        List<SysFile> sysFiles = fileService.uploadCompressImages2(uploadingFileSet, request.getParameter("pmInsType"),
                request.getParameter("pmInsId"), request.getParameter("pmInsTypePart"),
                request.getParameter("compressWidth"), request.getParameter("fileSuffix"));
        JsonResponse jsonResponse;
        if (!sysFiles.isEmpty()) {
            UploadFileResponse uploadFileResponse = new UploadFileResponse();
            uploadFileResponse.setSysFiles(sysFiles);
            jsonResponse = JsonResponse.success(uploadFileResponse);
        } else {
            jsonResponse = JsonResponse.defaultErrorResponse();
        }
        return jsonResponse;
    }

    /**
     * 下载视频文件(解决iOS操作系统播放MP4)
     * 参考：https://blog.csdn.net/weixin_42553179/article/details/100008911
     *
     * @param request
     * @param id
     * @throws IOException
     */
    @GetMapping(value = { "/downloadVideo", "/downloadVideo/sso", "/downloadVideo/api", "/downloadVideo/anonymous" })
    @ResponseBody
    public void downloadVideo(HttpServletRequest request, HttpServletResponse response, @RequestParam("id") String id)
            throws IOException {
        SysFile sysFile = fileService.findById(id);
        Assert.notNull(sysFile, String.format("通过文件Id【%s】无法获取文件", id));

        // 获取真实文件
        File realFile = fileService.getRealFileById(id);
        long contentLength = realFile.length();
        String range = request.getHeader("Range");

        // 统一Range解析逻辑 - 修复Range解析重复且不一致的问题
        long rangeStart = 0, rangeEnd = 0;
        boolean isRangeRequest = false;
        if (range != null && range.startsWith("bytes=")) {
            isRangeRequest = true;
            String[] values = range.split("=")[1].split("-");
            rangeStart = Long.parseLong(values[0]);
            if (values.length > 1 && !values[1].isEmpty()) {
                rangeEnd = Long.parseLong(values[1]);
            } else {
                rangeEnd = contentLength - 1; // 如果没有指定结束位置，默认到文件末尾
            }
        }

        // 计算实际需要传输的字节数
        long transferLength = isRangeRequest ? (rangeEnd - rangeStart + 1) : contentLength;

        String fileType = AppFileUtil.getFileType(realFile); // 支持 video/mp4
        log.debug("下载文件【{}】类型为【{}】", sysFile.getFileName(), fileType);

        // 设置响应头
        response.setContentType(fileType);
        response.setHeader("Accept-Ranges", "bytes");
        response.setHeader("ETag", appFileUtil.getFileNameMd5(sysFile.getFileName()));
        response.setHeader("Last-Modified", sysFile.getModifiedTime().toString());

        // 设置文件名称 - 修复部分手机无法下载的问题
        boolean isMSIE = BrowserUtil.isMSBrowser(request);
        String fileName;
        if (StringUtils.contains(request.getRequestURI(), "anonymous")) {
            // 修复内存溢出问题：使用文件ID而不是文件内容MD5，避免大文件加载到内存
            //fileName = Md5Encryptor.getFileMd5(realFile) + ApplicationConstants.DOT + AppFileUtil.getFileSuffix(realFile.getName());
            fileName = sysFile.getId() + ApplicationConstants.DOT + AppFileUtil.getFileSuffix(realFile.getName());
        } else {
            if (isMSIE) {
                fileName = URLEncoder.encode(sysFile.getFileName(), ApplicationConstants.UTF_8);
            } else {
                fileName = new String(sysFile.getFileName().getBytes(ApplicationConstants.UTF_8), "ISO-8859-1");
            }
        }
        response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");

        // 设置响应状态和Content-Length、Content-Range
        if (isRangeRequest) {
            log.debug("分段请求Range区间【{}】，范围：{}-{}", range, rangeStart, rangeEnd);
            response.setStatus(HttpServletResponse.SC_PARTIAL_CONTENT); // 206
            response.setHeader("Content-Length", String.valueOf(transferLength));
            response.setHeader("Content-Range", "bytes " + rangeStart + "-" + rangeEnd + "/" + contentLength);
        } else {
            log.debug("完整文件请求，文件大小：{}", contentLength);
            response.setHeader("Content-Length", String.valueOf(contentLength));
        }

        // 使用try-with-resources确保资源正确关闭
        try (RandomAccessFile randomFile = new RandomAccessFile(realFile, "r");
                ServletOutputStream out = response.getOutputStream()) {

            // 定位到起始位置
            randomFile.seek(rangeStart);

            // 修复缓冲区处理逻辑
            long remainingBytes = transferLength;
            byte[] buffer = new byte[4096];

            while (remainingBytes > 0) {
                int bytesToRead = (int) Math.min(buffer.length, remainingBytes);
                int bytesRead = randomFile.read(buffer, 0, bytesToRead);

                if (bytesRead == -1) {
                    // 文件结束
                    break;
                }

                out.write(buffer, 0, bytesRead);
                remainingBytes -= bytesRead;
            }

            out.flush();
        }
    }

    /**
     * 下载文件(图片和通用文档)
     *
     * @param request
     * @param id
     * @return JsonResponse
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException
     */
    @ApiOperation(value = "下载文件")
    @GetMapping(value = { DOWNLOAD_URL, DOWNLOAD_URL_SSO, DOWNLOAD_URL_API, DOWNLOAD_URL_ANONYMOUSI })
    @ResponseBody
    public ResponseEntity<?> download(HttpServletRequest request, @RequestParam("id") String id) throws IOException {
        SysFile sysFile = fileService.findById(id);
        Assert.notNull(sysFile, String.format("通过文件Id【%s】无法获取文件", id));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.add("Pragma", "no-cache");
        headers.add("Expires", "0");

        // 获取真实文件
        File realFile = fileService.getRealFileById(id);

        // 设置文件类型
        String fileType = AppFileUtil.getFileType(realFile); // text/plain image/jpeg image/png video/mp4
                                                             // application/vnd.openxmlformats-officedocument.wordprocessingml.document
                                                             // 等文件类型
        log.debug("下载文件【{}】类型为【{}】", sysFile.getFileName(), fileType);
        String[] fileTypes = StringUtils.split(fileType, ApplicationConstants.SLASH);
        // 1-响应图片
        if (AppFileUtil.isImage(realFile)) {
            headers.setContentType(new MediaType(fileTypes[0], fileTypes[1]));
        }
        // 2-响应视频--iOS操作系统无法播放，可使用/downloadVideo
        else if ("video".equals(fileTypes[0])) {
            headers.setContentType(new MediaType(fileTypes[0], fileTypes[1]));
        }
        // 3-响应文件流
        else {
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        }

        // 设置文件名称
        boolean isMSIE = BrowserUtil.isMSBrowser(request);
        String fileName;
        if (StringUtils.contains(request.getRequestURI(), "anonymous")) {
            // 修复内存溢出问题：使用文件ID而不是文件内容MD5，避免大文件加载到内存
            fileName = sysFile.getId() + ApplicationConstants.DOT + AppFileUtil.getFileSuffix(realFile.getName());
        } else {
            if (isMSIE) {
                fileName = URLEncoder.encode(sysFile.getFileName(), ApplicationConstants.UTF_8);
            } else {
                fileName = new String(sysFile.getFileName().getBytes(ApplicationConstants.UTF_8), "ISO-8859-1");
            }
        }
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=\"" + fileName + "\"");

        // 设置文件大小
        RandomAccessFile randomFile = new RandomAccessFile(realFile, "r");// 只读模式
        headers.setContentLength(randomFile.length());
        randomFile.close();

        // 输出文件
        Resource resource = new InputStreamResource(new FileInputStream(realFile));
        return ResponseEntity.ok().headers(headers).body(resource);
    }

    /**
     * 借助Nginx直接访问文件, 依赖于Nginx的反向代理
     *
     * @param id
     * @param uploadPath
     * @return String
     */
    @GetMapping(value = { "/ngopen", "/ngopen/sso", "/ngopen/api" })
    public String ngopen(@RequestParam("id") String id,
            @RequestParam(value = "uploadPath", required = false) String uploadPath) {
        SysFile sysFile = fileService.findById(id);
        Assert.notNull(sysFile, String.format("通过文件Id【%s】无法获取文件", id));
        log.debug("尝试预览文件地址为【{}】", sysFile.getFilePath());
        if (StringUtils.isEmpty(uploadPath)) {
            uploadPath = config.getUploadPath();
        }
        String nginxUrl = config.getAppHostPort() + NGINX_STATIC_FILE_LOCATION
                + StringUtils.remove(sysFile.getFilePath(), uploadPath);
        log.debug("转换后webOfficeUrl地址为【{}】", nginxUrl);
        return "redirect:" + nginxUrl;
    }

    /**
     * 在线预览文件, 适用于保存在FastDfs和共享存储Disk中的文件, 并且依赖http://www.officeweb365.com/
     *
     * @param id
     * @return String
     * @throws Exception
     */
    @GetMapping(value = { OPEN_URL, OPEN_URL_SSO, OPEN_URL_API, OPEN_URL_ANONYMOUS })
    public String open(@RequestParam("id") String id) throws Exception {
        String redirectUrl;
        String fileUrl = null;
        SysFile sysFile = fileService.findById(id);
        Assert.notNull(sysFile, String.format("通过文件Id【%s】无法获取文件", id));
        log.debug("尝试预览文件信息为【{}】", sysFile);
        if (StoreLocation.fastdfs.equals(sysFile.getStoreLocation())) {
            fileUrl = config.getAppHostPort() + ApplicationConstants.SLASH + sysFile.getFilePath();
        }
        if (StoreLocation.disk.equals(sysFile.getStoreLocation())) {
            fileUrl = sysFile.getAnonymousFilePath();
        }
        redirectUrl = getOfficeweb365Url(fileUrl);
        log.debug("转换前地址【{}】，转换后webOfficeUrl地址为【{}】", fileUrl, redirectUrl);
        return "redirect:" + redirectUrl;
    }

    /**
     * 在线预览文件, 支持任意免认证的URL, 并且依赖http://www.officeweb365.com/
     *
     * @param url url必须可以匿名直接访问
     * @return String
     * @throws Exception
     */
    @RequestMapping(value = { "/openurl", "/openurl/sso", "/openurl/api" }, method = { RequestMethod.POST,
            RequestMethod.GET })
    public String openurl(@RequestParam String url) throws Exception {
        return "redirect:" + getOfficeweb365Url(url);
    }

    /**
     * 在线预览文件，支持任意免认证的URL,不进行重定向, 并且依赖http://www.officeweb365.com/
     *
     * @param url url必须可以匿名直接访问
     * @return
     * @throws Exception
     */
    @RequestMapping(value = { "/get/url", "/get/url/sso", "/get/url/api" }, method = { RequestMethod.POST,
            RequestMethod.GET })
    @ResponseBody
    public ResponseEntity openurlNoRedirect(@RequestParam String url) throws Exception {
        return new ResponseEntity(JsonResponse.success(getOfficeweb365Url(url), EMPTY), HttpStatus.OK);
    }

    /**
     * 获取Officeweb365在预览文件时浏览器重定向后的URL 说明如下：
     * 1、原始文件地址url：http://10.92.81.163:8088/wgjk/sys/file/download/anonymous?id=F316872804598370304
     * 2、先获取在浏览器通过Officeweb365可以通过的地址，如：
     * http://10.92.81.163:8088/webOffice/?furl=KL59YOPs3YY4Zu7UwAeLOLGmw6gush8pYGkMaXY6kxr5PyH1brzeAedxcO0C4xWD@4vGoKD65@S6wfJkJluaQgHA4eB@ahVltc9Hzg1rZTev@kCQbpihBg==
     * 3、再转换为浏览器打开后重定向的地址，如： 返回结果
     * http://10.92.81.163:8088/e/MTAuOTIuODEuMTYzLjgwODhceGxzeDEueGxzeA%3d%3d?furl=KL59YOPs3YY4Zu7UwAeLOLGmw6gush8pYGkMaXY6kxr5PyH1brzeAedxcO0C4xWD%404vGoKD65%40S6wfJkJluaQgHA4eB%40ahVltc9Hzg1rZTev%40kCQbpihBg%3D%3D
     *
     * @param url url必须可以匿名直接访问
     * @return
     * @throws Exception
     */
    @RequestMapping(value = { "/getRedirectUrl", "/getRedirectUrl/sso", "/getRedirectUrl/api" }, method = {
            RequestMethod.POST, RequestMethod.GET })
    @ResponseBody
    public ResponseEntity getOfficeweb365RedirectUrl(@RequestParam String url) throws Exception {
        // 先获取在浏览器通过Officeweb365可以通过的地址
        url = getOfficeweb365Url(url);
        // 再转换为浏览器打开后重定向的地址
        WebClient webClient = new WebClient(BrowserVersion.CHROME);
        webClient.getOptions().setJavaScriptEnabled(false);
        webClient.getOptions().setCssEnabled(false);
        String redirectUrl = webClient.getPage(url).getUrl().toString();
        webClient.close(); // 关闭webclient
        return new ResponseEntity(JsonResponse.success(redirectUrl, EMPTY), HttpStatus.OK);
    }

    private String getOfficeweb365Url(String url) throws Exception {
        if (UrlEncoderUtils.hasUrlEncoded(url)) {
            url = urlEncryptor.decrypt(url);
        }
        log.debug("尝试预览文件地址为【{}】", url);
        String redirectUrl = config.getAppHostPort() + "/webOffice/?furl=" + WebOffice3Des.encode(url);
        log.debug("转换后webOfficeUrl地址为【{}】", redirectUrl);
        return redirectUrl;
    }

    /**
     * 删除数据，并物理删除文件
     * 
     * @param id
     * @return
     */
    @PostMapping(value = DELETE_URL)
    @ResponseBody
    public JsonResponse deleteById(@RequestParam("id") String id) {
        fileService.deleteById(id);
        return JsonResponse.defaultSuccessResponse();
    }

    /**
     * 仅删除数据，保留物理文件
     * 
     * @param id
     * @return
     */
    @PostMapping(value = { "/deleteByIdNoFile", "/deleteByIdNoFile/api", "/deleteByIdNoFile/sso" })
    @ResponseBody
    public JsonResponse deleteByIdNoFile(@RequestParam("id") String id) {
        fileService.deleteByIdNoFile(id);
        return JsonResponse.defaultSuccessResponse();
    }

    @Override
    @ResponseBody
    @PostMapping(value = { "/update", "/update/api", "/update/sso" })
    public JsonResponse update(@RequestBody SysFile sysFile) {
        JsonResponse jsonResponse = super.update(sysFile);
        return jsonResponse;
    }

    // /**
    // * 涉及到具体对象的操作，所以不直接暴露接口
    // *
    // * @param uploadfile
    // * @param pmInsType
    // * @param pmInsId
    // * @param pmInsTypePart
    // * @param clazz
    // * @param <T>
    // * @throws IOException
    // * @rn
    // */
    // private <T> JsonResponse importExcel(MultipartFile uploadfile,
    // String pmInsType,
    // String pmInsId, //起草阶段上传文件，可不填写业务单据ID
    // String pmInsTypePart,
    // Class<T> clazz) throws IOException {
    // UploadFileResponse uploadFileResponse = fileService.importExcel(uploadfile,
    // pmInsType, pmInsId, pmInsTypePart, clazz);
    // if (null != uploadFileResponse) {
    // return JsonResponse.success(uploadFileResponse);
    // } else {
    // return JsonResponse.defaultErrorResponse();
    // }
    // }

    /**
     * 扫描不可读取的文件，可成功读取标识为1，因文件乱码等原因不可读取标识为-1，文件记录主键与文件路径名称一致为2
     * 
     * @param id      文件主键ID
     * @param isLocal 文件是否可读扫描标识
     * @return
     * @throws Exception
     */
    @RequestMapping(value = { "/scanCheckRealFile" }, method = { RequestMethod.POST, RequestMethod.GET })
    @ResponseBody
    public JsonResponse scanCheckRealFile(@RequestParam(required = false) String id,
            @RequestParam(required = false) Integer isLocal) throws Exception {
        Future<String> scanResult = fileService.findFileByIsLocal(id, isLocal);
        return JsonResponse.success(scanResult.get());
    }

    @GetMapping(value = { "/downloadZip", "/downloadZip/sso", "/downloadZip/api", "/downloadZip/anonymous" })
    @ResponseBody
    public ResponseEntity<?> downloadZip(HttpServletRequest request, @RequestParam("ids") String ids)
            throws IOException {
        final String[] idList = StringUtils.split(ids, ApplicationConstants.COMMA);
        List<SysFile> sysFileList = Lists.newArrayList();
        for (String id : idList) {
            SysFile sysFile = fileService.findById(id);
            if (null != sysFile) {
                sysFileList.add(sysFile);
            }
        }
        File tempZipFile = appFileUtil.createTempFile("zip");
        fileService.addFilesToZip(tempZipFile, sysFileList);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.add("Pragma", "no-cache");
        headers.add("Expires", "0");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

        // 设置文件名称
        boolean isMSIE = BrowserUtil.isMSBrowser(request);
        String fileName;
        if (StringUtils.contains(request.getRequestURI(), "anonymous")) {
            // 修复内存溢出问题：使用时间戳而不是文件内容MD5，避免大文件加载到内存
            fileName = "download_" + System.currentTimeMillis() + ApplicationConstants.DOT
                    + AppFileUtil.getFileSuffix(tempZipFile.getName());
        } else {
            if (isMSIE) {
                fileName = URLEncoder.encode(tempZipFile.getName(), ApplicationConstants.UTF_8);
            } else {
                fileName = new String(tempZipFile.getName().getBytes(ApplicationConstants.UTF_8), "ISO-8859-1");
            }
        }
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=\"" + fileName + "\"");

        // 设置文件大小
        RandomAccessFile randomFile = new RandomAccessFile(tempZipFile, "r");// 只读模式
        headers.setContentLength(randomFile.length());
        randomFile.close();

        // 输出文件
        Resource resource = new InputStreamResource(new FileInputStream(tempZipFile));
        return ResponseEntity.ok().headers(headers).body(resource);
    }

    public static void main(String[] args) throws Exception {
        WebOffice3Des webOffice3Des = new WebOffice3Des();
        AppConfig config = new AppConfig();
        config.setAppHostPort("http://211.138.31.210:8088");
        SysFileController sysFileController = new SysFileController(null);
        sysFileController.setConfig(config);
        String url = "http://10.87.13.91:8888/20200525/DemoExcel.xlsx";
        System.out.println(sysFileController.getOfficeweb365Url(url));
        url = "http://10.87.13.91:8888/20200525/DemoPdf.pdf";
        System.out.println(sysFileController.getOfficeweb365Url(url));
        url = "http://10.87.13.91:8888/20200525/DemoPpt.pptx";
        System.out.println(sysFileController.getOfficeweb365Url(url));
        url = "http://10.87.13.91:8888/20200525/DemoWord.doc";
        System.out.println(sysFileController.getOfficeweb365Url(url));
    }
}