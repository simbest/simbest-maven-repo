package com.simbest.boot.config;

import com.simbest.boot.component.GracefulShutdown;
import com.simbest.boot.util.SpringContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.connector.Connector;
import org.apache.commons.lang3.StringUtils;
import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.apache.coyote.http11.Http11NioProtocol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * 用途：内部Servlet容器配置类
 * 主要提供以下功能：
 * 1. Tomcat服务器参数配置
 * 2. 优雅关机支持
 * 3. 文件上传大小限制
 * 4. HTTP端口监听配置
 * 5. 特殊字符请求支持
 */
@Slf4j
@Configuration
public class EmbeddedServletConfiguration {

    /**
     * 服务器端口号
     */
    public static int serverPort;

    /**
     * 应用配置对象
     */
    @Autowired
    private AppConfig appConfig;

    /**
     * Spring上下文工具类
     */
    @Autowired
    private SpringContextUtil springContextUtil;

    /**
     * Spring环境配置对象
     */
    @Autowired
    private Environment env;

    /**
     * 最大文件上传大小限制
     */
    @Value("${spring.servlet.multipart.max-file-size}")
    private String maxFileSize;

    /**
     * 配置优雅关机组件
     * @return GracefulShutdown 优雅关机处理器
     */
    @Bean
    public GracefulShutdown gracefulShutdown() {
        return new GracefulShutdown(appConfig, springContextUtil);
    }

    /**
     * 配置Tomcat容器工厂
     * 包含连接器自定义配置、HTTP端口监听、特殊字符支持等
     * @param gracefulShutdown 优雅关机处理器
     * @return TomcatServletWebServerFactory Tomcat容器工厂实例
     */
    @Bean
    public TomcatServletWebServerFactory containerFactory(final GracefulShutdown gracefulShutdown) {
        TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory() {
            protected void customizeConnector(Connector connector) {
                super.customizeConnector(connector);
                if (connector.getProtocolHandler() instanceof AbstractHttp11Protocol) {
                    /**
                     * 通过设置MaxSwallowSize，解决在发生MaxUploadSizeExceededException异常时，
                     * Tomcat不停的尝试上传，导致前端拿不到错误信息的问题
                     */
                    Http11NioProtocol protocol = (Http11NioProtocol)connector.getProtocolHandler();
                    protocol.setMaxSwallowSize(-1);
                    log.info("应用支持的附件上传最大限制为【{}】",maxFileSize);

                    //配置Tomcat连接器参数
                    protocol.setMinSpareThreads(20);      //最小监听线程数
                    protocol.setAcceptCount(200);         //最大排队数
                    protocol.setMaxConnections(1000);     //最大连接数
                    protocol.setMaxThreads(800);          //最大线程数
                    protocol.setConnectionTimeout(10000); //连接超时时间(毫秒)

                    serverPort = connector.getPort();
                    log.info("内置Tomcat将在端口【{}】启动", serverPort);
                }
            }
        };

        //判断是否需要强制启动一个额外的http监听端口
        if(StringUtils.isNotEmpty(env.getProperty("force.another.http.port"))) {
            tomcat.addAdditionalTomcatConnectors(createStandardConnector());
        }

        //添加优雅关机支持
        tomcat.addConnectorCustomizers(gracefulShutdown);

        //添加特殊字符支持
        tomcat.addConnectorCustomizers(new TomcatConnectorCustomizer() {
            @Override
            public void customize(Connector connector) {
                connector.setProperty("relaxedPathChars", "\"<>[\\]^`{|}");
                connector.setProperty("relaxedQueryChars", "\"<>[\\]^`{|}");
            }
        });

        return tomcat;
    }

    /**
     * 创建额外的HTTP连接器
     * 用于确保HTTP协议的监听端口可用
     * @return Connector HTTP连接器实例
     */
    private Connector createStandardConnector() {
        int anotherHttpPort = Integer.parseInt(env.getProperty("force.another.http.port"));
        Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
        connector.setPort(anotherHttpPort);
        log.info("内置Tomcat将再监听一个端口【{}】启动", anotherHttpPort);
        return connector;
    }
}