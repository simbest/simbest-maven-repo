package com.simbest.boot.component.thread;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;

import java.util.concurrent.Future;

/**
 * 用途：Spring Boot异步任务执行器抽象基类
 * 作为异步任务执行的基础框架，提供统一的异步调用模式。
 * 
 * 主要功能：
 * 1. 异步任务执行：
 *    - 支持无返回值的异步任务
 *    - 支持有返回值的异步任务
 *    - 基于Spring的@Async注解实现异步调用
 * 
 * 2. 线程池管理：
 *    - 使用自定义线程池"simbestThreadExecutor"
 *    - 线程池参数可在MultiThreadConfiguration中配置
 *    - 支持线程池监控和管理
 * 
 * 3. 异步任务控制：
 *    - 支持任务执行状态跟踪
 *    - 提供任务执行结果获取机制
 *    - 异常处理和日志记录
 * 
 * 使用方式：
 * 1. 无返回值任务：
 *    ```java
 *    @Component
 *    public class MyExecutor extends AbstractThreadExecutor {
 *        @Override
 *        public void executeNoReturn() {
 *            // 实现异步任务逻辑
 *        }
 *        
 *        @Override
 *        public <T> Future<T> executeWithReturn() {
 *            return null; // 如果不需要返回值的任务，可以返回null
 *        }
 *    }
 *    ```
 * 
 * 2. 有返回值任务：
 *    ```java
 *    @Component
 *    public class MyExecutor extends AbstractThreadExecutor {
 *        @Override
 *        public void executeNoReturn() {
 *            // 如果不需要无返回值任务，可以留空
 *        }
 *        
 *        @Override
 *        public <T> Future<T> executeWithReturn() {
 *            // 实现异步任务逻辑
 *            return new AsyncResult<T>(result);
 *        }
 *    }
 *    ```
 * 
 * 配置说明：
 * 1. 线程池配置位于MultiThreadConfiguration类
 * 2. 可配置参数包括：
 *    - 核心线程数
 *    - 最大线程数
 *    - 队列容量
 *    - 线程存活时间
 *    - 线程名称前缀
 * 
 * 注意事项：
 * 1. 确保应用配置了@EnableAsync注解
 * 2. 注意异步任务的异常处理
 * 3. 合理配置线程池参数
 * 4. 避免在异步任务中使用@Transactional
 */
@Slf4j
public abstract class AbstractThreadExecutor {

    /**
     * 执行无返回值的异步任务
     * 
     * 说明：
     * 1. 使用自定义线程池"simbestThreadExecutor"
     * 2. 方法异步执行，调用后立即返回
     * 3. 适用于不需要获取执行结果的场景
     * 
     * 注意事项：
     * 1. 异常处理：方法内部需要处理异常，避免异常抛出导致线程终止
     * 2. 日志记录：建议记录关键执行步骤和异常情况
     * 3. 任务超时：注意控制任务执行时间，避免线程池资源耗尽
     */
    @Async("simbestThreadExecutor")
    public abstract void executeNoReturn();

    /**
     * 执行有返回值的异步任务
     * 
     * 说明：
     * 1. 使用自定义线程池"simbestThreadExecutor"
     * 2. 返回Future对象，支持异步获取执行结果
     * 3. 支持任务执行状态监控
     * 
     * 使用示例：
     * ```java
     * Future<String> future = executor.executeWithReturn();
     * String result = future.get(); // 等待任务完成并获取结果
     * ```
     * 
     * 注意事项：
     * 1. Future.get()方法会阻塞直到任务完成
     * 2. 建议使用Future.get(timeout, unit)避免永久阻塞
     * 3. 注意处理任务执行异常和中断异常
     * 
     * @param <T> 返回结果的类型
     * @return Future对象，包含任务的执行结果
     */
    @Async("simbestThreadExecutor")
    public abstract <T> Future<T> executeWithReturn();

}