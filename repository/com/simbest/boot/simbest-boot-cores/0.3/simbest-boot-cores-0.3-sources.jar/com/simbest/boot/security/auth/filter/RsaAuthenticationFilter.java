package com.simbest.boot.security.auth.filter;

import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.auth.a4.A4PasswordCheck;
import com.simbest.boot.security.auth.authentication.LoginPreWebAuthenticationDetails;
import com.simbest.boot.security.auth.authentication.UumsAuthentication;
import com.simbest.boot.security.auth.authentication.UumsAuthenticationCredentials;
import com.simbest.boot.security.auth.provider.GenericAuthenticationChecker;
import com.simbest.boot.security.auth.service.IAuthUserCacheService;
import com.simbest.boot.security.util.AuthenticationUtil;
import com.simbest.boot.util.ApplicationContextProvider;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.redis.RedisRetryLoginCache;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.util.server.HostUtil;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 用途：基于数据库的主数据登录认证拦截器，拦截/login请求
 * 重载UsernamePasswordAuthenticationFilter
 *
 *
 */
@Slf4j
public class RsaAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    @Setter
    private RsaEncryptor encryptor;

    @Setter
    private IAuthUserCacheService authUserCacheService;

    @Setter
    private GenericAuthenticationChecker genericAuthenticationChecker;

    /**
     * 前端RSA加密，后端验证时，先RSA解密，再进行FormSecurityConfigurer的认证
     * @param request
     * @return String
     */
    @Override
    protected String obtainPassword(HttpServletRequest request) {
        return encryptor.decrypt(request.getParameter(SPRING_SECURITY_FORM_PASSWORD_KEY));
    }

    /**
     * @param request
     * @param response
     * @return Authentication
     * @throws AuthenticationException
     */
    @Override
    public Authentication attemptAuthentication(HttpServletRequest request,
                                                HttpServletResponse response) throws AuthenticationException {
        String username = obtainUsername(request);
        String password = obtainPassword(request);
        String appcode = request.getParameter(AuthoritiesConstants.SSO_API_APP_CODE);
        Authentication existingAuth = SecurityContextHolder.getContext().getAuthentication();
        if (AuthenticationUtil.authenticationIsRequired(existingAuth, username, appcode)) {
            RedisRetryLoginCache.preCheckTryTimes(username);
            log.debug("用户【{}】即将通过凭证【{}】尝试登录应用【{}】", username, password, appcode);
            //判断是否启用4A认证
            A4PasswordCheck a4PasswordCheck = ApplicationContextProvider.getBean(A4PasswordCheck.class);
            if(a4PasswordCheck.shouldCheckFrom4A(username)){
                log.debug("用户【{}】通过4A对密码【{}】进行校验", username, password);
                return doAttemptAuthentication(request, response, username, password, appcode);
            }
            else {
                Boolean cacheUserPassword = authUserCacheService.loadCacheUserPassword(username, password);
                if (null != cacheUserPassword && cacheUserPassword) {
                    log.debug("恭喜用户【{}】认证命中缓存！Congratulation auth user 【{} 】for success cache password----------START", username, username);
                    log.debug("用户名【{}】和密码【{}】在缓存中存在登录认证通过的缓存记录，直接认证，可以登录成功！", username, password);
                    log.debug("恭喜用户【{}】认证命中缓存！Congratulation auth user 【{} 】for success cache password----------END", username, username);
                    UumsAuthentication uumsAuthentication = new UumsAuthentication(username, UumsAuthenticationCredentials.builder().password(password).appcode(appcode).build());
                    return genericAuthenticationChecker.authChek(uumsAuthentication, appcode, null);
                } else {
                    log.debug("用户【{}】通过CustomDaoAuthenticationProvider对密码明文【{}】进行校验", username, password);
                    return doAttemptAuthentication(request, response, username, password, appcode);
                }
            }
        }
        return existingAuth;
    }

    private Authentication doAttemptAuthentication(HttpServletRequest request, HttpServletResponse response, String username, String password, String appcode){
        //由UsernamePasswordAuthenticationFilter构建UsernamePasswordAuthenticationToken，通过密码明文进行认证
        Authentication existingAuth = super.attemptAuthentication(request, response);
        //账号密码认证通过，清理用户缓存密码，并进行应用鉴权和角色设置
        if (null != existingAuth && existingAuth.isAuthenticated()) {
            if (!DigestUtils.md5Hex(password).equals(SecurityUtils.getRefinePasswordMd5(username))) {
                authUserCacheService.removeCacheUserPassword(username);
                authUserCacheService.saveOrUpdateCacheUserPassword(username, password, true);
            }
            return genericAuthenticationChecker.authChek(existingAuth, appcode, null);
        }
        return existingAuth;
    }

    @Override
    protected void setDetails(HttpServletRequest request, UsernamePasswordAuthenticationToken authRequest) {
//        authRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
        String remoteAddress = HostUtil.getClientIpAddress(request);
        HttpSession session = request.getSession(false);
        String sessionId = session != null ? session.getId() : null;
        LoginPreWebAuthenticationDetails preDetail = LoginPreWebAuthenticationDetails.builder().remoteAddress(remoteAddress).sessionId(sessionId).build();
        authRequest.setDetails(preDetail);
    }

}