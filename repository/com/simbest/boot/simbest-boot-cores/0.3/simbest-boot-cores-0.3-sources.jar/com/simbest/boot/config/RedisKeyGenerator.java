package com.simbest.boot.config;

import com.simbest.boot.constants.ApplicationConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * Redis缓存键生成器
 * 主要功能：
 * 1. 自定义Redis缓存键的生成规则
 * 2. 支持基于类名、方法名和参数值生成唯一的缓存键
 * 3. 提供带参数和无参数两种键生成方式
 * 4. 使用统一的键前缀，便于管理和区分不同应用的缓存
 * 
 * 键格式说明：
 * - 无参数方法：prefix:className:methodName
 * - 有参数方法：prefix:className:methodName:param1&param2&...
 * 其中：
 * - prefix：从配置中获取的Redis键前缀
 * - className：完整的类名
 * - methodName：方法名
 * - paramN：方法参数值，多个参数用&连接
 */
@Component
@Slf4j
public class RedisKeyGenerator implements KeyGenerator {

    /**
     * 应用配置，用于获取Redis键前缀
     */
    @Autowired
    private AppConfig config;

    /**
     * 生成Redis缓存键
     * 实现KeyGenerator接口的方法，用于生成包含参数的完整缓存键
     *
     * @param target 目标对象
     * @param method 方法对象
     * @param objects 方法参数
     * @return 生成的缓存键
     */
    @Override
    public Object generate(Object target, Method method, Object... objects) {
        return getFullKey(target, method, objects);
    }

    /**
     * 生成完整的缓存键
     * 基于目标对象、方法和参数生成唯一的缓存键
     *
     * @param target 目标对象
     * @param method 方法对象
     * @param objects 方法参数
     * @return 完整的缓存键字符串
     */
    public String getFullKey(Object target, Method method, Object... objects) {
        StringBuilder sb = getNoArgsKey(target, method);
        log.debug("生成的无参数键为: {}", sb.toString());
        if(null != objects && objects.length > 0){
            sb.append(ApplicationConstants.COLON);
        }
        for (Object obj : objects) {
            sb.append(obj.toString() + ApplicationConstants.AND);
        }
        String runtimeKey = StringUtils.removeEnd(sb.toString(), ApplicationConstants.AND);
        log.debug("生成的完整键为: {}", runtimeKey);
        return runtimeKey;
    }

    /**
     * 生成不包含参数的基础缓存键
     * 仅基于目标对象和方法生成缓存键
     *
     * @param target 目标对象
     * @param method 方法对象
     * @return 不包含参数的基础缓存键
     */
    public StringBuilder getNoArgsKey(Object target, Method method) {
        StringBuilder sb = new StringBuilder();
        sb.append(config.getRedisKeyPrefix());
        sb.append(target.getClass().getName() + ApplicationConstants.COLON);
        sb.append(method.getName());
        return sb;
    }
}