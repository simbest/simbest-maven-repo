package com.simbest.boot.config;

import com.simbest.boot.base.service.IGenericService;
import com.simbest.boot.base.service.ISystemService;
import com.simbest.boot.base.service.impl.GenericService;
import com.simbest.boot.base.service.impl.SystemService;
import com.simbest.boot.sys.repository.SysLogLoginAdminRepository;
import com.simbest.boot.sys.repository.SysTaskExecutedLogRepository;
import com.simbest.boot.util.distribution.id.repository.SysRedisIdKeyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 用途：应用层服务Service泛型配置类
 * 主要提供以下服务的配置：
 * 1. 系统任务执行日志服务
 * 2. Redis ID键服务
 * 3. 系统管理员登录日志服务
 */
@Configuration
public class ApplicationServiceConfiguration {

    /**
     * 配置系统任务执行日志服务
     * @param repository 系统任务执行日志数据访问对象
     * @return 系统任务执行日志服务实现类实例
     */
    @Bean(name = "sysTaskExecutedLogService")
    @Autowired
    public ISystemService sysTaskExecutedLogService(SysTaskExecutedLogRepository repository) {
        return new SystemService(repository);
    }

    /**
     * 配置Redis ID键服务
     * @param repository Redis ID键数据访问对象
     * @return Redis ID键服务实现类实例
     */
    @Bean(name = "sysRedisIdKeyService")
    @Autowired
    public IGenericService sysRedisIdKeyService(SysRedisIdKeyRepository repository) {
        return new GenericService<>(repository);
    }

    /**
     * 配置系统管理员登录日志服务
     * @param repository 系统管理员登录日志数据访问对象
     * @return 系统管理员登录日志服务实现类实例
     */
    @Bean(name = "sysLogLoginAdminService")
    @Autowired
    public IGenericService sysLogLoginAdminService(SysLogLoginAdminRepository repository) {
        return new GenericService(repository);
    }
}