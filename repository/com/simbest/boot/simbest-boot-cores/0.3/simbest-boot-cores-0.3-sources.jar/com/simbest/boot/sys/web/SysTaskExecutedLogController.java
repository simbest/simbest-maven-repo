package com.simbest.boot.sys.web;

import com.simbest.boot.base.service.ISystemService;
import com.simbest.boot.base.web.controller.GenericController;
import com.simbest.boot.sys.model.SysTaskExecutedLog;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用途：定时任务日志记录控制器
 *
 *
 */
@Api(tags = {"3-系统管理", "定时任务管理"}, description = "提供系统定时任务执行日志的查询和管理功能，记录任务名称、执行节点、执行时间、执行结果等信息，用于任务执行监控和问题排查")
@RestController
@RequestMapping("/sys/task/log")
public class SysTaskExecutedLogController extends GenericController<SysTaskExecutedLog, String> {

    @Autowired
    public SysTaskExecutedLogController(@Qualifier("sysTaskExecutedLogService")ISystemService service) {
        super(service);
    }

}