package com.simbest.boot.base.web.log;

import cn.hutool.core.util.StrUtil;
import com.google.common.collect.ImmutableSet;
import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.sys.model.SysLogWeb;
import com.simbest.boot.sys.service.ISysLogWebService;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.util.server.HostUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.NamedThreadLocal;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Set;

import static com.simbest.boot.config.RedisSessionConfiguration.SECURITYID;

/**
 * 全局Web请求日志拦截器
 * 
 * 功能特点：
 * 1. 记录所有Web控制器的请求日志，包括：
 *    - 请求URL
 *    - 客户端IP
 *    - 控制器方法
 *    - 请求参数
 *    - 执行时间
 *    - 异常信息（如果有）
 * 
 * 2. 日志记录策略：
 *    - 支持配置是否记录日志（通过appConfig.isRecordWebLog()控制）
 *    - 排除特定控制器的日志记录（如验证码、登录等）
 *    - 记录用户会话信息（SecurityID Cookie）
 * 
 * 3. 性能考虑：
 *    - 使用ThreadLocal记录请求开始时间
 *    - 异步保存日志记录
 *    - 参数长度限制（最大2000字符）
 */
@Slf4j
@Aspect
@Order(10)
@Component
@DependsOn(value = {"appConfig", "sysLogWebService"})
public class GlobalWebRequestLogger {

    /**
     * 日志标识前缀
     */
    private final static String LOGTAG = "GWL=======>>";

    /**
     * 应用配置，用于控制是否记录Web日志
     */
    @Autowired
    private AppConfig appConfig;

    /**
     * Web日志服务，用于持久化日志记录
     */
    @Autowired
    private ISysLogWebService logWebService;

    /**
     * 请求开始时间记录器
     * 使用ThreadLocal确保线程安全
     */
    private ThreadLocal<Long> startTime = new NamedThreadLocal<>("global-web-logger");

    /**
     * 不需要记录日志的控制器列表
     * 包括：
     * - 验证码控制器
     * - 登录控制器
     * - 首页控制器
     * - 健康检查控制器
     * - 全局错误控制器
     */
    private Set<String> notRecordController = ImmutableSet.of(
            "com.simbest.boot.security.auth.controller.CaptchaController",
            "com.simbest.boot.security.auth.controller.LoginController", 
            "com.simbest.boot.security.auth.controller.IndexController",
            "com.simbest.boot.sys.web.SysHealthController",
            "com.simbest.exclude.web.GlobalErrorController");

    /**
     * 定义切入点
     * 拦截所有web包下的Controller类的所有方法
     * 注：不使用 *..*Controller.* 以避免影响websocket控制器
     */
    @Pointcut("execution(* *..web..*Controller.*(..))")
    public void webLog() { }

    /**
     * 环绕通知处理Web请求日志
     * 
     * 处理流程：
     * 1. 记录请求开始时间
     * 2. 获取请求信息：
     *    - URL
     *    - IP地址
     *    - 控制器方法
     *    - 请求参数
     * 3. 执行请求处理
     * 4. 记录响应信息：
     *    - 执行时间
     *    - 是否成功
     *    - 异常信息（如果有）
     * 5. 保存日志记录（如果配置允许）
     *
     * @param pjp 切入点信息
     * @return 方法执行结果
     * @throws Throwable 执行过程中的异常
     */
    @Around(value = "webLog()")
    public Object aroundAdvice(ProceedingJoinPoint pjp) throws Throwable {
        startTime.set(System.currentTimeMillis());
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        //防止不是http请求的方法，例如：scheduled
        if (ra == null || sra == null) {
            return pjp.proceed();
        }

        HttpServletRequest request = sra.getRequest();
        String url = request.getRequestURL().toString();
        String ip = HostUtil.getClientIpAddress(request);
        String controller = pjp.getSignature().getDeclaringTypeName();
        String methodname = pjp.getSignature().getName();
        String args = Arrays.toString(pjp.getArgs());
        log.debug(LOGTAG + "请求路径【{}】", url);
        log.debug(LOGTAG + "IP地址【{}】", ip);
        log.debug(LOGTAG + "请求方法【{}】", controller.concat(ApplicationConstants.DOT).concat(methodname));
        log.debug(LOGTAG + "请求参数【{}】", args);
        SysLogWeb logWeb = SysLogWeb.builder().url(request.getRequestURL().toString())
                .ip(ip).controller(controller).methodname(methodname).failed(true)
                .args(StringUtils.substring(args, 0, 1999))
                .build();
        try {
            Object response = pjp.proceed();
            logWeb.setFailed(false);
            return response;
        } catch (Throwable e) {
            log.debug(LOGTAG + "异常信息: " + e.getMessage());
            String failMsg = StrUtil.sub( e.getMessage(),1,2000 );
            logWeb.setFailedReason(failMsg);
            throw e;
        } finally {
            long duration = System.currentTimeMillis() - startTime.get();
            log.debug(LOGTAG + "花费耗时【{}】毫秒", duration);
            logWeb.setDuration(duration);
            try{
                if(appConfig.isRecordWebLog() && !notRecordController.contains(logWeb.getController())) {
                    logWeb.setCreator(SecurityUtils.getCurrentUserName());
                    Cookie[] cookies = request.getCookies();
                    if(cookies != null){
                        for(Cookie cookie : cookies){
                            if(cookie.getName().equals(SECURITYID)){
                                logWeb.setCookieName(cookie.getValue());
                            }
                        }
                    }
                    logWebService.insert(logWeb);
                }
            }catch(Exception e){
                log.error("保存全局日志失败！");
                Exceptions.printException(e);
            }
        }
    }


}