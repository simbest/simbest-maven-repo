package com.simbest.boot.security.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CheckIpIsDevOpsResult {

    private boolean checkRet;

    private String whiteIps;

    private String currentIp;

}