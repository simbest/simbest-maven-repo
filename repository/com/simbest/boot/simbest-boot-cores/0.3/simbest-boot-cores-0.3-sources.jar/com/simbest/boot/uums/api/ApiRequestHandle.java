package com.simbest.boot.uums.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.util.json.JacksonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

/**
 * API请求响应处理器
 * 
 * 提供以下功能：
 * 1. 统一处理API请求的响应结果
 * 2. 支持实体类和对象列表的响应转换
 * 3. 提供异常处理和错误码映射
 * 4. 实现认证相关异常的处理
 * 5. 支持泛型类型的响应处理
 * 6. 提供JSON格式的数据转换
 * 7. 实现统一的日志记录
 */
@Slf4j
@Component
public class ApiRequestHandle<T> {

    /**
     * 处理API请求的响应结果,返回为对应的实体类
     * @param response
     * @param clazz
     * @return
     */
    public T handRemoteResponse(JsonResponse response, Class<T> clazz) {
        return handRemoteNormalResponse( response, clazz,null );
    }

    /**
     * 处理API请求的响应结果,返回为对象实体列表
     * @param response
     * @param listType
     * @return
     */
    public T handRemoteTypeReferenceResponse(JsonResponse response, TypeReference<T> listType) {
        return handRemoteNormalResponse( response, null, listType );
    }

    private T handRemoteNormalResponse(JsonResponse response, Class<T> clazz,TypeReference<T> listType ){
        T object = null;
        if(response==null){
            log.error("接口请求响应为空，请立即确认请求地址和参数！");
        }
        else {
            if(response.getErrcode().equals(JsonResponse.SUCCESS_CODE)){
                String json = JacksonUtils.obj2json(response.getData());
                if(clazz==null){
                    object = JacksonUtils.json2Type( json, listType);
                }else{
                    object = JacksonUtils.json2obj(json, clazz);
                }
            }
            else {
                switch (response.getError()){
                    case AuthoritiesConstants.UsernameNotFoundException:
                        throw new UsernameNotFoundException(response.getError());
                    case AuthoritiesConstants.BadCredentialsException:
                        throw new BadCredentialsException(response.getError());
                    case AuthoritiesConstants.AccountExpiredException:
                        throw new AccountExpiredException(response.getError());
                    case AuthoritiesConstants.DisabledException:
                        throw new DisabledException(response.getError());
                    case AuthoritiesConstants.LockedException:
                        throw new LockedException(response.getError());
                    case AuthoritiesConstants.CredentialsExpiredException:
                        throw new CredentialsExpiredException(response.getError());
                    case AuthoritiesConstants.InternalAuthenticationServiceException:
                        throw new InternalAuthenticationServiceException(response.getError());
                }
            }
        }
        return object;
    }
}