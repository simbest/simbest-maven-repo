package com.simbest.boot.exceptions;

import org.springframework.security.core.AuthenticationException;

/**
 * 登录尝试次数超限异常类
 * 
 * 主要用途：
 * 1. 处理用户登录失败次数超过限制的情况
 * 2. 作为登录安全控制的一部分
 * 3. 防止暴力破解和账户滥用
 * 
 * 特点：
 * 1. 继承自Spring Security的AuthenticationException
 * 2. 支持带消息的异常构造
 * 3. 支持带根异常的异常构造
 * 
 * 使用场景：
 * 1. 用户多次输入错误密码
 * 2. 需要临时锁定账户时
 * 3. 需要强制用户等待一段时间后再试时
 * 
 * 注意事项：
 * 1. 建议配合登录失败计数器使用
 * 2. 可以设置锁定时间和最大尝试次数
 * 3. 应当记录相关的安全日志
 */
public class AttempMaxLoginFaildException extends AuthenticationException {

    /**
     * 创建一个登录尝试次数超限异常
     *
     * @param msg 异常详细信息
     */
    public AttempMaxLoginFaildException(String msg) {
        super(msg);
    }

    /**
     * 创建一个带有根异常的登录尝试次数超限异常
     *
     * @param msg 异常详细信息
     * @param t 根异常
     */
    public AttempMaxLoginFaildException(String msg, Throwable t) {
        super(msg, t);
    }
}