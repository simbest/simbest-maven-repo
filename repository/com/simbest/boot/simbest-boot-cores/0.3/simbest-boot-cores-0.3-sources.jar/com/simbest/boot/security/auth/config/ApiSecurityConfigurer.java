package com.simbest.boot.security.auth.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsByNameServiceWrapper;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.CompositeTokenGranter;
import org.springframework.security.oauth2.provider.TokenGranter;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

import com.simbest.boot.base.service.IOauth2ClientDetailsService;
import com.simbest.boot.security.IAuthService;
import com.simbest.boot.security.auth.oauth2.CustomExtraOauth2ExtendTokenGranter;
import com.simbest.boot.security.auth.oauth2.CustomWebResponseExceptionTranslator;
import com.simbest.boot.security.auth.oauth2.Oauth2RedisTokenStore;
import com.simbest.boot.security.auth.oauth2.Oauth2TokenServices;
import com.simbest.boot.security.auth.oauth2.OauthExceptionEntryPoint;
import com.simbest.boot.security.auth.oauth2.PhoneCodeTokenGranter;
import com.simbest.boot.security.auth.oauth2.PhoneTokenGranter;
import com.simbest.boot.security.auth.oauth2.RsaPasswordTokenGranter;
import com.simbest.boot.security.auth.oauth2.UumsTokenGranter;
import com.simbest.boot.security.auth.oauth2.WxmaBindTokenGranter;
import com.simbest.boot.security.auth.oauth2.WxmaCodeTokenGranter;
import com.simbest.boot.security.auth.oauth2.WxmaMiniTokenGranter;
import com.simbest.boot.security.auth.oauth2.WxmpCodeTokenGranter;
import com.simbest.boot.security.auth.provider.GenericAuthenticationChecker;
import com.simbest.boot.util.encrypt.RsaEncryptor;

import lombok.extern.slf4j.Slf4j;

/**
 * RESTful API安全配置
 * 
 * 主要功能：
 * 1. 配置OAuth2资源服务器和授权服务器
 * 2. 支持多种认证方式（RSA密码、UUMS密码、微信等）
 * 3. 实现令牌管理和访问控制
 * 
 * 认证流程：
 * 1. 客户端请求获取token
 * 2. 根据grant_type选择对应的认证方式
 * 3. 验证客户端和用户凭据
 * 4. 生成访问令牌和刷新令牌
 * 
 * 支持的认证类型：
 * - client_credentials：客户端模式
 * - password：密码模式
 * - rsapassword：RSA加密密码模式
 * - uumspassword：UUMS认证密码模式
 * - wxmabind：微信小程序绑定认证
 * - wxmacode：微信小程序code认证
 * - wxmamini：微信小程序认证
 * - wxmpcode：微信公众号认证
 * - phone：手机号认证
 * - phonecode：手机验证码认证
 * 
 * 配置说明：
 * 1. client_secret需要进行BCryptPasswordEncoder加密存储
 * 2. uumspassword模式的密码需要RSA加密
 * 3. 支持token刷新（除client模式外）
 * 4. Redis用于存储token和客户端信息
 * 
 * 
 * 参考：
 * http://blog.didispace.com/spring-security-oauth2-xjf-1/
 * http://niocoder.com/2018/04/29/Spring-Boot-2.0-%E6%95%B4%E5%90%88-Spring-Security-Oauth2/
 * https://github.com/longfeizheng/springboot2.0-oauth2
 * 作者: lishuyi
 * 时间: 2018/1/20  11:24
 * <p>
 * 获取token请求（/oauth/token），请求所需参数：client_id、client_secret、grant_type
 * client模式：         http://localhost:8080/uums/oauth/token?grant_type=client_credentials&scope=all&client_id=password_changer&client_secret=338d6311c8efad8314b9212860adb12e
 * password模式：       http://localhost:8080/uums/oauth/token?grant_type=password&scope=all&client_id=password_changer&client_secret=338d6311c8efad8314b9212860adb12e&username=hadmin&password=111.com
 * rsa加密password模式： http://localhost:8080/uums/oauth/token?grant_type=rsapassword&scope=all&client_id=password_changer&client_secret=338d6311c8efad8314b9212860adb12e&username=hadmin&password=nvXgA1H+5GLFVP9Fi4vFEZLRU8WzNC2XOAC2lOieB6T9B1rNPzWp1PNs5WptaX3ipQ8znbtn8RdIjDFkVhLx09hvAgWEjQFzYStMk8qAhQWUXa7bZOtC6RQDFJ0WEuDLPyF9CSjN5o3DrEVnNqzTRAHfeP2AYK+N0MsVCI5DkcQ=
 * uums认证password模式：http://localhost:6001/andhall/oauth/token?grant_type=uumspassword&scope=all&client_id=simbest_andhall&client_secret=338d6311c8efad8314b9212860adb12e&appcode=andhall&username=zhengxiaolei&password=pVOMsZTPznKFDU82BNN4BtaALbM4eQ/FphXo77BdSXnn+TTJU2yPqbVKhFoHCG5Kgcm7OuBBlhykzaRgUwGAn7xTXEKdU/uE3bBr4jRDKeOXJ8LxMyelqXFnPVOhF5/GqGCCbafp40BwMUDKdxqdqRVttZmjEST27DmX1U9Hqdc=
 * 注意：
 *  1、client的password的有两种方式：1、BCryptPasswordEncoder加密前的MD5值  2、SecurityUtils万能密码的MD5值
 *  2、client_secret对Simbest_2018做MD5加密得：338d6311c8efad8314b9212860adb12e，而数据库中client_secret需要进行BCryptPasswordEncoder加密后存放，即 $2a$12$.s06wfoiyPGWRCH6xwfdlOt8h.eWQXz97ZQQ/RSFjeReArJy8Ymg2
 *     client_secret对Oa@2018做MD5加密得：5884f8bc2ce66e48406b47b3e6d06757
 *  3、uumspassword方式的password的值因为到主数据认证，所以需要对password进行RSA加密
 *
 * http://andaily.com/blog/?p=528 返回格式
 *
 * 刷新token请求（/oauth/token），请求所需参数：grant_type、refresh_token、client_id、client_secret
 * 注意：client模式没有refresh_token
 * http://localhost:8080/uums/oauth/token?grant_type=refresh_token&client_id=password_changer&client_secret=e10adc3949ba59abbe56e057f20f883e&appcode=nma&refresh_token=fbde81ee-f419-42b1-1234-9191f1f95be9
 *
 * 检查token请求
 * http://localhost:8080/uums/oauth/check_token?token=d1034046-064d-4b5f-b9a6-c0f66abba28d
 *
 * client service的grant_type调整时，redis清理前缀为OAUTH2_CLIENT_PREFIX:,因此执行下述命令：
 * 127.0.0.1:6379> keys OAUTH2_CLIENT_PREFIX:*
 * 127.0.0.1:6379> del OAUTH2_CLIENT_PREFIX:simbest_andhall
 */
@Slf4j
@Configuration
@Order(20)
public class ApiSecurityConfigurer {

    @Autowired
    private ApplicationContext appContext;

    @Autowired
    @Qualifier(BeanIds.AUTHENTICATION_MANAGER)
    private AuthenticationManager authenticationManager;

    @Autowired
    private CustomWebResponseExceptionTranslator customWebResponseExceptionTranslator;

    /**
     * 创建访问拒绝处理器
     * 用于处理OAuth2访问被拒绝的情况
     * 
     * @return OAuth2访问拒绝处理器实例
     */
    @Bean
    public AccessDeniedHandler accessDeniedHandler() {
        final OAuth2AccessDeniedHandler handler = new OAuth2AccessDeniedHandler();
        handler.setExceptionTranslator(customWebResponseExceptionTranslator);
        return handler;
    }

    /**
     * 资源服务器配置
     * 用于保护API资源的访问
     */
    @Configuration
    @EnableResourceServer
    protected class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {

        /**
         * 配置资源服务器的资源ID和异常处理
         */
        @Override
        public void configure(ResourceServerSecurityConfigurer resources) {
            resources.resourceId("*").authenticationEntryPoint(new OauthExceptionEntryPoint());
        }

        /**
         * 配置HTTP安全规则
         * 1. 限制API访问需要认证
         * 2. 配置会话管理策略
         * 3. 设置异常处理
         */
        @Override
        public void configure(HttpSecurity http) throws Exception {
            http
                    .requestMatchers()
                    .antMatchers("/**/api/**")
                    .and()
                    //解决ERR no such key when RedisOperationsSessionRepository.saveChangeSessionId
                    .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)

                    .and()
                    .authorizeRequests()
                    .antMatchers("/**/api/**")
                    .authenticated()
                    .and().httpBasic()
                    .and().exceptionHandling().accessDeniedHandler(accessDeniedHandler()).authenticationEntryPoint(new OauthExceptionEntryPoint());
        }

    }

    /**
     * 授权服务器配置
     * 用于处理OAuth2认证和授权
     */
    @Configuration
    @EnableAuthorizationServer
    public class AuthorizationServerConfiguration extends AuthorizationServerConfigurerAdapter {

        @Autowired
        private IAuthService authService;

        @Autowired
        private Oauth2RedisTokenStore redisTokenStore;

        @Autowired
        private IOauth2ClientDetailsService oauth2ClientDetailsService;

        @Autowired
        private CustomWebResponseExceptionTranslator exceptionTranslator;

        @Autowired
        private RsaEncryptor encryptor;

        @Autowired
        private GenericAuthenticationChecker genericAuthenticationChecker;

        /**
         * 配置客户端详情服务
         */
        @Override
        public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
            clients.withClientDetails(oauth2ClientDetailsService);
        }

        /**
         * 配置授权服务器的安全约束
         */
        @Override
        public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
            security
                    .tokenKeyAccess("permitAll()")
                    //.checkTokenAccess("isAuthenticated()")
                    .checkTokenAccess("permitAll()")
                    .allowFormAuthenticationForClients()
                    .authenticationEntryPoint(new OauthExceptionEntryPoint())
                    .accessDeniedHandler(accessDeniedHandler());
        }

        /**
         * 为令牌服务添加用户详情服务
         * 用于支持刷新令牌功能
         */
        private void addUserDetailsService(DefaultTokenServices tokenServices, UserDetailsService userDetailsService) {
            if (userDetailsService != null) {
                PreAuthenticatedAuthenticationProvider provider = new PreAuthenticatedAuthenticationProvider();
                provider.setPreAuthenticatedUserDetailsService(new UserDetailsByNameServiceWrapper<PreAuthenticatedAuthenticationToken>(
                        userDetailsService));
                tokenServices
                        .setAuthenticationManager(new ProviderManager(Arrays.<AuthenticationProvider> asList(provider)));
            }
        }

        /**
         * 创建OAuth2令牌服务
         * 配置令牌存储、刷新策略等
         */
        @Bean
        public Oauth2TokenServices createOauth2TokenServices() {
            Oauth2TokenServices tokenServices = new Oauth2TokenServices();
            tokenServices.setTokenStore(redisTokenStore);
            tokenServices.setSupportRefreshToken(true);
            tokenServices.setReuseRefreshToken(false);
            tokenServices.setClientDetailsService(oauth2ClientDetailsService);
//            tokenServices.setTokenEnhancer(tokenEnhancer());
            addUserDetailsService(tokenServices, authService);
            tokenServices.setGenericAuthenticationChecker(genericAuthenticationChecker);
            return tokenServices;
        }

        /**
         * 配置授权服务器端点
         * 设置认证管理器、令牌存储、令牌服务等
         */
        @Override
        public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
            // 配置tokenStore，保存到redis缓存中
            endpoints.authenticationManager(authenticationManager)
                    .tokenStore(redisTokenStore)
                    .tokenServices(createOauth2TokenServices())
                    .tokenGranter(tokenGranter(endpoints))
                    // 不添加userDetailsService，刷新access_token时会报错
                    .userDetailsService(authService)
                    .exceptionTranslator(exceptionTranslator);
        }

        /**
         * 配置令牌授权器
         * 支持多种认证方式：
         * 1. RSA密码认证
         * 2. UUMS密码认证
         * 3. 微信小程序认证（绑定、code、mini）
         * 4. 微信公众号认证
         * 5. 手机号认证（密码、验证码）
         * 6. 自定义认证扩展
         */
        private TokenGranter tokenGranter(final AuthorizationServerEndpointsConfigurer endpoints) {
            List<TokenGranter> granters = new ArrayList<>(Arrays.asList(endpoints.getTokenGranter()));
            //追加rsapassword方式的认证
            granters.add(new RsaPasswordTokenGranter(authenticationManager, endpoints.getTokenServices(),
                    endpoints.getClientDetailsService(), endpoints.getOAuth2RequestFactory(), encryptor, genericAuthenticationChecker));
            //追加uumspassword方式的认证
            granters.add(new UumsTokenGranter(authenticationManager, endpoints.getTokenServices(),
                    endpoints.getClientDetailsService(), endpoints.getOAuth2RequestFactory()));

            /**小程序--START**/
            //追加wxmabind方式的认证
            granters.add(new WxmaBindTokenGranter(authenticationManager, endpoints.getTokenServices(),
                    endpoints.getClientDetailsService(), endpoints.getOAuth2RequestFactory()));
            //追加wxmacode方式的认证
            granters.add(new WxmaCodeTokenGranter(authenticationManager, endpoints.getTokenServices(),
                    endpoints.getClientDetailsService(), endpoints.getOAuth2RequestFactory()));
            //追加wxmamini方式的认证
            granters.add(new WxmaMiniTokenGranter(authenticationManager, endpoints.getTokenServices(),
                    endpoints.getClientDetailsService(), endpoints.getOAuth2RequestFactory()));
            /**小程序--END**/

            /**公众号--START**/
            granters.add(new WxmpCodeTokenGranter(authenticationManager, endpoints.getTokenServices(),
                    endpoints.getClientDetailsService(), endpoints.getOAuth2RequestFactory()));
            /**公众号--END**/

            //追加phone方式的认证
            granters.add(new PhoneTokenGranter(authenticationManager, endpoints.getTokenServices(),
                    endpoints.getClientDetailsService(), endpoints.getOAuth2RequestFactory(), encryptor));
            //追加phonecode方式的认证
            granters.add(new PhoneCodeTokenGranter(authenticationManager, endpoints.getTokenServices(),
                    endpoints.getClientDetailsService(), endpoints.getOAuth2RequestFactory(), encryptor));


            //添加应用自定义的令牌授权
            Map<String, CustomExtraOauth2ExtendTokenGranter> auths = appContext.getBeansOfType(CustomExtraOauth2ExtendTokenGranter.class);
            for(CustomExtraOauth2ExtendTokenGranter granter : auths.values()){
                granter.setRequestFactory(endpoints.getOAuth2RequestFactory());
                granters.add(granter);
                log.debug("追加自定义令牌授权器【{}】", granter);
            }

            return new CompositeTokenGranter(granters);
        }

    }


}