package com.simbest.boot.base.web.request;

import org.apache.commons.lang3.builder.ToStringBuilder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 通用请求参数封装类
 * 用于对外提供接口的请求参数标准化封装
 * 
 * 功能特点：
 * 1. 分页支持：
 *    - 包含页码和每页大小
 *    - 支持动态调整分页参数
 * 
 * 2. 排序支持：
 *    - 可指定排序方向（升序/降序）
 *    - 可指定排序字段
 * 
 * 3. 数据封装：
 *    - 使用泛型支持不同类型的请求数据
 *    - 统一的参数格式规范
 *    - 适用于/anonymous/**路径的接口
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description = "通用请求参数，支持分页和排序")
public class ReqParam<T> {

    /**
     * 当前页码，从0开始
     */
    @ApiModelProperty(value = "当前页码（从1开始）", example = "1", required = true)
    private int page = 1; // 提供默认值

    /**
     * 每页显示记录数
     */
    @ApiModelProperty(value = "每页显示记录数", example = "20", required = true)
    private int size = 20; // 提供默认值

    /**
     * 排序方向
     * 可选值：ASC（升序）、DESC（降序）
     */
    @ApiModelProperty(value = "排序方向（ASC/DESC）", example = "DESC")
    private String direction;

    /**
     * 排序字段
     * 支持多个字段，使用逗号分隔
     */
    @ApiModelProperty(value = "排序字段（多个字段用逗号分隔）", example = "createTime")
    private String properties;

    /**
     * 请求数据
     * 使用泛型T支持不同类型的数据结构
     */
    @ApiModelProperty(value = "请求数据")
    private T data;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}



