package com.simbest.boot.sys.web;

import com.github.wenhao.jpa.Specifications;
import com.simbest.boot.base.web.controller.GenericController;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.sys.model.SysLogLogin;
import com.simbest.boot.sys.service.ISysLogLoginService;
import com.simbest.boot.util.MapUtil;
import com.simbest.boot.util.security.LoginUtils;
import com.simbest.boot.util.security.SecurityUtils;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * 用途：登录日志控制器
 *
 *
 */
@Api(tags = {"3-系统管理", "登录日志管理"}, description = "提供系统用户登录日志的查询、统计和同步功能，包括登录次数统计、登录日志同步和4A认证日志记录检查")
@RestController
@RequestMapping("/sys/log/login")
public class SysLogLoginController extends GenericController<SysLogLogin, String> {

    private ISysLogLoginService service;

    @Autowired
    private LoginUtils loginUtils;

    @Autowired
    public SysLogLoginController(ISysLogLoginService service) {
        super(service);
        this.service = service;
    }

    @PostMapping(value = "/countLogin")
    public JsonResponse countLogin(@RequestBody SysLogLogin o) {
        return JsonResponse.success(service.countLogin(MapUtil.objectToMap(o)));
    }

    @PostMapping(value = {"/syncLoginLog", "/syncLoginLog/sso"})
    public JsonResponse sysLoginLog(@RequestBody SysLogLogin o) {
        Specification<SysLogLogin> specification = Specifications.<SysLogLogin>and()
                .between("loginTime", o.getSsDate(), o.getEeDate())
                .build();
        Iterable<SysLogLogin> datas = service.findAllNoPage(specification);
        return JsonResponse.success(datas);
    }


    /**
     * 接入4A统一认证时，提供前端判断当前请求是否记录登录日志（也可以用于判断当前请求是否是北环或省公司开发运维人员）
     * @param request
     * @return
     *
     * http://localhost:8080/appcode/sys/log/login/checkRecordLoginLog
     */
    @PostMapping("/checkRecordLoginLog")
    public boolean checkRecordLoginLog(HttpServletRequest request){
        String currentUserName = SecurityUtils.getCurrentUserName();
        return loginUtils.checkRecordLoginLog(request, currentUserName, null);
    }

}