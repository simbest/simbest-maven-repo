package com.simbest.boot.security.auth.authentication;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;

import java.security.Principal;

/**
 * SSO单点登录认证令牌
 * 
 * 主要功能：
 * 1. 实现基于SSO单点登录的用户认证
 * 2. 继承自Spring Security的AbstractAuthenticationToken
 * 3. 支持多种Principal类型的认证主体
 * 
 * 认证流程：
 * 1. 接收SSO系统传递的用户信息
 * 2. 验证应用访问权限
 * 3. 创建认证令牌并完成认证
 * 
 * 支持的Principal类型：
 * - UsernamePrincipal：基于用户名的认证主体
 * - KeyTypePrincipal：基于密钥类型的认证主体
 */
public class SsoUsernameAuthentication extends AbstractAuthenticationToken {

    /**
     * 认证主体
     * 可以是以下类型：
     * 1. UsernamePrincipal：包含用户名信息
     * 2. KeyTypePrincipal：包含密钥类型信息
     * 
     * 用于：
     * - 存储SSO系统传递的用户标识
     * - 支持多种认证主体类型
     * - 用户身份信息的传递
     */
    @Setter @Getter
    private Object principal;

    /**
     * 认证凭据
     * 存储应用代码(appcode)
     * 
     * 用于：
     * 1. 标识请求来源的应用系统
     * 2. 验证应用的访问权限
     * 3. 支持多应用SSO认证
     */
    @Setter @Getter
    private Object credentials;

    /**
     * 创建SSO认证令牌
     * 
     * @param principal 认证主体，可以是UsernamePrincipal或KeyTypePrincipal
     * @param credentials 应用代码，用于标识请求来源
     * 
     * 说明：
     * 1. 创建时使用空权限列表初始化
     * 2. 认证成功后需要重新设置对应的权限
     * 3. 支持多种类型的认证主体
     */
    public SsoUsernameAuthentication(Principal principal, Object credentials) {
        super(AuthorityUtils.NO_AUTHORITIES);
        this.principal = principal;
        this.credentials = credentials;
    }

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}