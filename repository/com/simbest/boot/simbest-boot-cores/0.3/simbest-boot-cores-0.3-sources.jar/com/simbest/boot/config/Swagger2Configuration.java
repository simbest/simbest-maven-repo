package com.simbest.boot.config;

import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.AlternateTypeRules;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Swagger2 API文档配置类
 * 
 * 主要功能：
 * 1. 提供RESTful API的在线文档功能
 * 2. 支持在线测试API接口
 * 3. 自动生成API文档，包含接口说明、请求参数、响应结果等
 * 4. 仅在开发(dev)、测试(test)和预生产(uat)环境中启用
 * 
 * 访问地址：http://localhost:8001/uums/swagger-ui.html
 * 
 * 注意事项：
 * 1. 生产环境下默认关闭，通过@Profile注解控制
 * 2. 可以通过@ApiOperation等注解添加接口描述
 * 3. 支持通过配置文件自定义API文档信息
 */
@Configuration
@EnableSwagger2 // 启用原生 Swagger2
// @EnableSwaggerBootstrapUi // 启用 Knife4j 增强
@Profile(value = { "dev", "test", "uat", "pdtest" })
public class Swagger2Configuration {

        @Bean
        public Docket buildDocket() {
                return (new Docket(DocumentationType.SWAGGER_2))
                                .apiInfo(buildApiInf())
                                .select()
                                .apis(RequestHandlerSelectors.basePackage("com.simbest"))
                                .paths(PathSelectors.any())
                                .build()
                                .useDefaultResponseMessages(false)
                                .forCodeGeneration(true)
                                .alternateTypeRules(
                                                AlternateTypeRules.newRule(Map.class, Object.class));
        }

        private ApiInfo buildApiInf() {
                return new ApiInfoBuilder()
                                .title("SIMBEST Boot API Documentation")
                                .description("RESTful API documentation based on SpringBoot 2.2.2 + Swagger2 2.9.2\n\n"
                                                +
                                                "Project Dependencies:\n" +
                                                "1. simbest-boot-cmcc:jar:0.3\n" +
                                                "2. simbest-boot-cores:jar:0.3\n" +
                                                "3. simbest-boot-orguser:jar:0.1\n" +
                                                "4. spring-cloud-starter-alibaba-nacos-config:jar:2.2.9.RELEASE\n" +
                                                "5. spring-cloud-starter-alibaba-nacos-discovery:jar:2.2.9.RELEASE\n" +
                                                "6. spring-cloud-starter-openfeign:jar:2.2.9.RELEASE\n" +
                                                "7. spring-cloud-starter-loadbalancer:jar:2.2.9.RELEASE\n" +
                                                "8. caffeine:jar:2.9.3\n" +
                                                "9. java-jwt:jar:4.4.0\n" +
                                                "10. spring-boot-starter-web:jar:2.2.2.RELEASE\n" +
                                                "11. spring-boot-starter-thymeleaf:jar:2.2.2.RELEASE\n" +
                                                "12. spring-boot-starter-security:jar:2.2.2.RELEASE\n" +
                                                "13. spring-security-acl:jar:5.2.1.RELEASE\n" +
                                                "14. spring-security-config:jar:5.2.1.RELEASE\n" +
                                                "15. spring-boot-starter-data-jpa:jar:2.2.2.RELEASE\n" +
                                                "16. spring-boot-starter-data-redis:jar:2.2.2.RELEASE\n" +
                                                "17. spring-session-data-redis:jar:2.2.0.RELEASE\n" +
                                                "18. spring-security-oauth2-autoconfigure:jar:2.0.8.RELEASE\n" +
                                                "19. spring-boot-starter-actuator:jar:2.2.2.RELEASE\n" +
                                                "20. spring-boot-configuration-processor:jar:2.2.2.RELEASE\n" +
                                                "21. cxf-spring-boot-starter-jaxws:jar:3.2.4\n" +
                                                "22. spring-boot-admin-starter-client:jar:2.0.0\n" +
                                                "23. springfox-swagger2:jar:2.9.2\n" +
                                                "24. springfox-swagger-ui:jar:2.9.2\n" +
                                                "25. spring-retry:jar:1.2.4.RELEASE\n" +
                                                "26. druid-spring-boot-starter:jar:1.2.23\n" +
                                                "27. mysql-connector-java:jar:8.0.11\n" +
                                                "28. h2:jar:1.4.196\n" +
                                                "29. ojdbc6:jar:11.2.0.3\n" +
                                                "30. oceanbase-client:jar:2.4.9\n" +
                                                "31. jpa-spec:jar:3.2.3\n" +
                                                "32. javax.interceptor-api:jar:3.1\n" +
                                                "33. redisson:jar:3.10.3\n" +
                                                "34. webjars-locator:jar:0.34\n" +
                                                "35. jsoup:jar:1.16.1\n" +
                                                "36. htmlunit:jar:2.70.0\n" +
                                                "37. fastdfs-client-java:jar:1.27\n" +
                                                "38. lombok:jar:1.18.10\n" +
                                                "39. commons-lang3:jar:3.9\n" +
                                                "40. commons-pool2:jar:2.7.0\n" +
                                                "41. commons-io:jar:2.6\n" +
                                                "42. commons-codec:jar:1.11\n" +
                                                "43. commons-beanutils:jar:1.9.3\n" +
                                                "44. joda-time:jar:2.7\n" +
                                                "45. commons-net:jar:3.6\n" +
                                                "46. jsch:jar:0.1.55\n" +
                                                "47. hutool-all:jar:5.3.7\n" +
                                                "48. xstream:jar:1.4.10\n" +
                                                "49. xk-time:jar:1.1.1\n" +
                                                "50. thumbnailator:jar:0.4.8\n" +
                                                "51. galimatias:jar:0.2.1\n" +
                                                "52. jpinyin:jar:1.1.8\n" +
                                                "53. zxing-core:jar:3.1.0\n" +
                                                "54. zxing-javase:jar:3.1.0\n" +
                                                "55. gson:jar:2.8.6\n" +
                                                "56. mapstruct-jdk8:jar:1.3.0.Beta1\n" +
                                                "57. easypoi-spring-boot-starter:jar:4.1.2\n" +
                                                "58. zip4j:jar:1.3.2\n" +
                                                "59. junrar:jar:0.7\n" +
                                                "60. itextpdf:jar:5.5.3\n" +
                                                "61. xmlworker:jar:5.5.3\n" +
                                                "62. itext-asian:jar:5.2.0\n" +
                                                "63. xmlbeans:jar:2.6.0\n" +
                                                "64. spring-boot-starter-test:jar:2.2.2.RELEASE\n" +
                                                "65. PortalEncrypt:jar:1.0\n" +
                                                "66. logstash-logback-encoder:jar:7.0.1\n" +
                                                "67. jpa-comment-spring-boot-starter:jar:1.0.1")
                                .termsOfServiceUrl("http://localhost:8080/")
                                .contact(new Contact("Service", "https://www.aliyun.com/", "service@aliyun.com"))
                                .version("1.0")
                                .build();
        }

}
