package com.simbest.boot.base.repository;

import com.simbest.boot.base.model.Oauth2ClientDetails;
import org.springframework.stereotype.Repository;

/**
 * OAuth2客户端信息数据持久层接口
 * 提供OAuth2客户端配置信息的数据访问功能：
 * - 扩展GenericRepository，继承其基础数据库操作功能
 * - 为Oauth2ClientDetails实体提供数据访问支持
 * - 支持基于clientId查询客户端详细信息
 * - 用于OAuth2认证授权框架中客户端应用的注册与管理
 */
@Repository
public interface Oauth2ClientDetailsRepository extends GenericRepository<Oauth2ClientDetails, String> {

    /**
     * 根据客户端ID查询OAuth2客户端详细信息
     * 
     * @param clientId OAuth2客户端唯一标识符
     * @return 对应的OAuth2客户端详细配置信息
     */
    Oauth2ClientDetails findByClientId(String clientId);
}