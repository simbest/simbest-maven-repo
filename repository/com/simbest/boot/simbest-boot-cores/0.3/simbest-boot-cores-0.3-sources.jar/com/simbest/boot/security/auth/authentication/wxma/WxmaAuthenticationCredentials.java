package com.simbest.boot.security.auth.authentication.wxma;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

/**
 * 微信小程序认证凭据
 * 
 * 主要功能：
 * 1. 封装微信小程序登录认证所需的凭据信息
 * 2. 支持多种认证方式（小程序码、短信验证码）
 * 3. 实现序列化接口，支持分布式环境
 * 
 * 认证流程：
 * 1. 获取微信小程序登录code
 * 2. 获取加密数据和初始向量
 * 3. 可选的短信验证码验证
 * 4. 支持自动创建新用户
 * 
 * 安全特性：
 * - 数据加密传输
 * - 多重认证验证
 * - 灵活的用户创建策略
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WxmaAuthenticationCredentials implements Serializable {

    /**
     * 应用代码
     * 用于：
     * 1. 标识请求来源的应用系统
     * 2. 支持多应用认证场景
     * 3. 应用级别的权限控制
     */
    private String appcode;

    /**
     * 微信小程序的AppID
     * 用于：
     * 1. 标识具体的微信小程序
     * 2. 调用微信开放接口
     * 3. 验证请求的合法性
     */
    private String appid;

    /**
     * 短信验证码
     * 用于：
     * 1. 手机号码验证
     * 2. 双重认证
     * 3. 增强安全性
     */
    private String smscode;

    /**
     * 微信小程序登录code
     * 用于：
     * 1. 换取用户openid和session_key
     * 2. 微信身份验证
     * 3. 临时凭证，有效期5分钟
     */
    private String wxcode;

    /**
     * 微信小程序加密数据
     * 用于：
     * 1. 存储通过微信接口获取的加密用户信息
     * 2. 需要配合session_key解密
     * 3. 包含用户敏感数据
     */
    private String encryptedData;

    /**
     * 加密算法初始向量
     * 用于：
     * 1. 配合encryptedData解密
     * 2. AES-128-CBC解密算法
     * 3. 保证数据安全性
     */
    private String iv;

    /**
     * 是否自动创建用户标志
     * 用于：
     * 1. 控制未注册用户的处理策略
     * 2. true表示自动创建新用户
     * 3. false表示仅允许已存在用户登录
     */
    private Boolean forceCreate;

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 注意：输出时应注意敏感信息的保护
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}