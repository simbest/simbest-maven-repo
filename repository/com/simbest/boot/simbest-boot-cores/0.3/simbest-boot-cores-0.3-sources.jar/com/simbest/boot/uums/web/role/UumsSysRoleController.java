package com.simbest.boot.uums.web.role;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.security.SimpleRole;
import com.simbest.boot.uums.api.role.UumsSysRoleApi;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 系统角色管理控制器
 * 提供角色相关的REST API接口：
 * - 角色基础信息管理
 * - 角色权限管理
 * - 角色状态管理
 * - 角色用户关联
 * - 支持分页和模糊查询
 */

@SuppressWarnings("ALL")
@Api(tags = {"2-统一用户管理", "角色管理"}, description = "提供角色相关的REST API接口，包括角色的基础CRUD操作、角色权限管理、角色状态管理、角色与用户的关联等功能")
@RestController
@RequestMapping(value = {"/uums/sys/role", "/sys/uums/role"})
public class UumsSysRoleController {

    @Autowired
    private UumsSysRoleApi uumsSysRoleApi;

    /**
     * 查询角色信息
     * @param id
     * @param appcode
     * @return
     */
    @ApiOperation(value = "查询角色信息",notes = "查询角色信息",tags={"角色API"})
    @ApiImplicitParams({
        @ApiImplicitParam(name = "id",value = "角色ID",dataType = "Integer",paramType = "query" ),
        @ApiImplicitParam(name = "appcode",value = "appcode",dataType = "String",paramType = "query" )
    })
    @PostMapping(value="/findById")
    public JsonResponse findById( @RequestParam String id, @RequestParam String appcode) {
        return JsonResponse.success(uumsSysRoleApi.findById(id,appcode));
    }

    @ApiOperation(value = "用于管理后台角色列表页查询角色列表，根据角色名模糊查询并分页", notes = "用于管理后台角色列表页查询角色列表，根据角色名查询并分页",tags={"角色API"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "当前页码", dataType = "int", paramType = "query", required = true, example = "1"),
            @ApiImplicitParam(name = "size", value = "每页数量", dataType = "int", paramType = "query",required = true, example = "10"),
            @ApiImplicitParam(name = "direction", value = "排序规则（asc/desc）", dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "properties", value = "排序规则（属性名称）", dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "map", value = "角色名字", dataType = "object",paramType = "body"),
    })
    @PostMapping(value = {"/findRoleNameIsARoleDim","/findRoleNameIsARoleDim/sso","/api/findRoleNameIsARoleDim/sso"})
    public JsonResponse findRoleNameIsARoleDim( @RequestParam(required = false, defaultValue = "1") int page,
                                                @RequestParam(required = false, defaultValue = "10") int size,
                                                @RequestParam(required = false) String direction,
                                                @RequestParam(required = false) String properties,
                                                @RequestBody Map<String,Object> map)
    {
        return uumsSysRoleApi.findRoleNameIsARoleDim(page,size,direction,properties,map);
    }

    /**
     * 获取角色信息列表并分页
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @param appcode
     * @param map
     * @return
     */
    @ApiOperation(value = "获取角色列表", notes = "通过此接口来获取角色列表")
    @ApiImplicitParams ({ //
            @ApiImplicitParam (name = "page", value = "当前页码", dataType = "int", paramType = "query", //
                    required = true, example = "1"), //
            @ApiImplicitParam(name = "size", value = "每页数量", dataType = "int", paramType = "query", //
                    required = true, example = "10"), //
            @ApiImplicitParam(name = "direction", value = "排序规则（asc/desc）", dataType = "String", //
                    paramType = "query"), //
            @ApiImplicitParam(name = "properties", value = "排序规则（属性名称）", dataType = "String", //
                    paramType = "query") //
    })
    @PostMapping("/findAll")
    public JsonResponse findAll( @RequestParam(required = false, defaultValue = "1") int page, //
                                 @RequestParam(required = false, defaultValue = "10") int size, //
                                 @RequestParam(required = false) String direction, //
                                 @RequestParam(required = false) String properties,
                                 @RequestParam String appcode,
                                 @RequestBody Map map ) {
        return JsonResponse.success(uumsSysRoleApi.findAll(page,size,direction,properties,appcode,map));
    }

    /**
     * 校验roleCode是否存在
     * @param appcode
     * @param roleCode
     * @return
     */
    @ApiOperation(value = "校验roleCode是否存在",notes = "校验roleCode是否存在" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "appcode",value = "appcode",dataType = "String",paramType = "query" ),
            @ApiImplicitParam(name = "roleCode",value = "角色code",dataType = "String",paramType = "query" )
    })
    @PostMapping(value="/isHaveCode")
    public JsonResponse isHaveCode(  @RequestParam String appcode,@RequestParam String roleCode) {
        return JsonResponse.success(uumsSysRoleApi.isHaveCode(appcode,roleCode));
    }


    @ApiOperation(value = "新增角色",notes = "新增角色" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "appcode",value = "appcode",dataType = "String",paramType = "query" ),
            @ApiImplicitParam(name = "simpleRole",value = "角色对象",dataType = "SimpleRole",paramType = "body" )
    })
    @PostMapping(value="/addRole")
    public JsonResponse addRole(@RequestParam String appcode, @RequestBody SimpleRole simpleRole) {
        SimpleRole addSimpleRole = uumsSysRoleApi.addRole(appcode,simpleRole);
        return JsonResponse.success(addSimpleRole);
    }

    @ApiOperation(value = "删除角色",notes = "删除角色" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "appcode",value = "appcode",dataType = "String",paramType = "query" ),
            @ApiImplicitParam(name = "simpleRole",value = "角色对象",dataType = "SimpleRole",paramType = "body" )
    })
    @PostMapping(value="/delRole")
    public JsonResponse delRole(@RequestParam String appcode, @RequestBody SimpleRole simpleRole) {
        boolean flag = uumsSysRoleApi.delRole(appcode,simpleRole);
        return JsonResponse.success(flag);
    }

    @ApiOperation(value = "修改角色",notes = "删除角色" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "appcode",value = "appcode",dataType = "String",paramType = "query" ),
            @ApiImplicitParam(name = "simpleRole",value = "角色对象",dataType = "SimpleRole",paramType = "body" )
    })
    @PostMapping(value="/updateRole")
    public JsonResponse updateRole(@RequestParam String appcode, @RequestBody SimpleRole simpleRole) {
        SimpleRole updateRole = uumsSysRoleApi.updateRole(appcode,simpleRole);
        return JsonResponse.success(updateRole);
    }

    @ApiOperation(value = "根据菜单ID查询被授权的角色", notes = "根据菜单ID查询被授权的角色",tags={"角色API"})
    @ApiImplicitParam(name = "permissionId", value = "菜单ID", dataType = "String", paramType = "query")
    @PostMapping(value = {"/queryRoleByPermissionId", "/queryRoleByPermissionId/sso","/api/queryRoleByPermissionId"})
    public JsonResponse queryRoleByPermissionId(@RequestParam(required = false) String  permissionId) {
        return uumsSysRoleApi.queryRoleByPermissionId(permissionId);
    }

    //启用群组
    @PostMapping(value = {"/updateSysRole","/updateSysRole/sso"})
    public JsonResponse updateSysRole(@RequestParam String id,@RequestParam String status) {
        return  uumsSysRoleApi.updateSysRole(id,status);
    }
}