package com.simbest.boot.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

/**
 * Spring Session Redis配置类
 * 主要功能：
 * 1. 配置基于Redis的会话管理
 * 2. 自定义Cookie序列化器，定制会话Cookie的行为
 * 3. 支持跨域和分布式会话管理
 * 
 * Cookie配置说明：
 * 1. Cookie名称：使用自定义的SECURITYID，而不是默认的SESSION
 * 2. Cookie路径：当前未启用自定义路径，避免多应用共享时的类加载问题
 * 3. Cookie域名：当前未限制域名模式，以支持微信和CAS等场景的重定向
 * 
 * 注意事项：
 * - 不同应用共享会话时需注意类加载问题
 * - 重定向场景下需要确保会话信息的正确传递
 */
@Configuration
public class RedisSessionConfiguration {

    /**
     * 自定义会话Cookie的名称
     */
    public static final String SECURITYID = "SECURITYID";

    /**
     * 应用配置，用于获取Cookie相关配置
     */
    @Autowired
    private AppConfig config;

    /**
     * 配置Cookie序列化器
     * 自定义会话Cookie的行为，包括名称、路径和域名等
     * 
     * @return CookieSerializer Cookie序列化器实例
     */
    @Bean
    public CookieSerializer cookieSerializer() {
        DefaultCookieSerializer serializer = new DefaultCookieSerializer();
        serializer.setCookieName(SECURITYID); // 设置自定义的Cookie名称

        // Cookie路径配置（当前已注释）
        // 注释原因：避免不同应用共享会话时，因类加载问题导致的序列化异常
        // 如：Failed to deserialize object type; nested exception is java.lang.ClassNotFoundException: com.simbest.boot.uums.role.model.SysRole
//        if(StringUtils.isNotEmpty(config.getCookiePath()))
//            serializer.setCookiePath(config.getCookiePath());

        // Cookie域名配置（当前已注释）
        // 注释原因：避免在微信、CAS等服务器302重定向时丢失会话信息
//        serializer.setDomainNamePattern("^.+?\\.(\\w+\\.[a-z]+)$");

        return serializer;
    }
}