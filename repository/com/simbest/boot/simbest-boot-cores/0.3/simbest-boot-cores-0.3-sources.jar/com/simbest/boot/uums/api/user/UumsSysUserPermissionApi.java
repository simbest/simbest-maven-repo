package com.simbest.boot.uums.api.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.util.UriEncoder;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.security.SimpleApp;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.uums.api.app.UumsSysAppApi;

import lombok.extern.slf4j.Slf4j;

/**
 * 用于管理用户权限的API
 */
@Component
@Slf4j
public class UumsSysUserPermissionApi {

    private static final String USER_MAPPING = "/action/user/permission/";
    private static final String SSO = "/sso";

    @Autowired
    private AppConfig config;

    @Autowired
    private RsaEncryptor encryptor;

    @Autowired
    private UumsSysAppApi uumsSysAppApi;

    /**
     * 修改用户权限信息，先删除用户所有权限，再重新添加
     * 
     * @param permissionId 权限ID
     * @param userCodes    用户代码列表
     * @return JsonResponse
     */
    public JsonResponse updateListByPermissionId(String permissionId,List<String> userCodes) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        SimpleApp simpleApp = uumsSysAppApi.findAppByAppCode(config.getAppcode(),username);
        String username1 = encryptor.encrypt(username);
        String username2 = UriEncoder.encode( username1 );
        JsonResponse response =  HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "updateListByPermissionId"+SSO+"?loginuser="+username2+
                        "&appcode="+config.getAppcode()+"&permissionId="+permissionId+"&appId="+simpleApp.getId())
                .json(JacksonUtils.obj2json(userCodes))
                .asBean(JsonResponse.class);
        if(response == null){
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }
}