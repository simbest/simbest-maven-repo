package com.simbest.boot.security.auth.oauth2;

import com.simbest.boot.config.AppConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.security.oauth2.common.ExpiringOAuth2RefreshToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.AuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.DefaultAuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.redis.JdkSerializationStrategy;
import org.springframework.security.oauth2.provider.token.store.redis.RedisTokenStoreSerializationStrategy;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * 用途：自定义基于Redis的令牌存储
 *
 *
 */
@Slf4j
@Component
public class Oauth2RedisTokenStore implements TokenStore {
    private static final String ACCESS = "access:";
    private static final String AUTH_TO_ACCESS = "auth_to_access:";
    private static final String AUTH = "auth:";
    private static final String REFRESH_AUTH = "refresh_auth:";
    private static final String ACCESS_TO_REFRESH = "access_to_refresh:";
    private static final String REFRESH = "refresh:";
    private static final String REFRESH_TO_ACCESS = "refresh_to_access:";
    private static final String CLIENT_ID_TO_ACCESS = "client_id_to_access:";
    private static final String UNAME_TO_ACCESS = "uname_to_access:";

    private final RedisConnectionFactory connectionFactory;
    private AuthenticationKeyGenerator authenticationKeyGenerator = new DefaultAuthenticationKeyGenerator();
    private RedisTokenStoreSerializationStrategy serializationStrategy = new JdkSerializationStrategy();

    private String prefix;

    private volatile Boolean isClusterMode = null;

    @Autowired
    public Oauth2RedisTokenStore(RedisConnectionFactory connectionFactory, AppConfig config) {
        this.connectionFactory = connectionFactory;
        this.prefix = config.getRedisKeyPrefix();
    }

    public void setAuthenticationKeyGenerator(AuthenticationKeyGenerator authenticationKeyGenerator) {
        this.authenticationKeyGenerator = authenticationKeyGenerator;
    }

    public void setSerializationStrategy(RedisTokenStoreSerializationStrategy serializationStrategy) {
        this.serializationStrategy = serializationStrategy;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    private RedisConnection getConnection() {
        return connectionFactory.getConnection();
    }

    /**
     * 判断是否为Redis集群模式
     * JedisClusterConnection不支持Pipeline操作
     */
    private boolean isClusterMode() {
        if (isClusterMode == null) {
            synchronized (this) {
                if (isClusterMode == null) {
                    RedisConnection conn = null;
                    try {
                        conn = getConnection();
                        // JedisClusterConnection的类名包含"Cluster"
                        isClusterMode = conn.getClass().getSimpleName().contains("Cluster");
                        log.info("检测到Redis连接类型: {}, 集群模式: {}",
                                conn.getClass().getSimpleName(), isClusterMode);
                    } catch (Exception e) {
                        log.warn("检测Redis连接类型失败，默认为单机模式", e);
                        isClusterMode = false;
                    } finally {
                        if (conn != null) {
                            conn.close();
                        }
                    }
                }
            }
        }
        return isClusterMode;
    }

    /**
     * Pipeline操作回调接口
     */
    private interface PipelineCallback {
        void doInPipeline(RedisConnection conn);
    }

    /**
     * 安全执行Pipeline操作的包装方法
     * 如果是集群模式，则逐个执行命令；否则使用Pipeline批量执行
     */
    private List<Object> executePipeline(RedisConnection conn, PipelineCallback callback) {
        if (isClusterMode()) {
            // 集群模式：直接执行命令，不使用Pipeline
            callback.doInPipeline(conn);
            return Collections.emptyList();
        } else {
            // 单机模式：使用Pipeline批量执行
            conn.openPipeline();
            callback.doInPipeline(conn);
            return conn.closePipeline();
        }
    }

    private byte[] serialize(Object object) {
        return serializationStrategy.serialize(object);
    }

    private byte[] serializeKey(String object) {
        return serialize(prefix + object);
    }

    private OAuth2AccessToken deserializeAccessToken(byte[] bytes) {
        return serializationStrategy.deserialize(bytes, OAuth2AccessToken.class);
    }

    private OAuth2Authentication deserializeAuthentication(byte[] bytes) {
        return serializationStrategy.deserialize(bytes, OAuth2Authentication.class);
    }

    private OAuth2RefreshToken deserializeRefreshToken(byte[] bytes) {
        return serializationStrategy.deserialize(bytes, OAuth2RefreshToken.class);
    }

    private byte[] serialize(String string) {
        return serializationStrategy.serialize(string);
    }

    private String deserializeString(byte[] bytes) {
        return serializationStrategy.deserializeString(bytes);
    }

    @Override
    public OAuth2AccessToken getAccessToken(OAuth2Authentication authentication) {
        String key = authenticationKeyGenerator.extractKey(authentication);
        byte[] serializedKey = serializeKey(AUTH_TO_ACCESS + key);
        byte[] bytes = null;
        RedisConnection conn = getConnection();
        try {
            bytes = conn.get(serializedKey);
        } finally {
            conn.close();
        }
        OAuth2AccessToken accessToken = deserializeAccessToken(bytes);
//        if (accessToken != null
//                && !key.equals(authenticationKeyGenerator.extractKey(readAuthentication(accessToken.getValue())))) {
//            // Keep the stores consistent (maybe the same user is
//            // represented by this authentication but the details have
//            // changed)
//            storeAccessToken(accessToken, authentication);
//        }
        if (accessToken != null) {
            OAuth2Authentication storedAuthentication = readAuthentication(accessToken.getValue());
            if ((storedAuthentication == null || !key.equals(authenticationKeyGenerator.extractKey(storedAuthentication)))) {
                // Keep the stores consistent (maybe the same user is
                // represented by this authentication but the details have
                // changed)
                storeAccessToken(accessToken, authentication);
            }

        }
        return accessToken;
    }

    @Override
    public OAuth2Authentication readAuthentication(OAuth2AccessToken accessToken) {
        return readAuthentication(accessToken.getValue());
    }

    @Override
    public OAuth2Authentication readAuthentication(String accessToken) {
        byte[] bytes = null;
        RedisConnection conn = getConnection();
        try {
            bytes = conn.get(serializeKey(AUTH + accessToken));
        } finally {
            conn.close();
        }
        OAuth2Authentication auth = deserializeAuthentication(bytes);
        return auth;
    }

    @Override
    public OAuth2Authentication readAuthenticationForRefreshToken(OAuth2RefreshToken refreshToken) {
        return readAuthenticationForRefreshToken(refreshToken.getValue());
    }

    public OAuth2Authentication readAuthenticationForRefreshToken(String refreshToken) {
        RedisConnection conn = getConnection();
        try {
            byte[] bytes = conn.get(serializeKey(REFRESH_AUTH + refreshToken));
            OAuth2Authentication auth = deserializeAuthentication(bytes);
            return auth;
        } finally {
            conn.close();
        }
    }

    @Override
    public void storeAccessToken(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
        byte[] serializedAccessToken = serialize(accessToken);
        byte[] serializedAuth = serialize(authentication);
        byte[] accessKey = serializeKey(ACCESS + accessToken.getValue());
        byte[] authKey = serializeKey(AUTH + accessToken.getValue());
        byte[] authToAccessKey = serializeKey(AUTH_TO_ACCESS + authenticationKeyGenerator.extractKey(authentication));
        byte[] approvalKey = serializeKey(UNAME_TO_ACCESS + getApprovalKey(authentication));
        byte[] clientId = serializeKey(CLIENT_ID_TO_ACCESS + authentication.getOAuth2Request().getClientId());

        RedisConnection conn = getConnection();
        try {
            executePipeline(conn, c -> {
                c.stringCommands().set(accessKey, serializedAccessToken);
                c.stringCommands().set(authKey, serializedAuth);
                c.stringCommands().set(authToAccessKey, serializedAccessToken);
                if (!authentication.isClientOnly()) {
                    c.rPush(approvalKey, serializedAccessToken);
                }
                c.rPush(clientId, serializedAccessToken);
                if (accessToken.getExpiration() != null) {
                    int seconds = accessToken.getExpiresIn();
                    c.expire(accessKey, seconds);
                    c.expire(authKey, seconds);
                    c.expire(authToAccessKey, seconds);
                    c.expire(clientId, seconds);
                    c.expire(approvalKey, seconds);
                }
                OAuth2RefreshToken refreshToken = accessToken.getRefreshToken();
                if (refreshToken != null && refreshToken.getValue() != null) {
                    byte[] refresh = serialize(accessToken.getRefreshToken().getValue());
                    byte[] auth = serialize(accessToken.getValue());
                    byte[] refreshToAccessKey = serializeKey(REFRESH_TO_ACCESS + accessToken.getRefreshToken().getValue());
                    c.stringCommands().set(refreshToAccessKey, auth);
                    byte[] accessToRefreshKey = serializeKey(ACCESS_TO_REFRESH + accessToken.getValue());
                    c.stringCommands().set(accessToRefreshKey, refresh);
                    if (refreshToken instanceof ExpiringOAuth2RefreshToken) {
                        ExpiringOAuth2RefreshToken expiringRefreshToken = (ExpiringOAuth2RefreshToken) refreshToken;
                        Date expiration = expiringRefreshToken.getExpiration();
                        if (expiration != null) {
                            int seconds = Long.valueOf((expiration.getTime() - System.currentTimeMillis()) / 1000L)
                                    .intValue();
                            c.expire(refreshToAccessKey, seconds);
                            c.expire(accessToRefreshKey, seconds);
                        }
                    }
                }
            });
        } finally {
            conn.close();
        }
    }

    private static String getApprovalKey(OAuth2Authentication authentication) {
        String userName = authentication.getUserAuthentication() == null ? ""
                : authentication.getUserAuthentication().getName();
        return getApprovalKey(authentication.getOAuth2Request().getClientId(), userName);
    }

    private static String getApprovalKey(String clientId, String userName) {
        return clientId + (userName == null ? "" : ":" + userName);
    }

    @Override
    public void removeAccessToken(OAuth2AccessToken accessToken) {
        removeAccessToken(accessToken.getValue());
    }

    @Override
    public OAuth2AccessToken readAccessToken(String accessTokenValue) {
        byte[] key = serializeKey(ACCESS + accessTokenValue);
        byte[] bytes = null;
        RedisConnection conn = getConnection();
        try {
            bytes = conn.get(key);
        } finally {
            conn.close();
        }
        OAuth2AccessToken accessToken = deserializeAccessToken(bytes);
        return accessToken;
    }

    public void removeAccessToken(String accessTokenValue) {
        byte[] accessKey = serializeKey(ACCESS + accessTokenValue);
        byte[] authKey = serializeKey(AUTH + accessTokenValue);
        byte[] accessToRefreshKey = serializeKey(ACCESS_TO_REFRESH + accessTokenValue);
        RedisConnection conn = getConnection();
        try {
            // 先获取需要的数据
            byte[] access = conn.get(accessKey);
            byte[] auth = conn.get(authKey);

            // 执行删除操作
            executePipeline(conn, c -> {
                c.del(accessKey);
                c.del(accessToRefreshKey);
                // Don't remove the refresh token - it's up to the caller to do that
                c.del(authKey);
            });

            OAuth2Authentication authentication = deserializeAuthentication(auth);
            if (authentication != null) {
                String key = authenticationKeyGenerator.extractKey(authentication);
                byte[] authToAccessKey = serializeKey(AUTH_TO_ACCESS + key);
                byte[] unameKey = serializeKey(UNAME_TO_ACCESS + getApprovalKey(authentication));
                byte[] clientId = serializeKey(CLIENT_ID_TO_ACCESS + authentication.getOAuth2Request().getClientId());

                executePipeline(conn, c -> {
                    c.del(authToAccessKey);
                    c.lRem(unameKey, 1, access);
                    c.lRem(clientId, 1, access);
                    c.del(serialize(ACCESS + key));
                });
            }
        } finally {
            conn.close();
        }
    }

    @Override
    public void storeRefreshToken(OAuth2RefreshToken refreshToken, OAuth2Authentication authentication) {
        byte[] refreshKey = serializeKey(REFRESH + refreshToken.getValue());
        byte[] refreshAuthKey = serializeKey(REFRESH_AUTH + refreshToken.getValue());
        byte[] serializedRefreshToken = serialize(refreshToken);
        RedisConnection conn = getConnection();
        try {
            executePipeline(conn, c -> {
                c.stringCommands().set(refreshKey, serializedRefreshToken);
                c.stringCommands().set(refreshAuthKey, serialize(authentication));
                if (refreshToken instanceof ExpiringOAuth2RefreshToken) {
                    ExpiringOAuth2RefreshToken expiringRefreshToken = (ExpiringOAuth2RefreshToken) refreshToken;
                    Date expiration = expiringRefreshToken.getExpiration();
                    if (expiration != null) {
                        int seconds = Long.valueOf((expiration.getTime() - System.currentTimeMillis()) / 1000L)
                                .intValue();
                        c.expire(refreshKey, seconds);
                        c.expire(refreshAuthKey, seconds);
                    }
                }
            });
        } finally {
            conn.close();
        }
    }

    @Override
    public OAuth2RefreshToken readRefreshToken(String refreshTokenValue) {
        byte[] key = serializeKey(REFRESH + refreshTokenValue);
        byte[] bytes = null;
        RedisConnection conn = getConnection();
        try {
            bytes = conn.get(key);
        } finally {
            conn.close();
        }
        OAuth2RefreshToken refreshToken = deserializeRefreshToken(bytes);
        return refreshToken;
    }

    @Override
    public void removeRefreshToken(OAuth2RefreshToken refreshToken) {
        removeRefreshToken(refreshToken.getValue());
    }

    public void removeRefreshToken(String refreshToken) {
        byte[] refreshKey = serializeKey(REFRESH + refreshToken);
        byte[] refreshAuthKey = serializeKey(REFRESH_AUTH + refreshToken);
        byte[] refresh2AccessKey = serializeKey(REFRESH_TO_ACCESS + refreshToken);
        byte[] access2RefreshKey = serializeKey(ACCESS_TO_REFRESH + refreshToken);
        RedisConnection conn = getConnection();
        try {
            executePipeline(conn, c -> {
                c.del(refreshKey);
                c.del(refreshAuthKey);
                c.del(refresh2AccessKey);
                c.del(access2RefreshKey);
            });
        } finally {
            conn.close();
        }
    }

    @Override
    public void removeAccessTokenUsingRefreshToken(OAuth2RefreshToken refreshToken) {
        removeAccessTokenUsingRefreshToken(refreshToken.getValue());
    }

    public void removeAccessTokenUsingRefreshToken(String refreshToken) {
        byte[] key = serializeKey(REFRESH_TO_ACCESS + refreshToken);
        RedisConnection conn = getConnection();
        try {
            // 先获取数据
            byte[] bytes = conn.get(key);

            // 执行删除操作
            executePipeline(conn, c -> {
                c.del(key);
            });

            String accessToken = deserializeString(bytes);
            if (accessToken != null) {
                removeAccessToken(accessToken);
            }
        } finally {
            conn.close();
        }
    }

    @Override
    public Collection<OAuth2AccessToken> findTokensByClientIdAndUserName(String clientId, String userName) {
        byte[] approvalKey = serializeKey(UNAME_TO_ACCESS + getApprovalKey(clientId, userName));
        List<byte[]> byteList = null;
        RedisConnection conn = getConnection();
        try {
            byteList = conn.lRange(approvalKey, 0, -1);
        } finally {
            conn.close();
        }
        if (byteList == null || byteList.size() == 0) {
            return Collections.<OAuth2AccessToken>emptySet();
        }
        List<OAuth2AccessToken> accessTokens = new ArrayList<OAuth2AccessToken>(byteList.size());
        for (byte[] bytes : byteList) {
            OAuth2AccessToken accessToken = deserializeAccessToken(bytes);
            accessTokens.add(accessToken);
        }
        return Collections.<OAuth2AccessToken>unmodifiableCollection(accessTokens);
    }

    @Override
    public Collection<OAuth2AccessToken> findTokensByClientId(String clientId) {
        byte[] key = serializeKey(CLIENT_ID_TO_ACCESS + clientId);
        List<byte[]> byteList = null;
        RedisConnection conn = getConnection();
        try {
            byteList = conn.lRange(key, 0, -1);
        } finally {
            conn.close();
        }
        if (byteList == null || byteList.size() == 0) {
            return Collections.<OAuth2AccessToken>emptySet();
        }
        List<OAuth2AccessToken> accessTokens = new ArrayList<OAuth2AccessToken>(byteList.size());
        for (byte[] bytes : byteList) {
            OAuth2AccessToken accessToken = deserializeAccessToken(bytes);
            accessTokens.add(accessToken);
        }
        return Collections.<OAuth2AccessToken>unmodifiableCollection(accessTokens);
    }
}