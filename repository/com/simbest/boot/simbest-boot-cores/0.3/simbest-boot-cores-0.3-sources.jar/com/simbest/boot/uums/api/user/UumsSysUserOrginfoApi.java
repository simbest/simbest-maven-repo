package com.simbest.boot.uums.api.user;

import com.fasterxml.jackson.core.type.TypeReference;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.SimpleUserOrg;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.uums.api.ApiRequestHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @version <strong>V1.0.0</strong><br>
 */

@SuppressWarnings("ALL")
@Component
@Slf4j
public class UumsSysUserOrginfoApi {
    private static final String USER_MAPPING = "/action/user/org/";
    private static final String SSO = "/sso";
    private static final String NEW_SSO = "sso/";
    @Autowired
    private AppConfig config;
    //private String uumsAddress="http://localhost:8080/uums";
    @Autowired
    private RsaEncryptor encryptor;

    @Autowired
    private ApiRequestHandle<List<SimpleUserOrg>> userUserOrgApiHandle;

    /**
     * 单表条件查询不分页
     *
     * @param appcode
     * @param simpleUserOrgMap
     * @return
     */
    public List<SimpleUserOrg> findAllNoPage(String appcode, Map simpleUserOrgMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(simpleUserOrgMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAllNoPage" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode)
                .json(json0)
                .asBean(JsonResponse.class);
        return userUserOrgApiHandle.handRemoteTypeReferenceResponse(response, new TypeReference<List<SimpleUserOrg>>() {
        });
    }

    /**
     * 查找所有用户信息
     *
     * @param page       当前页码
     * @param size       每页大小
     * @param direction  排序方向
     * @param properties 排序属性
     * @param userOrg    用户组织信息
     * @return JsonResponse 包含用户信息的JsonResponse对象
     */
    public JsonResponse findAllForAdmin(int page, int size, String direction, String properties, SimpleUserOrg userOrg) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(userOrg);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAllForAdmin" + SSO + "?loginuser=" + username1 + "&appcode=" + config.getAppcode())
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 根据用户名查询用户信息
     *
     * @param username 用户名
     * @return JsonResponse 包含用户信息的JsonResponse对象
     */
    public JsonResponse getOrgInfoByUsername(String username) {
        String authUser = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "getOrgInfoByUsername" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(authUser))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .param("username", username)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    public JsonResponse create(SimpleUserOrg sysUserOrg) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysUserOrg);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + NEW_SSO + "create" + "?loginuser=" + username1 + "&appcode=" + config.getAppcode())
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    public JsonResponse findById(String id) {
        String authUser = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", authUser);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findById" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(authUser))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .param("id", id)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    public JsonResponse update(SimpleUserOrg sysUserOrg) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysUserOrg);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + NEW_SSO + "update" + "?loginuser=" + username1 + "&appcode=" + config.getAppcode())
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    public JsonResponse deleteById(String id) {
        String authUser = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", authUser);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + NEW_SSO + "deleteById")
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(authUser))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .param("id", id)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }
}