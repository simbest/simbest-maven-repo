package com.simbest.boot.ws.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.io.CacheAndWriteOutputStream;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.io.CachedOutputStreamCallback;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;

import java.io.OutputStream;

/**
 * 用途：拦截输出的请求SOAP消息
 *
 *
 */
/**
 * SOAP响应日志拦截器
 * 提供SOAP消息的输出拦截和日志记录功能：
 * - 拦截所有输出的SOAP响应消息
 * - 支持消息内容的格式化输出
 * - 实现响应消息的日志记录
 * - 继承自CXF的LoggingOutInterceptor
 * - 提供异步日志记录回调机制
 */
@Slf4j
public class SoapLoggingOutInterceptor extends LoggingOutInterceptor {

    public SoapLoggingOutInterceptor() {
        super(Phase.PRE_STREAM);
        this.setPrettyLogging(true);
    }

    @Override
    public void handleMessage(Message message) throws Fault {
        OutputStream out = message.getContent(OutputStream.class);
        final CacheAndWriteOutputStream newOut = new CacheAndWriteOutputStream(out);
        message.setContent(OutputStream.class, newOut);
        newOut.registerCallback(new LoggingCallback());
        super.handleMessage(message);
    }

    public class LoggingCallback implements CachedOutputStreamCallback {
        public void onFlush(CachedOutputStream cos) {
        }

        public void onClose(CachedOutputStream cos) {
            try {
                StringBuilder builder = new StringBuilder();
                cos.writeCacheTo(builder, limit);
                String soapXml = builder.toString();
                log.debug(soapXml);
            } catch (Exception e) {
            }
        }
    }
}