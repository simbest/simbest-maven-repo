package com.simbest.boot.uums.web.sys;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.sys.model.SysDictValue;
import com.simbest.boot.uums.api.sys.UumsSysDictValueApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 系统数据字典管理控制器
 * 提供数据字典相关的REST API接口：
 * - 支持数据字典值的查询操作
 * - 提供按条件过滤的查询功能
 * - 用于维护系统中的数据字典配置
 */
@Api(tags = {"2-统一用户管理", "数据字典管理"}, description = "提供数据字典值的管理功能，包括字典值的查询、字典类型的维护、字典数据的同步等功能")
@RestController
@RequestMapping("/uums/sys/dictvalue")
public class UumsSysDictValueController {

    @Autowired
    private UumsSysDictValueApi uumsSysDictValueApi;


    /**
     * pc单表条件查询
     * @param sysDictValue
     * @return
     */
    @ApiOperation(value = "pc单表条件查询", notes = "pc单表条件查询")
    @PostMapping("/findDictValue")
    public JsonResponse findDictValue(@RequestBody SysDictValue sysDictValue) {
        List<SysDictValue> list =uumsSysDictValueApi.findDictValue(sysDictValue);
        return JsonResponse.success(list);
    }

}