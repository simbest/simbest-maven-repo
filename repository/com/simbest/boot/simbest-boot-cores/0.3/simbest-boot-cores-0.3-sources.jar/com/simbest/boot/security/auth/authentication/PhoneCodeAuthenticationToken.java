package com.simbest.boot.security.auth.authentication;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;

/**
 * 手机验证码认证令牌
 * 
 * 主要功能：
 * 1. 实现基于手机号码和短信验证码的登录认证
 * 2. 继承自Spring Security的AbstractAuthenticationToken
 * 3. 支持加密手机号码的安全传输
 * 
 * 认证流程：
 * 1. 创建时使用加密的手机号码作为principal
 * 2. 使用PhoneCodeAuthenticationCredentials作为credentials
 * 3. 初始状态下不包含任何权限
 * 
 * 安全特性：
 * - 手机号码加密传输
 * - 验证码认证
 * - 支持多应用认证
 */
public class PhoneCodeAuthenticationToken extends AbstractAuthenticationToken {

    /**
     * 认证主体
     * 在手机验证码认证场景中，这里存储加密后的手机号码
     * 用于：
     * 1. 安全传输用户手机号码
     * 2. 作为用户身份标识
     * 3. 用于后续的验证码校验
     */
    @Setter @Getter
    private Object principal;

    /**
     * 认证凭据
     * 包含应用代码和短信验证码信息
     * 用于：
     * 1. 存储验证码认证所需的信息
     * 2. 支持多应用验证码认证
     * 3. 验证码的有效性校验
     */
    @Setter @Getter
    private PhoneCodeAuthenticationCredentials credentials;

    /**
     * 创建手机验证码认证令牌
     * 
     * @param principal 加密后的手机号码，作为认证主体
     * @param credentials 包含应用代码和验证码的认证凭据
     * 
     * 说明：
     * 1. 创建时使用空权限列表初始化
     * 2. 认证成功后需要重新设置对应的权限
     * 3. 手机号码应该在传入前进行加密处理
     */
    public PhoneCodeAuthenticationToken(String principal, PhoneCodeAuthenticationCredentials credentials) {
        super(AuthorityUtils.NO_AUTHORITIES);
        this.principal = principal;
        this.credentials = credentials;
    }

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}