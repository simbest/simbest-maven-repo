package com.simbest.boot.base.web.controller;

import com.simbest.boot.base.model.LogicModel;
import com.simbest.boot.base.service.ILogicService;
import com.simbest.boot.base.web.response.JsonResponse;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.Serializable;

/**
 * 业务实体逻辑控制器基类
 * 
 * 主要功能：
 * 1. 继承GenericController，具备通用实体的基础操作能力
 * 2. 提供业务实体的可用性管理（启用/禁用）
 * 3. 支持实体的逻辑删除（软删除）
 * 4. 提供SSO和API双重访问支持
 * 5. 统一的响应格式和异常处理
 * 6. 完整的Swagger接口文档
 * 7. 可被其他业务控制器继承复用
 *
 * @param <T> 业务实体类型，必须继承自LogicModel
 * @param <PK> 主键类型，必须实现Serializable接口
 */
public class LogicController<T extends LogicModel, PK extends Serializable> extends GenericController<T, PK>{

    /**
     * 业务实体服务接口，提供业务逻辑处理功能
     */
    private ILogicService<T, PK> service;

    /**
     * 构造函数，注入业务实体服务接口
     *
     * @param service 业务实体服务接口实现
     */
    public LogicController(ILogicService<T, PK> service) {
        super(service);
        this.service = service;
    }

    /**
     * 更新实体的可用状态
     * 支持标准访问、SSO访问和API访问三种方式
     *
     * @param id 实体主键ID
     * @param enabled 是否可用，true表示可用，false表示不可用
     * @return 更新结果的JSON响应，包含更新后的实体对象
     */
    @PostMapping(value = {"/updateEnable", "/sso/updateEnable", "/api/updateEnable"})
    public JsonResponse updateEnable(
            @ApiParam(value = "主键ID", required = true) @RequestParam PK id,
            @ApiParam(value = "是否可用", required = true) @RequestParam boolean enabled) {
        return JsonResponse.success(service.updateEnable(id, enabled));
    }
}