package com.simbest.boot.ws.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;

import java.io.InputStream;

/**
 * 用途：拦截输入的请求SOAP消息
 *
 *
 */
/**
 * SOAP请求日志拦截器
 * 提供SOAP消息的输入拦截和日志记录功能：
 * - 拦截所有输入的SOAP请求消息
 * - 支持消息内容的格式化输出
 * - 实现请求消息的日志记录
 * - 继承自CXF的LoggingInInterceptor
 */
@Slf4j
public class SoapLoggingInInterceptor extends LoggingInInterceptor {


    public SoapLoggingInInterceptor() {
        super(Phase.PRE_STREAM);
        this.setPrettyLogging(true);
    }

    @Override
    public void handleMessage(Message message) throws Fault {
        InputStream is = message.getContent(InputStream.class);
        CachedOutputStream os = new CachedOutputStream();
        try {
            IOUtils.copy(is, os);
            os.flush();
            message.setContent(InputStream.class, os.getInputStream());
            is.close();
            String soapXml = IOUtils.toString(os.getInputStream());
            log.debug(soapXml);
            super.handleMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}