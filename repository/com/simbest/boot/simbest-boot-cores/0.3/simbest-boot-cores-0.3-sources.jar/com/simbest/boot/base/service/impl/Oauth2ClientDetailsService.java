package com.simbest.boot.base.service.impl;

import cn.hutool.json.JSONUtil;
import com.simbest.boot.base.model.Oauth2ClientDetails;
import com.simbest.boot.base.repository.Oauth2ClientDetailsRepository;
import com.simbest.boot.base.service.IOauth2ClientDetailsService;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.util.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientRegistrationException;
import org.springframework.stereotype.Service;

import static com.simbest.boot.constants.AuthoritiesConstants.OAUTH2_UNKNOW_CLIENT;

/**
 * OAuth2客户端信息服务实现类
 * 
 * 主要功能：
 * 1. 实现Spring Security OAuth2的ClientDetailsService接口
 * 2. 提供OAuth2客户端信息的数据库存储和访问
 * 3. 使用Redis缓存机制优化性能
 * 4. 继承GenericService实现通用实体操作
 * 5. 支持多应用下的客户端信息隔离
 * 6. 提供客户端认证和信息管理功能
 */
@Slf4j
@Service
public class Oauth2ClientDetailsService extends GenericService<Oauth2ClientDetails, String> implements IOauth2ClientDetailsService {

    /**
     * OAuth2客户端信息缓存前缀
     * 用于在Redis中构建缓存键
     */
    private static final String OAUTH2_CLIENT_PREFIX = "OAUTH2_CLIENT_PREFIX:";

    /**
     * OAuth2客户端信息仓库
     * 提供对OAuth2客户端数据的访问能力
     */
    @Autowired
    private Oauth2ClientDetailsRepository repository;

    /**
     * 应用配置对象
     * 用于获取当前应用编码
     */
    @Autowired
    private AppConfig config;

    /**
     * 构造函数
     * 
     * @param repository OAuth2客户端信息仓库
     */
    @Autowired
    public Oauth2ClientDetailsService(Oauth2ClientDetailsRepository repository) {
        super(repository);
        this.repository = repository;
    }

    /**
     * 根据客户端ID加载OAuth2客户端详情
     * 首先尝试从Redis缓存获取，如果不存在则从数据库加载并缓存
     * 
     * @param clientId 客户端ID
     * @return 客户端详情对象
     * @throws ClientRegistrationException 当客户端不存在时抛出异常
     */
    @Override
    public ClientDetails loadClientByClientId(String clientId) throws ClientRegistrationException {
        String appcode = config.getAppcode();
        Oauth2ClientDetails clientDetails = null;
        String clientDetailsJSON = RedisUtil.getGlobal(OAUTH2_CLIENT_PREFIX+appcode+ ApplicationConstants.COLON +clientId);
        if(StringUtils.isEmpty(clientDetailsJSON)){
            // 缓存中不存在，从数据库加载
            clientDetails = repository.findByClientId(clientId);
            if(null != clientDetails){
                // 转换为JSON并存入缓存
                clientDetailsJSON = JSONUtil.toJsonStr(clientDetails);
                RedisUtil.setGlobal(OAUTH2_CLIENT_PREFIX+appcode+ApplicationConstants.COLON+clientId, clientDetailsJSON);
            }
        }
        else{
            // 从缓存的JSON还原对象
            clientDetails = JSONUtil.toBean(clientDetailsJSON, Oauth2ClientDetails.class);
        }
        if(null == clientDetails){
            log.error("无法获取到OAuth2的信息，目前接收的clientId为【{}】，请检查数据库oauth2client_details配置和请求参数", clientId);
            throw new BadCredentialsException(OAUTH2_UNKNOW_CLIENT+clientId);
        }
        return clientDetails;
    }
}