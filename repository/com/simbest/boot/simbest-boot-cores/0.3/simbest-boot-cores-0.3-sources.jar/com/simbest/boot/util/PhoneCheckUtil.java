package com.simbest.boot.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * 手机号码校验工具类
 * 提供中国大陆和香港手机号码格式的校验功能
 * 支持不同运营商号段的识别和验证
 */
public class PhoneCheckUtil {

    /**
     * 测试方法
     * 用于验证各种手机号码格式是否符合规则
     * 包含各种运营商号段的测试用例
     * 
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        System.out.println(isChinaPhoneLegal("13111112222"));
        System.out.println(isChinaPhoneLegal("15711112222"));
        System.out.println(isChinaPhoneLegal("15411112222"));
        System.out.println(isChinaPhoneLegal("18011112222"));
        System.out.println(isChinaPhoneLegal("18111112222"));
        System.out.println(isChinaPhoneLegal("19711112222"));
        System.out.println(isChinaPhoneLegal("19811112222"));
        System.out.println(isChinaPhoneLegal("19911112222"));
        System.out.println(isChinaPhoneLegal("199111122221"));
        System.out.println(isChinaPhoneLegal("1991111222"));
    }

    /**
     * 校验手机号码格式是否正确
     * 可同时验证大陆号码或香港号码
     * 
     * @param str 待校验的手机号码字符串
     * @return 如果是合法的大陆或香港手机号码则返回true，否则返回false
     * @throws PatternSyntaxException 正则表达式异常
     */
    public static boolean isPhoneLegal(String str)throws PatternSyntaxException {
        return isChinaPhoneLegal(str) || isHKPhoneLegal(str);
    }

    /**
     * 验证中国大陆手机号码格式
     * 大陆手机号码11位数，匹配格式：前三位固定格式+后8位任意数
     * 支持的前三位格式包括：
     * - 13+任意数
     * - 15+除4的任意数
     * - 18+除1和4的任意数
     * - 17+除9的任意数
     * - 147
     * - 166
     * - 198、199
     * 
     * @param str 待校验的手机号码字符串
     * @return 如果是合法的大陆手机号码则返回true，否则返回false
     * @throws PatternSyntaxException 正则表达式异常
     */
    public static boolean isChinaPhoneLegal(String str) throws PatternSyntaxException {
        String regExp = "^((13[0-9])|(15[^4])|(18[0,1,2,3,5-9])|(17[0-8])|(147)|(166)|(19[8|9]))\\d{8}$";
        Pattern p = Pattern.compile(regExp);
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 验证香港手机号码格式
     * 香港手机号码8位数，以5|6|8|9开头+7位任意数
     * 
     * @param str 待校验的手机号码字符串
     * @return 如果是合法的香港手机号码则返回true，否则返回false
     * @throws PatternSyntaxException 正则表达式异常
     */
    public static boolean isHKPhoneLegal(String str)throws PatternSyntaxException {
        String regExp = "^(5|6|8|9)\\d{7}$";
        Pattern p = Pattern.compile(regExp);
        Matcher m = p.matcher(str);
        return m.matches();
    }
}