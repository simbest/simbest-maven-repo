package com.simbest.boot.config;

import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Component;

import com.google.common.collect.ImmutableList;

/**
 * Swagger2 CSRF保护配置类
 * 
 * 主要功能：
 * 1. 解决Spring Security CSRF保护机制下Swagger UI的POST请求问题
 * 2. 为Swagger UI提供特殊的CSRF规则，使其能够正常进行API测试
 * 
 * 规则说明：
 * 1. DELETE、PUT、HEAD、TRACE、OPTIONS请求不需要CSRF保护
 * 2. 当请求来自本地主机（127.0.0.1或0:0:0:0:0:0:0:1）且Referer为Swagger UI时，不需要CSRF保护
 * 3. 其他情况下，需要正常的CSRF保护
 * 
 * 注意事项：
 * 1. 此配置仅用于开发和测试环境
 * 2. 生产环境应当启用完整的CSRF保护
 * 3. 通过AppConfig配置类获取Swagger UI的URL
 */
@Component
public class Swagger2CsrfProtection implements RequestMatcher {

    @Autowired
    private AppConfig config;

    private static final Pattern ALLOWED_METHODS =
            Pattern.compile("^(DELETE|PUT|HEAD|TRACE|OPTIONS)$");
    private static final List<String> LOCALHOST_PATTERNS =
            ImmutableList.of("127.0.0.1", "0:0:0:0:0:0:0:1");

    @Override
    public boolean matches(HttpServletRequest request) {
        // CSRF disabled on PUT, HEAD, TRACE, OPTIONS (i.e. enabled for POST, GET)
        if (ALLOWED_METHODS.matcher(request.getMethod()).matches()) return false;
        // CSRF not required on localhost when swagger-ui is referer
        final String remoteHost = request.getRemoteHost();
        final String referer = request.getHeader("Referer");
        if (remoteHost != null && referer != null
                && LOCALHOST_PATTERNS.contains(remoteHost)
                && config.getSwaggerUrl().equals(referer)) {
            return false;
        }
        // otherwise, CSRF is required
        return true;
    }
}