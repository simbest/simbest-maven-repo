package com.simbest.boot.sys.service;

import com.simbest.boot.base.service.ILogicService;
import com.simbest.boot.sys.model.SysCustomFieldValue;

/**
 * 用途：实体自定义字段值逻辑层
 *
 *
 */
public interface ISysCustomFieldValueService extends ILogicService<SysCustomFieldValue, String> {



}