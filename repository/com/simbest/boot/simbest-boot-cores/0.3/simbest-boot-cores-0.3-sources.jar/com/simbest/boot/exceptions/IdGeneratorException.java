package com.simbest.boot.exceptions;

import lombok.NoArgsConstructor;

/**
 * ID生成器异常
 * 
 * 主要用途：
 * 1. 用于标识在生成唯一标识符（ID）过程中发生的异常
 * 2. 包含主键生成、序列号生成等相关操作的异常情况
 * 
 * 使用场景：
 * 1. 数据库主键生成失败
 * 2. 序列号生成器出现错误
 * 3. ID生成过程中的配置错误
 * 4. ID生成资源（如序列表）不可用
 * 
 * 注意事项：
 * 1. 此异常通常表示系统级别的错误，需要及时处理
 * 2. 建议在异常消息中包含具体的失败原因和相关参数
 * 3. 作为RuntimeException的子类，属于非受检异常
 */
@NoArgsConstructor
public class IdGeneratorException extends RuntimeException {

    /**
     * 使用指定的错误消息构造异常
     *
     * @param msg 详细的错误消息，说明ID生成失败的具体原因
     */
    public IdGeneratorException(String msg) {
        super(msg);
    }

    /**
     * 使用指定的错误消息和根异常构造异常
     *
     * @param msg 详细的错误消息，说明ID生成失败的具体原因
     * @param t 导致此异常的根本原因
     */
    public IdGeneratorException(String msg, Throwable t) {
        super(msg, t);
    }
}