package com.simbest.boot.security.auth.authentication;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

/**
 * UUMS统一用户管理系统认证令牌
 * 
 * 主要功能：
 * 1. 实现基于UUMS主数据的用户认证
 * 2. 继承自Spring Security的UsernamePasswordAuthenticationToken
 * 3. 支持用户名密码和应用代码的组合认证
 * 
 * 认证流程：
 * 1. 接收用户名和认证凭据
 * 2. 通过UUMS系统验证用户身份
 * 3. 验证应用访问权限
 * 
 * 扩展特性：
 * - 支持多应用认证
 * - 集成UUMS主数据
 * - 统一的用户管理
 */
public class UumsAuthentication extends UsernamePasswordAuthenticationToken {

    /**
     * 创建UUMS认证令牌
     * 
     * @param principal 用户名，作为认证主体
     * @param uumsAuthenticationCredentials 认证凭据，包含密码和应用代码
     * 
     * 说明：
     * 1. 使用用户名作为认证主体
     * 2. 使用UumsAuthenticationCredentials作为认证凭据
     * 3. 认证凭据包含密码和应用代码两部分信息
     */
    public UumsAuthentication(Object principal, Object uumsAuthenticationCredentials) {
        super(principal, uumsAuthenticationCredentials);
    }

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}