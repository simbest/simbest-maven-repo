package com.simbest.boot.config;

import com.alibaba.druid.filter.Filter;
import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceBuilder;
import com.alibaba.druid.wall.WallConfig;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

/**
 * 用途：数据源配置类
 * 主要提供以下功能：
 * 1. 默认数据源配置
 * 2. JdbcTemplate配置
 * 3. NamedParameterJdbcTemplate配置
 * 4. SQL防火墙配置
 */
@Configuration
public class DataSourceConfiguration {

    /*@Autowired
    private WallFilter wallFilter;*/

    /**
     * 配置默认数据源
     * 使用Druid连接池，并应用SQL防火墙过滤器
     * @return 数据源实例
     */
    @Bean
    @Primary
    @Qualifier("dataSource")
    @ConfigurationProperties(prefix = "spring.datasource.druid")
    public DataSource defaultDataSource() {
        DruidDataSource druidDataSource = DruidDataSourceBuilder.create().build();
        List<Filter> filters = new ArrayList<>();
        //filters.add(wallFilter);
        druidDataSource.setProxyFilters(filters);
        return druidDataSource;
    }

    /**
     * 配置JdbcTemplate
     * 用于执行SQL查询和更新操作
     * @param dataSource 注入的数据源
     * @return JdbcTemplate实例
     */
    @Bean(name = "jdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("dataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    /**
     * 配置NamedParameterJdbcTemplate
     * 支持命名参数的JDBC操作模板
     * @param dataSource 注入的数据源
     * @return NamedParameterJdbcTemplate实例
     */
    @Bean(name = "namedParameterJdbcTemplate")
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(@Qualifier("dataSource") DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

    /**
     * 配置SQL防火墙规则
     * 主要用于防止SQL注入等安全问题
     * @return WallConfig实例
     */
    @Bean(name = "wallConfig")
    WallConfig wallFilterConfig(){
        WallConfig wc = new WallConfig();
        wc.setMultiStatementAllow(true);        //允许一次执行多条语句
        wc.setNoneBaseStatementAllow(true);     //允许一次执行多条语句
        wc.setConditionAndAlwayTrueAllow(true); //检查查询条件(WHERE/HAVING子句)中是否包含AND永真条件
        return wc;
    }

    /*@Bean(name = "wallFilter")
    @DependsOn ("wallConfig")
    WallFilter wallFilter(WallConfig wallConfig){
        WallFilter wfilter = new WallFilter();
        wfilter.setConfig(wallConfig);
        return wfilter;
    }*/

    /**
     * 多数据源配置建议：
     * 1、主体工程基于JPA，默认数据源为dataSource
     * 2、扩展多数据源使用JdbcTemplate，即每增加一个dataSource，对应增加一个JdbcTemplate
     * 3、application.properties和application-dev.properties增加如下配置，其中application.properties不要写死，在pom.xml进行占位设置和profile切换
     * custom.datasource.druid.sms82008201.name=sms82008201
     * custom.datasource.druid.sms82008201.driver-class-name=com.mysql.jdbc.Driver
     * custom.datasource.druid.sms82008201.url=jdbc:mysql://localhost/test?useUnicode=true&characterEncoding=UTF-8&characterSetResults=utf8&serverTimezone=GMT%2B8
     * custom.datasource.druid.sms82008201.port=3306
     * custom.datasource.druid.sms82008201.username=root
     * custom.datasource.druid.sms82008201.password=123456
     */
//    @Bean
//    @Qualifier("sms82008201DataSource")
//    @ConfigurationProperties(prefix = "custom.datasource.druid.sms82008201")
//    public DataSource sms82008201Ds() {
//        return DruidDataSourceBuilder.create().build();
//    }
//
//    @Bean(name = "sms82008201JdbcTemplate")
//    public JdbcTemplate sms82008201JdbcTemplate(@Qualifier("sms82008201DataSource") DataSource dataSource) {
//        return new JdbcTemplate(dataSource);
//    }
}