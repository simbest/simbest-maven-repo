package com.simbest.boot.sys.repository;

import com.simbest.boot.base.repository.GenericRepository;
import com.simbest.boot.sys.model.SysLogLoginAdmin;
import org.springframework.stereotype.Repository;

/**
 * 用途：系统登录日志(维护账号)持久层
 *
 *
 */
@Repository
public interface SysLogLoginAdminRepository extends GenericRepository<SysLogLoginAdmin, String> {


}