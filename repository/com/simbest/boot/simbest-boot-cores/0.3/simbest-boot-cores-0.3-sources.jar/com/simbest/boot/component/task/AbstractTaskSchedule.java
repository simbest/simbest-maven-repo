package com.simbest.boot.component.task;

import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.component.distributed.lock.AppRuntimeMaster;
import com.simbest.boot.component.distributed.lock.DistributedRedisLock;
import com.simbest.boot.component.distributed.lock.DistributedRedissonLock;
import com.simbest.boot.sys.model.SysTaskExecutedLog;
import com.simbest.boot.sys.repository.SysTaskExecutedLogRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

/**
 * 分布式定时任务调度抽象基类
 * 
 * 主要功能：
 * 1. 提供分布式环境下定时任务的统一调度框架
 * 2. 实现主从节点任务分配，确保任务只在主节点执行
 * 3. 通过Redis分布式锁实现任务互斥，防止重复执行
 * 4. 支持任务执行日志记录和监控
 * 5. 提供任务执行状态跟踪和异常处理
 * 
 * 实现原理：
 * 1. 主从节点控制
 *    - 通过AppRuntimeMaster判断当前节点角色
 *    - 只允许主节点执行定时任务
 *    - 从节点自动跳过任务执行
 * 
 * 2. 分布式锁控制
 *    - 使用Redis实现分布式锁
 *    - 支持锁的超时和自动释放
 *    - 防止任务在集群中重复执行
 * 
 * 3. 日志记录机制
 *    - 记录任务执行的开始和结束时间
 *    - 跟踪任务执行状态和结果
 *    - 支持执行异常的记录和追踪
 * 
 * 使用方式：
 * ```java
 * @Component
 * public class MyTask extends AbstractTaskSchedule {
 *     @Scheduled(cron = "0 0 * * * ?")
 *     public void run() {
 *         checkAndExecute();
 *     }
 *     
 *     @Override
 *     public String execute() {
 *         // 实现具体的任务逻辑
 *         return CHECK_SUCCESS;
 *     }
 * }
 * ```
 * 
 * 注意事项：
 * 1. 子类必须实现execute()方法
 * 2. 合理设置分布式锁的超时时间
 * 3. 注意处理任务执行异常
 * 4. 确保Redis服务的可用性
 */
@Slf4j
public abstract class AbstractTaskSchedule {

    @Value("${app.task.switch:true}")
    private Boolean taskSwitch;

    /**
     * 任务执行成功的标识
     * 
     * 使用场景：
     * 1. 任务正常完成时返回
     * 2. 用于日志记录和状态跟踪
     * 3. 作为任务执行结果的判断依据
     */
    public final static String CHECK_SUCCESS = "PASS";

    /**
     * 任务执行失败的标识
     * 
     * 使用场景：
     * 1. 任务执行出现异常时返回
     * 2. 业务逻辑校验失败时返回
     * 3. 作为任务重试的判断依据
     */
    public final static String CHECK_FAILED = "FAILED";

    /**
     * 应用运行时主控管理器
     * 
     * 功能：
     * 1. 判断当前节点是否为主节点
     * 2. 获取集群节点信息
     * 3. 控制任务的执行权限
     * 
     * 注意：
     * 1. 确保主控管理器正确初始化
     * 2. 监控主从节点的状态变化
     */
    private AppRuntimeMaster appRuntime;

    /**
     * 任务执行日志仓库
     * 
     * 功能：
     * 1. 记录任务执行的详细信息
     * 2. 支持任务执行历史查询
     * 3. 提供任务监控的数据支持
     * 
     * 记录内容：
     * 1. 任务名称和执行时间
     * 2. 执行节点信息
     * 3. 执行结果和异常信息
     */
    private SysTaskExecutedLogRepository repository;

    /**
     * 构造函数
     * 
     * @param appRuntime 应用运行时主控管理器，用于主从节点控制
     * @param repository 任务执行日志仓库，用于记录执行历史
     * 
     * 初始化说明：
     * 1. 注入必要的依赖组件
     * 2. 由Spring容器管理生命周期
     */
    public AbstractTaskSchedule(AppRuntimeMaster appRuntime, SysTaskExecutedLogRepository repository){
        this.appRuntime = appRuntime;
        this.repository = repository;
    }

    /**
     * 执行任务的核心方法
     * 
     * 执行流程：
     * 1. 判断当前节点是否为主节点
     * 2. 获取分布式锁（等待3秒，120分钟后自动释放）
     * 3. 执行具体任务逻辑
     * 4. 记录执行日志（可选）
     * 5. 释放分布式锁
     * 
     * 安全控制：
     * 1. 主从节点判断，避免重复执行
     * 2. 分布式锁控制，确保互斥执行
     * 3. 异常处理和日志记录
     * 
     * 日志记录：
     * 1. 任务开始和结束时间
     * 2. 执行节点信息
     * 3. 执行结果和异常信息
     * 
     * @param writeLog 是否记录执行日志
     *                true - 记录到数据库
     *                false - 仅输出到日志文件
     */
    public void checkAndExecute(boolean writeLog) {
        long threadId = Thread.currentThread().getId();
        if(appRuntime.getMyHost().equals(appRuntime.getMasterHost())
                && appRuntime.getMyPort().equals(appRuntime.getMasterPort())) {
            log.info(this.getClass().getName()+"当前主机地址【{}】运行端口【{}】是集群主控节点，可以执行定时任务", appRuntime.getMyHost(), appRuntime.getMyPort());
            Long beginTime = System.currentTimeMillis();
            Boolean executeFlag = true;
            String content = CHECK_FAILED;
            //获取锁, 默认最多等待3秒，获得锁后120分钟释放。确保长周期任务执行超时，不会死锁
            DistributedRedissonLock lock = DistributedRedisLock.tryLock(this.getClass().getSimpleName(),
                    appRuntime.getRedisLockWaitSeconds(), appRuntime.getRedisLockReleaseSeconds());
            if(lock.isLocked()) {
                try {
                    //执行子类特定的定时任务
                    if (taskSwitch) {
                        log.info("------------------------------【{}】【{}】上锁成功，即将执行定时任务", this.getClass().getName(),threadId);
                        content = this.execute();
                        log.info("------------------------------【{}】【{}】定时任务执行完毕", this.getClass().getName(),threadId);
                    } else {
                        log.info("taskSwitch定时任务开关未开启。");
                    }

                } catch (Exception e) {
                    executeFlag = false;
                    log.error("------------------------------【{}】【{}】上锁成功，但执行任务发生异常", this.getClass().getSimpleName(),threadId);
                    Exceptions.printException(e);
                } finally {
                    try {
                        //释放锁
                        lock.getRLock().unlock();
                        log.info("------------------------------【{}】【{}】定时任务执行完毕，集群锁已成功释放", this.getClass().getName(),threadId);
                    } catch (IllegalMonitorStateException emse) {
                        log.error("------------------------------【{}】【{}】定时任务执行完毕，集群锁解锁异常", this.getClass().getSimpleName(),threadId);
                        Exceptions.printException(emse);
                    }
                }
                if(writeLog && taskSwitch) {
                    Long endTime = System.currentTimeMillis();
                    SysTaskExecutedLog taskExecutedLog = SysTaskExecutedLog.builder()
                            .taskName(this.getClass().getSimpleName())
                            .hostname(appRuntime.getMyHost())
                            .port(appRuntime.getMyPort())
                            .durationTime(endTime - beginTime)
                            .content(threadId+StringUtils.substring(content, 0, 2000))
                            .executeFlag(executeFlag)
                            .build();
                    repository.save(taskExecutedLog);
                    log.info("------------------------------【{}】【{}】定时任务执行完毕，已写入定时任务记录日志", this.getClass().getName(),threadId);
                }
            }
        } else {
            log.info("集群主控节点主机地址【{}】运行端口【{}】,当前主机地址【{}】运行端口【{}】, 无法执行定时任务【{}】【{}】",
                    appRuntime.getMasterHost(), appRuntime.getMasterPort(), appRuntime.getMyHost(), appRuntime.getMyPort(), this.getClass().getName(), threadId);
        }
    }

    /**
     * 执行任务并记录日志的便捷方法
     * 
     * 说明：
     * 1. 默认开启日志记录功能
     * 2. 等同于调用checkAndExecute(true)
     * 3. 建议在大多数场景下使用此方法
     */
    public void checkAndExecute() {
        checkAndExecute(true);
    }

    /**
     * 具体任务的执行方法
     * 
     * 要求：
     * 1. 子类必须实现此方法
     * 2. 实现实际的业务逻辑
     * 3. 返回执行结果状态
     * 
     * 返回值：
     * - CHECK_SUCCESS：任务执行成功
     * - CHECK_FAILED：任务执行失败
     * - 其他自定义状态：需在日志中说明
     * 
     * 注意事项：
     * 1. 处理好异常情况
     * 2. 注意方法执行时间
     * 3. 合理使用事务
     * 
     * @return String 任务执行结果状态
     */
    public abstract String execute();
}