package com.simbest.boot.sys.web;

import com.simbest.boot.base.web.controller.GenericController;
import com.simbest.boot.sys.model.SysOperateLog;
import com.simbest.boot.sys.service.ISysOperateLogService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <strong>Title : SysOperateLogController</strong><br>
 * <strong>Description : 系统操作日志控制器</strong><br>
 * <strong>功能：</strong><br>
 * 1. 提供系统操作日志的查询、管理功能<br>
 * 2. 支持对系统操作日志进行分页查询<br>
 * 3. 继承通用控制器，复用通用CRUD操作接口<br>
 * <br>
 * 操作日志用于记录系统中的重要操作，便于审计和问题排查<br>
 * 包括用户操作、系统自动处理等关键行为日志<br>
 */
@Api(tags = {"3-系统管理", "操作日志管理"}, description = "提供系统操作日志的查询和管理功能，支持分页查询，记录用户操作和系统自动处理等关键行为日志，用于系统审计和问题排查")
@RestController
@RequestMapping("/sys/log/operate")
public class SysOperateLogController extends GenericController<SysOperateLog, String> {

    /**
     * 系统操作日志服务接口
     * 提供操作日志的业务处理功能
     */
    private ISysOperateLogService service;

    /**
     * 构造函数，注入操作日志服务
     * 并调用父类构造函数初始化通用控制器
     *
     * @param service 系统操作日志服务实现
     */
    @Autowired
    public SysOperateLogController(ISysOperateLogService service) {
        super(service);
        this.service = service;
    }

}