package com.simbest.boot.security.auth.authentication;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

/**
 * UUMS认证凭据
 * 
 * 主要功能：
 * 1. 封装UUMS主数据认证所需的凭据信息
 * 2. 支持密码和应用代码的组合认证
 * 3. 实现序列化接口，支持分布式环境
 * 
 * 认证流程：
 * 1. 用户提供密码和应用代码
 * 2. UUMS系统验证密码的正确性
 * 3. 验证应用的访问权限
 * 
 * 安全特性：
 * - 密码传输加密
 * - 多应用隔离
 * - 统一的认证管理
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UumsAuthenticationCredentials implements Serializable {

    /**
     * 用户密码
     * 用于：
     * 1. 用户身份验证
     * 2. 通常需要加密传输
     * 3. 与UUMS系统中存储的密码进行比对
     */
    private String password;

    /**
     * 应用代码
     * 用于：
     * 1. 标识请求来源的应用系统
     * 2. 验证应用的访问权限
     * 3. 支持多应用认证场景
     */
    private String appcode;

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 注意：输出时应注意敏感信息的保护
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}