package com.simbest.boot.constants;

import java.util.concurrent.TimeUnit;

/**
 * 应用程序全局常量定义类
 * 
 * 包含以下类别的常量：
 * 1. 环境配置常量：开发、测试、预生产、生产等环境标识
 * 2. 基础数值常量：0、1、-1等基础数值
 * 3. 字符编码常量：UTF-8、GB2312、GBK等
 * 4. 操作系统常量：Linux、Windows等系统标识
 * 5. 路由和页面常量：各类页面路径和URL配置
 * 6. 认证相关常量：登录、登出、会话等相关配置
 * 7. 分页和格式常量：默认分页大小、日期时间格式等
 * 8. HTTP相关常量：协议、请求方法等
 * 9. 特殊字符常量：冒号、点号、逗号等常用字符
 * 10. Redis相关常量：缓存前缀、锁超时等配置
 * 11. 安全相关常量：RSA密钥路径、许可证路径等
 * 12. 系统消息常量：成功、失败等提示信息
 * 
 * 注意事项：
 * 1. 所有常量均为public static final，不可修改
 * 2. 常量命名应当清晰明确，表明其用途
 * 3. 相关常量应当按类别分组放置
 * 4. 重要常量应当添加必要的注释说明
 */
public class ApplicationConstants {
    public static final String DEV = "dev";
    public static final String TEST = "test";
    public static final String UAT = "uat";
    public static final String PRD = "prd";
    public static final String OTHER = "other";

    public static final int ZERO = 0;
    public static final int ONE = 1;
    public static final int FONE = -1;
    public static final Boolean TRUE = true;
    public static final Boolean FALSE = false;

    public static final String ISO8859 = "ISO8859-1";
    public static final String UTF_8 = "UTF-8";
    public static final String GB2312 = "GB2312";
    public static final String GBK = "GBK";

    public static final String Linux = "Linux";
    public static final String Windows = "Windows";

    public static final String PACKAGE_NAME = "com.simbest.boot";
    public static final String ROOT_PAGE = "/";
    public static final String ROOT_SSO_PAGE = "/sso";
    public static final String ROOT_SSO_USER = "/getCurrentUser/sso";
    public static final String WELCOME_PAGE = "/welcome"; //匿名站点首页，不需要session
    public static final String LOGIN_PAGE = "/login";   //匿名登录首页，不需要session
    public static final String SIGNIN_PAGE = "/signin"; //匿名安全登录首页，不需要session
    public static final String REST_LOGIN_PAGE = "/restlogin";
    public static final String LOGOUT_PAGE = "/logout";
    public static final String REST_LOGOUT_PAGE = "/restlogout";
    public static final String ERROR_PAGE = "/error";
    public static final String HOME_PAGE = "/home"; //自动跳转至index，需要session
    public static final String UUMS_LOGIN_PAGE = "/uumslogin";
    public static final String REST_UUMS_LOGIN_PAGE = "/restuumslogin";
    public static final String REST_UUMS_LOGOUT_PAGE = "/restuumslogout";
    public static final String GET_CAS_USER = "/getCasCurrentUser"; //匿名接口
    public static final String REST_CAS_LOGIN_PAGE = "/restcaslogin"; //匿名接口
    public static final String CAS_LOGIN_PAGE = "/caslogin";
    public static final String CAS_LOGIN_SUCCESS_PAGE = "/caslogin/cas";
    public static final String CAS_LOGOUT_PAGE = "/caslogout";
    public static final String CAS_LOGOUT_SUCCESS_PAGE = "/caslogout/cas";
    public static final String LOGIN_ERROR_PAGE = "/login?loginError";
    public static final String LOGIN_SESSION_CODE = "validateCode";
    public static final String LOGIN_VALIDATE_CODE = "verifyCode";
    public static final String ANY_PASSWORD = "_anypassword_";
    //登录授权码的Redis缓存前缀
    public final static String REFINE_ANY_PASSWORD = "appAuthCode:%s:%s";
    //新NSSO单点登录的Redis缓存前缀
    public final static String NSSO_USER_ACCESS = "nsso:%s:%s:%s";
    public static final int ANY_PASSWORDTIME = 3600;

    public static final int DEFAULT_PAGE = 0;
    public static final int DEFAULT_SIZE = 100;

    public static final String FORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss";
    public static final String FORMAT_DATE = "yyyy-MM-dd";
    public static final String FORMAT_TIME = "HH:mm:ss";
    public static final String FORMAT_TIME_ZONE = "GMT+8";

    public final static String HTTPPROTOCAL = "http://";
    public final static String HTTP = "http";
    public final static String HTTPS = "https";
    public final static String HTTPGET = "GET";
    public final static String HTTPPOST = "POST";
    public final static String COLON = ":";
    public final static String DOT = ".";
    public final static String COMMA = ",";
    public final static String STAR = "*";
    public final static String LINE = "-";
    public final static String SQUOTE = "'";
    public final static String MYSQL_SQUOTE = "`";
    public final static String SPACE = " ";
    public final static String UNDERLINE = "_";
    public final static String PERCENT = "%";
    public final static String EMPTY = "";
    public final static String NULL = "null";
    public final static String NEWLINE = "\n";
    public final static String LEFT_BRACKET="(";
    public final static String RIGHT_BRACKET=")";
    public final static String AND = "&";
    public final static String EQUAL = "=";
    public final static String SEPARATOR = System.getProperty("file.separator");
    public final static String SLASH = "/";
    public final static String VERTICAL = "|";
    public final static String HASH = "#";

    public final static String REDIS_DEFAULT_CACHE_PREFIX = "runtime";

    public final static String RSA_PUBLIC_KEY_PATH = "certificate/rsa/rsa_public_key.pem";
    public final static String RSA_PRIVATE_KEY_PATH = "certificate/rsa/pkcs8_private_key.pem";
    
    public final static String LICENSE_KEY_PATH = "simbestkey/simbest.pem";

    public final static int REDIS_LOCK_WAIT_TIMEOUT = 1;
    public final static int REDIS_LOCK_RELEASE_TIMEOUT = 10;
    public final static int REDIS_LOCK_TIMEOUT = 2;
    public final static TimeUnit REDIS_LOCK_DEFAULT_TIME_UNIT = TimeUnit.SECONDS;
    public final static String REDIS_TEMP_KEY = "_redis_tmp_";
    public final static String  MASTER_HOST = "master_ip";
    public final static String  MASTER_PORT = "master_port";
    public final static String  MASTER_LOCK = "master_lock";

    public static final String ADMINISTRATOR = "hadmin";
    public static final String UUMS_APPCODE = "uums";

    public static final String MSG_SUCCESS = "操作成功";
    public static final String MSG_ERRO = "操作失败";
    public static final String MSG_FILE_CHECK = "fileOK";

    public static final String REST_TEMPLATE_PARM_FILE = "file";
}