package com.simbest.boot.uums.api.bloc;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.IBloc;
import com.simbest.boot.security.SimpleBloc;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 集团信息管理API接口
 * 
 * 提供以下功能：
 * 1. 集团基本信息的查询操作
 * 2. 支持基于集团ID的信息检索
 * 3. 实现与UUMS系统的集团信息同步
 * 4. 提供集团信息的安全访问控制
 * 5. 支持管理员级别的集团信息管理
 */
@Component
@Slf4j
public class UumsSysBlocApi {
    private static final String BLOC_MAPPING = "/action/bloc/";
    private static final String SSO = "/sso";

    @Autowired
    private AppConfig config;

    @Autowired
    private RsaEncryptor encryptor;


    /**
     * 根据集团id查找集团信息
     */
    public IBloc findById(String blocid, String appcode){
        JsonResponse response= HttpClient.post(config.getUumsAddress() + BLOC_MAPPING + "findById"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(ApplicationConstants.ADMINISTRATOR))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,appcode)
                .param("id", blocid)
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleBloc Simplebloc = JacksonUtils.json2obj(json, SimpleBloc.class);
        return Simplebloc;
    }



}