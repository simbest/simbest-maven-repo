package com.simbest.boot.base.repository;

import lombok.Getter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 动态查询条件构建器
 * 提供单表动态条件查询功能的辅助类：
 * - 支持等于、不等于、大于、小于、模糊匹配、包含、不包含等多种查询条件
 * - 可以灵活组合多种条件，构建复杂的查询逻辑
 * - 与BaseRepository配合使用，简化JPA动态查询的实现
 * - 所有方法自动忽略null值，避免空值条件对查询结果的影响
 */
public class Condition {

	/**
	 * 等值条件映射
	 * 存储字段名和对应值的映射关系，用于构建 field = value 条件
	 */
	@Getter
	private Map<String, Object> eq = new HashMap<>();

	/**
	 * 不等条件映射
	 * 存储字段名和对应值的映射关系，用于构建 field != value 条件
	 */
	@Getter
	private Map<String, Object> neq = new HashMap<>();

	/**
	 * 大于条件映射
	 * 存储字段名和对应值的映射关系，用于构建 field > value 条件
	 */
	@Getter
	private Map<String, Number> gt = new HashMap<>();

	/**
	 * 小于条件映射
	 * 存储字段名和对应值的映射关系，用于构建 field < value 条件
	 */
	@Getter
	private Map<String, Number> lt = new HashMap<>();

	/**
	 * 模糊匹配条件映射
	 * 存储字段名和对应值的映射关系，用于构建 field LIKE value 条件
	 */
	@Getter
	private Map<String, String> like = new HashMap<>();

	/**
	 * 包含条件映射
	 * 存储字段名和对应值列表的映射关系，用于构建 field IN (value1, value2, ...) 条件
	 */
	@Getter
	private Map<String, List<Object>> in = new HashMap<>();

	/**
	 * 不包含条件映射
	 * 存储字段名和对应值列表的映射关系，用于构建 field NOT IN (value1, value2, ...) 条件
	 */
	@Getter
	private Map<String, List<Object>> notIn = new HashMap<>();

	/**
	 * 添加等值查询条件
	 * 当值不为null时，添加 field = value 条件
	 *
	 * @param key 字段名
	 * @param value 字段值
	 */
	public void eq(String key, Object value) {
		if (value != null) {
			eq.put(key, value);
		}
	}

	/**
	 * 添加不等查询条件
	 * 当值不为null时，添加 field != value 条件
	 *
	 * @param key 字段名
	 * @param value 字段值
	 */
	public void neq(String key, Object value) {
		if (value != null) {
			neq.put(key, value);
		}
	}

	/**
	 * 添加大于查询条件
	 * 当值不为null时，添加 field > value 条件
	 *
	 * @param key 字段名
	 * @param value 数值
	 */
	public void gt(String key, Number value) {
		if (value != null) {
			gt.put(key, value);
		}
	}

	/**
	 * 添加小于查询条件
	 * 当值不为null时，添加 field < value 条件
	 *
	 * @param key 字段名
	 * @param value 数值
	 */
	public void lt(String key, Number value) {
		if (value != null) {
			lt.put(key, value);
		}
	}

	/**
	 * 添加模糊匹配查询条件
	 * 当值不为null时，添加 field LIKE value 条件
	 * 注意：value应当已包含通配符（%）
	 *
	 * @param key 字段名
	 * @param value 包含通配符的匹配字符串
	 */
	public void like(String key, String value) {
		if (value != null) {
			like.put(key, value);
		}
	}

	/**
	 * 添加包含查询条件
	 * 当键和值都不为null时，添加 field IN (value) 条件
	 * 可多次调用添加多个值，构建 field IN (value1, value2, ...) 条件
	 *
	 * @param key 字段名
	 * @param value 字段值
	 */
	public void in(String key, Object value) {
		if (key != null && value != null) {
			List<Object> list = in.computeIfAbsent(key, k -> new ArrayList<>());
			list.add(value);
		}
	}

	/**
	 * 添加不包含查询条件
	 * 当键和值都不为null时，添加 field NOT IN (value) 条件
	 * 可多次调用添加多个值，构建 field NOT IN (value1, value2, ...) 条件
	 *
	 * @param key 字段名
	 * @param value 字段值
	 */
	public void notIn(String key, Object value) {
		if (key != null && value != null) {
			List<Object> list = notIn.computeIfAbsent(key, k -> new ArrayList<>());
			list.add(value);
		}
	}

}