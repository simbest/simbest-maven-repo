package com.simbest.boot.uums.web.user;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.uums.api.user.UumsSysUserPermissionApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <strong>Title : UumsSysUserPermissionController</strong><br>
 * <strong>Description : 人员权限相关操作</strong><br>
 * <strong>Create on : 2024/5/30</strong><br>
 * <strong>Modify on : 2024/5/30</strong><br>
 *
 * @version <strong>V1.0.0</strong><br>
 *          <strong>修改历史:</strong><br>
 *          修改人 修改日期 修改描述<br>
 *          -------------------------------------------<br>
 */
/**
 * 系统用户权限管理控制器
 * 提供用户权限管理的REST API接口：
 * - 管理用户与权限的关联关系
 * - 支持批量更新用户的权限配置
 * - 提供权限分配和回收的功能
 * - 实现用户权限的动态调整
 */
@SuppressWarnings("All")
@Api(tags = {"2-统一用户管理", "用户权限管理"}, description = "提供用户与权限关联关系的管理功能，包括用户权限的分配和回收、批量更新用户权限、用户权限的查询和管理等")
@RestController
@RequestMapping(value = {"/uums/sys/user/permission", "/sys/uums/user/permission"})
public class UumsSysUserPermissionController {

    @Autowired
    private UumsSysUserPermissionApi uumsSysUserPermissionApi;

    @Autowired
    private AppConfig appConfig;

    @ApiOperation(value = "修改用户权限信息，先删除用户所有权限，再重新添加", notes = "修改用户权限信息，先删除用户所有权限，再重新添加",tags={"人员权限API"})
    @PostMapping(value = {"/updateListByPermissionId","/updateListByPermissionId/sso","/api/updateListByPermissionId"})
    public JsonResponse updateListByPermissionId(@RequestParam String permissionId, @RequestBody List<String> orgCodes){
        return uumsSysUserPermissionApi.updateListByPermissionId(permissionId, orgCodes);
    }
}