package com.simbest.boot.uums.api.group;

import com.fasterxml.jackson.core.type.TypeReference;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.SimpleGroup;
import com.simbest.boot.util.ObjectUtil;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 系统群组管理API接口
 * 
 * 提供以下功能：
 * 1. 群组信息的基础CRUD操作
 * 2. 支持群组树结构的查询和管理
 * 3. 提供父子群组关系的维护
 * 4. 支持基于应用和权限的群组查询
 * 5. 实现用户与群组的关联管理
 * 6. 提供群组类型的管理功能
 * 7. 支持分页和条件查询
 * 8. 提供数据权限相关的群组查询
 * 9. 实现群组代码的唯一性校验
 * 10. 支持与流程和决策相关的群组管理
 */
@Component
@Slf4j
@SuppressWarnings("All")
public class UumsSysGroupApi {

    private static final String USER_MAPPING = "/action/group/group/";

    private static final String SSO = "/sso";

    private static final String SSO_NWE = "sso/";

    @Autowired
    private AppConfig config;

    //private String uumsAddress="http://localhost:8080/uums";
    @Autowired
    private RsaEncryptor encryptor;

    @Autowired
    private UumsSysUserGroupApi uumsSysUserGroupApi;

    /**
     * 根据id查找
     *
     * @param id
     * @param appcode
     * @return
     */
    public SimpleGroup findById(String id, String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findById" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("id", String.valueOf(id))
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleGroup auth = JacksonUtils.json2obj(json, SimpleGroup.class);
        return auth;
    }

    /**
     * 单表条件查询
     *
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @param appcode
     * @param sysGroupMap
     * @return
     */
    public JsonResponse findAll(int page, int size, String direction, String properties, String appcode, Map sysGroupMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysGroupMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + SSO_NWE + "findAll" + "?loginuser=" + username2 + "&appcode=" + appcode
                        + "&page=" + page + "&size=" + size + "&direction=" + direction + "&properties=" + properties)
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    public JsonResponse getAll(int page, int size, Map sysGroupMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysGroupMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING  + "getAll" + SSO + "?loginuser=" + username2 + "&appcode=" + config.getAppcode()
                        + "&page=" + page + "&size=" + size)
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 校验群组的sid是否存在
     *
     * @param sid
     * @param appcode
     * @return
     */
    public Boolean isHaveCode(String sid, String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "isHaveCode" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("sid", sid)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof Boolean)) {
            log.error("--uums接口返回的类型不为Boolean--");
            return null;
        }
        return (Boolean) response.getData();
    }

    /**
     * 根据sid查看父群组信息
     *
     * @param appcode
     * @param sid
     * @return
     */
    public SimpleGroup findParentGroup(String appcode, String sid) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findParentGroup" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("sid", sid)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleGroup auth = JacksonUtils.json2obj(json, SimpleGroup.class);
        return auth;
    }

    /**
     * 查看一个群组下的全部子群组不分页
     *
     * @param appcode
     * @param sid
     * @return
     */
    public List<SimpleGroup> findAllSonGroup(String appcode, String sid) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findAllSonGroup" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("sid", sid)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleGroup> groupList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleGroup>>() {
        });
        return groupList;
    }

    /**
     * 查看群组的下一级子群组不分页
     *
     * @param appcode
     * @param sid
     * @return
     */
    public List<SimpleGroup> findSonGroups(String appcode, String sid) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findSonGroups" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("sid", sid)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleGroup> groupList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleGroup>>() {
        });
        return groupList;
    }

    /**
     * 根据应用编码、流程定义ID、环节定义ID或者决策定义ID查询群组信息不分页
     *
     * @param appcode
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @param sysAppDecisionMap
     * @return
     */
    public List<SimpleGroup> findGroupByAppNoPage(String appcode, int page, int size, String direction, String properties, Map sysAppDecisionMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysAppDecisionMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findGroupByAppNoPage" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode
                        + "&page=" + page + "&size=" + size + "&direction=" + direction + "&properties=" + properties)
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleGroup> groupList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleGroup>>() {
        });
        return groupList;
    }

    /**
     * 根据应用编码、流程定义ID、环节定义ID或者决策定义ID查询群组信息不分页
     *
     * @param appcode
     * @param sysAppDecisionMap
     * @return
     */
    public List<SimpleGroup> findGroupByAppNoPage(String appcode, Map sysAppDecisionMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysAppDecisionMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findGroupByAppNoPage" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode)
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleGroup> groupList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleGroup>>() {
        });
        return groupList;
    }

    /**
     * 查看当前用户所属群组的信息并分页
     *
     * @param appcode
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @return
     */
    public JsonResponse findGroupByUsername(String appcode, int page, int size, String direction, String properties) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findGroupByUsername" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("page", String.valueOf(page))
                .param("size", String.valueOf(size))
                .param("direction", direction)
                .param("properties", properties)
                .param("username", username)
                .asBean(JsonResponse.class);
        return response;
    }

    /**
     * 查看当前用户所属群组的信息不分页
     *
     * @param appcode
     * @return
     */
    public List<SimpleGroup> findGroupByUsernameNoPage(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findGroupByUsernameNoPage" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("username", username)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleGroup> groupList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleGroup>>() {
        });
        return groupList;
    }

    /**
     * 查看具有当前应用权限的群组信息并分页
     *
     * @param appcode
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @return
     */
    public JsonResponse findGroupByPermission(String appcode, int page, int size, String direction, String properties) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findGroupByPermission" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("page", String.valueOf(page))
                .param("size", String.valueOf(size))
                .param("direction", direction)
                .param("properties", properties)
                .param("appCode", appcode)
                .asBean(JsonResponse.class);
        return response;
    }

    /**
     * 查看具有当前应用权限的群组信息不分页
     *
     * @param appcode
     * @return
     */
    public List<SimpleGroup> findGroupByPermissionNoPage(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findGroupByPermissionNoPage" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("appCode", appcode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleGroup> groupList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleGroup>>() {
        });
        return groupList;
    }

    /**
     * 查看某个用户拥有哪种数据权限
     *
     * @param appcode
     * @return
     */
    public List<SimpleGroup> findDataPermission(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findDataPermission" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("username", username)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleGroup> groupList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleGroup>>() {
        });
        return groupList;
    }

    /**
     * 新增群组
     *
     * @param appcode
     * @return
     */
    public SimpleGroup addGroup(String appcode, SimpleGroup simpleGroup) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {},appcode:{}", username, appcode);
        JsonResponse jsonResponse = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "create" + SSO + "?"
                        + AuthoritiesConstants.SSO_API_USERNAME + ApplicationConstants.EQUAL + encryptor.encrypt(username) + "&"
                        + AuthoritiesConstants.SSO_API_APP_CODE + ApplicationConstants.EQUAL + appcode)
                .json(JacksonUtils.obj2json(simpleGroup))
                .asBean(JsonResponse.class);
        if (ObjectUtil.isEmpty(jsonResponse)) {
            log.error("--新增群组接口调用失败!--");
            return null;
        }
        String json = JacksonUtils.obj2json(jsonResponse.getData());
        SimpleGroup simpleGroupTmp = JacksonUtils.json2obj(json, SimpleGroup.class);
        return simpleGroupTmp;
    }

    /**
     * 删除群组
     *
     * @param appcode
     * @return
     */
    public boolean delGroup(String appcode, SimpleGroup simpleGroup) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {},appcode:{}", username, appcode);
        JsonResponse jsonResponse = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "delete" + SSO + "?"
                        + AuthoritiesConstants.SSO_API_USERNAME + ApplicationConstants.EQUAL + encryptor.encrypt(username) + "&"
                        + AuthoritiesConstants.SSO_API_APP_CODE + ApplicationConstants.EQUAL + appcode)
                .json(JacksonUtils.obj2json(simpleGroup))
                .asBean(JsonResponse.class);
        if (ObjectUtil.isEmpty(jsonResponse)) {
            log.error("--删除群组接口调用失败!--");
            return false;
        }
        return ObjectUtil.isNotEmpty(jsonResponse) ? true : false;
    }

    /**
     * 修改群组
     *
     * @param appcode
     * @return
     */
    public SimpleGroup updateGroup(String appcode, SimpleGroup simpleGroup) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {},appcode:{}", username, appcode);
        JsonResponse jsonResponse = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "update" + SSO + "?"
                        + AuthoritiesConstants.SSO_API_USERNAME + ApplicationConstants.EQUAL + encryptor.encrypt(username) + "&"
                        + AuthoritiesConstants.SSO_API_APP_CODE + ApplicationConstants.EQUAL + appcode)
                .json(JacksonUtils.obj2json(simpleGroup))
                .asBean(JsonResponse.class);
        if (ObjectUtil.isEmpty(jsonResponse)) {
            log.error("--修改群组接口调用失败!--");
            return null;
        }
        String json = JacksonUtils.obj2json(jsonResponse.getData());
        SimpleGroup simpleGroupTmp = JacksonUtils.json2obj(json, SimpleGroup.class);
        return simpleGroupTmp;
    }

    public JsonResponse findGroupsType() {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findGroupsType" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    public JsonResponse deleteById(String id,String sid) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + SSO_NWE + "deleteById")
                .param("id", id)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }
}