package com.simbest.boot.base.repository;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;

/**
 * 系统实体通用数据持久层接口
 * 提供系统实体的数据访问功能：
 * - 扩展GenericRepository，继承其基础数据库操作功能
 * - 为SystemModel类及其子类提供数据访问支持
 * - 自动处理创建时间和修改时间字段
 * - 作为LogicRepository的基础接口
 *
 * @param <T> 系统实体类型
 * @param <PK> 实体主键类型
 */
@Transactional
@NoRepositoryBean
public interface SystemRepository<T, PK extends Serializable> extends GenericRepository<T, PK>{

}