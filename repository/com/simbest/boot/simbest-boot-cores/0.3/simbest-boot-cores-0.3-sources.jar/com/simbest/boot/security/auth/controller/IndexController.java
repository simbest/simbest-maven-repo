package com.simbest.boot.security.auth.controller;

import static com.simbest.boot.constants.ApplicationConstants.COMMA;
import static com.simbest.boot.constants.ApplicationConstants.MSG_SUCCESS;
import static com.simbest.boot.constants.AuthoritiesConstants.ACCESS_FORBIDDEN;
import static com.simbest.boot.constants.ErrorCodeConstants.LOGIN_ERROR_OPT_IP;
import static com.simbest.boot.constants.ErrorCodeConstants.SUCCESS_MSG;

import javax.servlet.http.HttpServletRequest;

import com.simbest.boot.config.AppConfig;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.exceptions.AccesssAppDeniedException;
import com.simbest.boot.security.IUser;
import com.simbest.boot.security.util.AuthenticationUtil;
import com.simbest.boot.security.util.CheckIpIsDevOpsResult;
import com.simbest.boot.util.encrypt.AesEncryptor;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.util.server.HostUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
 * 用途：首页控制器
 *
 *
 */
@Api(tags = { "4-安全认证", "首页管理" }, description = "提供系统首页访问控制，包括匿名访问、安全登录、SSO单点登录、用户信息获取等功能")
@Slf4j
@Controller
public class IndexController {

    @Autowired
    private AppConfig appConfig;

    @Autowired
    private AesEncryptor aesEncryptor;

    @ApiOperation(value = "匿名访问首页", notes = "互联网应用为主站点页面，企业应用为登录页面，调整以下welcome模板页面")
    @RequestMapping(value = { "/" }, method = { RequestMethod.POST, RequestMethod.GET })
    public String root(HttpServletRequest request) {
        return "redirect:/welcome";
    }

    @ApiOperation(value = "匿名访问首页", notes = "互联网应用welcome为主站点页面，企业应用welcome为登录页面")
    @GetMapping("/welcome")
    public ModelAndView welcome() {
        return new ModelAndView("welcome");
    }

    @ApiOperation(value = "匿名安全登录首页", notes = "匿名安全登录首页，不需要session")
    @GetMapping("/signin")
    public String signin(HttpServletRequest request) {
        Boolean signin = appConfig.getSignin();
        if (!signin) {
            return "signin";
        }
        else {
            CheckIpIsDevOpsResult checkDevOpsResult = AuthenticationUtil
                    .checkIpIsDevOps(HostUtil.getClientIpAddress(request));
            if (checkDevOpsResult.isCheckRet()) {
                return "signin";
            } else {
                log.error(String.format(LOGIN_ERROR_OPT_IP, String.join(COMMA, checkDevOpsResult.getWhiteIps()),
                        checkDevOpsResult.getCurrentIp()));
                throw new AccesssAppDeniedException(ACCESS_FORBIDDEN);
            }
        }
    }

    @ApiOperation(value = "需要SESSION信息的后台首页", notes = "支持SSO单点登录")
    @RequestMapping(value = { "/home", "/sso", "/hqsso" }, method = { RequestMethod.POST, RequestMethod.GET })
    public String home(HttpServletRequest request, Model indexModel) {
        String menuId = request.getParameter("menuId");
        indexModel.addAttribute("menuId", menuId);
        log.debug("登录成功后获取url中的参数{}", menuId);

        if (StringUtils.isEmpty(request.getQueryString())) {
            return "redirect:/index";
        } else {
            // 过滤掉hqClientId和hqTicket参数
            String queryString = request.getQueryString();
            try {
                queryString = java.net.URLDecoder.decode(queryString, "UTF-8");
            } catch (Exception e) {
                log.warn("解码查询字符串失败: {}", e.getMessage());
            }
            // 处理URL参数
            StringBuilder filteredQuery = new StringBuilder();
            String[] pairs = queryString.split("&");
            for (String pair : pairs) {
                // 确保参数对有内容
                if (StringUtils.isNotEmpty(pair)) {
                    // 检查是否是需要过滤的参数
                    if (!pair.startsWith("hqClientId=") && !pair.startsWith("hqTicket=")) {
                        if (filteredQuery.length() > 0) {
                            filteredQuery.append("&");
                        }
                        filteredQuery.append(pair);
                    }
                }
            }
            String finalQuery = filteredQuery.toString();
            if (StringUtils.isEmpty(finalQuery)) {
                return "redirect:/index";
            } else {
                return "redirect:/index?" + finalQuery;
            }
        }
    }

    @ApiOperation(value = "需要SESSION信息的后台首页")
    @RequestMapping(value = "/index", method = { RequestMethod.POST, RequestMethod.GET })
    public ModelAndView index(Model indexModel) {
        IUser iuser = SecurityUtils.getCurrentUser();
        indexModel.addAttribute("iuser", iuser);
        return new ModelAndView("index", "indexModel", indexModel);
    }

    @ApiOperation(value = "获取当前登陆人信息")
    @PostMapping(value = { "/getCurrentUser", "/getCurrentUser/sso", "/getCurrentUser/api", "/getCurrentUser/hqsso" })
    @ResponseBody
    public JsonResponse getCurrentUser() {
        IUser iuser = SecurityUtils.getCurrentUser();
        return JsonResponse.success(iuser);
    }

    @ApiOperation(value = "获取当前登陆人信息")
    @PostMapping(value = { "/getCurrentUserInfo", "/getCurrentUserInfo/sso", "/getCurrentUserInfo/api",
            "/getCurrentUserInfo/hqsso" })
    @ResponseBody
    public JsonResponse getCurrentUserInfo() {
        // IUser iuser = SecurityUtils.getCurrentUser();
        // SimpleUser simpleUser = new SimpleUser();
        // BeanUtils.copyProperties(iuser, simpleUser);
        // simpleUser.setPreferredMobile(aesEncryptor.encrypt(simpleUser.getPreferredMobile()));
        // simpleUser.setEmail(aesEncryptor.encrypt(simpleUser.getEmail()));
        // return JsonResponse.success(simpleUser);
        // com.fasterxml.jackson.databind.JsonMappingException:
        // java.lang.ClassCastException@70be4007 (through reference chain:
        // com.simbest.boot.base.web.response.JsonResponse["data"]->com.simbest.boot.security.SimpleUser["authorities"]->java.util.TreeSet[0]->com.simbest.boot.anddoc.uums.permission.model.SysPermission["authority"])

        // //此方式不会出现JSON解析错误，但只针对了手机号码和邮箱两个字段
        // IUser iuser = SecurityUtils.getCurrentUser();
        // String iuserString = JacksonUtils.obj2json(iuser);
        // JsonNode userNode = JacksonUtils.json2node(iuserString);
        // if(StringUtils.isNotEmpty(iuser.getEmail())) {
        // ((ObjectNode) userNode).put("email", aesEncryptor.encrypt(iuser.getEmail()));
        // }
        // if(StringUtils.isNotEmpty(iuser.getPreferredMobile())) {
        // ((ObjectNode) userNode).put("preferredMobile",
        // aesEncryptor.encrypt(iuser.getPreferredMobile()));
        // }
        // return JsonResponse.success(userNode);

        IUser iuser = SecurityUtils.getCurrentUser();
        String aesUser = aesEncryptor.encrypt(JacksonUtils.obj2json(iuser));
        return JsonResponse.success(aesUser, SUCCESS_MSG);

    }

    @ApiOperation(value = "获取当前请求IP地址,判断IPv4或IPv6访问")
    @RequestMapping(value = { "/anonymous/getClientIP" }, method = { RequestMethod.POST, RequestMethod.GET })
    @ResponseBody
    public JsonResponse getClientIP(HttpServletRequest request) {
        return JsonResponse.success(HostUtil.getClientIpAddress(request), MSG_SUCCESS);
    }

    @ApiOperation(value = "页面转发", httpMethod = "GET", notes = "application/x-www-form-urlencoded", response = ModelAndView.class, consumes = "application/x-www-form-urlencoded")
    @RequestMapping(value = { "/anonymous/{pageName}" }, method = { RequestMethod.POST, RequestMethod.GET })
    public ModelAndView redirectView(
            @ApiParam(required = true, name = "pageName", value = "页面名称") @PathVariable String pageName) {
        log.debug("redirectView3: Redirect to page: " + pageName);
        return new ModelAndView(pageName);
    }

}