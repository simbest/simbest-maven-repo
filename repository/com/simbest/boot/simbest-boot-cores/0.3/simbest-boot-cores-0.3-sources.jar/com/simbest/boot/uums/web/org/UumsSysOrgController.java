package com.simbest.boot.uums.web.org;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.uums.api.org.UumsSysOrgApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 系统组织管理控制器
 * 提供组织相关的REST API接口：
 * - 组织基础信息管理
 * - 组织层级关系管理
 * - 组织架构查询
 * - 组织权限管理
 * - 特殊组织查询（省公司、地市分公司等）
 */
@Api(tags = {"2-统一用户管理", "组织管理"}, description = "提供组织相关的管理功能，包括组织信息的CRUD操作、组织树结构的查询和管理、父子组织关系的维护、组织权限关联的查询等")
@RestController
@RequestMapping(value = {"/uums/sys/org", "/sys/uums/org"})
public class UumsSysOrgController {

    @Autowired
    private UumsSysOrgApi uumsSysOrgApi;

    @Autowired
    private AppConfig appConfig;

    @ApiOperation(value = "基本增删改查之根据id查询组织信息", notes = "根据id查询组织信息", tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "id", value = "组织ID", dataType = "Integer", paramType = "query")
    @PostMapping(value = {"/findById", "/findById/sso"})
    public JsonResponse findById(@RequestParam String id) {
        return JsonResponse.success(uumsSysOrgApi.findById(id,appConfig.getAppcode()));
    }

    @ApiOperation(value = "基本增删改查之新增一个组织", notes = "新增一个组织",tags={"组织 组织特殊查询"})
    @PostMapping(value = {"/create", "/create/sso"})
    public JsonResponse create(@RequestBody(required = false) Map<String, Object> sysOrgInfoFull) {
        return JsonResponse.success(uumsSysOrgApi.create(sysOrgInfoFull));
    }

    @ApiOperation(value = "基本增删改查之获取组织信息列表并分页", notes = "获取组织信息列表并分页", tags = {"组织 基本增删改查"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "当前页码", dataType = "int", paramType = "query",required = true, example = "1"),
            @ApiImplicitParam(name = "size", value = "每页数量", dataType = "int", paramType = "query",required = true, example = "10"),
            @ApiImplicitParam(name = "direction", value = "排序规则（asc/desc）", dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "properties", value = "排序规则（属性名称）", dataType = "String",paramType = "query")
    })
    @PostMapping(value = {"/findAll", "/findAll/sso"})
    public JsonResponse findAll(@RequestParam(required = false, defaultValue = "1") int page,
                                @RequestParam(required = false, defaultValue = "10") int size,
                                @RequestParam(required = false) String direction,
                                @RequestParam(required = false) String properties,
                                @RequestBody Map sysOrgInfoFull
    ) {
        return JsonResponse.success(uumsSysOrgApi.findAll(page, size, direction, properties, appConfig.getAppcode(),sysOrgInfoFull));
    }

    /**
     * 查看某个父组织的子组织
     * @param appcode
     * @param orgCode
     * @return
     */
    @ApiOperation (value = "查看某个父组织的子组织", notes = "查看某个父组织的子组织",tags = {"组织 基本增删改查"})
    @ApiImplicitParams( {
            @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "orgCode", value = "组织code", dataType = "String", paramType = "query")
    } )
    @PostMapping ("/findSonByParentOrgId")
    public JsonResponse findSonByParentOrgId( @RequestParam  String appcode,@RequestParam String orgCode) {
        return JsonResponse.success(uumsSysOrgApi.findSonByParentOrgId( appcode,orgCode ));
    }

    /**
     * 查看某个父组织的子组织,返回树形结构UserOrgTree
     * @param appcode
     * @param mapOrg
     * @return
     */
    @ApiOperation (value = "查看某个父组织的子组织,返回树形结构UserOrgTree", notes = "查看某个父组织的子组织,返回树形结构UserOrgTree",tags = {"组织 基本增删改查"})
    @ApiImplicitParams( {
            @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    } )
    @PostMapping ("/findSonByParentOrgIdTree")
    public JsonResponse findSonByParentOrgIdTree( @RequestParam  String appcode,@RequestBody Map<String,Object> mapOrg) {
        return JsonResponse.success(uumsSysOrgApi.findSonByParentOrgIdTree( appcode,mapOrg ));
    }

    /**
     *页面初始化时获取根组织以及根组织下一级组织
     * @param appcode
     * @return
     */
    @ApiOperation (value = "页面初始化时获取根组织以及根组织下一级组织", notes = "页面初始化时获取根组织以及根组织下一级组织",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    @PostMapping ("/findRootAndNextRoot")
    public JsonResponse findRootAndNextRoot( @RequestParam  String appcode) {
        return JsonResponse.success(uumsSysOrgApi.findRootAndNext( appcode ));
    }

    /**
     * 出省公司以及地市分公司，还有省公司下的部门
     * @param appcode
     * @return
     */
    @ApiOperation (value = "出省公司以及地市分公司，还有省公司下的部门", notes = "出省公司以及地市分公司，还有省公司下的部门",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    @PostMapping ("/findPOrgAndCityOrg")
    public JsonResponse findPOrgAndCityOrg( @RequestParam  String appcode) {
        return JsonResponse.success(uumsSysOrgApi.findPOrgAndCityOrg( appcode ));
    }

    /**
     * 出某些组织之出省公司以及18个地市分公司，不要省飞达等公司
     * @param appcode
     * @return
     */
    @ApiOperation (value = "出某些组织之出省公司以及18个地市分公司，不要省飞达等公司", notes = "出某些组织之出省公司以及18个地市分公司，不要省飞达等公司",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    @PostMapping ("/findPOrgAnd18CityOrg")
    public JsonResponse findPOrgAnd18CityOrg( @RequestParam  String appcode) {
        return JsonResponse.success(uumsSysOrgApi.findPOrgAnd18CityOrg( appcode ));
    }

    /**
     * 查出用户所在的市公司下的部门以及市公司下的县公司
     * @param appcode
     * @return
     */
    @ApiOperation (value = "查出用户所在的市公司下的部门以及市公司下的县公司", notes = "查出用户所在的市公司下的部门以及市公司下的县公司",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    @PostMapping ("/findCityDeapartmentAndCountyCompany")
    public JsonResponse findCityDeapartmentAndCountyCompany( @RequestParam  String appcode) {
        return JsonResponse.success(uumsSysOrgApi.findCityDeapartmentAndCountyCompany( appcode ));
    }

    /**
     * 根据用户名以及规则出组织
     * @param appcode
     * @param userMap
     * @return
     */
    @ApiOperation (value = "根据用户名以及规则出组织", notes = "根据用户名以及规则出组织",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    @PostMapping ("/findOrgByUserMap")
    public JsonResponse findCityDeapartmentAndCountyCompany( @RequestParam(required = false)  String appcode, @RequestBody(required = false) Map userMap) {
        return JsonResponse.success(uumsSysOrgApi.findOrgByUserMap(appcode,userMap));
    }

    /**
     * 根据corpId查询企业根节点
     * @param appcode
     * @param corpId
     * @return
     */
    @ApiOperation(value = "根据corpId查询企业根节点", notes = "根据corpId查询企业根节点",tags = {"组织 基本增删改查"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "corpId", value = "企业id", dataType = "String", paramType = "query")
    })
    @PostMapping(value = "/findRootByCorpId")
    public JsonResponse findRootByCorpId(@RequestParam(required = false)  String appcode,@RequestParam String corpId) {
        return JsonResponse.success(uumsSysOrgApi.findRootByCorpId(appcode,corpId));
    }

    /**
     * 用于查询当前人所在的组织树，直到企业的顶级
     * @param corpMap
     * @return
     */
    @ApiOperation(value = "用于查询当前人所在的组织树，直到企业的顶级", notes = "用于查询当前人所在的组织树，直到企业的顶级",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    @PostMapping(value = {"/findOrgTreeFromCorp","/findOrgTreeFromCorp/sso"})
    public JsonResponse findOrgTreeFromCorp(@RequestParam(required = false) String appcode, @RequestBody(required = false) Map<String,Object> corpMap) {
        return JsonResponse.success(uumsSysOrgApi.findUserTreeFromCorp(appcode,corpMap));
    }

    /**
     * 出某些组织的上级组织以及它的全部下级组织以及某些组织的上级组织
     * @param orgMap
     * @return
     */
    @ApiOperation(value = "出某些组织的上级组织以及它的全部下级组织以及某些组织的上级组织", notes = "出某些组织的上级组织以及它的全部下级组织以及某些组织的上级组织",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    @PostMapping(value = {"/findRuleOrgTree","/findRuleOrgTree/sso"})
    public JsonResponse findRuleOrgTree(@RequestParam(required = false) String appcode, @RequestBody(required = false) Map<String,Object> orgMap) {
        return JsonResponse.success(uumsSysOrgApi.findRuleOrgTree(appcode,orgMap));
    }

    /**
     * 根据组织code查询组织信息
     * @param orgCode
     */
    @ApiOperation(value = "特殊查询之根据组织编码查询存在的组织列表", notes = "根据组织编码查询存在的组织列表",tags = {"组织 基本增删改查"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "orgCode", value = "组织编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "appcode", value = "应用编码", dataType = "String", paramType = "query")
    })
    @PostMapping(value = {"/findListByOrgCode","/findListByOrgCode/sso"})
    public JsonResponse findListByOrgCode( @RequestParam(required = false) String orgCode,@RequestParam(required = false) String appcode) {
        return JsonResponse.success(uumsSysOrgApi.findListByOrgCode(appcode,orgCode));
    }


    /**
     * 查询某个子组织的父组织
     * @param orgCode
     * @param appcode
     * @return
     */
    @ApiOperation(value = "子父级之查看某个子组织的父组织", notes = "子父级之查看某个子组织的父组织",tags = {"组织 基本增删改查"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "orgCode", value = "组织编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "appcode", value = "应用编码", dataType = "String", paramType = "query")
    })
    @PostMapping(value = {"/findParentBySon","/findParentBySon/sso"})
    public JsonResponse findParentBySon( @RequestParam(required = false) String orgCode,@RequestParam(required = false) String appcode) {
        return JsonResponse.success(uumsSysOrgApi.findParentBySon(appcode,orgCode));
    }

    @ApiOperation(value = "根据组织编码和组织名模糊查询存在的组织列表，包括已禁用的，不包括已删除的", notes = "根据组织编码和组织名模糊查询存在的组织列表，包括已禁用的，不包括已删除的",tags = {"组织 基本增删改查"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "当前页码", dataType = "int", paramType = "query", required = true, example = "1"),
            @ApiImplicitParam(name = "size", value = "每页数量", dataType = "int", paramType = "query", required = true, example = "10"),
            @ApiImplicitParam(name = "direction", value = "排序规则（asc/desc）", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "properties", value = "排序规则（属性名称）", dataType = "String",  paramType = "query"),
            @ApiImplicitParam(name = "orgCode", value = "组织编码", dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "orgName", value = "组织名称", dataType = "String",paramType = "query")
    })
    @PostMapping(value = {"/findOrgCodeOrgNameDim", "/findOrgCodeOrgNameDim/sso"})
    public JsonResponse findOrgCodeOrgNameDim(@RequestParam(required = false, defaultValue = "1") int page,
                                              @RequestParam(required = false, defaultValue = "10") int size,
                                              @RequestParam(required = false, defaultValue = "asc") String direction,
                                              @RequestParam(required = false, defaultValue = "displayOrder") String properties,
                                              @RequestParam(required = false) String parentOrgCode,
                                              @RequestParam(required = false) String orgCode,
                                              @RequestParam(required = false) String orgName,
                                              @RequestParam(required = false) String companyTypeDictValue
    ) {
        return uumsSysOrgApi.findOrgCodeOrgNameDim(page, size, direction, properties,parentOrgCode,orgCode,orgName,companyTypeDictValue);
    }

    @ApiOperation(value = "更新组织信息", notes = "更新组织信息",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "sysOrgInfoFull", value = "组织对象", dataType = "SimpleOrg", required = true, paramType = "body")
    @PostMapping(value = {"/updateOrgCustom", "/updateOrgCustom/sso","/api/updateOrgCustom"})
    public JsonResponse updateOrgCustom(@RequestBody Map<String, Object> sysOrgInfoFull) {
        return uumsSysOrgApi.updateOrgCustom(sysOrgInfoFull);
    }

    @ApiOperation(value = "删除组织信息", notes = "删除组织信息",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "orgCode", value = "组织code", dataType = "String", paramType = "query")
    @PostMapping(value = {"/deleteOrgCustom", "/deleteOrgCustom/sso","/api/deleteOrgCustom"})
    public JsonResponse deleteOrgCustom(@RequestParam String id) {
        return uumsSysOrgApi.deleteOrgCustom(id);
    }

    @ApiOperation(value = "根据菜单ID查询被授权的组织", notes = "根据菜单ID查询被授权的组织",tags = {"组织 基本增删改查"})
    @ApiImplicitParam(name = "permissionId", value = "菜单ID", dataType = "String", paramType = "query")
    @PostMapping(value = {"/queryOrgByPermissionId", "/queryOrgByPermissionId/sso","/api/queryOrgByPermissionId"})
    public JsonResponse queryOrgByPermissionId(@RequestParam String permissionId) {
        return uumsSysOrgApi.queryOrgByPermissionId(permissionId);
    }
}