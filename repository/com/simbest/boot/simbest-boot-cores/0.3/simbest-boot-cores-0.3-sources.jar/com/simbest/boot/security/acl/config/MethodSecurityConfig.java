package com.simbest.boot.security.acl.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * 方法级安全配置类
 * 
 * 主要功能：
 * 1. 配置Spring Security的方法级安全控制
 * 2. 启用基于注解的安全控制
 * 3. 集成自定义ACL权限评估器
 * 
 * 支持特性：
 * 1. 支持@PreAuthorize和@PostAuthorize注解
 * 2. 支持@Secured注解
 * 3. 支持自定义权限表达式
 * 4. 支持ACL访问控制
 * 
 * 使用方式：
 * 1. 在方法上使用@PreAuthorize注解进行权限控制
 * 2. 在方法上使用@PostAuthorize注解进行结果过滤
 * 3. 使用@Secured注解指定所需角色
 */
@Slf4j
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class MethodSecurityConfig extends GlobalMethodSecurityConfiguration {

    /**
     * JPA实体管理器
     */
    @PersistenceContext
    private EntityManager em;

    /**
     * 创建方法安全表达式处理器
     * 
     * @return 配置了自定义权限评估器的表达式处理器
     */
    @Override
    protected MethodSecurityExpressionHandler createExpressionHandler() {
        DefaultMethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
        CustomAclPermissionEvaluator customAclPermissionEvaluator = new CustomAclPermissionEvaluator(em);
        expressionHandler.setPermissionEvaluator(customAclPermissionEvaluator);
        return expressionHandler;
    }


//    /**
//     * 基于策略的ACL
//     * https://github.com/lordlothar99/strategy-spring-security-acl
//     * 特别注意OAuth2MethodSecurityExpressionHandler，如果官方注入，可以使用@SpringBootApplication(exclude= OAuth2AutoConfiguration.class) 进行过滤
//     */
//    private final MethodSecurityExpressionHandler methodSecurityExpressionHandler;
//
//    public MethodSecurityConfig(MethodSecurityExpressionHandler methodSecurityExpressionHandler) {
//        this.methodSecurityExpressionHandler = methodSecurityExpressionHandler;
//    }



}