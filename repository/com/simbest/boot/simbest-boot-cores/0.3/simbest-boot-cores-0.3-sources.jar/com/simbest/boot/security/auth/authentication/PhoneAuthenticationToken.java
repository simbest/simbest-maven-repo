package com.simbest.boot.security.auth.authentication;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;

/**
 * 手机号码认证令牌
 * 
 * 主要功能：
 * 1. 实现基于手机号码的登录认证
 * 2. 继承自Spring Security的AbstractAuthenticationToken
 * 3. 支持认证前状态的令牌管理
 * 
 * 认证流程：
 * 1. 创建时使用手机号码作为principal
 * 2. 使用应用代码(appcode)作为credentials
 * 3. 初始状态下不包含任何权限
 * 
 * 使用场景：
 * - 手机号码+验证码登录
 * - 手机号码+密码登录
 * - 其他基于手机号码的认证方式
 */
public class PhoneAuthenticationToken extends AbstractAuthenticationToken {

    /**
     * 认证主体
     * 在手机认证场景中，这里存储手机号码
     * 用于：
     * 1. 唯一标识用户
     * 2. 后续的短信验证码发送
     * 3. 用户信息关联查询
     */
    @Setter @Getter
    private Object principal;

    /**
     * 认证凭据
     * 在手机认证场景中，这里存储应用代码(appcode)
     * 用于：
     * 1. 标识请求来源的应用
     * 2. 支持多应用认证场景
     * 3. 应用级别的权限控制
     */
    @Setter @Getter
    private Object credentials;

    /**
     * 创建手机认证令牌
     * 
     * @param principal 手机号码，作为认证主体
     * @param credentials 应用代码，作为认证凭据
     * 
     * 说明：
     * 1. 创建时使用空权限列表初始化
     * 2. 认证成功后需要重新设置对应的权限
     */
    public PhoneAuthenticationToken(String principal, Object credentials) {
        super(AuthorityUtils.NO_AUTHORITIES);
        this.principal = principal;
        this.credentials = credentials;
    }

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}