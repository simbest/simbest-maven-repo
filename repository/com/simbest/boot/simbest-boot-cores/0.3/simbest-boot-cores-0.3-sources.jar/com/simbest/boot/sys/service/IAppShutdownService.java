package com.simbest.boot.sys.service;

/**
 * 用途：完美关闭应用的钩子
 *
 *
 */
public interface IAppShutdownService {

    /**
     * 应用退出销毁前的关闭动作
     */
    void gracefulShutdown();

}