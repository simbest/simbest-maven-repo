package com.simbest.boot.exceptions;

import lombok.NoArgsConstructor;

/**
 * 插入已存在对象异常
 * 
 * 主要用途：
 * 1. 用于标识尝试插入或创建已经存在的对象时的异常情况
 * 2. 通常用于维护数据唯一性约束
 * 
 * 使用场景：
 * 1. 插入数据时违反唯一键约束
 * 2. 创建具有唯一标识的对象时发现重复
 * 3. 批量导入数据时遇到重复记录
 * 
 * 注意事项：
 * 1. 建议在异常消息中包含导致冲突的关键字段信息
 * 2. 可以用于防止重复数据的插入
 * 3. 作为RuntimeException的子类，属于非受检异常
 */
@NoArgsConstructor
public class InsertExistObjectException extends RuntimeException {

    /**
     * 使用指定的错误消息构造异常
     *
     * @param msg 详细的错误消息，说明对象已存在的具体原因
     */
    public InsertExistObjectException(String msg) {
        super(msg);
    }

    /**
     * 使用指定的错误消息和根异常构造异常
     *
     * @param msg 详细的错误消息，说明对象已存在的具体原因
     * @param t 导致此异常的根本原因
     */
    public InsertExistObjectException(String msg, Throwable t) {
        super(msg, t);
    }
}