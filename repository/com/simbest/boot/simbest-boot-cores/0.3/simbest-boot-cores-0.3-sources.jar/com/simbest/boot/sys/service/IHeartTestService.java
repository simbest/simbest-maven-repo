package com.simbest.boot.sys.service;

import com.simbest.boot.sys.model.SysHealth;

/**
 * 用途：心跳测试服务
 *
 *
 */
public interface IHeartTestService {

    SysHealth doTest();
}