package com.simbest.boot.exceptions;

import org.springframework.security.core.AuthenticationException;

/**
 * 应用访问权限异常类
 * 
 * 主要用途：
 * 1. 处理用户访问未注册应用的情况
 * 2. 处理用户访问未授权应用群组的情况
 * 
 * 特点：
 * 1. 继承自Spring Security的AuthenticationException
 * 2. 支持带消息的异常构造
 * 3. 支持带根异常的异常构造
 * 
 * 使用场景：
 * 1. 用户尝试访问未注册的应用时
 * 2. 用户尝试访问未被授权的应用群组时
 * 3. 应用访问权限校验失败时
 */
public class AccesssAppDeniedException extends AuthenticationException {

    /**
     * 创建一个应用访问权限异常
     *
     * @param msg 异常详细信息
     */
    public AccesssAppDeniedException(String msg) {
        super(msg);
    }

    /**
     * 创建一个带有根异常的应用访问权限异常
     *
     * @param msg 异常详细信息
     * @param t 根异常
     */
    public AccesssAppDeniedException(String msg, Throwable t) {
        super(msg, t);
    }
}