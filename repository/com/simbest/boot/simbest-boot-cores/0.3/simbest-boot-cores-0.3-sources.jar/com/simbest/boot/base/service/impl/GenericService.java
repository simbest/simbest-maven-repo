package com.simbest.boot.base.service.impl;

import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Sets;
import com.simbest.boot.base.model.GenericModel;
import com.simbest.boot.base.repository.Condition;
import com.simbest.boot.base.repository.GenericRepository;
import com.simbest.boot.base.service.IGenericService;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.exceptions.InsertExistObjectException;
import com.simbest.boot.exceptions.UpdateNotExistObjectException;
import com.simbest.boot.util.CustomBeanUtil;
import com.simbest.boot.util.ObjectUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.simbest.boot.constants.ApplicationConstants.DEFAULT_SIZE;

/**
 * 通用实体服务层实现类
 * 
 * 功能特点：
 * 1. 提供基础的实体CRUD操作实现
 * 2. 支持分页查询和动态条件查询
 * 3. 集成缓存配置
 * 4. 所有操作都有完整的日志记录
 * 5. 支持事务管理
 * 6. 提供灵活的查询条件构建
 */
@Slf4j
@CacheConfig(cacheNames = ApplicationConstants.REDIS_DEFAULT_CACHE_PREFIX)
public class GenericService<T extends GenericModel,PK extends Serializable> implements IGenericService<T,PK> {

    /**
     * 通用仓库接口，提供数据访问能力
     */
    private GenericRepository<T,PK> genericRepository;

    /**
     * 无参构造函数
     */
    public GenericService(){}

    /**
     * 带仓库参数的构造函数
     * 
     * @param genericRepository 泛型仓库接口
     */
    public GenericService ( GenericRepository<T, PK> genericRepository ) {
        this.genericRepository = genericRepository;
    }

    /**
     * 获取默认分页对象
     * 
     * @return 默认配置的分页对象
     */
    @Override
    public Pageable getPageable() {
        return genericRepository.getPageable();
    }

    /**
     * 获取指定页码和大小的分页对象
     * 
     * @param page 页码（从1开始）
     * @param size 每页记录数
     * @return 配置好的分页对象
     */
    @Override
    public Pageable getPageable(int page, int size) {
        // 页码是从零开始的，需要转换
        int pagePage = page < 1 ? 0 : (page - 1);
        int pageSize = size < 1 ? 1 : size;
        return PageRequest.of(pagePage, pageSize);
    }

    /**
     * 获取带排序功能的分页对象
     * 
     * @param page 页码（从1开始）
     * @param size 每页记录数
     * @param direction 排序方向（ASC或DESC）
     * @param properties 排序字段，多个字段用逗号分隔
     * @return 配置好的带排序的分页对象
     */
    @Override
    public Pageable getPageable(int page, int size, String direction, String properties) {
        // 页码是从零开始的，需要转换
        int pagePage = page < 1 ? 0 : (page - 1);
        int pageSize = size < 1 ? 1 : size;
        if(DEFAULT_SIZE < pageSize){
            log.warn("分页查询容量为【{}】，超过系统默认阈值【{}】，请检查必要性！", pageSize, DEFAULT_SIZE);
        }

        Pageable pageable;

        if (!StrUtil.isBlankOrUndefined(direction) && !StrUtil.isBlankOrUndefined(properties)) {
            // 生成指定排序规则-顺序
            Sort.Direction sortDirection;
            String[] sortProperties;
            try {
                // 先转换为大写
                direction = direction.toUpperCase();
                // 再获取枚举
                sortDirection = Sort.Direction.valueOf(direction);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                sortDirection = Sort.Direction.ASC;
            }

            // 生成指定排序规则-关键字
            sortProperties = properties.split(",");

            // 生成排序规则
            Sort sort = Sort.by(sortDirection, sortProperties);
            pageable = PageRequest.of(pagePage, pageSize, sort);
        } else {
            pageable = PageRequest.of(pagePage, pageSize);
        }
        return pageable;
    }

    /**
     * 根据实体对象创建查询规范
     * 
     * @param entity 实体对象
     * @return 查询规范
     */
    @Override
    public Specification<T> getSpecification(T entity) {
        return genericRepository.getSpecification(entity);
    }

    /**
     * 根据条件Map创建查询规范
     * 
     * @param conditions 条件Map
     * @return 查询规范
     */
    @Override
    public Specification<T> getSpecification(Map<String, Object> conditions) {
        return genericRepository.getSpecification(conditions);
    }

    /**
     * 根据Condition对象创建查询规范
     * 
     * @param condition 条件对象
     * @return 查询规范
     */
    @Override
    public Specification<T> getSpecification(Condition condition) {
        return genericRepository.getSpecification(condition);
    }

    /**
     * 统计实体总数
     * 
     * @return 实体总数
     */
    @Override
    public long count ( ) {
        log.debug("@Generic Repository Service count null param");
        return genericRepository.count();
    }

    /**
     * 根据条件统计实体数量
     * 
     * @param specification 查询条件
     * @return 符合条件的实体数量
     */
    @Override
    public long count ( Specification<T> specification ) {
        log.debug("@Generic Repository Service count Specification param");
        return genericRepository.count( specification );
    }

    /**
     * 检查指定ID的实体是否存在
     * 
     * @param id 实体ID
     * @return 是否存在
     */
    @Override
    public boolean exists ( PK id ) {
        log.debug("@Generic Repository Service exists object by id: " + id);
        return genericRepository.existsById( id );
    }

    /**
     * 根据ID查找实体（懒加载方式）
     * 
     * @param id 实体ID
     * @return 实体对象
     */
    @Override
    public T findOne ( PK id ) {
        log.debug("@Generic Repository Service getOne object by id: " + id);
        return genericRepository.getOne(id);
    }

    /**
     * 根据条件查找单个实体
     * 
     * @param conditions 查询条件
     * @return 实体对象，如果不存在则返回null
     */
    @Override
    public T findOne(Specification<T> conditions){
        log.debug("@Generic Repository Service findOne Specification param");
        return genericRepository.findOne(conditions).orElse(null);
    }

    /**
     * 根据ID查找实体（即时加载方式）
     * 
     * @param id 实体ID
     * @return 实体对象，如果不存在则返回null
     */
    @Override
    public T findById ( PK id ) {
        log.debug("@Generic Repository Service get single object by id: " + id);
        return genericRepository.findById(id).orElse( null );
    }

    /**
     * 查询所有实体并分页
     * 
     * @return 分页后的实体列表
     */
    @Override
    public Page<T> findAll ( ) {
        log.debug("@Generic Repository Service findAll");
        return genericRepository.findAll(genericRepository.getPageable());
    }

    /**
     * 根据分页参数查询所有实体
     * 
     * @param pageable 分页参数
     * @return 分页后的实体列表
     */
    @Override
    public Page<T>  findAll ( Pageable pageable ) {
        log.debug("@Generic Repository Service findAll object PageSize:" + pageable.getPageSize() + ":PageNumber:" + pageable.getPageNumber());
        return genericRepository.findAll( pageable );
    }

    /**
     * 根据排序参数查询所有实体并分页
     * 
     * @param sort 排序参数
     * @return 分页后的实体列表
     */
    @Override
    public Page<T>  findAll ( Sort sort ) {
        log.debug("@Generic Repository Service object by Sort");
        return genericRepository.findAll(PageRequest.of(ApplicationConstants.DEFAULT_PAGE, DEFAULT_SIZE, sort));
    }

    /**
     * 查询所有实体不分页
     * 
     * @return 所有实体列表
     */
    @Override
    public Iterable<T> findAllNoPage(){
        log.debug("@Generic Repository Service findAllNoPage");
        return genericRepository.findAll();
    }

    /**
     * 根据排序参数查询所有实体不分页
     * 
     * @param sort 排序参数
     * @return 排序后的所有实体列表
     */
    @Override
    public Iterable<T> findAllNoPage(Sort sort){
        log.debug("@Generic Repository Service findAllNoPage");
        return genericRepository.findAll(sort);
    }

    /**
     * 根据ID集合查询多个实体
     * 
     * @param ids ID集合
     * @return 实体列表
     */
    @Override
    public Iterable<T> findAllByIDs(Iterable<PK> ids) {
        log.debug("@Generic Repository Service object by findAllByIDs");
        return genericRepository.findAllById(ids);
    }

    /**
     * 根据条件查询实体并分页
     * 
     * @param conditions 查询条件
     * @param pageable 分页参数
     * @return 分页后的实体列表
     */
    @Override
    public Page<T> findAll ( Specification<T> conditions, Pageable pageable ) {
        log.debug("@Generic Repository Service findAll Specification object PageSize:" + pageable.getPageSize() + ":PageNumber:" + pageable.getPageNumber());
        return genericRepository.findAll(conditions, pageable);
    }

    /**
     * 根据条件查询实体不分页
     * 
     * @param conditions 查询条件
     * @return 符合条件的所有实体
     */
    @Override
    public Iterable<T> findAllNoPage(Specification<T> conditions){
        log.debug("@Generic Repository Service object by findAllNoPage");
        return genericRepository.findAll(conditions);
    }

    /**
     * 根据条件和排序参数查询实体不分页
     * 
     * @param conditions 查询条件
     * @param sort 排序参数
     * @return 排序后的符合条件的所有实体
     */
    @Override
    public Iterable<T> findAllNoPage(Specification<T> conditions, Sort sort){
        log.debug("@Generic Repository Service object by findAllNoPage");
        return genericRepository.findAll(conditions, sort);
    }

    /**
     * 新增实体
     * 
     * @param source 待保存的实体对象
     * @return 保存后的实体对象（包含生成的ID）
     * @throws InsertExistObjectException 如果尝试插入已存在ID的对象
     */
    @Override
    @Transactional
    public T insert ( T source ) {
        if(null == ObjectUtil.getEntityIdVaue(source)) {
            log.debug("@Generic Repository Service create new object: " + source);
            T target = genericRepository.save(source);
            CustomBeanUtil.copyTransientProperties(source,target);
            log.debug("@Generic Repository Service create new object successful： " + target);
            return target;
        } else {
            throw new InsertExistObjectException();
        }
    }

    @Override
    @Transactional
    public T update ( T source ) {
        PK pk = (PK)ObjectUtil.getEntityIdVaue(source);
        if(null != pk) {
            log.debug("@Generic Repository Service update a already object: " + source);
            T target = findById(pk);
            CustomBeanUtil.copyPropertiesIgnoreNull(source, target);
            T newTarget = genericRepository.save(target);
            CustomBeanUtil.copyTransientProperties(target,newTarget);
            return newTarget;
        } else {
            throw new UpdateNotExistObjectException();
        }
    }

    @Override
    @Transactional
    public List<T> saveAll(Iterable<T> entities){
        log.debug("@Generic Repository Service saveAll");
        return genericRepository.saveAll(entities);
    }


    /**
     * @see
     */
    @Override
    @Transactional
    public T saveAndFlush ( T o ) {
        log.debug("@Generic Repository Service saveAndFlush object:" + o);
        return genericRepository.saveAndFlush( o );
    }

    /**
     * @see
     */
    @Override
    @Transactional
    public void deleteById ( PK id ) {
        log.debug("@Generic Repository Service deleteById object by id: " + id);
        try {
            genericRepository.deleteById(id);
        } catch (EmptyResultDataAccessException e){
            log.error("注意：通过主键【{}】没有发现需要删除的记录", id);
        }
    }

    /**
     * @see
     */
    @Override
    @Transactional
    public void delete ( T o ) {
        log.debug("@Generic Repository Service delete object: " + o);
        genericRepository.delete( o );
    }

    /**
     * @see
     */
    @Override
    @Transactional
    public void deleteAll ( Iterable<? extends T> iterable ) {
        log.debug("@Generic Repository Service deleteAll Iterable param");
        genericRepository.deleteAll( iterable );
    }

    /**
     * @see
     */
    @Override
    @Transactional
    public void deleteAll ( ) {
        log.debug("@Generic Repository Service deleteAll null param");
        genericRepository.deleteAll();
    }

    /**
     * @see
     */
    @Override
    @Transactional
    public void deleteAllByIds ( Iterable<? extends PK> ids ) {
        log.debug("@Generic Repository Service deleteAllByIds Iterable param");
        Set<T> psSet = Sets.newHashSet();
        for(PK pk: ids){
            psSet.add(genericRepository.findById(pk).orElse(null));
        }
        genericRepository.deleteAll( psSet );
    }


}