package com.simbest.boot.component.distributed.lock;

import com.google.common.collect.Maps;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.util.redis.RedisUtil;
import com.simbest.boot.util.server.HostUtil;
import com.simbest.boot.util.server.SocketUtil;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Map;

/**
 * 分布式集群Master节点管理器
 * 
 * 功能特点：
 * 1. Master节点选举：
 *    - 基于Redis分布式锁实现选举机制
 *    - 确保集群中只有一个Master节点
 *    - 支持自动故障转移
 * 
 * 2. 健康检查：
 *    - 定期检查Master节点状态
 *    - 通过Socket连接验证节点可用性
 *    - 自动处理节点故障情况
 * 
 * 3. 状态管理：
 *    - 维护当前节点和Master节点信息
 *    - 提供节点状态查询接口
 *    - 支持手动设置Master节点
 * 
 * 4. 高可用保证：
 *    - 分布式锁避免脑裂
 *    - 定时任务确保Master节点存在
 *    - 快速响应节点故障
 */
@Slf4j
@Component
@DependsOn(value = {"redisUtil", "hostUtil"})
public class AppRuntimeMaster {

    /**
     * 应用配置对象
     * 用于获取Redis锁相关配置
     */
    @Autowired
    private AppConfig appConfig;

    /**
     * 主机工具类
     * 用于获取当前主机信息
     */
    @Autowired
    private HostUtil hostUtil;

    /**
     * 当前主机地址
     * 在初始化时自动获取本机IP地址
     */
    @Getter
    private String myHost;

    /**
     * 当前主机端口
     * 在初始化时自动获取应用运行端口
     */
    @Getter
    private Integer myPort;

    /**
     * 集群Master节点主机地址
     * 从Redis中获取，所有节点共享此信息
     */
    @Getter
    private String masterHost;

    /**
     * 集群Master节点端口
     * 从Redis中获取，所有节点共享此信息
     */
    @Getter
    private Integer masterPort;

    /**
     * Redis分布式锁等待时间（秒）
     * 尝试获取锁时的最大等待时间
     */
    @Getter
    private int redisLockWaitSeconds;

    /**
     * Redis分布式锁释放时间（秒）
     * 锁的自动释放时间，防止死锁
     */
    @Getter
    private int redisLockReleaseSeconds;

    /**
     * 初始化方法
     * 在Spring容器启动时自动执行
     * 
     * 执行步骤：
     * 1. 检查当前节点是否为Master
     * 2. 初始化Redis锁相关配置
     */
    @PostConstruct
    private void init() {
        checkMasterIsMe();
        redisLockWaitSeconds = appConfig.getRedisLockWaitSeconds();
        redisLockReleaseSeconds = appConfig.getRedisLockReleaseSeconds();
    }

    /**
     * 检查当前节点是否为Master节点
     * 
     * 检查流程：
     * 1. 获取当前节点信息：
     *    - 如果myHost为空，获取本机IP
     *    - 如果myPort为空或0，获取运行端口
     * 2. 从Redis获取Master节点信息
     * 3. 比较当前节点与Master节点信息
     *
     * @return true-当前节点是Master节点，false-当前节点不是Master节点
     */
    public boolean checkMasterIsMe() {
        if(StringUtils.isEmpty(myHost)) {
            myHost = HostUtil.getHostAddress();
        }
        if(myPort == null || ApplicationConstants.ZERO==myPort) {
            myPort = hostUtil.getRunningPort();
        }
        log.debug("当前主机地址【{}】 ", myHost);
        masterHost = RedisUtil.get(ApplicationConstants.MASTER_HOST);
        log.debug("集群主机地址【{}】 ", masterHost);
        log.debug("当前主机端口【{}】", myPort);
        masterPort = RedisUtil.getBean(ApplicationConstants.MASTER_PORT, Integer.class);
        log.debug("集群主机端口【{}】", masterPort);
        boolean isMaster = myHost.equals(masterHost) && myPort.equals(masterPort);
        log.debug("判断当前主机是否是集群主控节点结果为【{}】", isMaster);
        return isMaster;
    }

    /**
     * Master节点检查和选举定时任务
     * 每分钟执行一次
     * 
     * 执行流程：
     * 1. 获取分布式锁（等待1秒，持有5秒）
     * 2. 检查Master节点状态：
     *    - 不存在Master -> 将当前节点设为Master
     *    - Master不可用 -> 将当前节点设为Master
     *    - Master正常 -> 记录状态日志
     * 3. 释放分布式锁
     */
    @Scheduled(cron = "0 0/1 * * * ?")
    public void becameMasertIfNotExist() {
        //获取锁，最多等待1秒，获得锁后5秒后释放
        DistributedRedissonLock lock = DistributedRedisLock.tryLock(ApplicationConstants.MASTER_LOCK, 1, 5);
        if(lock.isLocked()) {
            //提取应用主机端口信息
            masterHost = RedisUtil.get(ApplicationConstants.MASTER_HOST);
            masterPort = RedisUtil.getBean(ApplicationConstants.MASTER_PORT, Integer.class);
            //1.没有Master
            if (StringUtils.isEmpty(masterHost) || null == masterPort || ApplicationConstants.ZERO == masterPort) {
                makeMeAsMaster(myHost, myPort);
                log.debug("集群没有主控节点，当前主机将成为主控节点, 主机地址【{}】运行端口【{}】", myHost, myPort);
            }

            //检查集群主控节点端口是否存活
            boolean masterIsAvailable = SocketUtil.checkHeartConnection(masterHost, Integer.valueOf(masterPort));
            //2.Master不可用
            if (!masterIsAvailable) {
                myPort = hostUtil.getRunningPort();
                makeMeAsMaster(myHost, myPort);
                log.debug("集群主控节点不可用，当前主机将成为主控节点, 主机地址【{}】运行端口【{}】", myHost, myPort);
            } else {
                log.debug("集群主控节点状态良好，主控节点主机地址【{}】运行端口【{}】", masterHost, masterPort);
            }

            try {
                //释放锁
                lock.getRLock().unlock();
            }catch (IllegalMonitorStateException emse){
                log.trace(emse.getMessage());
            }
        }
    }

    /**
     * 将指定节点设置为Master
     * 
     * 操作步骤：
     * 1. 更新本地Master节点信息
     * 2. 将信息写入Redis：
     *    - 设置masterHost
     *    - 设置masterPort
     *
     * @param myHost 要设置为Master的主机地址
     * @param myPort 要设置为Master的主机端口
     */
    public void makeMeAsMaster(String myHost, Integer myPort){
        masterHost = myHost;
        masterPort = myPort;
        RedisUtil.set(ApplicationConstants.MASTER_HOST, myHost);   //设置我为Master
        RedisUtil.setBean(ApplicationConstants.MASTER_PORT, myPort);
    }

    /**
     * 获取当前Master节点信息
     * 
     * 返回信息：
     * - masterHost：Master节点的主机地址
     * - masterPort：Master节点的端口号
     *
     * @return 包含Master节点信息的Map对象
     */
    public Map<String, Object> getCurrentMaster(){
        masterHost = RedisUtil.get(ApplicationConstants.MASTER_HOST);
        masterPort = RedisUtil.getBean(ApplicationConstants.MASTER_PORT, Integer.class);
        Map<String, Object> master = Maps.newHashMap();
        master.put("masterHost", masterHost);
        master.put("masterPort", masterPort);
        return master;
    }

}