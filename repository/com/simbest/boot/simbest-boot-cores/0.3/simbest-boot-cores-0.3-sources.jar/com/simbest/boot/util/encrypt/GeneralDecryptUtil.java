package com.simbest.boot.util.encrypt;

import com.simbest.boot.config.AppConfig;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * 通用解密工具类。
 */
@Slf4j
@Component
public class GeneralDecryptUtil {

    private static final int RSA_BLOCK_LENGTH = 128;

    private final MochaEncryptor mochaEncryptor;
    private final Des3Encryptor des3Encryptor;
    private final RsaEncryptor rsaEncryptor;

    public GeneralDecryptUtil(MochaEncryptor mochaEncryptor, Des3Encryptor des3Encryptor, RsaEncryptor rsaEncryptor) {
        this.mochaEncryptor = mochaEncryptor;
        this.des3Encryptor = des3Encryptor;
        this.rsaEncryptor = rsaEncryptor;
    }

    public String decrypt(String code) {
        if (code == null || code.length() == 0) {
            return null;
        }

        List<EncryptorHolder> holders = resolveDecryptOrder(code);
        for (EncryptorHolder holder : holders) {
            String plaintext = tryDecrypt(holder, code);
            if (plaintext != null && plaintext.length() > 0) {
                return plaintext;
            }
        }
        return null;
    }

    private String tryDecrypt(EncryptorHolder holder, String code) {
        try {
            String plaintext = holder.getEncryptor().decrypt(code);
            if (plaintext == null || plaintext.length() == 0) {
                log.warn("尝试解密内容【{}】使用【{}】失败，解密结果为空", code, holder.getName());
                return null;
            }
            return plaintext;
        } catch (Exception e) {
            log.warn("尝试解密内容【{}】使用【{}】失败", code, holder.getName(), e);
            return null;
        }
    }

    private List<EncryptorHolder> resolveDecryptOrder(String code) {
        List<EncryptorHolder> holders = new ArrayList<EncryptorHolder>(3);
        EncryptorHolder preferred = getPreferredEncryptor(code);
        if (preferred != null) {
            holders.add(preferred);
        }
        addIfAbsent(holders, EncryptorHolder.MOCHA);
        addIfAbsent(holders, EncryptorHolder.DES3);
        addIfAbsent(holders, EncryptorHolder.RSA);
        return bindEncryptors(holders);
    }

    private EncryptorHolder getPreferredEncryptor(String code) {
        if (isHex(code)) {
            return EncryptorHolder.MOCHA;
        }
        byte[] decoded = decodeBase64(code);
        if (decoded == null) {
            return null;
        }
        if (decoded.length == RSA_BLOCK_LENGTH) {
            return EncryptorHolder.RSA;
        }
        return EncryptorHolder.DES3;
    }

    private List<EncryptorHolder> bindEncryptors(List<EncryptorHolder> holders) {
        List<EncryptorHolder> boundHolders = new ArrayList<EncryptorHolder>(holders.size());
        for (EncryptorHolder holder : holders) {
            if (holder == EncryptorHolder.MOCHA) {
                boundHolders.add(new EncryptorHolder(holder.getName(), mochaEncryptor));
            } else if (holder == EncryptorHolder.DES3) {
                boundHolders.add(new EncryptorHolder(holder.getName(), des3Encryptor));
            } else if (holder == EncryptorHolder.RSA) {
                boundHolders.add(new EncryptorHolder(holder.getName(), rsaEncryptor));
            }
        }
        return boundHolders;
    }

    private void addIfAbsent(List<EncryptorHolder> holders, EncryptorHolder holder) {
        if (!holders.contains(holder)) {
            holders.add(holder);
        }
    }

    private boolean isHex(String code) {
        if ((code.length() & 1) != 0) {
            return false;
        }
        for (int i = 0; i < code.length(); i++) {
            char ch = code.charAt(i);
            boolean isNumber = ch >= '0' && ch <= '9';
            boolean isUpperHex = ch >= 'A' && ch <= 'F';
            boolean isLowerHex = ch >= 'a' && ch <= 'f';
            if (!isNumber && !isUpperHex && !isLowerHex) {
                return false;
            }
        }
        return true;
    }

    private byte[] decodeBase64(String code) {
        try {
            return Base64.getDecoder().decode(code.replace(' ', '+'));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    @AllArgsConstructor
    @Getter
    private static class EncryptorHolder {
        private static final EncryptorHolder MOCHA = new EncryptorHolder("MochaEncryptor", null);
        private static final EncryptorHolder DES3 = new EncryptorHolder("Des3Encryptor", null);
        private static final EncryptorHolder RSA = new EncryptorHolder("RsaEncryptor", null);

        private final String name;
        private final AbstractEncryptor encryptor;
    }

    public static void main(String[] args) throws Exception {
        AppConfig appConfig = new AppConfig();
        appConfig.setMochaPortalToken("SIMBEST_SSO");

        MochaEncryptor mochaEncryptor = new MochaEncryptor();
        Field configField = MochaEncryptor.class.getDeclaredField("config");
        configField.setAccessible(true);
        configField.set(mochaEncryptor, appConfig);

        Des3Encryptor des3Encryptor = new Des3Encryptor();

        RsaEncryptor rsaEncryptor = new RsaEncryptor();
        rsaEncryptor.init();

        GeneralDecryptUtil decryptUtil = new GeneralDecryptUtil(mochaEncryptor, des3Encryptor, rsaEncryptor);

        String mochaCode = mochaEncryptor.encrypt("wangao");
        log.info("Mocha密文【{}】，解密明文【{}】", mochaCode, decryptUtil.decrypt(mochaCode));

        String des3Code = des3Encryptor.encrypt("hadmin");
        log.info("3DES密文【{}】，解密明文【{}】", des3Code, decryptUtil.decrypt(des3Code));

        String rsaCode = rsaEncryptor.encrypt("111.com");
        log.info("RSA密文【{}】，解密明文【{}】", rsaCode, decryptUtil.decrypt(rsaCode));
    }
}
