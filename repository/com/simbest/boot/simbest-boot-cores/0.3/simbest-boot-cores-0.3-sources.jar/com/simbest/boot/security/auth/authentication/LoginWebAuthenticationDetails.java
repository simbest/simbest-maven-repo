package com.simbest.boot.security.auth.authentication;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * 登录认证后的认证详情类
 * 
 * 主要功能：
 * 1. 存储认证成功后的详细信息
 * 2. 支持PC端和OAuth2两种认证方式
 * 3. 记录授权申请账号信息
 * 
 * 处理方式：
 * - PC端：由GenericAuthenticationChecker处理，使用WebAuthenticationDetails
 * - OAuth2：由UumsTokenGranter处理，使用LinkedHashMap
 * 
 * 扩展性：
 * - 当前主要记录授权申请账号
 * - 预留扩展空间，可根据需求添加更多认证信息
 */
@Data
@Builder
public class LoginWebAuthenticationDetails implements Serializable {

    /**
     * 授权申请用户名的常量键名
     * 用于在认证详情中标识授权申请账号
     */
    public static final String APPLY_USERNAME = "applyUsername";

    /**
     * 认证详情对象
     * 
     * 两种类型：
     * 1. PC端登录：WebAuthenticationDetails类型，由GenericAuthenticationChecker封装
     * 2. OAuth2登录：java.util.LinkedHashMap类型，由UumsTokenGranter的getOAuth2Authentication方法封装
     */
    private Object details;

    /**
     * 授权申请账号
     * 
     * 用途：
     * 1. 记录发起认证请求的账号
     * 2. 用于审计和追踪认证流程
     * 3. 支持授权链跟踪
     * 
     * 说明：
     * - 当前仅包含此属性
     * - 可根据业务需求扩展更多属性
     */
    private String applyUsername;

}