package com.simbest.boot.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Maps;
import com.simbest.boot.base.enums.StoreLocation;
import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.component.distributed.lock.DistributedLockFactoryBean;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.sys.model.SysDictValue;
import com.simbest.boot.util.AppFileSftpUtil;
import com.simbest.boot.util.encrypt.Des3Encryptor;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.redis.RedisUtil;
import com.simbest.boot.uums.api.ApiRequestHandle;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import redis.clients.jedis.JedisPoolConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.env.MapPropertySource;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.cache.RedisCacheWriter;
import org.springframework.data.redis.connection.*;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.session.data.redis.RedisIndexedSessionRepository;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.time.Duration;
import java.util.*;

import static com.simbest.boot.constants.ApplicationConstants.*;
import static com.simbest.boot.sys.model.SysDictValue.SYS_CONFIG;

/**
 * Redis和RedissonClient配置类
 * 主要功能：
 * 1. 配置Redis连接工厂，支持单机和集群模式
 * 2. 支持多种Redis配置来源：配置文件、FTP/SFTP文件、数据库字典值
 * 3. 配置Redis缓存管理器，支持自定义序列化和错误处理
 * 4. 配置RedissonClient，用于分布式锁等高级功能
 * 5. 提供连接池配置，优化性能和资源利用
 *
 * 配置来源说明：
 * - propertiesRedis：从配置文件读取Redis配置
 * - ftpRedis：从FTP服务器读取Redis配置
 * - sftpRedis：从SFTP服务器读取Redis配置
 * - dictValueRedis：从数据库字典值读取Redis配置
 *
 * 注意：使用 Jedis 替代 Lettuce，在 Spring Boot 自动配置之前执行
 */
@Slf4j
@Configuration
@EnableCaching
@EnableRedisHttpSession
@AutoConfigureBefore(RedisAutoConfiguration.class)
public class RedisConfiguration extends CachingConfigurerSupport {

    /**
     * Redis配置来源类型枚举
     */
    public enum RedisConfigType {
        propertiesRedis,  ftpRedis, sftpRedis, dictValueRedis
    }

    @Autowired
    private AppConfig config;

    @Autowired
    private RedisKeyGenerator redisKeyGenerator;

    @Autowired
    private RedisIndexedSessionRepository sessionRepository;

    private Des3Encryptor encryptor = new Des3Encryptor();

    private ApiRequestHandle<SysDictValue> sysDictValueApiHandle = new ApiRequestHandle();

    private ApiRequestHandle<List<SysDictValue>> sysDictValueApiListHandle = new ApiRequestHandle();

    @Getter
    private RedissonClient redissonClient;

    @Getter
    private String redisClusterNodes;

    /**
     * 初始化配置，设置会话超时和命名空间
     */
    @PostConstruct
    private void afterPropertiesSet() {
        sessionRepository.setDefaultMaxInactiveInterval(config.getSessionTimeout());
        sessionRepository.setRedisKeyNamespace(config.getRedisNamespace());
    }

    /**
     * 配置Redis集群配置
     * 设置集群节点和最大重定向次数
     */
    @Bean
    public RedisClusterConfiguration redisClusterConfiguration(){
        Map<String, Object> source = Maps.newHashMap();
        source.put("spring.redis.cluster.nodes", redisClusterNodes);
        source.put("spring.redis.cluster.max-redirects", config.getRedisMaxRedirects());
        return new RedisClusterConfiguration(new MapPropertySource("RedisClusterConfiguration", source));
    }

    /**
     * 配置Jedis连接池
     * 设置连接池参数，包括最大连接数、空闲连接等
     * 注意：Jedis不支持Lettuce的集群自适应刷新功能，
     * 如果集群节点发生变更，可能需要重启应用或实现自定义的刷新机制
     */
    private JedisPoolConfig getJedisPoolConfig() {
        JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
        jedisPoolConfig.setMaxTotal(config.getRedisPoolMaxTotal()); //最大连接数
        jedisPoolConfig.setMaxIdle(config.getRedisPoolMaxIdle()); //最大空闲连接数
        jedisPoolConfig.setMinIdle(config.getRedisPoolMinIdle());  //最小空闲连接数
        jedisPoolConfig.setMaxWaitMillis(10000); //连接池最大等待时间(毫秒)
        jedisPoolConfig.setTestOnBorrow(true); //获取连接时检测可用性
        jedisPoolConfig.setTestOnReturn(false);
        jedisPoolConfig.setTestWhileIdle(true); //空闲时检测连接可用性
        return jedisPoolConfig;
    }

    /**
     * 配置Jedis客户端
     * 设置使用连接池
     * 注意：Jedis的超时配置在连接时通过其他方式设置，这里主要配置连接池
     */
    private JedisClientConfiguration getJedisClientConfiguration() {
        JedisClientConfiguration.JedisPoolingClientConfigurationBuilder builder =
                (JedisClientConfiguration.JedisPoolingClientConfigurationBuilder) JedisClientConfiguration.builder();
        builder.poolConfig(getJedisPoolConfig());
        return builder.build();
    }

    /**
     * 配置Redis连接工厂
     * 支持单机模式和集群模式
     * 根据配置类型从不同来源加载Redis节点信息
     */
    @Bean
    public RedisConnectionFactory redisConnectionFactory() {
        JedisConnectionFactory factory = null;
        try {
            RedisConfigType redisConfigTypeEnum = Enum.valueOf(RedisConfigType.class, config.getRedisConfigType());
            Assert.notNull(redisConfigTypeEnum, "Redis配置类型不能为空");
            log.info("缓存配置信息"+redisConfigTypeEnum.name());
            if(RedisConfigType.propertiesRedis.equals(redisConfigTypeEnum)){
                log.info("基于配置文件读取Redis配置");
                redisClusterNodes = config.getRedisClusterNodes();
            }
            else if(RedisConfigType.dictValueRedis.equals(redisConfigTypeEnum)){
                log.info("基于数据库读取Redis配置");
                log.debug("即将通过UUMS主数据【{}】读取Redis配置项【{}】的Redis节点信息", config.getUumsAddress(), config.getRedisConfigTypeRedis());
                SysDictValue sysDictValue = SysDictValue.builder().dictType(SYS_CONFIG).name(config.getRedisConfigTypeRedis()).build();
                String loginuser = StringUtils.replace(encryptor.encrypt(ADMINISTRATOR), "+", "%2B");

                String uumsUrl = config.getUumsAddress() + "/sys/dictValue/sso/findAllNoPage?loginuser="+loginuser+"&appcode="+UUMS_APPCODE;
                HttpUriRequest request = RequestBuilder.post().setUri(uumsUrl)
                        .setEntity(new StringEntity(JacksonUtils.obj2json(sysDictValue), ContentType.APPLICATION_JSON)).build();
                CloseableHttpClient httpClient = HttpClients.createDefault();
                CloseableHttpResponse response = httpClient.execute(request);
                String resp = EntityUtils.toString(response.getEntity(), UTF_8);
                JsonResponse jsonResponse = JacksonUtils.json2obj(resp, JsonResponse.class);
//                JsonResponse jsonResponse = HttpClient.textBody(uumsUrl)
//                        .json(JacksonUtils.obj2json(sysDictValue))
//                        .asBean(JsonResponse.class);

                List<SysDictValue> sysDictValueList = sysDictValueApiListHandle.handRemoteTypeReferenceResponse(jsonResponse, new TypeReference<List<SysDictValue>>(){});
                Assert.notEmpty(sysDictValueList, String.format("通过字典类型%s和字典值名称%s，无法读取REDIS配置",SYS_CONFIG, config.getRedisConfigTypeRedis()));
                SysDictValue redisDv = sysDictValueList.get(ZERO);
                Assert.notNull(redisDv, "REDIS节点配置不能为空！");
                redisClusterNodes = redisDv.getValue();
            }
            else {
                log.info("基于FTP文件读取Redis配置");
                AppFileSftpUtil appFileSftpUtil = new AppFileSftpUtil();
                appFileSftpUtil.setUsername(config.getRedisFtpUsername());
                appFileSftpUtil.setPassword(config.getRedisFtpPassword());
                appFileSftpUtil.setHost(config.getRedisFtpHost());
                appFileSftpUtil.setPort(config.getRedisFtpPort());
                appFileSftpUtil.setKeyFilePath(config.getRedisFtpKeyFile());
                appFileSftpUtil.setPassphrase(config.getRedisFtpPassphrase());
                if(RedisConfigType.ftpRedis.equals(redisConfigTypeEnum)){
                    appFileSftpUtil.setServerUploadLocation(StoreLocation.ftp);
                }
                if(RedisConfigType.sftpRedis.equals(redisConfigTypeEnum)){
                    appFileSftpUtil.setServerUploadLocation(StoreLocation.sftp);
                }
                redisClusterNodes = new String(appFileSftpUtil.download2Byte(config.getRedisFtpNodeConfigDirectory(),
                        config.getRedisFtpNodeConfigFile()));
            }
            redisClusterNodes = StringUtils.trimAllWhitespace(redisClusterNodes);
            Assert.notNull(redisClusterNodes, "REDIS节点配置不能为空！");
            log.info("*************************Redis加载配置节点START******************************");
            log.info("Redis节点为【{}】", redisClusterNodes);
            log.info("*************************Redis加载配置节点END********************************");
            if (redisClusterNodes.split(ApplicationConstants.COMMA).length == 1) {
                RedisStandaloneConfiguration standaloneConfig = new RedisStandaloneConfiguration();
                standaloneConfig.setHostName(redisClusterNodes.split(ApplicationConstants.COLON)[ZERO]);
                standaloneConfig.setPort(Integer.valueOf(redisClusterNodes.split(ApplicationConstants.COLON)[ONE]));
                standaloneConfig.setPassword(RedisPassword.of(config.getRedisPassword()));
                standaloneConfig.setDatabase(0);
                factory = new JedisConnectionFactory(standaloneConfig, getJedisClientConfiguration());
                factory.afterPropertiesSet(); // 必须调用此方法初始化连接池
            } else {
                // 集群模式配置
                // 注意：Jedis不支持Lettuce的集群自适应刷新功能
                // 如果集群节点发生变更，可能需要重启应用或实现自定义的刷新机制
                Set<RedisNode> redisNodes = new HashSet<>();
                Arrays.asList(redisClusterNodes.split(ApplicationConstants.COMMA)).stream().forEach(address -> {
                    String redisHost = address.split(":")[0].trim();
                    int redisPort = Integer.valueOf(address.split(":")[1]);
                    redisNodes.add(new RedisNode(redisHost, redisPort));
                });
                RedisClusterConfiguration clusterConfig = new RedisClusterConfiguration();
                clusterConfig.setClusterNodes(redisNodes);
                clusterConfig.setPassword(RedisPassword.of(config.getRedisPassword()));
                clusterConfig.setMaxRedirects(Integer.parseInt(config.getRedisMaxRedirects()));
                factory = new JedisConnectionFactory(clusterConfig, getJedisClientConfiguration());
                factory.afterPropertiesSet(); // 必须调用此方法初始化连接池
            }
        }
        catch (Exception e){
            log.error("加载Redis配置发生错误，请检查配置文件");
            Exceptions.printException(e);
        }
        return factory;
    }

    /**
     * 配置Spring Session Redis消息监听器的线程池
     * 解决从Lettuce切换到Jedis后，SimpleAsyncTaskExecutor无限制创建线程的问题
     * 避免出现 springSessionRedisMessageListenerContainer-N 线程数暴涨导致系统崩溃
     */
    @Bean
    public ThreadPoolTaskExecutor springSessionRedisTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);           // 核心线程数
        executor.setMaxPoolSize(8);            // 最大线程数
        executor.setQueueCapacity(100);        // 队列容量
        executor.setThreadNamePrefix("session-redis-");
        executor.setRejectedExecutionHandler(new java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }

    /**
     * 覆盖默认的RedisMessageListenerContainer配置
     * 使用有界线程池替代SimpleAsyncTaskExecutor，防止线程无限创建
     */
    @Bean
    public RedisMessageListenerContainer springSessionRedisMessageListenerContainer(
            RedisConnectionFactory connectionFactory,
            ThreadPoolTaskExecutor springSessionRedisTaskExecutor) {
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setTaskExecutor(springSessionRedisTaskExecutor);
        container.setSubscriptionExecutor(springSessionRedisTaskExecutor);
        return container;
    }

    /**
     * 配置缓存管理器
     * 设置序列化方式和缓存过期时间
     */
    @Bean
    @Override
    public CacheManager cacheManager() {
        // 初始化一个RedisCacheWriter
        RedisCacheWriter cacheWriter = RedisCacheWriter.nonLockingRedisCacheWriter(redisConnectionFactory());
        // 设置默认过期时间：60 分钟
        RedisCacheConfiguration defaultCacheConfig = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofSeconds(config.getSessionTimeout()))
                //.prefixKeysWith("cache:key:uums:") //无法区分不同对象相同id时的key
                // .disableCachingNullValues()
                // 使用注解时的序列化、反序列化
                .serializeKeysWith(RedisSerializationContext
                        .SerializationPair.fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(RedisSerializationContext
                        .SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()));
        Map<String, RedisCacheConfiguration> initialCacheConfigurations = new HashMap<>();
        return new RedisCacheManager(cacheWriter, defaultCacheConfig, initialCacheConfigurations);
    }

    /**
     * 配置RedisTemplate
     * 设置键值序列化器，支持String和JSON格式
     */
    @Bean
    @Qualifier("redisTemplate")
    public <T> RedisTemplate<String, T> redisTemplate() {
        /**
         * 解决分离项目报空指针问题
         * 参考：https://www.jianshu.com/p/32d38a7fd20a
         */
        ClassLoader classLoader = this.getClass().getClassLoader();
        RedisTemplate<String, T> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory());
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new JdkSerializationRedisSerializer(classLoader));
        template.setHashKeySerializer(new JdkSerializationRedisSerializer(classLoader));
        template.setHashValueSerializer(new JdkSerializationRedisSerializer(classLoader));
        template.setDefaultSerializer(new JdkSerializationRedisSerializer(classLoader));
        template.afterPropertiesSet();
        return template;
    }

    /**
     * 配置缓存键生成器
     */
    @Bean
    @Override
    public KeyGenerator keyGenerator() {
        return redisKeyGenerator;
    }

    /**
     * 配置缓存错误处理器
     * 处理缓存操作中的异常，包括连接失败等情况
     */
    @Bean
    @Override
    public CacheErrorHandler errorHandler() {
        CacheErrorHandler cacheErrorHandler = new CacheErrorHandler() {
            /**
             * 从缓存读取数据报错时，不作处理，由数据库提供服务
             * @param e
             * @param cache
             * @param key
             */
            @Override
            public void handleCacheGetError(RuntimeException e, Cache cache, Object key) {
                if(e instanceof RedisConnectionFailureException){
                    log.warn("redis 丢失连接 connection:",e);
                    return;
                }
                throw e;
            }

            /**
             * 向缓存写入数据报错时，不作处理，由数据库提供服务
             * @param e
             * @param cache
             * @param key
             * @param value
             */
            @Override
            public void handleCachePutError(RuntimeException e, Cache cache, Object key, Object value) {
                if(e instanceof RedisConnectionFailureException){
                    log.warn("redis 丢失连接 connection:",e);
                    return;
                }
                throw e;
            }

            /**
             * 删除缓存报错时，抛出异常
             * @param e
             * @param cache
             * @param key
             */
            @Override
            public void handleCacheEvictError(RuntimeException e, Cache cache, Object key) {
                log.error("handleCacheEvictError缓存时异常---key：-"+key+"异常信息:"+e);
                throw e;
            }

            /**
             * 清理缓存报错时，抛出异常
             * @param e
             * @param cache
             */
            @Override
            public void handleCacheClearError(RuntimeException e, Cache cache) {
                log.error("清除缓存时异常---：-"+"异常信息:"+e);
                throw e;
            }
        };
        return cacheErrorHandler;
    }

    /**
     * 配置RedissonClient
     * 用于分布式锁等高级功能
     */
    @Bean(destroyMethod = "shutdown")
    public RedissonClient redissonClient() {
        Config redissonConfig = new Config();
        if (redisClusterNodes.split(ApplicationConstants.COMMA).length == 1) {
            redissonConfig.useSingleServer().setAddress("redis://"+redisClusterNodes)
            .setPassword(config.getRedisPassword());
        } else {
            String[] nodes = redisClusterNodes.split(ApplicationConstants.COMMA);
            for(int i=0; i<nodes.length; i++){
                nodes[i] = "redis://"+ nodes[i];
            }
            redissonConfig.useClusterServers()
                    .setScanInterval(2000) // cluster state scan interval in milliseconds
                    .setPassword(config.getRedisPassword())
                    .addNodeAddress(nodes);
//                    .addNodeAddress("redis://10.92.80.70:26379", "redis://10.92.80.70:26389", "redis://10.92.80.70:26399")
//                    .addNodeAddress("redis://10.92.80.71:26379", "redis://10.92.80.71:26389", "redis://10.92.80.71:26399");
        }
        redissonClient = Redisson.create(redissonConfig);
        log.debug("Congratulations------------------------------------------------Redis 进程实例已创建成功");
        return redissonClient;
    }

    /**
     * 配置分布式锁工厂
     * 依赖于RedissonClient
     */
    @Bean
    @DependsOn("redissonClient")
    public DistributedLockFactoryBean distributeLockTemplate(){
        DistributedLockFactoryBean d = new DistributedLockFactoryBean();
        d.setMode("SINGLE");
        return d;
    }

    /**
     * 销毁时关闭RedissonClient
     */
    @PreDestroy
    public void destroy() {
        if(null != redissonClient) {
            log.debug("清理分布式事务锁START................................");
            RedisUtil.cleanRedisLock();
            log.debug("清理分布式事务锁END................................");
//            redissonClient.shutdown(); //RedisConfiguration.redissonClient()申明创建出来的RedissonClient的shutdown执行真正的销毁redissonClient
            log.debug("Congratulations------------------------------------------------Redis 进程实例已销毁成功");
        }
    }
}