package com.simbest.boot.sys.repository;

import com.simbest.boot.base.repository.GenericRepository;
import com.simbest.boot.sys.model.SysLogLogin;
import org.springframework.stereotype.Repository;

/**
 * 用途：登录日志
 *
 *
 */
@Repository
public interface SysLogLoginRepository extends GenericRepository<SysLogLogin, String> {

}