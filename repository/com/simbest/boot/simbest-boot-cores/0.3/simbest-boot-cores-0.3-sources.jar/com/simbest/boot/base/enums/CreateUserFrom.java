package com.simbest.boot.base.enums;

import lombok.Getter;
import lombok.Setter;

/**
 * 用户创建来源枚举
 * 用于标识用户是从哪个渠道创建的
 * 实现了GenericEnum接口，提供统一的枚举值获取方法
 */
public enum CreateUserFrom implements GenericEnum {

    /**
     * 应用内创建的用户
     */
    inner("应用内"),
    
    /**
     * 应用外创建的用户
     */
    outter("应用外"),
    
    /**
     * 通过微信小程序创建的用户
     */
    wxma("微信小程序"),
    
    /**
     * 通过微信公众号创建的用户
     */
    wxmp("微信公众号");

    /**
     * 枚举值的中文描述
     */
    @Setter @Getter
    private String value;

    /**
     * 构造函数
     * @param value 枚举值的中文描述
     */
    CreateUserFrom(String value) {
        this.value = value;
    }
}