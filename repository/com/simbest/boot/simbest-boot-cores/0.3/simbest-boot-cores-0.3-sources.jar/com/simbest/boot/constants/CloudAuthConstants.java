package com.simbest.boot.constants;

/**
 * 云平台认证相关常量定义类
 * 
 * 包含以下类别的常量：
 * 1. JWT（JSON Web Token）相关常量：
 *    - 标准声明字段：sub（主题）、aud（受众）等
 *    - 认证头部信息：Authorization及其前缀
 * 
 * 2. OAuth 2.1相关常量：
 *    - JWT缓存前缀
 *    - 令牌主题和ID
 *    - 令牌过期检查和获取API地址
 * 
 * 注意事项：
 * 1. 所有常量均为public static final，不可修改
 * 2. API地址中的%s为占位符，使用时需要替换为实际值
 * 3. Bearer认证方案遵循RFC 6750规范
 */
public class CloudAuthConstants {
    // JWT标准声明字段
    public static final String SUB = "sub";                  // JWT主题（Subject）
    public static final String AUD = "aud";                  // JWT受众（Audience）
    
    // HTTP认证头部
    public static final String AUTHORIZATION = "Authorization";           // 认证请求头
    public static final String AUTHORIZATION_PREFIX = "Bearer ";         // Bearer认证方案前缀

    // OAuth 2.1 JWT相关
    public static final String OAUTH21_JWT = "oauth21:jwt:";            // JWT缓存键前缀
    public static final String OAUTH21_SUBJECT = "subject";             // JWT主题标识
    public static final String OAUTH21_JWTID = "jwtId";                // JWT唯一标识

    // OAuth 2.1 API地址
    // 应用到auth统一认证中心中检查JWT过期时间
//    public static final String OAUTH21_CHECK_JWT_EXPIRE_DATETIME = "http://gateway/gateway/%s/jwt/getJwtExpiryDate";
    public static final String OAUTH21_CHECK_JWT_EXPIRE_DATETIME = "/%s/jwt/anonymous/getJwtExpiryDate";
    // 应用到auth统一认证中心中获取应用令牌过期时间
//    public static final String OAUTH21_GET_JWT_TOKEN_EXPIRE_SECOND = "http://gateway/gateway/auth/client/anonymous/findClientTokenExpireSecond/%s";
    public static final String OAUTH21_GET_JWT_TOKEN_EXPIRE_SECOND = "/auth/client/anonymous/findClientTokenExpireSecond/%s";
}