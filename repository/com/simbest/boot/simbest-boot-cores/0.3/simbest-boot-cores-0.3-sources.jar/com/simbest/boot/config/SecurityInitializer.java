package com.simbest.boot.config;

import com.simbest.boot.security.auth.config.ApiSecurityConfigurer;
import com.simbest.boot.security.auth.config.FormSecurityConfigurer;
import com.simbest.boot.security.auth.config.MonitorSecurityConfigurer;
import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * Spring Security和Session初始化配置类
 * 主要功能：
 * 1. 初始化Spring Security过滤器链
 * 2. 集成Spring Session和Redis会话管理
 * 3. 配置多种安全认证方式：
 *    - 监控安全配置（MonitorSecurityConfigurer）
 *    - API接口安全配置（ApiSecurityConfigurer）
 *    - 表单登录安全配置（FormSecurityConfigurer）
 * 
 * 实现说明：
 * 1. 继承AbstractSecurityWebApplicationInitializer，自动注册Spring Security的过滤器链
 * 2. 通过构造函数注册多个安全配置类，实现不同场景的安全控制
 * 3. 集成RedisConfiguration，支持分布式会话管理
 * 
 * 安全配置组合：
 * - 监控安全：用于系统监控和管理
 * - API安全：用于REST API的认证和授权
 * - 表单安全：用于传统的表单登录认证
 */
public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer {

    /**
     * 初始化安全配置
     * 注册多个安全配置类和Redis配置
     */
    public SecurityInitializer() {
        super(MonitorSecurityConfigurer.class, ApiSecurityConfigurer.class,
                FormSecurityConfigurer.class, RedisConfiguration.class);
    }
}