package com.simbest.boot.sys.web;

import cn.hutool.http.HttpUtil;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.util.json.JacksonUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static com.simbest.boot.constants.ApplicationConstants.MSG_SUCCESS;

/**
 * 用途：组件版本控制器
 *
 *
 */
@Api(tags = { "3-系统管理", "系统版本管理" }, description = "提供系统各组件版本管理功能，支持查看所有组件当前版本信息，包括cores、cmcc、bps、flowable等组件")
@Slf4j
@RestController
@RequestMapping("/version")
public class SysCoresVersionController {

    @Autowired
    private AppConfig appConfig;

    /**
     * GET请求获取各组件当前最新更新情况，目前包括cores、cmcc、bps、flowable，请求格式如下：
     * http://nginxIp:nginxPort/appcode/version/anonymous?url=http://nginxIp:nginxPort
     * 如：
     * http://10.88.178.111:8088/jgjp/version/anonymous?url=http://10.228.113.111:8088
     *
     * @param url
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    @ApiOperation(value = "查看所有组件当前版本", notes = "查看所有组件当前版本")
    @GetMapping(value = "/anonymous")
    public JsonResponse all(String url) throws ExecutionException, InterruptedException {
        String coresVersionUrl = url + "/" + appConfig.getContextPath() + "/version/anonymous/cores";
        String cmccVersionUrl = url + "/" + appConfig.getContextPath() + "/version/anonymous/cmcc";
        String flowableVersionUrl = url + "/" + appConfig.getContextPath() + "/version/anonymous/flowableDriver";
        String bpsVersionUrl = url + "/" + appConfig.getContextPath() + "/version/anonymous/bpsDriver";
        String mqVersionUrl = url + "/" + appConfig.getContextPath() + "/version/anonymous/mqDriver";
        String mqProcessVersionUrl = url + "/" + appConfig.getContextPath() + "/version/anonymous/processMqDriver";
        String historyVersionUrl = url + "/" + appConfig.getContextPath() + "/version/anonymous/historyDriver";

        String coresResult = getAsyncVersion(coresVersionUrl).get();
        String cmccResult = getAsyncVersion(cmccVersionUrl).get();
        String flowableResult = getAsyncVersion(flowableVersionUrl).get();
        String bpsResult = getAsyncVersion(bpsVersionUrl).get();
        String mqResult = getAsyncVersion(mqVersionUrl).get();
        String mqProcessResult = getAsyncVersion(mqProcessVersionUrl).get();
        String historyResult = getAsyncVersion(historyVersionUrl).get();

        Map<String, String> resultMap = new HashMap<String, String>() {
            {
                put("cores", coresResult);
                put("cmcc", cmccResult);
                put("flowable", flowableResult);
                put("bps", bpsResult);
                put("mq", mqResult);
                put("mqProcess", mqProcessResult);
                put("history", historyResult);
            }
        };
        return JsonResponse.success(resultMap, MSG_SUCCESS);
    }

    /**
     * GET请求获取Cores最新更新情况 http://url/appcode/version/anonymous/cores
     *
     * @return
     */
    @ApiOperation(value = "查看CORES组件当前版本", notes = "查看CORES组件当前版本")
    @GetMapping(value = "/anonymous/cores")
    public JsonResponse version() {
        return JsonResponse.success(
                //String.format("【%s】-【%s】", "2026-09-24", "本次升级内容：IndexController 的 getCurrentUse，UumsSysUserinfoApi 的 findByUsername 两个查询用户敏感信息进行脱敏"),
                String.format("【%s】-【%s】", "2026-09-12", "本次升级内容：app.sso.force.time=true时强制ts/tk新单点校验；false时仅当ts和tk均真实有效才启用，否则回退老单点"),
                //String.format("【%s】-【%s】", "2026-09-04", "本次升级内容：默认不允许访问sign，但是支持配置app.signin开关放开"),
                //String.format("【%s】-【%s】", "2026-08-18", "本次升级内容：MessageEnum消息模板增加提醒后中文逗号v0.1"),
                //String.format("【%s】-【%s】", "2026-07-08", "本次升级内容：深化PostgreSQL兼容性，修复字典接口列名大小写、探活SQL按库选择、排序CASE失效等问题，三库通吃MySQL/Oracle/PostgreSQLv0.1"),
                //String.format("【%s】-【%s】", "2026-07-07", "本次升级内容：修复PostgreSQL兼容性，支持MySQL/Oracle/PostgreSQL三库通吃v0.1"),
                //String.format("【%s】-【%s】", "2026-06-30", "本次升级内容：验证码默认为false，不启用v0.1"),
//                String.format("【%s】-【%s】", "2026-06-22", "本次升级内容：新增GeneralDecryptUtil实现通用解密v0.1"),
                //String.format("【%s】-【%s】", "2026-04-08", "本次升级内容：增强HttpClient/PostRequest的表单提交流程，在保持客户端.param(\"file\", file)调用不变的情况下支持File类型参数上传，并与普通表单字段一起按multipart/form-data发送"),
                //String.format("【%s】-【%s】", "2025-12-05", "本次升级内容：新增app.task.switch配置信息，用于启用或关闭定时任务执行"),
                //String.format("【%s】-【%s】", "2025-07-23", "本次升级内容：将cores中CsrfProtectFilter，@WebFilter注解将asyncSupported = false 调整为true！"),
                MSG_SUCCESS);
    }

    public CompletableFuture<String> getAsyncVersion(String url) {
        return CompletableFuture.supplyAsync(() -> {
            String result = HttpUtil.createGet(url).execute().body();
            JsonResponse jsonResponse = JacksonUtils.json2obj(result, JsonResponse.class);
            if (null != jsonResponse) {
                return jsonResponse.getData().toString();
            } else {
                return "";
            }
        });
    }

}
