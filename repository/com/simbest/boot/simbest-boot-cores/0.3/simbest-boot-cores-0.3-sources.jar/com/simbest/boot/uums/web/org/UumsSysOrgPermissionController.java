package com.simbest.boot.uums.web.org;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.uums.api.org.UumsSysOrgPermissionApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 系统组织权限管理控制器
 * 提供组织权限相关的REST API接口：
 * - 管理组织与权限的关联关系
 * - 支持批量更新组织的权限配置
 * - 提供权限分配和回收的功能
 */
@SuppressWarnings("All")
@Api(tags = {"2-统一用户管理", "组织权限管理"}, description = "提供组织权限相关的管理功能，包括组织与权限的关联关系管理、批量更新组织的权限配置、权限分配和回收等功能")
@RestController
@RequestMapping(value = {"/uums/sys/org/permission", "/sys/uums/org/permission"})
public class UumsSysOrgPermissionController {

    @Autowired
    private UumsSysOrgPermissionApi uumsSysOrgPermissionApi;

    @Autowired
    private AppConfig appConfig;

    @ApiOperation(value = "修改组织权限信息，先删除角色所有权限，再重新添加", notes = "修改组织权限信息，先删除角色所有权限，再重新添加",tags={"组织权限API"})
    @PostMapping(value = {"/updateListByPermissionId","/updateListByPermissionId/sso","/api/updateListByPermissionId"})
    public JsonResponse updateListByPermissionId(@RequestParam String permissionId, @RequestBody List<String> orgCodes){
        return uumsSysOrgPermissionApi.updateListByPermissionId(permissionId, orgCodes);
    }
}