package com.simbest.boot.base.service;

import com.simbest.boot.base.model.SystemModel;

import java.io.Serializable;

/**
 * 系统实体通用服务层接口
 * 
 * 功能说明：
 * 1. 提供系统级实体的标准化服务操作接口
 * 2. 支持对SystemModel及其子类的通用CRUD操作
 * 3. 实现创建时间和修改时间的自动维护
 * 4. 作为业务实体服务接口的基础接口规范
 * 
 * 主要职责：
 * 1. 继承IGenericService，获取通用实体的基础服务功能
 * 2. 定义系统实体的标准化操作规范
 * 3. 提供实体创建和修改时间的自动处理机制
 * 4. 支持业务实体的扩展需求
 * 5. 确保系统实体操作的一致性和规范性
 *
 * @param <T> 系统实体类型，必须继承自SystemModel
 * @param <PK> 实体主键类型，必须实现Serializable接口
 */
public interface ISystemService <T extends SystemModel,PK extends Serializable> extends IGenericService<T,PK>{

}