package com.simbest.boot.uums.web.group;

import cn.hutool.core.collection.CollectionUtil;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.security.SimpleGroup;
import com.simbest.boot.sys.model.SysDictValue;
import com.simbest.boot.uums.api.group.UumsSysGroupApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 群组管理控制器
 * 提供群组相关的REST API接口：
 * - 群组基础信息管理
 * - 群组成员管理
 * - 群组权限配置
 * - 群组关系管理
 * - 支持分页和条件查询
 */
@SuppressWarnings("ALL")
@Api(tags = {"2-统一用户管理", "群组管理"}, description = "提供群组相关的管理功能，包括群组信息的CRUD操作、群组权限的管理、用户群组关系的维护、群组类型的管理等")
@RestController
@RequestMapping(value = {"/uums/sys/group", "/sys/uums/group"})
public class UumsSysGroupController {

    @Autowired
    private UumsSysGroupApi uumsSysGroupApi;

    /**
     * 分页查询群组信息
     * 支持条件筛选和排序：
     * - 可指定页码和每页大小
     * - 支持排序方向和排序字段的设置
     * - 可按应用编码过滤
     * - 支持自定义查询条件
     *
     * @param page 页码
     * @param size 每页大小
     * @param direction 排序方向
     * @param properties 排序字段
     * @param appcode 应用编码
     * @param sysGroupMap 查询条件
     * @return 分页查询结果
     */
    @PostMapping(value = {"/findAll", "/findAll/sso","/api/findAll"})
    public JsonResponse findAll(@RequestParam(required = false, defaultValue = "1") int page,
                                            @RequestParam(required = false, defaultValue = "10") int size,
                                            @RequestParam(required = false) String direction,
                                            @RequestParam(required = false) String properties,
                                            @RequestParam(required = false) String appcode,
                                            @RequestBody Map sysGroupMap) {
        JsonResponse js = uumsSysGroupApi.findAll(page,size,direction,properties,appcode,sysGroupMap);
        return js;
    }

    /**
     * 简单分页查询群组信息
     * 仅支持基础分页功能：
     * - 可指定页码和每页大小
     * - 支持自定义查询条件
     *
     * @param page 页码
     * @param size 每页大小
     * @param sysGroupMap 查询条件
     * @return 分页查询结果
     */
    @PostMapping(value = {"/getAll", "/getAll/sso","/api/getAll"})
    public JsonResponse getAll(@RequestParam(required = false, defaultValue = "1") int page,
                                @RequestParam(required = false, defaultValue = "10") int size,
                                @RequestBody Map sysGroupMap) {
        JsonResponse js = uumsSysGroupApi.getAll(page,size,sysGroupMap);
        return js;
    }

    /**
     * 查询用户的数据权限
     * 获取指定用户在特定应用下的数据权限：
     * - 支持按应用编码查询
     * - 返回用户拥有的所有数据权限类型
     *
     * @param appcode 应用编码
     * @return 数据权限信息
     */
    @ApiOperation (value = "查看某个用户拥有哪种数据权限", notes = "查看某个用户拥有哪种数据权限")
    @ApiImplicitParams( {
            @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    } )
    @PostMapping ("/findDataPermission")
    public JsonResponse findDataPermission( @RequestParam(required = false)  String appcode) {
        return JsonResponse.success(uumsSysGroupApi.findDataPermission( appcode ));
    }

    /**
     * 创建新群组
     * 支持在指定应用下创建群组：
     * - 需要提供应用编码
     * - 包含群组的基本信息
     * - 返回创建成功的群组信息
     *
     * @param appcode 应用编码
     * @param simpleGroup 群组信息对象
     * @return 创建的群组信息
     */
    @ApiOperation(value = "新增群组",notes = "新增群组" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "appcode",value = "appcode",dataType = "String",paramType = "query" ),
            @ApiImplicitParam(name = "simpleGroup",value = "群组对象",dataType = "SimpleGroup",paramType = "body" )
    })
    @PostMapping(value={"/addGroup", "/addGroup/sso","/api/addGroup"})
    public JsonResponse addGroup(@RequestParam String appcode, @RequestBody SimpleGroup simpleGroup) {
        SimpleGroup addSimpleGroup = uumsSysGroupApi.addGroup(appcode,simpleGroup);
        return JsonResponse.success(addSimpleGroup);
    }

    /**
     * 删除群组
     * 支持删除指定应用下的群组：
     * - 需要提供应用编码
     * - 根据群组信息进行删除
     * - 返回删除操作的结果
     *
     * @param appcode 应用编码
     * @param simpleGroup 群组信息对象
     * @return 删除操作结果
     */
    @ApiOperation(value = "删除群组",notes = "删除群组" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "appcode",value = "appcode",dataType = "String",paramType = "query" ),
            @ApiImplicitParam(name = "simpleGroup",value = "群组对象",dataType = "SimpleGroup",paramType = "body" )
    })
    @PostMapping(value="/delGroup")
    public JsonResponse delGroup(@RequestParam String appcode, @RequestBody SimpleGroup simpleGroup) {
        boolean flag = uumsSysGroupApi.delGroup(appcode,simpleGroup);
        return JsonResponse.success(flag);
    }

    /**
     * 更新群组信息
     * 支持更新指定应用下的群组：
     * - 需要提供应用编码
     * - 根据群组信息进行更新
     * - 返回更新后的群组信息
     *
     * @param appcode 应用编码
     * @param simpleGroup 群组信息对象
     * @return 更新后的群组信息
     */
    @ApiOperation(value = "修改群组",notes = "修改群组" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "appcode",value = "appcode",dataType = "String",paramType = "query" ),
            @ApiImplicitParam(name = "simpleGroup",value = "群组对象",dataType = "SimpleGroup",paramType = "body" )
    })
    @PostMapping(value="/updateGroup")
    public JsonResponse updateGroup(@RequestParam String appcode, @RequestBody SimpleGroup simpleGroup) {
        SimpleGroup updateGroup = uumsSysGroupApi.updateGroup(appcode,simpleGroup);
        return JsonResponse.success(updateGroup);
    }

    /**
     * 获取所有群组类型
     * 查询系统支持的所有群组类型：
     * - 返回群组类型的完整列表
     * - 用于群组分类和管理
     *
     * @return 群组类型列表
     */
    @ApiOperation(value = "获取所有群组类型", notes = "获取所有群组类型",tags={"群组API"})
    @PostMapping(value = {"/findGroupsType","/findGroupsType/sso","/api/findGroupsType"})
    public JsonResponse findGroupsType() {
        return uumsSysGroupApi.findGroupsType();
    }

    /**
     * 根据ID删除群组
     * 通过群组ID删除特定群组：
     * - 需要提供群组ID和会话ID
     * - 支持精确删除指定群组
     *
     * @param id 群组ID
     * @param sid 会话ID
     * @return 删除操作结果
     */
    @ApiOperation(value = "根据ID删除群组", notes = "根据ID删除群组",tags={"群组API"})
    @PostMapping(value = {"/deleteById","/deleteById/sso","/api/deleteById"})
    public JsonResponse deleteById(@RequestParam String id,@RequestParam String sid) {
        return uumsSysGroupApi.deleteById(id,sid);
    }
}