package com.simbest.boot.config;

import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.simbest.boot.util.json.JacksonCustomDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * 用途：Jackson JSON序列化配置类
 * 主要提供以下功能：
 * 1. 自定义日期时间格式化
 * 2. 自定义序列化和反序列化规则
 * 3. 配置Jackson特性和行为
 * 4. 注册自定义模块
 */
@Configuration
public class JacksonConfiguration {

    /** 默认日期时间格式：yyyy-MM-dd HH:mm:ss */
    public static final String DEFAULT_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    
    /** 默认日期格式：yyyy-MM-dd */
    public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
    
    /** 默认时间格式：HH:mm:ss */
    public static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";

    /**
     * 配置ObjectMapper
     * 用于全局的JSON序列化和反序列化配置
     * @return ObjectMapper 配置完成的ObjectMapper实例
     */
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        // 创建并配置自定义模块
        SimpleModule simbestModule = new SimpleModule("Simbest JSON Module");
        simbestModule.addDeserializer(String.class, new JacksonCustomDeserializer());

        // 配置Java 8日期时间类型的序列化和反序列化
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(DateTimeFormatter.ofPattern(DEFAULT_DATE_TIME_FORMAT)));
        javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer(DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT)));
        javaTimeModule.addSerializer(LocalTime.class, new LocalTimeSerializer(DateTimeFormatter.ofPattern(DEFAULT_TIME_FORMAT)));
        javaTimeModule.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ofPattern(DEFAULT_DATE_TIME_FORMAT)));
        javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT)));
        javaTimeModule.addDeserializer(LocalTime.class, new LocalTimeDeserializer(DateTimeFormatter.ofPattern(DEFAULT_TIME_FORMAT)));

        // 创建数值类型处理模块
        SimpleModule simpleModule = new SimpleModule();

        // 创建并配置ObjectMapper
        ObjectMapper mapper = new ObjectMapper()
            .registerModule(new ParameterNamesModule())
            .registerModule(new Jdk8Module())
            .registerModule(simpleModule)
            .registerModule(javaTimeModule)
            .registerModule(simbestModule);

        // 配置JSON解析特性
        mapper.configure(JsonReadFeature.ALLOW_UNESCAPED_CONTROL_CHARS.mappedFeature(), false); // 不允许出现特殊字符和转义符
        mapper.configure(MapperFeature.AUTO_DETECT_FIELDS, true); // 自动检测字段

        // 配置反序列化特性
        mapper.configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, false); // 原始类型允许空值
        mapper.configure(DeserializationFeature.READ_ENUMS_USING_TO_STRING, true); // 枚举类型使用toString方法
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); // 允许未知属性
        mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false); // 允许忽略的属性
        mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true); // 空字符串转为null
        mapper.configure(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS, true); // 时间戳使用纳秒
        mapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true); // 未知枚举值转为null
        mapper.configure(DeserializationFeature.READ_ENUMS_USING_TO_STRING, true); // 枚举类型使用toString方法

        // 配置序列化特性
        mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false); // 允许空对象
        mapper.configure(SerializationFeature.WRITE_ENUMS_USING_TO_STRING, true); // 枚举类型使用toString方法
        mapper.configure(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS, true); // 时间戳使用纳秒
        mapper.configure(SerializationFeature.FLUSH_AFTER_WRITE_VALUE, true); // 写入后刷新
        mapper.configure(SerializationFeature.INDENT_OUTPUT, false); // 不进行格式化输出

        return mapper;
    }
}