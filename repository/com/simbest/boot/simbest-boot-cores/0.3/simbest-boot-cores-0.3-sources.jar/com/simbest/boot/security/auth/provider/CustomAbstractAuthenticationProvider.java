package com.simbest.boot.security.auth.provider;

import org.springframework.security.authentication.AuthenticationProvider;

/**
 * 用途：自定义抽象认证Provider，用于认证扩展
 *
 *
 */
public interface CustomAbstractAuthenticationProvider extends AuthenticationProvider {
}