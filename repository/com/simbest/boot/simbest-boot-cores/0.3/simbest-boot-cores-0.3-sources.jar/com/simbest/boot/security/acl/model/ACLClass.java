package com.simbest.boot.security.acl.model;

import com.simbest.boot.base.annotations.EntityIdPrefix;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * ACL类型实体
 * 
 * 主要功能：
 * 1. 存储需要进行访问控制的对象类型信息
 * 2. 通过全限定类名区分不同的对象类型
 * 3. 为ACL系统提供对象类型的唯一标识
 * 
 * 数据结构：
 * 1. id: 唯一标识符，使用雪花算法生成
 * 2. clazz: 对象的全限定类名，用于标识不同类型的对象
 * 
 * 使用场景：
 * 1. ACL权限控制系统中识别不同类型的受保护对象
 * 2. 作为ACL对象身份和权限条目的关联实体
 */
@Entity
@Table(name = "acl_class")
@Data
public class ACLClass implements Serializable {

    /**
     * 主键ID
     * 使用雪花算法生成，前缀为AC
     */
    @Id
    @Column(name = "id", length = 40)
//    @SequenceGenerator(name = "ACL_CLASS_SEQ", sequenceName = "ACL_CLASS_SEQ")
//    @GeneratedValue(strategy = GenerationType.AUTO, generator = "ACL_CLASS_SEQ")
    @GeneratedValue(generator = "snowFlakeId")
    @GenericGenerator(name = "snowFlakeId", strategy = "com.simbest.boot.util.distribution.id.SnowflakeId")
    @EntityIdPrefix(prefix = "AC") //主键前缀，此为可选项注解
    private String id;

    /**
     * 类的全限定名
     * 用于唯一标识一个需要进行访问控制的对象类型
     */
    @Column(name = "class", nullable = false, unique = true)
    private String clazz;
}