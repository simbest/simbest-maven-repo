package com.simbest.boot.security.auth.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.web.util.matcher.RequestMatcher;

/**
 * 用途：REST方式基于UUMS主数据的单点登录拦截器
 *
 *
 */
@Slf4j
public class RestUumsAuthenticationFilter extends UumsAuthenticationFilter {

    public RestUumsAuthenticationFilter(RequestMatcher requiresAuthenticationRequestMatcher) {
        super(requiresAuthenticationRequestMatcher);
    }


}