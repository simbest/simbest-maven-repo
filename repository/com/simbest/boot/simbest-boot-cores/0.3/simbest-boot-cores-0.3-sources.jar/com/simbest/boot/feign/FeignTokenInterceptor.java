package com.simbest.boot.feign;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Feign请求令牌拦截器
 * 
 * 主要用途：
 * 1. 在微服务间调用时自动传递认证令牌
 * 2. 确保服务调用的安全性和用户身份的连续性
 * 
 * 工作原理：
 * 1. 从当前请求上下文中获取认证令牌
 * 2. 将令牌添加到Feign请求的请求头中
 * 3. 实现服务间的无缝认证传递
 * 
 * 注意事项：
 * 1. 需要确保原始请求中包含有效的认证令牌
 * 2. 适用于需要认证的微服务调用场景
 * 3. 支持标准的Bearer Token认证方式
 */
@Component
public class FeignTokenInterceptor implements RequestInterceptor {
    
    /**
     * 拦截并处理Feign请求
     * 
     * @param template Feign请求模板，用于修改请求信息
     */
    @Override
    public void apply(RequestTemplate template) {
        //从请求头获取Token
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attributes != null) {
            String token = attributes.getRequest().getHeader(HttpHeaders.AUTHORIZATION);
            if (token != null) {
                // 将Token添加到Feign请求的头部
                template.header(HttpHeaders.AUTHORIZATION, token);
            }
        }
    }
}