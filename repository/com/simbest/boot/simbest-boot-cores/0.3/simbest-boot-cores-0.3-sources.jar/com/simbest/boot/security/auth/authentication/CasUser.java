package com.simbest.boot.security.auth.authentication;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/**
 * CAS用户信息传输对象
 * 主要用途：
 * 1. 用于向CAS服务器传递用户验证数据
 * 2. 实现CAS协议所需的Principal接口要求
 * 3. 支持自定义用户属性的扩展
 *
 * 数据结构说明：
 * - username: 用户唯一标识，在JSON序列化时映射为"id"
 * - clazz: 指定CAS Principal实现类，默认使用SimplePrincipal
 * - attributes: 用户扩展属性，支持存储任意键值对信息
 */
@Data
public class CasUser {

    /**
     * 用户名，作为用户的唯一标识
     * 在与CAS服务器通信时，会被序列化为"id"字段
     */
    @JsonProperty("id")
    private String username;

    /**
     * CAS Principal实现类的全限定类名
     * 默认使用org.apereo.cas.authentication.principal.SimplePrincipal
     * 该字段在JSON中使用"@class"作为键名，用于CAS服务器进行类型识别和实例化
     */
    @JsonProperty("@class")
    private String clazz = "org.apereo.cas.authentication.principal.SimplePrincipal";

    /**
     * 用户扩展属性Map
     * 用于存储用户的额外信息，如：
     * - 用户角色
     * - 权限信息
     * - 组织机构
     * - 其他自定义属性
     */
    @JsonProperty("attributes")
    private Map<String, Object> attributes = new HashMap<>();

}