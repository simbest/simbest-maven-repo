package com.simbest.boot.security.auth.authentication;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

/**
 * 手机验证码认证凭据
 * 
 * 主要功能：
 * 1. 封装手机验证码登录所需的认证信息
 * 2. 支持应用级别的验证码认证
 * 3. 实现序列化接口，支持分布式环境
 * 
 * 认证流程：
 * 1. 用户输入手机号码和验证码
 * 2. 系统验证应用代码的合法性
 * 3. 校验短信验证码的正确性
 * 
 * 安全特性：
 * - 支持多应用隔离
 * - 验证码具有时效性
 * - 可扩展的认证属性
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PhoneCodeAuthenticationCredentials implements Serializable {

    /**
     * 应用代码
     * 用于：
     * 1. 标识请求来源的应用系统
     * 2. 支持多应用验证码认证
     * 3. 实现应用级别的安全隔离
     */
    private String appcode;

    /**
     * 短信验证码
     * 用于：
     * 1. 验证用户身份的动态口令
     * 2. 通常为4-6位数字
     * 3. 具有时效性和一次性使用特征
     */
    private String smscode;

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}