package com.simbest.boot.base.enums;

import lombok.Getter;
import lombok.Setter;

/**
 * 系统自定义字段类型枚举
 * 用于定义系统中自定义字段的数据类型
 * 实现了GenericEnum接口和Comparable接口，提供统一的枚举值获取方法和比较功能
 */
public enum SysCustomFieldType implements GenericEnum, Comparable<SysCustomFieldType> {

    /**
     * 文本类型
     */
    TEXT("文本"),
    
    /**
     * 长文本类型
     */
    TEXTAREA("长文本"),
    
    /**
     * 数字类型
     */
    INTEGER("数字"),
    
    /**
     * 金额类型
     */
    PRICE("金额"),
    
    /**
     * 日期类型
     */
    DATE("日期"),
    
    /**
     * 时间类型
     */
    TIME("时间"),
    
    /**
     * 时间戳类型
     */
    TIMESTAMP("时间戳"),
    
    /**
     * 数据字典类型
     */
    ZDICT("数据字典");

    /**
     * 枚举值的中文描述
     */
    @Setter @Getter
    private String value;

    /**
     * 构造函数
     * @param value 枚举值的中文描述
     */
    SysCustomFieldType(String value) {
        this.value = value;
    }
}