package com.simbest.boot.base.service;

import com.simbest.boot.base.model.Oauth2ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;

/**
 * OAuth2客户端信息服务接口
 * 
 * 功能说明：
 * 1. 提供OAuth2客户端信息的基础管理服务
 * 2. 实现OAuth2客户端的认证和授权功能
 * 3. 支持客户端信息的CRUD操作
 * 4. 提供客户端详情的查询服务
 * 
 * 主要职责：
 * 1. 继承IGenericService，获取通用实体的基础服务功能
 * 2. 继承Spring Security OAuth2的ClientDetailsService接口，提供标准的客户端认证功能
 * 3. 管理OAuth2客户端的基本信息，如clientId、secret、scope、authorities等
 * 4. 支持OAuth2授权模式的配置和管理
 * 5. 提供客户端安全认证相关的服务支持
 */
public interface IOauth2ClientDetailsService extends IGenericService<Oauth2ClientDetails, String>, ClientDetailsService {

}