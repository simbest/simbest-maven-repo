package com.simbest.boot.component.distributed.lock;

import java.util.concurrent.TimeUnit;

/**
 * 分布式锁模板接口
 * 
 * 功能特点：
 * 1. 锁操作模板：
 *    - 提供统一的分布式锁操作接口
 *    - 支持回调式的业务逻辑执行
 *    - 自动处理锁的获取和释放
 * 
 * 2. 超时控制：
 *    - 支持默认超时时间
 *    - 支持自定义超时时间
 *    - 超时后自动释放锁
 * 
 * 3. 使用方式：
 *    - 通过回调接口定义业务逻辑
 *    - 支持泛型返回值
 *    - 异常时自动释放锁
 * 
 * 4. 实现要求：
 *    - 确保锁操作的原子性
 *    - 处理网络和服务异常
 *    - 支持可重入性
 */
public interface DistributedLockTemplate {

    /**
     * 使用默认超时时间的分布式锁
     * 
     * 执行流程：
     * 1. 获取分布式锁
     * 2. 执行回调中的业务逻辑
     * 3. 自动释放锁
     * 
     * 注意事项：
     * - 如果获取锁失败，将抛出异常
     * - 如果业务逻辑执行出错，确保锁被释放
     * - 使用默认的超时时间配置
     *
     * @param callback 业务逻辑回调接口
     * @param <T> 业务执行结果的类型
     * @return 业务执行的结果
     * @throws RuntimeException 获取锁失败或业务执行异常
     */
    <T> T lock(DistributedLockCallback<T> callback);

    /**
     * 使用自定义超时时间的分布式锁
     * 
     * 执行流程：
     * 1. 使用指定的超时时间获取锁
     * 2. 执行回调中的业务逻辑
     * 3. 超时或完成后自动释放锁
     * 
     * 参数说明：
     * - leaseTime为0时，需要手动释放锁
     * - leaseTime大于0时，超时后自动释放
     * - timeUnit指定时间单位（秒、毫秒等）
     * 
     * 使用建议：
     * - 根据业务复杂度设置合适的超时时间
     * - 避免设置过长的超时时间
     * - 考虑网络延迟的影响
     *
     * @param callback 业务逻辑回调接口
     * @param leaseTime 锁的超时时间，0表示永不超时
     * @param timeUnit 时间单位
     * @param <T> 业务执行结果的类型
     * @return 业务执行的结果
     * @throws RuntimeException 获取锁失败或业务执行异常
     */
    <T> T lock(DistributedLockCallback<T> callback, long leaseTime, TimeUnit timeUnit);
}