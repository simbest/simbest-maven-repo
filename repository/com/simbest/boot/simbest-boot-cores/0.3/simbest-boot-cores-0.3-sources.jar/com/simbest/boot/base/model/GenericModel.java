package com.simbest.boot.base.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.simbest.boot.constants.ApplicationConstants;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 通用实体模型基类
 * 所有实体类的基础父类，提供通用功能：
 * - 提供实体序列化支持
 * - 提供动态排序功能
 * - 提供日期范围查询支持
 * - 提供分页查询支持
 * - 重写基础Object方法实现更好的对象比较和字符串表示
 */
@Setter
@Getter
@MappedSuperclass
public abstract class GenericModel implements Serializable, Comparable<Object>{

    /**
     * 动态排序字段，用于传递排序条件，不持久化存储
     */
    @Transient
    private String orderByClause;

    /**
     * 日期范围查询起始时间，不持久化存储
     */
    @Transient
    @JsonFormat(pattern = ApplicationConstants.FORMAT_DATE_TIME, timezone = ApplicationConstants.FORMAT_TIME_ZONE)
    private Date ssDate;

    /**
     * 日期范围查询结束时间，不持久化存储
     */
    @Transient
    @JsonFormat(pattern = ApplicationConstants.FORMAT_DATE_TIME, timezone = ApplicationConstants.FORMAT_TIME_ZONE)
    private Date eeDate;

    /**
     * 分页查询的页码（从第几页开始），不持久化存储
     */
    @Transient
    @ApiModelProperty(value = "当前页码（从1开始）")
    private Integer pageIndex;

    /**
     * 分页查询的每页记录数，不持久化存储
     */
    @ApiModelProperty(value = "分页查询的页容量")
    @Transient
    private Integer pagesize;

    /**
     * 重写toString方法，使用Apache Commons Lang的ToStringBuilder基于反射实现
     * 提供更详细的对象字符串表示
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    /**
     * 重写equals方法，使用Apache Commons Lang的EqualsBuilder基于反射实现
     * 提供更准确的对象相等性比较
     * 
     * @param obj 需要比较的对象
     * @return 两个对象是否相等
     */
    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj);
    }

    /**
     * 重写hashCode方法，使用Apache Commons Lang的HashCodeBuilder基于反射实现
     * 提供更稳定的哈希码生成
     * 
     * @return 对象的哈希码
     */
    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    /**
     * 实现Comparable接口的compareTo方法，使用Apache Commons Lang的CompareToBuilder基于反射实现
     * 用于对象排序
     * 
     * @param obj 需要比较的对象
     * @return 比较结果，小于0表示小于，等于0表示相等，大于0表示大于
     */
    @Override
    public int compareTo(Object obj) {
        return CompareToBuilder.reflectionCompare(this, obj);
    }
}
