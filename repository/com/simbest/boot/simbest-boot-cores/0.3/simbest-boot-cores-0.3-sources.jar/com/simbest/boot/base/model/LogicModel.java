package com.simbest.boot.base.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.simbest.boot.constants.ApplicationConstants;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 逻辑实体模型
 * 支持逻辑删除和数据可用性控制的实体模型：
 * - 提供数据的逻辑删除功能（软删除），而非物理删除
 * - 记录数据的创建者和修改者信息，用于审计跟踪
 * - 提供数据可用性控制，可以禁用而非删除数据
 * - 继承自SystemModel，拥有创建时间和修改时间的记录
 */
@EqualsAndHashCode(callSuper = true)
@MappedSuperclass
public abstract class LogicModel extends SystemModel {

    /**
     * 数据是否可用标志
     * true: 可用状态
     * false: 不可用状态
     * 通过该字段可以控制数据的可见性，而不需要物理删除
     */
    @Setter
    @Getter
    @Column(nullable = false)
    private Boolean enabled;

    /**
     * 数据逻辑删除时间
     * 用于记录数据被标记为删除状态的时间点
     * 可以用于数据恢复和历史记录追踪
     */
    @Setter
    @Getter
    @JsonFormat(pattern = ApplicationConstants.FORMAT_DATE_TIME, timezone = ApplicationConstants.FORMAT_TIME_ZONE)    
    private LocalDateTime removedTime;

    /**
     * 数据创建者
     * 记录创建该条数据的用户标识
     * 用于数据审计和责任追踪
     */
    @Setter
    @Getter
    @Column(nullable = false)
    private String creator;

    /**
     * 数据最后修改者
     * 记录最后一次修改该条数据的用户标识
     * 用于数据审计和修改记录追踪
     */
    @Setter
    @Getter
    @Column(nullable = false)
    private String modifier;
}