package com.simbest.boot.sys.service;

import com.simbest.boot.sys.model.SysHealth;

/**
 * 用途：系统健康检查服务层
 *
 *
 */
public interface ISysHealthService {

    SysHealth databaseCheck();

    SysHealth redisCheck();

    SysHealth fileSystemCheck();

}