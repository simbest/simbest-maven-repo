package com.simbest.boot.base.service.impl;

import com.google.common.collect.Lists;
import com.simbest.boot.base.model.LogicModel;
import com.simbest.boot.base.repository.LogicRepository;
import com.simbest.boot.base.service.ILogicService;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.exceptions.InsertExistObjectException;
import com.simbest.boot.exceptions.UpdateNotExistObjectException;
import com.simbest.boot.util.CustomBeanUtil;
import com.simbest.boot.util.DateUtil;
import com.simbest.boot.util.ObjectUtil;
import com.simbest.boot.util.security.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * 业务实体逻辑服务层实现类
 * 
 * 主要功能：
 * 1. 继承SystemService，支持系统实体的基础功能
 * 2. 实现实体的逻辑删除（软删除）功能
 * 3. 提供实体的可用性控制
 * 4. 自动维护创建者和修改者信息
 * 5. 所有查询方法仅返回未被逻辑删除的数据（enabled=true）
 * 6. 支持定时逻辑删除功能
 * 7. 提供批量操作支持
 */
@Slf4j
public class LogicService<T extends LogicModel,PK extends Serializable> extends SystemService<T,PK> implements ILogicService<T,PK> {

    /**
     * 逻辑实体仓库接口，提供逻辑删除的数据访问能力
     */
    private LogicRepository<T,PK> logicRepository;

    /**
     * 带仓库参数的构造函数
     * 
     * @param logicRepository 逻辑实体仓库接口
     */
    public LogicService ( LogicRepository<T, PK> logicRepository) {
        super(logicRepository);
        this.logicRepository = logicRepository;
    }

    /**
     * 统计可用实体总数（未逻辑删除的）
     * 
     * @return 可用实体总数
     */
    @Override
    public long count ( ) {
        long count = logicRepository.countActive();
        log.debug("LogicService count 调用结果为【{}】", count);
        return count;
    }

    /**
     * 根据条件统计可用实体数量（未逻辑删除的）
     * 
     * @param specification 查询条件
     * @return 符合条件的可用实体数量
     */
    @Override
    public long count ( Specification<T> specification ) {
        long count = logicRepository.countActive(specification);
        log.debug("LogicService count 调用结果为【{}】", count);
        return count;
    }

    /**
     * 检查指定ID的实体是否存在且可用（未逻辑删除）
     * 
     * @param id 实体ID
     * @return 是否存在且可用
     */
    @Override
    public boolean exists ( PK id ) {
        boolean exist = logicRepository.existsActive( id );
        log.debug("LogicService exists 参数为【{}】，调用结果为【{}】", id, exist);
        return exist;
    }

    /**
     * 根据ID查找可用的实体（未逻辑删除）
     * 
     * @param id 实体ID
     * @return 可用的实体对象
     */
    @Override
    public T findOne ( PK id ){
        T obj = logicRepository.findOneActive(id);
        log.debug("LogicService findOne 参数为【{}】，调用结果为【{}】", id, obj);
        return obj;
    }

    /**
     * 根据ID查找可用的实体（未逻辑删除）
     * 
     * @param id 实体ID
     * @return 可用的实体对象
     */
    @Override
    public T findById ( PK id ){
        T obj = logicRepository.findOneActive(id);
        log.debug("LogicService findById 参数为【{}】，调用结果为【{}】", id, obj);
        return obj;
    }

    /**
     * 根据条件查找单个可用的实体（未逻辑删除）
     * 
     * @param conditions 查询条件
     * @return 可用的实体对象，如果不存在则返回null
     */
    @Override
    public T findOne(Specification<T> conditions){
        T obj = logicRepository.findOneActive(conditions);
        log.debug("LogicService findOne 参数为【{}】，调用结果为【{}】", conditions, obj);
        return obj;
    }

    /**
     * 查询所有可用的实体并分页（未逻辑删除）
     * 
     * @return 分页后的可用实体列表
     */
    @Override
    public Page<T> findAll ( ) {
        Page<T> page = logicRepository.findAllActive();
        log.debug("LogicService findAll 调用结果返回记录数为【{}】", page.getTotalElements());
        return page;
    }

    /**
     * 根据分页参数查询所有可用的实体（未逻辑删除）
     * 
     * @param pageable 分页参数
     * @return 分页后的可用实体列表
     */
    @Override
    public Page<T>  findAll ( Pageable pageable ) {
        Page<T> page = logicRepository.findAllActive( pageable );
        log.debug("LogicService findAll 调用页码【{}】和页容量【{}】, 调用结果返回记录数为【{}】", pageable.getPageNumber(), pageable.getPageSize(), page.getTotalElements());
        return page;
    }

    @Override
    public Page<T>  findAll ( Sort sort ) {
        Page<T> page = logicRepository.findAllActive(PageRequest.of(ApplicationConstants.DEFAULT_PAGE, ApplicationConstants.DEFAULT_SIZE, sort));
        log.debug("LogicService findAll 调用结果返回记录数为【{}】", page.getTotalElements());
        return page;
    }

    @Override
    public List<T> findAllNoPage(){
        List<T> list = logicRepository.findAllActiveNoPage();
        log.debug("LogicService findAllNoPage 调用结果返回记录数为【{}】", list.size());
        return list;
    }

    @Override
    public List<T> findAllNoPage(Sort sort){
        List<T> list = logicRepository.findAllActiveNoPage(sort);
        log.debug("LogicService findAllNoPage 调用结果返回记录数为【{}】", list.size());
        return list;
    }

    @Override
    public List<T> findAllByIDs(Iterable<PK> ids) {
        List<T> list = logicRepository.findAllActive(ids);
        log.debug("LogicService findAllNoPage 调用结果返回记录数为【{}】", list.size());
        return list;
    }

    @Override
    public Page<T> findAll (Specification<T> conditions, Pageable pageable ) {
        Page<T> page = logicRepository.findAllActive(conditions, pageable);
        log.debug("LogicService findAll 调用结果返回记录数为【{}】", page.getTotalElements());
        return page;
    }

    @Override
    public List<T> findAllNoPage(Specification<T> conditions){
        List<T> list = logicRepository.findAllActive(conditions);
        log.debug("LogicService findAllNoPage 调用结果返回记录数为【{}】", list.size());
        return list;
    }

    @Override
    public List<T> findAllNoPage(Specification<T> conditions, Sort sort){
        List<T> list = logicRepository.findAllActive(conditions, sort);
        log.debug("LogicService findAllNoPage 调用结果返回记录数为【{}】", list.size());
        return list;
    }

    /**
     * 更新实体的可用状态
     * 
     * @param id 实体ID
     * @param enabled 是否可用
     * @return 更新后的实体
     */
    @Override
    @Transactional
    public T updateEnable (PK id, boolean enabled) {
        T obj =  super.findById( id );
        if (obj == null) {
            log.warn("根据主键ID【{}】无法检索到对象，无法更新，请确认！", id);
            return null;
        }
        obj.setEnabled( enabled );
        obj = update(obj);
        log.debug("主键为【{}】的【{}】对象可用性已调整为【{}】", id, obj.getClass(), enabled);
        return obj;
    }

    /**
     * 新增实体，自动填充创建者信息
     * 
     * @param source 待保存的实体对象
     * @return 保存后的实体对象（包含生成的ID）
     * @throws InsertExistObjectException 如果尝试插入已存在ID的对象
     */
    @Override
    @Transactional
    public T insert ( T source) {
        if(null == ObjectUtil.getEntityIdVaue(source)) {
            wrapCreateInfo(source);
            T target = logicRepository.save(source);
            CustomBeanUtil.copyTransientProperties(source,target);
            log.debug("对象【{}】保存成功", target);
            return target;
        } else {
            throw new InsertExistObjectException();
        }
    }

    /**
     * 更新实体，自动填充修改者信息，仅更新非null字段
     * 
     * @param source 待更新的实体对象
     * @return 更新后的实体对象
     * @throws UpdateNotExistObjectException 如果尝试更新不存在的对象
     */
    @Override
    @Transactional
    public T update ( T source) {
        PK pk = (PK)ObjectUtil.getEntityIdVaue(source);
        if(null != pk) {
            T target = findById(pk);
            CustomBeanUtil.copyPropertiesIgnoreNull(source, target);
            wrapUpdateInfo( target );
            T newTarget = logicRepository.save(target);
            CustomBeanUtil.copyTransientProperties(target,newTarget);
            log.debug("对象【{}】修改成功", newTarget);
            return newTarget;
        } else {
            throw new UpdateNotExistObjectException();
        }
    }

    /**
     * 更新实体，自动填充修改者信息，允许将字段值更新为null
     * 
     * @param source 待更新的实体对象
     * @return 更新后的实体对象
     * @throws UpdateNotExistObjectException 如果尝试更新不存在的对象
     */
    @Override
    @Transactional
    public T updateWithNull ( T source) {
        PK pk = (PK)ObjectUtil.getEntityIdVaue(source);
        if(null != pk) {
            T target = findById(pk);
            String[] ignoreProperties = {"enabled","creator","modifier","createdTime","modifiedTime"};
            BeanUtils.copyProperties(source,target,ignoreProperties);
            wrapUpdateInfo( target );
            T newTarget = logicRepository.save(target);
            CustomBeanUtil.copyTransientProperties(target,newTarget);
            log.debug("对象【{}】修改成功", newTarget);
            return newTarget;
        } else {
            throw new UpdateNotExistObjectException();
        }
    }

    @Override
    @Transactional
    public List<T> saveAll(Iterable<T> entities) {
        List<T> list = Lists.newArrayList();
        for(T o : entities){
            o = insert(o);
            list.add(o);
        }
        log.debug("成功保存【{}】条记录", list.size());
        return list;
    }

    /**
     * 逻辑删除实体，不进行物理删除
     * 
     * @param id 实体ID
     */
    @Override
    @Transactional
    public void deleteById ( PK id ) {
        T o = findById(id);
        wrapUpdateInfo(o);
        logicRepository.logicDelete( id );
        log.debug("已成功删除主键为【{}】的记录", id);
    }

    /**
     * 逻辑删除实体，不进行物理删除
     * 
     * @param o 要删除的实体对象
     */
    @Override
    @Transactional
    public void delete ( T o ) {
        wrapUpdateInfo( o );
        logicRepository.logicDelete( o );
        log.debug("已成功删除对象【{}】", o);
    }

    @Override
    @Transactional
    public void deleteAll ( Iterable<? extends T> iterable ) {
        iterable.forEach( o -> {
            delete(o);
            log.debug("已成功删除对象【{}】", o);
        });
    }

    @Override
    @Transactional
    public void deleteAll ( ) {
        Iterable<? extends T> iterable = findAllNoPage();
        deleteAll(iterable);
        iterable.forEach( o -> log.debug("已成功删除对象【{}】", o));
    }

    @Override
    @Transactional
    public void deleteAllByIds ( Iterable<? extends PK> pks ) {
        pks.forEach( pk -> {
            deleteById(pk);
            log.debug("已成功删除对象主键为【{}】的记录", pk);
        });
    }

    /**
     * 计划在指定时间进行逻辑删除
     * 
     * @param id 实体ID
     * @param localDateTime 计划删除时间
     */
    @Override
    @Transactional
    public void scheduleLogicDelete(PK id, LocalDateTime localDateTime) {
        this.logicRepository.scheduleLogicDelete(id, localDateTime);
        log.debug("将在【{}】删除主键ID为【{}】的记录", LocalDateTime.now(), id);
    }

    /**
     * 计划在指定时间进行逻辑删除
     * 
     * @param entity 要删除的实体对象
     * @param localDateTime 计划删除时间
     */
    @Override
    @Transactional
    public void scheduleLogicDelete(T entity, LocalDateTime localDateTime) {
        this.logicRepository.scheduleLogicDelete(entity, localDateTime);
        log.debug("将在【{}】删除对象【{}】", LocalDateTime.now(), entity);
    }

    /**
     * 为新创建的实体封装创建者信息
     * 
     * @param o 新创建的实体对象
     */
    protected void wrapCreateInfo(T o) {
        String creator = o.getCreator();
        if (StringUtils.isEmpty(creator)) {
            creator = SecurityUtils.getCurrentUserName();
        }
        o.setCreator(creator);
        o.setEnabled(true);
        o.setCreatedTime(DateUtil.date2LocalDateTime(new Date()));
        this.wrapUpdateInfo(o);
    }

    /**
     * 为更新的实体封装修改者信息
     * 
     * @param o 更新的实体对象
     */
    protected void wrapUpdateInfo(T o) {
        String modifier = SecurityUtils.getCurrentUserName();
        //String modifier = o.getModifier();
        if (StringUtils.isEmpty(modifier)) {
            modifier = o.getModifier();
            if (StringUtils.isEmpty(modifier)) {
                modifier = o.getCreator();
            }
        }
        o.setModifier(modifier);
    }

}