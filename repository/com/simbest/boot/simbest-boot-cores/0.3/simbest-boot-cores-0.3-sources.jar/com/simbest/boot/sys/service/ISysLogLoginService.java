package com.simbest.boot.sys.service;

import com.simbest.boot.base.service.IGenericService;
import com.simbest.boot.sys.model.SysLogLogin;

import java.util.List;
import java.util.Map;

/**
 * 用途：登录日志管理逻辑层
 *
 *
 */
public interface ISysLogLoginService extends IGenericService<SysLogLogin, String> {

    List<Map<String, Object>> countLogin(Map<String, ?> paramMap);


}