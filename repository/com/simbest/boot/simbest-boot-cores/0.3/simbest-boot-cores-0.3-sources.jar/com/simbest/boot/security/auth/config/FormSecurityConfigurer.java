package com.simbest.boot.security.auth.config;

import static com.simbest.boot.constants.ApplicationConstants.ERROR_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.LOGIN_ERROR_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.LOGIN_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.LOGOUT_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.REST_LOGIN_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.REST_LOGOUT_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.REST_UUMS_LOGIN_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.REST_UUMS_LOGOUT_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.ROOT_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.SIGNIN_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.UUMS_LOGIN_PAGE;
import static com.simbest.boot.constants.ApplicationConstants.WELCOME_PAGE;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.context.SecurityContextPersistenceFilter;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.security.SpringSessionBackedSessionRegistry;
import org.springframework.web.bind.annotation.RequestMethod;

import com.simbest.boot.config.Swagger2CsrfProtection;
import com.simbest.boot.security.IAuthService;
import com.simbest.boot.security.auth.entryPoint.IAccessDeniedEntryPoint;
import com.simbest.boot.security.auth.filter.CaptchaAuthenticationFilter;
import com.simbest.boot.security.auth.filter.CloudHeaderTokenAuthenticationFilter;
import com.simbest.boot.security.auth.filter.CustomAbstractAuthenticationProcessingFilter;
import com.simbest.boot.security.auth.filter.RestCaptchaAuthenticationFilter;
import com.simbest.boot.security.auth.filter.RestRsaAuthenticationFilter;
import com.simbest.boot.security.auth.filter.RestUumsAuthenticationFilter;
import com.simbest.boot.security.auth.filter.RsaAuthenticationFilter;
import com.simbest.boot.security.auth.filter.SsoAuthenticationFilter;
import com.simbest.boot.security.auth.filter.SsoAuthenticationRegister;
import com.simbest.boot.security.auth.filter.UumsAuthenticationFilter;
import com.simbest.boot.security.auth.handle.DefaultLogoutHandler;
import com.simbest.boot.security.auth.handle.FailedAccessDeniedHandler;
import com.simbest.boot.security.auth.handle.FailedLoginHandler;
import com.simbest.boot.security.auth.handle.RestSuccessLoginHandler;
import com.simbest.boot.security.auth.handle.RestSuccessLogoutHandler;
import com.simbest.boot.security.auth.handle.SsoSuccessLoginHandler;
import com.simbest.boot.security.auth.handle.SuccessLoginHandler;
import com.simbest.boot.security.auth.handle.SuccessLogoutHandler;
import com.simbest.boot.security.auth.provider.GenericAuthenticationChecker;
import com.simbest.boot.security.auth.service.IAuthUserCacheService;
import com.simbest.boot.util.encrypt.RsaEncryptor;

import lombok.extern.slf4j.Slf4j;

/**
 * 用途：通用Web请求安全配置类
 * 
 * 主要功能：
 * 1. 配置Web安全相关的过滤器链和认证处理器
 * 2. 实现多种认证方式的支持，包括：
 *    - 表单登录认证（Form-based Authentication）
 *    - REST API认证
 *    - SSO单点登录认证
 *    - UUMS统一用户管理系统认证
 *    - 验证码认证
 * 3. 提供安全防护功能：
 *    - CSRF防御
 *    - XSS防御
 *    - 会话固定攻击防护
 *    - 同一用户最大会话数控制
 * 4. 静态资源访问控制
 * 5. 自定义登录、登出处理
 * 6. 权限访问控制
 */
@Slf4j
@Configuration
@Order(100)
public class FormSecurityConfigurer extends WebSecurityConfigurerAdapter {

    @Autowired
    private ApplicationContext appContext;

    @Autowired
    private FailedAccessDeniedHandler failedAccessDeniedHandler;

    @Autowired
    private SuccessLoginHandler successLoginHandler;

    @Autowired
    private SuccessLogoutHandler successLogoutHandler;

    @Autowired
    private FailedLoginHandler failedLoginHandler;

    @Autowired
    private SsoSuccessLoginHandler ssoSuccessLoginHandler;

    @Autowired
    private RestSuccessLoginHandler restSuccessLoginHandler;

    @Autowired
    private RestSuccessLogoutHandler restSuccessLogoutHandler;

    @Autowired
    private DefaultLogoutHandler defaultLogoutHandler;

    @Autowired
    private IAccessDeniedEntryPoint accessDeniedEntryPoint;

    @Autowired
    private Swagger2CsrfProtection swagger2CsrfProtection;

    @Autowired
    private RsaEncryptor rsaEncryptor;

    @Autowired
    private SsoAuthenticationRegister ssoAuthenticationRegister;

    @Autowired
    private FindByIndexNameSessionRepository sessionRepository;

    @Autowired
    private IAuthService authService;

    @Autowired
    private IAuthUserCacheService authUserCacheService;

    @Autowired
    private GenericAuthenticationChecker genericAuthenticationChecker;

    @Bean
    public SpringSessionBackedSessionRegistry sessionRegistry() {
        return new SpringSessionBackedSessionRegistry(sessionRepository);
    }

    /**
     * 配置静态资源访问规则
     * 设置不需要进行权限验证的资源路径，包括：
     * 1. 静态资源文件（css、js、图片等）
     * 2. 匿名访问路径
     * 3. WebSocket相关路径
     * 4. Swagger API文档路径
     * 5. H2数据库控制台
     *
     * @param web WebSecurity配置对象
     */
    @Override
    public void configure(WebSecurity web) {
        web.ignoring().antMatchers(
                "/**/*.ico",
                "/**/*.css",
                "/**/*.js",
                "/**/*.gif",
                "/**/*.png",
                "/**/*.jpg",
                "/**/*.jpeg",
                "/**/*.bmp",
                "/**/*.html",
                "/**/*.htm",
                "/**/*.eot",
                "/**/*.svg",
                "/**/*.ttf",
                "/**/*.txt",
                "/webjars/**"
        );
        web.ignoring().antMatchers("/anonymous/**");
        web.ignoring().antMatchers("**/anonymous");
        web.ignoring().antMatchers("/**/anonymous/**");
        web.ignoring().antMatchers("/resources/**");
        web.ignoring().antMatchers("/wssocket/**","/wstopic/**","/wsqueue/**","/wsclient/**");
        web.ignoring().antMatchers("/captcha/**");
        web.ignoring().antMatchers("/h2-console/**");
        //allow Swagger URL to be accessed without authentication
        web.ignoring().antMatchers("/v2/api-docs", //swagger api json
                "/swagger-resources/configuration/ui", //用来获取支持的动作
                "/swagger-resources", //用来获取api-docs的URI
                "/swagger-resources/configuration/security", //安全选项
                "/swagger-ui.html", "/doc.html");
    }


    /**
     * 配置HTTP请求的安全处理规则
     * 主要包含：
     * 1. 安全防护配置（CSRF、XSS等）
     * 2. 认证过滤器配置
     * 3. 请求授权规则配置
     * 4. 登录/登出行为配置
     * 5. 会话管理配置
     * 6. 自定义过滤器注册
     *
     * @param http HttpSecurity配置对象
     * @throws Exception 配置过程中的异常
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                //CSRF防御
                .cors().and()
                .csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()).and()
                .headers()
                .contentTypeOptions().and()
                //XSS防御，配合nacos配置如下属性，可解决CXF框架的XSS攻击 如：http://localhost:7979/robot/services/%22%3E%3Cscript%3Ealert%28document.domain%29%3C/script%3E/services
                //cxf.servlet.enabled=false
                //cxf.servlet.init.hide-service-list-page=true
                .xssProtection().and()
                .cacheControl().and()
                .httpStrictTransportSecurity().and()
                .frameOptions().deny();

        //认证配置
        http
                .addFilterAfter(new CloudHeaderTokenAuthenticationFilter(), SecurityContextPersistenceFilter.class)
                //.addFilterBefore(new CloudHeaderTokenAuthenticationFilter(), BasicAuthenticationFilter.class)
                .addFilterBefore(captchaAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .addFilterBefore(restCaptchaAuthenticationFilter(), CaptchaAuthenticationFilter.class)
                .addFilterBefore(uumsAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .addFilterBefore(restUumsAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .addFilterAt(rsaAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .addFilterBefore(restRsaAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .addFilterAfter(ssoAuthenticationFilter(), UumsAuthenticationFilter.class)
                .authorizeRequests()
                .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
                .antMatchers(HttpMethod.OPTIONS).permitAll()//跨域请求会先进行一次options请求
                .antMatchers(ROOT_PAGE, WELCOME_PAGE, SIGNIN_PAGE, LOGIN_PAGE, LOGOUT_PAGE, ERROR_PAGE).permitAll()  // 主页、欢迎页、错误页、登陆页、登出页可以匿名访问
                //.antMatchers("/**/hqsso/**").permitAll() // HQ SSO单点登录路径允许匿名访问，由HqSsoAuthenticationFilter处理认证
                .antMatchers("/h2-console/**", "/html/**").permitAll()  // 都可以访问
                .antMatchers("/httpauth/**", "/**/anonymous/**", "/services/**", "/wx/**").permitAll()  // 都可以访问
                .antMatchers("/action/**").hasRole("USER")   // 需要相应的角色才能访问
                // 需要相应的角色才能访问, 后台管理和javamelody监控
                .antMatchers("/sys/admin/**", "/monitoring/**").hasAnyRole("ADMIN", "SUPER")
                .anyRequest().authenticated()
                .and().formLogin().successHandler(successLoginHandler) // 成功登入后，重定向到首页
                .loginPage(LOGIN_PAGE).failureUrl(LOGIN_ERROR_PAGE) // 自定义登录界面
                .failureHandler(failedLoginHandler) //记录登录错误日志，并自定义登录错误提示信息
                .and().logout().logoutSuccessHandler(successLogoutHandler) // 成功登出后，重定向到登陆页
                .and().exceptionHandling().authenticationEntryPoint(accessDeniedEntryPoint) //无权限返回JSON数据
                .accessDeniedHandler(failedAccessDeniedHandler) //无权限返回JSON数据
                .and().headers().frameOptions().sameOrigin()
                .and().csrf().disable().cors().and()

                .sessionManagement().sessionFixation().newSession().invalidSessionUrl(LOGIN_PAGE).maximumSessions(1)
//                .sessionManagement().invalidSessionUrl(LOGIN_PAGE).maximumSessions(5)
                .maxSessionsPreventsLogin(true)
                .sessionRegistry(sessionRegistry())
                .expiredUrl(LOGIN_PAGE);

        Map<String, CustomAbstractAuthenticationProcessingFilter> auths = appContext.getBeansOfType(CustomAbstractAuthenticationProcessingFilter.class);
        for(CustomAbstractAuthenticationProcessingFilter filter : auths.values()){
            log.debug("系统将注册自定义过滤器【{}】", filter.getClass());
            http.addFilterAfter(filter, UumsAuthenticationFilter.class);
        }
    }


    /**
     * 配置基于RSA加密的数据库主数据登录认证过滤器
     * 处理/login请求的表单登录认证
     * 
     * 功能特点：
     * 1. 支持RSA加密传输敏感数据
     * 2. 记录登录成功/失败日志
     * 3. 实现登录失败次数控制
     * 4. 集成用户缓存服务
     * 
     * @return RsaAuthenticationFilter 认证过滤器实例
     * @throws Exception 配置异常
     */
    @Bean
    public RsaAuthenticationFilter rsaAuthenticationFilter() throws Exception {
        RsaAuthenticationFilter filter = new RsaAuthenticationFilter();
        filter.setRequiresAuthenticationRequestMatcher(new AntPathRequestMatcher(LOGIN_PAGE, RequestMethod.POST.name()));
        filter.setAuthenticationManager(authenticationManagerBean());
        //记录成功登录日志
        filter.setAuthenticationSuccessHandler(successLoginHandler);
        //记录失败登录次数
        filter.setAuthenticationFailureHandler(failedLoginHandler);
        filter.setEncryptor(rsaEncryptor);
        filter.setAuthUserCacheService(authUserCacheService);
        filter.setGenericAuthenticationChecker(genericAuthenticationChecker);
       return filter;
    }


    /**
     * 配置REST风格的RSA加密认证过滤器
     * 处理/restlogin请求的API登录认证
     * 
     * 功能特点：
     * 1. 支持RSA加密传输敏感数据
     * 2. 提供REST风格的认证响应
     * 3. 集成用户缓存服务
     * 4. 支持通用认证检查
     * 
     * @return RestRsaAuthenticationFilter 认证过滤器实例
     * @throws Exception 配置异常
     */
    @Bean
    public RestRsaAuthenticationFilter restRsaAuthenticationFilter() throws Exception {
        RestRsaAuthenticationFilter filter = new RestRsaAuthenticationFilter();
        filter.setRequiresAuthenticationRequestMatcher(new AntPathRequestMatcher(REST_LOGIN_PAGE, RequestMethod.POST.name()));
        filter.setAuthenticationManager(authenticationManagerBean());
        //记录成功登录日志
        filter.setAuthenticationSuccessHandler(restSuccessLoginHandler);
        //记录失败登录次数
        filter.setAuthenticationFailureHandler(failedAccessDeniedHandler);
        filter.setEncryptor(rsaEncryptor);
        filter.setAuthUserCacheService(authUserCacheService);
        filter.setGenericAuthenticationChecker(genericAuthenticationChecker);
        return filter;
    }

    /**
     * 配置UUMS统一用户管理系统认证过滤器（Web方式）
     * 处理/uumslogin请求的Web表单认证
     * 
     * 功能特点：
     * 1. 集成UUMS统一用户管理系统
     * 2. 支持Web表单方式登录
     * 3. 记录登录日志和失败次数
     * 
     * @return UumsAuthenticationFilter 认证过滤器实例
     * @throws Exception 配置异常
     */
    @Bean
    public UumsAuthenticationFilter uumsAuthenticationFilter() throws Exception {
        UumsAuthenticationFilter filter = new UumsAuthenticationFilter(new AntPathRequestMatcher(UUMS_LOGIN_PAGE, RequestMethod.POST.name()));
        filter.setAuthenticationManager(authenticationManagerBean());
        //记录成功登录日志
        filter.setAuthenticationSuccessHandler(successLoginHandler);
        //记录失败登录次数
        filter.setAuthenticationFailureHandler(failedLoginHandler);
        return filter;
    }

    /**
     * 配置UUMS统一用户管理系统认证过滤器（REST方式）
     * 处理/restuumslogin请求的API认证
     * 
     * 功能特点：
     * 1. 集成UUMS统一用户管理系统
     * 2. 提供REST风格的认证接口
     * 3. 支持JSON格式的请求和响应
     * 4. 记录认证日志
     * 
     * @return RestUumsAuthenticationFilter 认证过滤器实例
     * @throws Exception 配置异常
     */
    @Bean
    public RestUumsAuthenticationFilter restUumsAuthenticationFilter() throws Exception {
        RestUumsAuthenticationFilter filter = new RestUumsAuthenticationFilter(new AntPathRequestMatcher(REST_UUMS_LOGIN_PAGE, RequestMethod.POST.name()));
        filter.setAuthenticationManager(authenticationManagerBean());
        //记录成功登录日志
        filter.setAuthenticationSuccessHandler(restSuccessLoginHandler);
        //记录失败登录次数
        filter.setAuthenticationFailureHandler(failedAccessDeniedHandler);
        return filter;
    }

    /**
     * 配置REST方式的退出登录过滤器
     * 处理/restuumslogout和/restlogout请求
     * 
     * 功能特点：
     * 1. 支持多个退出登录URL
     * 2. 提供REST风格的退出响应
     * 3. 支持自定义退出处理逻辑
     * 
     * @return LogoutFilter 退出过滤器实例
     */
    @Bean
    public LogoutFilter restUumsLogoutFilter() {
        LogoutFilter filter = new LogoutFilter(restSuccessLogoutHandler, defaultLogoutHandler);
//        filter.setLogoutRequestMatcher(new AntPathRequestMatcher(REST_UUMS_LOGOUT_PAGE, RequestMethod.POST.name()));
        filter.setLogoutRequestMatcher( new OrRequestMatcher(
                new AntPathRequestMatcher(REST_UUMS_LOGOUT_PAGE, RequestMethod.POST.name()),
                new AntPathRequestMatcher(REST_LOGOUT_PAGE, RequestMethod.POST.name())
        ));
        return filter;
    }


    /**
     * 配置SSO单点登录认证过滤器
     * 处理包含/sso的URL请求
     * 
     * 功能特点：
     * 1. 支持SSO单点登录集成
     * 2. 提供自定义SSO认证注册器
     * 3. 支持自定义认证成功/失败处理
     * 4. 记录认证日志
     * 
     * @return SsoAuthenticationFilter 认证过滤器实例
     * @throws Exception 配置异常
     */
    @Bean
    public SsoAuthenticationFilter ssoAuthenticationFilter() throws Exception {
        SsoAuthenticationFilter filter = new SsoAuthenticationFilter(new AntPathRequestMatcher("/**/sso/**"));
        filter.setAuthenticationManager(authenticationManagerBean());
        filter.setSsoAuthenticationRegister(ssoAuthenticationRegister);
        // 不跳回首页
        filter.setAuthenticationSuccessHandler(ssoSuccessLoginHandler);
        //跳至登陆页，但不作任何提醒
        //filter.setAuthenticationFailureHandler(new SimpleUrlAuthenticationFailureHandler(LOGIN_PAGE));
        //记录失败登录次数
        filter.setAuthenticationFailureHandler(failedAccessDeniedHandler);
        return filter;
    }

    /**
     * 配置验证码认证过滤器
     * 处理需要验证码校验的登录请求
     * 
     * 功能特点：
     * 1. 支持验证码校验
     * 2. 集成登录认证流程
     * 3. 提供验证失败处理
     * 4. 支持自定义验证规则
     * 
     * @return CaptchaAuthenticationFilter 验证码认证过滤器实例
     * @throws Exception 配置异常
     */
    @Bean
    public CaptchaAuthenticationFilter captchaAuthenticationFilter() throws Exception {
        CaptchaAuthenticationFilter filter = new CaptchaAuthenticationFilter(
                new OrRequestMatcher(
//                        new AntPathRequestMatcher("/*login", RequestMethod.POST.name())
                        new AntPathRequestMatcher(UUMS_LOGIN_PAGE, RequestMethod.POST.name()),
                        new AntPathRequestMatcher(LOGIN_PAGE, RequestMethod.POST.name())
                ));
        filter.setAuthenticationManager(authenticationManagerBean());
        //跳至登陆页，提醒验证码错误
        filter.setAuthenticationFailureHandler(new SimpleUrlAuthenticationFailureHandler(LOGIN_ERROR_PAGE));
        return filter;
    }

    /**
     * 配置REST风格的验证码认证过滤器
     * 处理需要验证码校验的REST API请求
     * 
     * 功能特点：
     * 1. 支持REST API验证码校验
     * 2. 提供JSON格式的响应
     * 3. 集成REST认证流程
     * 4. 支持自定义验证规则
     * 
     * @return RestCaptchaAuthenticationFilter REST风格验证码过滤器实例
     * @throws Exception 配置异常
     */
    @Bean
    public RestCaptchaAuthenticationFilter restCaptchaAuthenticationFilter() throws Exception {
        RestCaptchaAuthenticationFilter filter = new RestCaptchaAuthenticationFilter(
                new OrRequestMatcher(
                        new AntPathRequestMatcher(REST_UUMS_LOGIN_PAGE, RequestMethod.POST.name()),
                        new AntPathRequestMatcher(REST_LOGIN_PAGE, RequestMethod.POST.name())
                ));
        filter.setAuthenticationManager(authenticationManagerBean());
        // 配置验证失败处理器
        filter.setAuthenticationFailureHandler(failedAccessDeniedHandler);
        return filter;
    }

    /**
     * 配置认证管理器Bean
     * 用于管理所有认证过滤器的认证流程
     * 
     * @return AuthenticationManager 认证管理器实例
     * @throws Exception 配置异常
     */
    @Bean(name = BeanIds.AUTHENTICATION_MANAGER)
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

}