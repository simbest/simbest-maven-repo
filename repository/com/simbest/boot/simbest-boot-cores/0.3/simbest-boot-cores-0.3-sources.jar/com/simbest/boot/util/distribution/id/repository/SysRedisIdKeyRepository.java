package com.simbest.boot.util.distribution.id.repository;

import com.simbest.boot.base.repository.GenericRepository;
import com.simbest.boot.util.distribution.id.model.SysRedisIdKey;
import org.springframework.stereotype.Repository;

/**
 * 用途：Redis序列号前缀持久层
 *
 *
 */
@Repository
public interface SysRedisIdKeyRepository extends GenericRepository<SysRedisIdKey, String> {

    SysRedisIdKey findByName(String name);
}