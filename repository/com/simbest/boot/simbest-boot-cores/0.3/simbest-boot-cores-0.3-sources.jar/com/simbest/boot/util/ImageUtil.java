package com.simbest.boot.util;

import com.simbest.boot.base.exception.Exceptions;
import lombok.extern.slf4j.Slf4j;
import net.coobird.thumbnailator.Thumbnails;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;

/**
 * <strong>Title : ImageUtil</strong><br>
 * <strong>Description : 图片压缩工具类</strong><br>
 * <strong>Create on : 2020/8/31</strong><br>
 * <strong>Modify on : 2020/8/31</strong><br>
 *
 * @version <strong>V1.0.0</strong><br>
 * <strong>修改历史:</strong><br>
 * 修改人 修改日期 修改描述<br>
 * -------------------------------------------<br>
 */
@Slf4j
@Component
public class ImageUtil {

    /**
     * 根据指定大小和指定精度压缩图片
     * 递归压缩图片直到达到指定大小，同时保持图片质量
     * 
     * @param srcPath 源图片地址
     * @param desPath 目标图片地址
     * @param desFileSize 指定图片大小，单位kb
     * @param accuracy 精度，递归压缩的比率，建议小于0.9
     */
    public void commpressPicForSize(String srcPath, String desPath,long desFileSize, double accuracy) {
        Assert.notNull(srcPath, "源图片路径不能为空！");
        Assert.notNull(desPath, "目标图片路径不能为空！");
        try {
            File srcFile = new File(srcPath);
            long srcFileSize = srcFile.length();
            log.warn("源图片：{}，大小：" ,srcFileSize / 1024 + "kb");
            // 1、先转换成jpg
            Thumbnails.of(srcPath).scale(1f).toFile(desPath);
            // 递归压缩，直到目标文件大小小于desFileSize
            commpressPicCycle(desPath, desFileSize, accuracy);
            File desFile = new File(desPath);
            log.warn("目标图片：{}，大小",desFile.length()/ 1024 + "kb");
        } catch (Exception e) {
            Exceptions.printException(e);
        }
    }

    /**
     * 按照比例进行缩放压缩图片
     * 递归按比例缩小图片直到达到指定大小
     * 
     * @param srcPath 源图片地址
     * @param desPath 目标图片地址
     * @param desFileSize 指定图片大小，单位kb
     * @param accuracy 精度，递归压缩的比率，建议小于0.9
     */
    public void commpressPicForScale(String srcPath, String desPath,long desFileSize, double accuracy) {
        Assert.notNull(srcPath, "源图片路径不能为空！");
        Assert.notNull(desPath, "目标图片路径不能为空！");
        try {
            File srcFile = new File(srcPath);
            long srcFileSize = srcFile.length();
            log.warn("源图片：{}，大小：" ,srcFileSize / 1024 + "kb");
            // 1、先转换成jpg
            Thumbnails.of(srcPath).scale(1f).toFile(desPath);
            // 按照比例进行缩放
            imgScale(desPath, desFileSize, accuracy);
            File desFile = new File(desPath);
            log.warn("目标图片：{}，大小",desFile.length()/ 1024 + "kb");
        } catch (Exception e) {
            Exceptions.printException(e);
        }
    }

    /**
     * 图片尺寸不变，压缩文件大小
     * 只降低图片质量而不改变尺寸
     * 
     * @param srcPath 源图片地址
     * @param desPath 目标图片地址
     * @param desFileSize 指定图片大小，单位kb
     * @param accuracy 精度，递归压缩的比率，建议小于0.9
     */
    public void commpressPicForScaleSize(String srcPath, String desPath,long desFileSize, double accuracy) {
        Assert.notNull(srcPath, "源图片路径不能为空！");
        Assert.notNull(desPath, "目标图片路径不能为空！");
        try {
            File srcFile = new File(srcPath);
            long srcFileSize = srcFile.length();
            log.warn("源图片：{}，大小：" ,srcFileSize / 1024 + "kb");
            // 1、先转换成jpg
            Thumbnails.of(srcPath).scale(1f).toFile(desPath);
            // 按照比例进行缩放
            imgScaleSize(desPath, desFileSize, accuracy);
            File desFile = new File(desPath);
            log.warn("目标图片：{}，大小",desFile.length()/ 1024 + "kb");
        } catch (Exception e) {
            Exceptions.printException(e);
        }
    }

    /**
     * 递归压缩图片到指定大小
     * 按指定大小把图片进行缩放（会遵循原图高宽比例）并设置图片文件大小
     * 
     * @param desPath 目标图片路径
     * @param desFileSize 目标文件大小（KB）
     * @param accuracy 压缩精度，每次压缩比例
     */
    private void commpressPicCycle(String desPath, long desFileSize, double accuracy){
        try {
            File srcFileJPG = new File(desPath);
            long srcFileSizeJPG = srcFileJPG.length();
            // 2、判断大小，如果小于指定大小，不压缩；如果大于等于指定大小，压缩
            if (srcFileSizeJPG <= desFileSize * 1024) {
                return;
            }
            // 计算宽高
            BufferedImage bim = ImageIO.read(srcFileJPG);
            int srcWdith = bim.getWidth();
            int srcHeigth = bim.getHeight();
            int desWidth = new BigDecimal(srcWdith).multiply(new BigDecimal(accuracy)).intValue();
            int desHeight = new BigDecimal(srcHeigth).multiply(new BigDecimal(accuracy)).intValue();
            Thumbnails.of(desPath).size(desWidth, desHeight).outputQuality(accuracy).toFile(desPath);
            commpressPicCycle(desPath, desFileSize, accuracy);
        }catch (Exception e){
            Exceptions.printException( e );
        }
    }

    /**
     * 按照比例缩放图片
     * 递归按比例缩小图片直到达到指定大小
     * 
     * @param desPath 目标图片路径
     * @param desFileSize 目标文件大小（KB）
     * @param accuracy 压缩精度，每次压缩比例
     */
    private void imgScale(String desPath, long desFileSize, double accuracy){
        try {
            File file=new File(desPath);
            long fileSize=file.length();
            //判断大小，如果小于指定大小，不压缩；如果大于等于指定大小，压缩
            if(fileSize<=desFileSize*1024){
                return;
            }
            //按照比例进行缩小
            Thumbnails.of(desPath).scale(accuracy).toFile(desPath);//按比例缩小
            //按照比例进行缩放
            imgScale(desPath, desFileSize, accuracy);
        }catch (Exception e){
            Exceptions.printException( e );
        }
    }

    /**
     * 图片尺寸不变，压缩文件大小
     * 通过降低图片质量来减小文件大小，适用于需要保持图片尺寸的场景
     * 
     * @param desPath 目标图片路径
     * @param desFileSize 目标文件大小（KB）
     * @param accuracy 压缩精度，图片质量系数(0-1之间)
     */
    private void imgScaleSize(String desPath, long desFileSize,double accuracy){
        try {
            File fileName=new File(desPath);
            long fileNameSize=fileName.length();
            //判断大小，如果小于指定大小，不压缩；如果大于等于指定大小，压缩
            if(fileNameSize<=desFileSize*1024){
                return;
            }
            //图片尺寸不变，压缩图片文件大小
            //图片尺寸不变，压缩图片文件大小outputQuality实现,参数1为最高质量
            Thumbnails.of(desPath).scale(1f).outputQuality(accuracy).toFile(desPath);
            //图片尺寸不变，压缩文件大小
            imgScaleSize(desPath, desFileSize, accuracy);
        }catch (Exception e){
            Exceptions.printException( e );
        }
    }


    /**
     * 检查上传的文件是否为有效的图片文件
     * 通过尝试读取为BufferedImage来判断文件是否为合法图片
     * 
     * @param multipartFile 需要检查的上传文件
     * @return 如果是有效图片文件返回true，否则返回false
     */
    public boolean checkImage(MultipartFile multipartFile){
        try {
            BufferedImage bi = ImageIO.read(multipartFile.getInputStream());
            if(bi == null){
                return false;
            }
        } catch (IOException e) {
            Exceptions.printException(e);
        }
        return true;
    }
}