package com.simbest.boot.component.converter;

import com.simbest.boot.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 字符串转日期的通用转换器
 * 
 * 功能特点：
 * 1. 支持多种日期格式：
 *    - 完整日期时间：yyyy-MM-dd HH:mm:ss
 *    - 短日期：yyyy-MM-dd
 *    - 时间戳：毫秒数字符串
 * 
 * 2. 格式识别规则：
 *    - 包含"-"和":"的字符串按完整日期时间格式解析
 *    - 仅包含"-"的字符串按短日期格式解析
 *    - 纯数字字符串按时间戳解析
 * 
 * 3. 异常处理：
 *    - 空值返回null
 *    - 格式错误抛出RuntimeException
 *    - 自动去除字符串前后空格
 * 
 * 使用示例：
 * 1. "2024-01-01 12:00:00" -> 2024年1月1日12点
 * 2. "2024-01-01" -> 2024年1月1日0点
 * 3. "1704067200000" -> 对应的日期对象
 */
public class StringToDateConverter implements Converter<String, Date> {

    /**
     * 完整日期时间格式
     * 格式：yyyy-MM-dd HH:mm:ss
     * 示例：2024-01-01 12:00:00
     */
    private static final String dateFormat = DateUtil.timestampPattern1;

    /**
     * 短日期格式
     * 格式：yyyy-MM-dd
     * 示例：2024-01-01
     */
    private static final String shortDateFormat = DateUtil.datePattern1;

    /**
     * 将字符串转换为日期对象
     * 
     * 转换规则：
     * 1. 空字符串或null -> 返回null
     * 2. 包含"-"和":"的字符串 -> 使用完整日期时间格式解析
     * 3. 仅包含"-"的字符串 -> 使用短日期格式解析
     * 4. 纯数字字符串 -> 按时间戳解析
     * 5. 其他格式 -> 抛出异常
     *
     * @param source 源字符串，支持以下格式：
     *              - yyyy-MM-dd HH:mm:ss（如：2024-01-01 12:00:00）
     *              - yyyy-MM-dd（如：2024-01-01）
     *              - 时间戳（如：1704067200000）
     * @return 转换后的日期对象，如果输入为空则返回null
     * @throws RuntimeException 当日期格式不正确或解析失败时抛出异常
     */
    @Override
    public Date convert(String source) {
        if (StringUtils.isBlank(source)) {
            return null;
        }
        source = source.trim();
        try {
            if (source.contains("-")) {
                SimpleDateFormat formatter;
                if (source.contains(":")) {
                    formatter = new SimpleDateFormat(dateFormat);
                } else {
                    formatter = new SimpleDateFormat(shortDateFormat);
                }
                return formatter.parse(source);
            } else if (source.matches("^\\d+$")) {
                Long lDate = new Long(source);
                return new Date(lDate);
            }
        } catch (Exception e) {
            throw new RuntimeException(String.format("parser %s to Date fail", source));
        }
        throw new RuntimeException(String.format("parser %s to Date fail", source));
    }
}