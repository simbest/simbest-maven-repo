package com.simbest.boot.exceptions;

import lombok.NoArgsConstructor;

/**
 * 应用通用运行时异常类
 * 
 * 主要用途：
 * 1. 作为应用中运行时异常的基类
 * 2. 统一处理非受检异常
 * 3. 提供统一的异常信息格式
 * 
 * 特点：
 * 1. 继承自RuntimeException，属于非受检异常
 * 2. 使用@NoArgsConstructor提供无参构造
 * 3. 支持带消息的异常构造
 * 4. 支持带根异常的异常构造
 * 
 * 使用场景：
 * 1. 业务逻辑异常处理
 * 2. 系统运行时错误处理
 * 3. 需要中断当前执行流程时
 * 
 * 注意事项：
 * 1. 建议在抛出异常时提供清晰的错误信息
 * 2. 如果有根异常，应当传递以保留完整的异常栈信息
 * 3. 可以被其他具体的业务异常继承和扩展
 */
@NoArgsConstructor
public class AppRuntimeException extends RuntimeException {

    /**
     * 创建一个带有错误信息的应用运行时异常
     *
     * @param msg 异常详细信息
     */
    public AppRuntimeException(String msg) {
        super(msg);
    }

    /**
     * 创建一个带有错误信息和根异常的应用运行时异常
     *
     * @param msg 异常详细信息
     * @param t 根异常
     */
    public AppRuntimeException(String msg, Throwable t) {
        super(msg, t);
    }
}