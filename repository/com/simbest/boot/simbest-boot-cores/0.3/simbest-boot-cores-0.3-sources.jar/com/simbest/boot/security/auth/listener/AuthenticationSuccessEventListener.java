package com.simbest.boot.security.auth.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * org.springframework.security.authentication.ProviderManager 的authenticate方法 通过eventPublisher.publishAuthenticationSuccess(result);
 * 推出了一个认证成功的事件。
 *
 * 这样我们可以通过注册一个监听AuthenticationSuccessEvent事件的类， 对认证成功后 作出一些处理。
 * 注意的是这个事件源可能有2种情况:
 * 1.通过用户名密码校验身份的事件源（UsernamePasswordAuthenticationToken）
 * 2.根据access_token校验 是否有效token的的事件源（OAuth2Authentication）
 */
@Slf4j
//@Component
public class AuthenticationSuccessEventListener implements ApplicationListener<AuthenticationSuccessEvent> {

    @Override
    public void onApplicationEvent(AuthenticationSuccessEvent event) {
        log.debug(event.getSource().getClass().getName());
        //这里的事件源除了登录事件（UsernamePasswordAuthenticationToken）还有可能是token验证事件源（OAuth2Authentication）
        if(!event.getSource().getClass().getName().equals("org.springframework.security.authentication.UsernamePasswordAuthenticationToken")){
            return ;
        }

        //这里还有oAuth2的客户端认证的事件，需要做一个判断
        if(event.getAuthentication().getDetails() != null){
            //登录日志逻辑。。。
            System.out.println("oauth2 login");
        }
    }



}