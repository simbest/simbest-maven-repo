package com.simbest.boot.security.auth.authentication;

import org.springframework.security.core.GrantedAuthority;

import java.io.Serializable;
import java.util.Comparator;

/**
 * 权限排序比较器
 * 
 * 主要功能：
 * 1. 实现Spring Security的GrantedAuthority权限对象比较
 * 2. 支持权限集合的排序操作
 * 3. 实现序列化接口，支持分布式环境
 * 
 * 使用场景：
 * - 权限列表排序
 * - 权限去重处理
 * - 权限优先级管理
 * 
 * 比较逻辑：
 * - 相等返回0
 * - 不等返回-1
 * - 用于保持权限的原有顺序
 */
public class SortGrantedAuthorityComparator implements Comparator<GrantedAuthority>, Serializable {

    /**
     * 比较两个权限对象
     * 
     * @param o1 第一个权限对象
     * @param o2 第二个权限对象
     * @return 比较结果：
     *         - 0：两个权限对象相等
     *         - -1：两个权限对象不相等
     *         
     * 说明：
     * 1. 使用equals方法判断权限是否相等
     * 2. 不相等时返回-1，保持原有顺序
     * 3. 主要用于权限去重和排序操作
     */
    @Override
    public int compare(GrantedAuthority o1, GrantedAuthority o2) {
        return o1.equals(o2) ? 0 : -1;
    }
}