package com.simbest.boot.util.redis;

import com.simbest.boot.base.web.response.JsonResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.simbest.boot.constants.ApplicationConstants.MSG_SUCCESS;


@Api(description = "提供JWT令牌的Redis缓存校验功能，用于验证和管理JWT令牌的有效期", tags = {"7-工具功能", "JWT令牌校验"})
@RestController
@RequestMapping("/jwt")
public class RedisJwtValidatorController {

    /**
     * http://localhost:9003/appcode/jwt/anonymous/getJwtExpiryDate
     * 可访问
     * @return
     */
    @ApiOperation(value = "获取JWT过期时间", notes = "根据subject和jwtId获取JWT的过期时间")
    @RequestMapping(value = "/anonymous/getJwtExpiryDate", method = {RequestMethod.GET, RequestMethod.POST})
    public JsonResponse getJwtExpiryDate(
            @ApiParam(value = "JWT的主题", required = true) @RequestParam("subject") String subject, 
            @ApiParam(value = "JWT的ID", required = true) @RequestParam("jwtId") String jwtId) {
        Long expiryCache = RedisJwtValidator.getJwtExpiryDate(subject, jwtId);
        return JsonResponse.success(expiryCache, MSG_SUCCESS);
    }


}