package com.simbest.boot.security.auth.authentication;

import com.simbest.boot.security.IUser;
import com.simbest.boot.security.auth.authentication.principal.KeyTypePrincipal;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

/**
 * 通用认证令牌实现类
 * 
 * 主要功能：
 * 1. 基于UUMS（统一用户管理系统）主数据的登录认证
 * 2. 支持认证前后两种状态的令牌管理
 * 3. 继承自Spring Security的AbstractAuthenticationToken，实现标准认证流程
 * 
 * 认证流程：
 * 1. 认证前：使用KeyTypePrincipal和认证凭据创建未认证状态的令牌
 * 2. 认证后：使用已验证的用户信息、认证凭据和权限信息创建已认证状态的令牌
 * 
 * 参考实现：
 * - 参考Spring Security的UsernamePasswordAuthenticationToken设计
 * - 扩展支持UUMS特定的认证需求
 */
@Data
public class GenericAuthentication extends AbstractAuthenticationToken {

    /**
     * 认证主体
     * - 认证前：KeyTypePrincipal类型，包含用户标识和认证类型
     * - 认证后：IUser类型，包含完整的用户信息
     */
    private Object principal;

    /**
     * 认证凭据
     * 包含用户提供的认证信息，如密码、令牌等
     */
    private UumsAuthenticationCredentials credentials;

    /**
     * 创建认证前状态的认证令牌
     * 
     * @param principal KeyTypePrincipal类型的认证主体，包含用户标识和认证类型
     * @param credentials 认证凭据，包含用户提供的认证信息
     */
    public GenericAuthentication(KeyTypePrincipal principal, UumsAuthenticationCredentials credentials) {
        super(null);
        this.principal = principal;
        this.credentials = credentials;
        setAuthenticated(false);
    }

    /**
     * 创建认证后状态的认证令牌
     * 
     * @param principal IUser类型的认证主体，包含完整的用户信息
     * @param credentials 认证凭据，包含用户提供的认证信息
     * @param authorities 用户的权限集合
     */
    public GenericAuthentication(IUser principal, UumsAuthenticationCredentials credentials,
                               Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.principal = principal;
        this.credentials = credentials;
        super.setAuthenticated(true); // 必须使用super，因为我们重写了setAuthenticated方法
    }

    /**
     * 重写toString方法，使用反射方式输出对象信息
     * 用于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}