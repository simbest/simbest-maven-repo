package com.simbest.boot.security.auth.filter;

import com.simbest.boot.config.AppConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.util.matcher.RequestMatcher;

/**
 * 用途：验证码过滤器
 *
 *
 */
public class RestCaptchaAuthenticationFilter extends CaptchaAuthenticationFilter {

    @Autowired
    private AppConfig config;

    public RestCaptchaAuthenticationFilter(RequestMatcher requiresAuthenticationRequestMatcher) {
        super(requiresAuthenticationRequestMatcher);
    }

}