package com.simbest.boot.base.enums;

import lombok.Getter;
import lombok.Setter;

/**
 * 文件存储位置枚举
 * 用于定义文件上传后的存储位置类型
 * 实现了GenericEnum接口，提供统一的枚举值获取方法
 */
public enum StoreLocation implements GenericEnum {

    /**
     * 本地磁盘存储
     */
    disk("disk"),
    
    /**
     * FastDFS分布式文件系统存储
     */
    fastdfs("fastdfs"),
    
    /**
     * FTP服务器存储
     */
    ftp("ftp"),
    
    /**
     * SFTP服务器存储
     */
    sftp("sftp");

    /**
     * 枚举值
     */
    @Setter @Getter
    private String value;

    /**
     * 构造函数
     * @param value 枚举值
     */
    StoreLocation(String value) {
        this.value = value;
    }
}