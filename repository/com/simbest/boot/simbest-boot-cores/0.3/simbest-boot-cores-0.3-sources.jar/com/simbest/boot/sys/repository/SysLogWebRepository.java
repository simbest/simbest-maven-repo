package com.simbest.boot.sys.repository;

import com.simbest.boot.base.repository.SystemRepository;
import com.simbest.boot.sys.model.SysLogWeb;
import org.springframework.stereotype.Repository;

/**
 * 用途：系统Web请求日志
 *
 *
 */
@Repository
public interface SysLogWebRepository extends SystemRepository<SysLogWeb, String> {

}