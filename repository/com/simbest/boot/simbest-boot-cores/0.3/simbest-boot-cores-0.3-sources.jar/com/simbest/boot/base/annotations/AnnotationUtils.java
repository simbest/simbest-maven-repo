package com.simbest.boot.base.annotations;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Component;

import com.google.common.collect.Maps;
import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.constants.ApplicationConstants;

import lombok.Getter;

/**
 * 注解工具类
 * 用于扫描和管理带有EntityCnName注解的类
 * 提供实体类中文名称的缓存和管理功能
 */
@Component
public class AnnotationUtils {

    /**
     * 存储实体类名称和对应的中文名称的映射关系
     * key: 实体类名称
     * value: 实体类中文名称
     */
    @Getter
    private static Map<String, String> entityCnNameClassifyMap = Maps.newHashMap();

    /**
     * 在Spring容器初始化完成后执行
     * 加载所有带有EntityCnName注解的类信息
     */
    @PostConstruct
    void loadEntityCnNames(){
        findAnnotatedEntityCnNameClasses();
    }

    /**
     * 扫描指定包路径下所有带有EntityCnName注解的类
     * 使用Spring的类路径扫描器实现
     */
    private void findAnnotatedEntityCnNameClasses() {
        ClassPathScanningCandidateComponentProvider provider
                = new ClassPathScanningCandidateComponentProvider(false);
        provider.addIncludeFilter(new AnnotationTypeFilter(EntityCnName.class));
        provider.findCandidateComponents(ApplicationConstants.PACKAGE_NAME).forEach(this::putEntityCnNameMetadata);
    }

    /**
     * 处理单个带有EntityCnName注解的类
     * 将类名和对应的中文名称存入映射集合中
     *
     * @param beanDef Spring Bean定义对象
     */
    private void putEntityCnNameMetadata(BeanDefinition beanDef) {
        try {
            Class<?> cl = Class.forName(beanDef.getBeanClassName());
            EntityCnName cnName = cl.getAnnotation(EntityCnName.class);
            entityCnNameClassifyMap.put(cl.getSimpleName(), cnName.name());
        } catch (Exception e) {
            Exceptions.printException(e);
        }
    }

}