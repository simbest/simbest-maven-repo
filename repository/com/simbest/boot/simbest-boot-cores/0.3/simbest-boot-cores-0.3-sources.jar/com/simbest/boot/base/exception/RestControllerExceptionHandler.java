package com.simbest.boot.base.exception;


import com.simbest.boot.base.web.response.JsonResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;

import static com.simbest.exclude.web.GlobalErrorController.printErrorRequest;

/**
 * REST控制器全局异常处理器
 * 用于统一处理应用内的运行时JSON请求错误
 * 其他类型的错误（包括未定义的页面和JSON请求）由GlobalErrorController处理
 */
@Slf4j
@RestControllerAdvice
public class RestControllerExceptionHandler {

    /**
     * 处理一般性异常
     * 捕获所有Exception类型的异常，转换为统一的JSON响应格式
     *
     * @param req HTTP请求对象
     * @param e 捕获的异常
     * @return 统一的JSON响应对象
     */
    @ExceptionHandler(value = Exception.class)
    public JsonResponse handleErrorException(HttpServletRequest req, Exception e) {
        return handleException(req, e);
    }

    /**
     * 处理运行时异常
     * 捕获所有RuntimeException类型的异常，转换为统一的JSON响应格式
     *
     * @param req HTTP请求对象
     * @param e 捕获的运行时异常
     * @return 统一的JSON响应对象
     */
    @ExceptionHandler(value = RuntimeException.class)
    public JsonResponse handleRuntimeException(HttpServletRequest req, RuntimeException e) {
        return handleException(req, e);
    }

    /**
     * 通用异常处理方法
     * 记录异常信息，打印请求详情，并返回统一的错误响应
     *
     * @param req HTTP请求对象
     * @param e 需要处理的异常
     * @return 包含错误信息的JSON响应对象
     */
    private JsonResponse handleException(HttpServletRequest req, Exception e) {
        log.error("执行请求【{}】发生异常", req.getRequestURL().toString());
        printErrorRequest(req);
        Exceptions.printException(e);
        JsonResponse response = GlobalExceptionRegister.returnErrorResponse(e);
        response.setPath(req.getRequestURL().toString());
        return response;
    }

}