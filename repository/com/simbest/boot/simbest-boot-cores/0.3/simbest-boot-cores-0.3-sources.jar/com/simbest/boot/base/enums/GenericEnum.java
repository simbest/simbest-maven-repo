package com.simbest.boot.base.enums;

/**
 * 通用枚举接口
 * 为所有枚举类型提供统一的获取和设置值的方法
 * 用于规范枚举类型的行为，确保所有枚举都能获取和设置其值
 */
public interface GenericEnum {

    /**
     * 获取枚举值
     * @return 返回枚举值的中文描述
     */
    String getValue();

    /**
     * 设置枚举值
     * @param value 要设置的枚举值中文描述
     */
    void setValue(String value);
}