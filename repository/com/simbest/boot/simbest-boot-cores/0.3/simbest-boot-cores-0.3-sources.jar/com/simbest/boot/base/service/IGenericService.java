package com.simbest.boot.base.service;

import com.simbest.boot.base.model.GenericModel;
import com.simbest.boot.base.repository.Condition;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 基础实体通用服务层接口
 * 定义所有实体的基础服务操作：
 * - 提供通用CRUD操作接口
 * - 支持分页查询和排序
 * - 支持多种条件查询方式
 * - 支持批量操作
 * - 是系统所有服务接口的基础
 *
 * @param <T> 实体类型，必须继承自GenericModel
 * @param <PK> 实体主键类型
 */
public interface IGenericService <T extends GenericModel,PK extends Serializable> {

    /**
     * 获取默认分页对象
     * 
     * @return 默认配置的分页对象
     */
    Pageable getPageable();

    /**
     * 获取指定页码和大小的分页对象
     * 
     * @param page 页码（从1开始）
     * @param size 每页记录数
     * @return 配置好的分页对象
     */
    Pageable getPageable(int page, int size);

    /**
     * 获取带排序功能的分页对象
     * 
     * @param page 页码（从1开始）
     * @param size 每页记录数
     * @param direction 排序方向（ASC或DESC）
     * @param properties 排序字段，多个字段用逗号分隔
     * @return 配置好的带排序的分页对象
     */
    Pageable getPageable(int page, int size, String direction, String properties);

    /**
     * 根据实体对象创建查询规范
     * 根据实体中非空字段构建等值查询条件
     * 
     * @param entity 实体对象
     * @return 查询规范
     */
    Specification<T> getSpecification(T entity);

    /**
     * 根据条件Map创建查询规范
     * Map的键为字段名，值为查询条件值
     * 
     * @param conditions 条件Map
     * @return 查询规范
     */
    Specification<T> getSpecification(Map<String, Object> conditions);

    /**
     * 根据自定义Condition对象创建查询规范
     * 支持更复杂的查询条件构建
     * 
     * @param condition 条件对象
     * @return 查询规范
     */
    Specification<T> getSpecification(Condition condition);

    /**
     * 统计实体总数
     * 
     * @return 实体总数
     */
    long count();

    /**
     * 根据条件统计实体数量
     * 
     * @param specification 查询条件
     * @return 符合条件的实体数量
     */
    long count(Specification<T> specification);

    /**
     * 检查指定ID的实体是否存在
     * 
     * @param id 实体ID
     * @return 是否存在
     */
    boolean exists(PK id);

    /**
     * 根据ID查找实体（懒加载方式）
     * 
     * @param id 实体ID
     * @return 实体对象
     */
    T findOne(PK id);

    /**
     * 根据条件查找单个实体
     * 
     * @param conditions 查询条件
     * @return 实体对象，如果不存在则返回null
     */
    T findOne(Specification<T> conditions);

    /**
     * 根据ID查找实体（即时加载方式）
     * 
     * @param id 实体ID
     * @return 实体对象，如果不存在则返回null
     */
    T findById(PK id);

    /**
     * 查询所有实体并分页
     * 使用默认分页参数
     * 
     * @return 分页后的实体列表
     */
    Page<T> findAll();

    /**
     * 根据分页参数查询所有实体
     * 
     * @param pageable 分页参数
     * @return 分页后的实体列表
     */
    Page<T> findAll(Pageable pageable);

    /**
     * 根据排序参数查询所有实体并分页
     * 使用默认分页大小
     * 
     * @param sort 排序参数
     * @return 分页后的实体列表
     */
    Page<T> findAll(Sort sort);

    /**
     * 查询所有实体不分页
     * 
     * @return 所有实体列表
     */
    Iterable<T> findAllNoPage();

    /**
     * 根据排序参数查询所有实体不分页
     * 
     * @param sort 排序参数
     * @return 排序后的所有实体列表
     */
    Iterable<T> findAllNoPage(Sort sort);

    /**
     * 根据ID集合查询多个实体
     * 
     * @param ids ID集合
     * @return 实体列表
     */
    Iterable<T> findAllByIDs(Iterable<PK> ids);

    /**
     * 根据条件查询实体并分页
     * 
     * @param conditions 查询条件
     * @param pageable 分页参数
     * @return 分页后的实体列表
     */
    Page<T> findAll(Specification<T> conditions, Pageable pageable);

    /**
     * 根据条件查询实体不分页
     * 
     * @param conditions 查询条件
     * @return 符合条件的所有实体
     */
    Iterable<T> findAllNoPage(Specification<T> conditions);

    /**
     * 根据条件和排序参数查询实体不分页
     * 
     * @param conditions 查询条件
     * @param sort 排序参数
     * @return 排序后的符合条件的所有实体
     */
    Iterable<T> findAllNoPage(Specification<T> conditions, Sort sort);

    /**
     * 新增实体
     * 不允许实体已有ID值，否则会抛出异常
     * 
     * @param o 待保存的实体对象
     * @return 保存后的实体对象（包含生成的ID）
     */
    T insert(T o);

    /**
     * 更新实体
     * 必须提供实体ID值，否则会抛出异常
     * 
     * @param o 待更新的实体对象
     * @return 更新后的实体对象
     */
    T update(T o);

    /**
     * 保存实体并立即刷新到数据库
     * 强制执行数据库同步，而不是等待事务提交
     * 
     * @param o 待保存的实体对象
     * @return 保存后的实体对象
     */
    T saveAndFlush(T o);

    /**
     * 批量保存实体集合
     * 
     * @param entities 待保存的实体集合
     * @return 保存后的实体列表
     */
    List<T> saveAll(Iterable<T> entities);

    /**
     * 根据ID删除实体
     * 
     * @param id 实体ID
     */
    void deleteById(PK id);

    /**
     * 删除指定实体
     * 
     * @param o 要删除的实体对象
     */
    void delete(T o);

    /**
     * 批量删除实体集合
     * 
     * @param iterable 要删除的实体集合
     */
    void deleteAll(Iterable<? extends T> iterable);

    /**
     * 删除所有实体
     * 谨慎使用，会清空整个表
     */
    void deleteAll();

    /**
     * 根据ID集合批量删除实体
     * 
     * @param pks ID集合
     */
    void deleteAllByIds(Iterable<? extends PK> pks);
}