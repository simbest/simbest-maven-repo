package com.simbest.boot.base.exception;


import com.github.stuxuhai.jpinyin.ChineseHelper;
import com.google.common.collect.Maps;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.constants.ErrorCodeConstants;
import com.simbest.boot.exceptions.InsertExistObjectException;
import com.simbest.boot.exceptions.UpdateNotExistObjectException;
import com.simbest.boot.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.TransactionException;
import org.springframework.beans.BeanUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;

import javax.persistence.NonUniqueResultException;
import java.util.Map;

import static com.simbest.boot.constants.AuthoritiesConstants.ACCESS_FORBIDDEN;

/**
 * 全局异常注册器
 * 用于统一管理系统中的异常处理，将不同类型的异常映射为对应的错误响应
 * 支持异常继承关系的处理，并提供友好的错误信息
 */
@Slf4j
public final class GlobalExceptionRegister {
    /**
     * 异常类型与错误响应的映射关系
     * key: 异常类型
     * value: 对应的JsonResponse响应对象
     */
    private static Map<Class<? extends Exception>, JsonResponse> errorMap = Maps.newHashMap();

    /**
     * 测试方法，用于验证HTTP状态码
     */
    public static void main(String[] args) {
        HttpStatus a = HttpStatus.BAD_REQUEST;
        System.out.println(a.name());
        System.out.println(a.value());
        System.out.println(errorMap);
    }

    /**
     * 初始化异常映射关系
     * 包含系统通用异常、权限相关异常、文件相关异常、自定义异常和数据库相关异常的处理
     */
    static {
        //系统通用异常
        errorMap.put(Exception.class,
                JsonResponse.builder().errcode(HttpStatus.BAD_REQUEST.value()).status(HttpStatus.BAD_REQUEST.value()).error(HttpStatus.BAD_REQUEST.name()).message("请求参数错误").build());
        errorMap.put(RuntimeException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("系统内部错误").build());
        errorMap.put(NullPointerException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("系统空指针异常").build());
        errorMap.put(IllegalStateException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).build());
        errorMap.put(IllegalArgumentException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).build());
        errorMap.put(HttpRequestMethodNotSupportedException.class,
                JsonResponse.builder().errcode(HttpStatus.METHOD_NOT_ALLOWED.value()).status(HttpStatus.METHOD_NOT_ALLOWED.value()).error(HttpStatus.METHOD_NOT_ALLOWED.name()).message("请求方式错误").build());

        //权限相关异常
        errorMap.put(AccessDeniedException.class,
                JsonResponse.builder().errcode(HttpStatus.FORBIDDEN.value()).status(HttpStatus.FORBIDDEN.value()).error(HttpStatus.FORBIDDEN.name()).message(ACCESS_FORBIDDEN).build());

        //文件相关异常
        errorMap.put(MultipartException.class,
                JsonResponse.builder().errcode(ErrorCodeConstants.ERRORCODE_ATTACHMENT_SIZE_EXCEEDS).status(HttpStatus.BAD_REQUEST.value()).error(HttpStatus.BAD_REQUEST.name()).message("文件上传失败").build());
        errorMap.put(MaxUploadSizeExceededException.class,
                JsonResponse.builder().errcode(ErrorCodeConstants.ERRORCODE_ATTACHMENT_SIZE_EXCEEDS).status(HttpStatus.REQUEST_ENTITY_TOO_LARGE.value()).error(HttpStatus.REQUEST_ENTITY_TOO_LARGE.name()).message("文件大小受限").build());

        //自定义异常
        errorMap.put(InsertExistObjectException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("不能写入有ID的对象").build());
        errorMap.put(UpdateNotExistObjectException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("不能更新不存在的对象").build());

        //数据库相关异常
        errorMap.put(DataRetrievalFailureException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("提取数据发出错误").build());
        errorMap.put(IncorrectResultSizeDataAccessException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("数据记录与预期不符").build());
        errorMap.put(NonUniqueResultException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("数据记录与预期不符").build());
        errorMap.put(HibernateException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("数据处理异常").build());
        errorMap.put(TransactionException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("数据库事务异常").build());
        errorMap.put(DataAccessException.class,
                JsonResponse.builder().errcode(HttpStatus.INTERNAL_SERVER_ERROR.value()).status(HttpStatus.INTERNAL_SERVER_ERROR.value()).error(HttpStatus.INTERNAL_SERVER_ERROR.name()).message("数据访问层异常").build());
    }

    /**
     * 私有构造函数，防止实例化
     */
    private GlobalExceptionRegister() {
    }

    /**
     * 根据异常类型返回对应的错误响应
     * 支持异常继承关系的处理，如果找不到直接匹配的异常类型，会向上查找父类异常
     *
     * @param e 需要处理的异常
     * @return 对应的JsonResponse错误响应对象
     */
    public static JsonResponse returnErrorResponse(Exception e) {
        JsonResponse response = errorMap.get(e.getClass());
        if (response == null) {
            log.debug("当前异常为【{}】，父类异常为【{}】，异常信息为【{}】", e.getClass().getSimpleName(), e.getClass().getSuperclass().getSimpleName(), e.getMessage());
            Class superClass = e.getClass().getSuperclass();
            while(null != superClass){
                if(errorMap.keySet().contains(superClass)){
                    response = errorMap.get(superClass);
                    superClass = null;
                } else {
                    log.debug("当前父类异常为【{}】，父类的父类异常为【{}】，异常信息为【{}】", superClass.getSimpleName(), superClass.getSuperclass().getSimpleName(), e.getMessage());
                    superClass = superClass.getSuperclass();
                }
            }
        }
        //循环遍历完成后，依然没有找到注册异常，返回默认异常错误
        if (response == null) {
            response = JsonResponse.defaultErrorResponse();
            response.setError(e.getClass().getSimpleName());
        }
        setCorrectErrorMessage(response, e);
        response.setTimestamp(DateUtil.getCurrent());
        //构建一个新的对象返回
        JsonResponse result = new JsonResponse();
        BeanUtils.copyProperties(response, result);
        return result;
    }

    /**
     * 设置正确的错误信息
     * 处理特殊情况的错误信息，如约束违反、中文错误信息等
     *
     * @param response 错误响应对象
     * @param e 异常对象
     */
    private static void setCorrectErrorMessage(JsonResponse response, Exception e){
        if(StringUtils.isNotEmpty(e.getMessage()) && e.getMessage().contains(" constraint [null]")){
            response.setMessage("必填字段不能为空");
        }
        else if(StringUtils.isNotEmpty(e.getMessage()) && e.getMessage().contains(" constraint [")){
            String constraintField = e.getMessage();
            constraintField = StringUtils.substringAfter(constraintField, "constraint [");
            constraintField = StringUtils.substringBefore(constraintField, "]");
            response.setMessage("数据【".concat(constraintField).concat("】不可重复"));
        }
        else if(StringUtils.isNotEmpty(e.getMessage()) && ChineseHelper.containsChinese(e.getMessage())){
            response.setMessage(e.getMessage());
        }
        else if(StringUtils.isEmpty(response.getMessage())){
            response.setMessage(e.getMessage());
        }
    }

}