package com.simbest.boot.security.auth.oauth2;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2RequestFactory;
import org.springframework.security.oauth2.provider.TokenRequest;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

import com.simbest.boot.security.auth.authentication.PhoneAuthenticationToken;
import com.simbest.boot.util.encrypt.RsaEncryptor;

import lombok.extern.slf4j.Slf4j;

/**
 * 用途：基于RSA加密手机号码的认证OAUTH2方式提交的认证主体
 * 参考：ResourceOwnerPasswordTokenGranter http://www.voidcn.com/article/p-kkszxmkr-bqq.html
 *
 *
 *
 * 请求URL：
 * http://localhost:10987/lawai/oauth/token?grant_type=phonecode&scope=all&client_id=simbest_maip&client_secret=338d6311c8efad8314b9212860adb12e&appcode=lawai&phone=uOj3DA8N9He1/2P2+0/C/GpJOd8jKDF8KxuZF46qIpSWDA8r/O4ztkVTAlrKYrThgOnxX2gCzRZKFTrV8CbRWiAek5dzr3PqguS7udEgCmUBNJyAffQoxAFqX7g4iUh75vmuldp/u0bOJiSbq2VE4hPEcaYfmS53ntOa6in9WDg=&smscode=1234
 */
@Slf4j
public class PhoneTokenGranter extends Oauth2ExtendTokenGranter {

    private static final String GRANT_TYPE = "phone";

    private final AuthenticationManager authenticationManager;

    private RsaEncryptor encryptor;

    public PhoneTokenGranter(AuthenticationManager authenticationManager, AuthorizationServerTokenServices tokenServices,
                             ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory,
                             RsaEncryptor encryptor) {
        this(authenticationManager, tokenServices, clientDetailsService, requestFactory, encryptor, GRANT_TYPE);
    }

    protected PhoneTokenGranter(AuthenticationManager authenticationManager, AuthorizationServerTokenServices tokenServices,
                                ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory,
                                RsaEncryptor encryptor, String grantType) {
        super(tokenServices, clientDetailsService, requestFactory, grantType);
        this.authenticationManager = authenticationManager;
        this.encryptor = encryptor;
        super.setAuthenticationManager(authenticationManager);
    }

    @Override
    protected OAuth2Authentication getOAuth2Authentication(ClientDetails client, TokenRequest tokenRequest) {
        Map<String, String> parameters = new LinkedHashMap<String, String>(tokenRequest.getRequestParameters());
        String appcode = parameters.get("appcode");
        String phone = encryptor.decrypt(parameters.get("phone"));
        log.debug("OAUTH2即将通过PhoneTokenGranter进行认证，appcode【{}】phone【{}】", appcode, phone);
        Authentication userAuth = new PhoneAuthenticationToken(phone, appcode);
        ((AbstractAuthenticationToken) userAuth).setDetails(parameters);
        return this.genericOAuth2Authentication(userAuth, client, tokenRequest);
    }

}