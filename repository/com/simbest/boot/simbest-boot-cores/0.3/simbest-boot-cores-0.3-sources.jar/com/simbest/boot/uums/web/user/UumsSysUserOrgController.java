package com.simbest.boot.uums.web.user;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.security.SimpleUserOrg;
import com.simbest.boot.uums.api.user.UumsSysUserOrginfoApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 系统用户组织关联管理控制器
 * 提供用户与组织关联的REST API接口：
 * - 用户组织关系管理
 * - 组织成员管理
 * - 组织架构查询
 * - 支持分页和后台管理功能
 */
@SuppressWarnings("ALL")
@Api(tags = {"2-统一用户管理", "用户组织管理"}, description = "提供用户与组织关联的REST API接口，包括用户组织关系管理、组织成员管理、组织架构查询、支持分页和后台管理功能等")
@Slf4j
@RestController
@RequestMapping(value = {"/uums/sys/user/org", "/sys/uums/user/org"})
public class UumsSysUserOrgController {

    @Autowired
    private UumsSysUserOrginfoApi uumsSysUserOrginfoApi;

    @Autowired
    private AppConfig appConfig;


    /**
     * 用于管理后台的，查询用户、组织、职务的管理关系
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @param sysUserOrg
     * @return
     */
    @ApiOperation(value = "获取用户组织列表，用于管理后台", notes = "通过此接口来获取用户组织用户组织列表，用于管理后台", tags = {"用户组织API"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "当前页码", dataType = "int", paramType = "query", required = true, example = "1"),
            @ApiImplicitParam(name = "size", value = "每页数量", dataType = "int", paramType = "query",required = true, example = "10"),
            @ApiImplicitParam(name = "direction", value = "排序规则（asc/desc）", dataType = "String",paramType = "query"),
            @ApiImplicitParam(name = "properties", value = "排序规则（属性名称）", dataType = "String",paramType = "query")
    })
    @PostMapping(value = {"/findAllForAdmin","/findAllForAdmin/sso", "/api/findAllForAdmin"})
    public JsonResponse findAllForAdmin(@RequestParam(required = false, defaultValue = "1") int page,
                                        @RequestParam(required = false, defaultValue = "10") int size,
                                        @RequestParam(required = false) String direction,
                                        @RequestParam(required = false) String properties,
                                        @RequestBody SimpleUserOrg userOrg) {
        return uumsSysUserOrginfoApi.findAllForAdmin(page, size, direction, properties, userOrg);
    }

    @ApiOperation(value = "查询人员所属组织信息", notes = "查询人员所属组织信息", tags = {"用户组织API"})
    @PostMapping(value = {"/getOrgInfoByUsername" , "/getOrgInfoByUsername/sso","/api/getOrgInfoByUsername"})
    public JsonResponse getOrgInfoByUsername(@RequestParam String username) {
        return uumsSysUserOrginfoApi.getOrgInfoByUsername(username);
    }

    @ApiOperation(value = "新增用户组织关联信息", notes = "新增用户组织关联信息", tags = {"用户组织API"})
    public JsonResponse create(@RequestBody SimpleUserOrg sysUserOrg) {
        return uumsSysUserOrginfoApi.create(sysUserOrg);
    }

    /**
     *根据id查询用户组织信息
     * @param id
     * @return
     */
    @ApiOperation(value = "根据id查询用户组织信息", notes = "根据id查询用户组织信息", tags = {"用户组织API"})
    @ApiImplicitParam(name = "id", value = "用户ID", dataType = "String", paramType = "query")
    @PostMapping(value = {"/findById","/findById/sso","/api/findById"})
    public JsonResponse findById(@RequestParam String id) {
        return uumsSysUserOrginfoApi.findById(id);
    }

    @ApiOperation(value = "修改用户组织信息", notes = "修改用户组织信息", tags = {"用户组织API"})
    @PostMapping(value = {"/update","/update/sso","/api/update"})
    public JsonResponse update( @RequestBody SimpleUserOrg sysUserOrg) {
        return uumsSysUserOrginfoApi.update(sysUserOrg);
    }

    @ApiOperation(value = "删除用户组织信息", notes = "删除用户组织信息", tags = {"用户组织API"})
    @PostMapping(value = {"/deleteById","/deleteById/sso","/api/deleteById"})
    @ApiImplicitParam(name = "id", value = "用户组织ID",  dataType = "Integer", paramType = "query")
    public JsonResponse deleteById(@RequestParam String id) {
        return uumsSysUserOrginfoApi.deleteById(id);
    }
}