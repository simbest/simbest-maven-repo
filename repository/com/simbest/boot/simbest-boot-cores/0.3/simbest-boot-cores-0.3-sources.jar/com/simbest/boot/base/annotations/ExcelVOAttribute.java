package com.simbest.boot.base.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Excel导入导出字段注解
 * 用于标记实体类中需要进行Excel导入导出的字段
 * 该注解只能应用在字段级别
 * 支持配置导出名称、列位置、列宽、提示信息等属性
 */
@Retention(RetentionPolicy.RUNTIME)
@Target( { java.lang.annotation.ElementType.FIELD })
public @interface ExcelVOAttribute {

    /**
     * 导出到Excel中的字段名称
     * @return 返回Excel中显示的字段名称
     */
    String name();

    /**
     * 配置列的位置，对应Excel中的A,B,C,D等列
     * @return 返回列位置标识
     */
    String column();

    /**
     * 设置Excel列的宽度
     * @return 返回列宽值，默认为0
     */
    int width() default 0;

    /**
     * 设置字段的提示信息
     * @return 返回提示信息，默认为空字符串
     */
    String prompt() default "";

    /**
     * 设置下拉选择框的内容
     * 用于限制用户只能从下拉列表中选择值，不能直接输入
     * @return 返回下拉选项数组，默认为空数组
     */
    String[] combo() default {};

    /**
     * 是否导出数据
     * 用于处理导出模板的场景，当只需要导出标题而内容需要用户手动填写时，可设置为false
     * @return 返回是否导出数据，默认为true
     */
    boolean isExport() default true;

    /**
     * 标记是否导出此列
     * 用于控制特定场景下是否导出该列
     * @return 返回标记数组，默认为空数组
     */
    String[] isTag() default {};
}