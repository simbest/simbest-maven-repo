package com.simbest.boot.uums.web.bloc;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.uums.api.bloc.UumsSysBlocApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 集团信息控制器
 * 提供集团基础信息的管理功能：
 * - 支持根据ID查询集团详细信息
 * - 提供多应用场景下的集团信息访问
 * - 实现集团信息的统一管理和查询
 */
@Api(tags = {"2-统一用户管理", "集团管理"}, description = "提供集团基础信息的管理功能，包括集团信息的查询、集团组织架构的管理、集团级别的权限控制等")
@RestController
@RequestMapping(value = {"/uums/sys/bloc", "/sys/uums/bloc"})
public class UumsSysBlocController {

    @Autowired
    private UumsSysBlocApi uumsSysBlocApi;

    /**
     * 根据ID查询集团信息
     * 提供集团详细信息的查询功能：
     * - 支持通过集团ID精确查询
     * - 需要提供应用编码进行权限控制
     * - 返回集团的完整信息
     *
     * @param id 集团ID
     * @param appcode 应用编码
     * @return 集团信息的JSON响应
     */
    @ApiOperation(value = "查询集团信息",notes = "查询集团信息" )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "id",value = "集团ID", dataType = "String", paramType = "query" ),
        @ApiImplicitParam(name = "appcode", value = "appcode",dataType = "String",paramType = "query" )
    })
    @PostMapping(value="/findById")
    public JsonResponse findById( @RequestParam String id, @RequestParam String appcode) {
        return JsonResponse.success(uumsSysBlocApi.findById(id, appcode));
    }


}