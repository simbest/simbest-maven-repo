package com.simbest.boot.constants;

/**
 * 系统错误码和错误信息常量定义类
 * 
 * 包含以下类别的常量：
 * 1. 错误码常量：
 *    - 应用访问权限错误码（10）
 *    - 附件大小超限错误码（20）
 * 
 * 2. 登录相关错误信息：
 *    - 用户信息验证错误
 *    - 账号密码校验错误
 *    - 验证码错误
 *    - 登录尝试次数超限
 *    - 应用访问权限错误
 * 
 * 3. 运维相关错误信息：
 *    - IP白名单校验错误
 * 
 * 4. 通用错误信息：
 *    - 操作成功提示
 *    - 未知异常提示
 * 
 * 5. 微信相关错误信息：
 *    - 服务器通信异常
 *    - 用户信息获取失败
 *    - 用户信息解析异常
 *    - 手机号码验证错误
 *    - 授权码使用错误
 * 
 * 注意事项：
 * 1. 错误码应当按模块分类，便于管理和维护
 * 2. 错误信息应当清晰明确，便于用户理解
 * 3. 包含格式化占位符的错误信息需要在使用时正确传入参数
 */
public class ErrorCodeConstants {
    // 错误码常量
    public static final Integer ERRORCODE_LOGIN_APP_UNREGISTER_GROUP = 10;    // 应用访问权限错误码
    public static final Integer ERRORCODE_ATTACHMENT_SIZE_EXCEEDS = 20;       // 附件大小超限错误码

    // 登录相关错误信息
    public static final String LOGIN_ERROR_INVALIDATE_USER = "用户信息错误";
    public static final String LOGIN_ERROR_INVALIDATE_USERNAME_PASSWORD = "账号密码校验错误";
    public static final String LOGIN_ERROR_INVALIDATE_CODE = "验证码错误";
    public static final String LOGIN_ERROR_BAD_CREDENTIALS = LOGIN_ERROR_INVALIDATE_USERNAME_PASSWORD;
    public static final String LOGIN_ERROR_EXCEED_MAX_TIMES = "尝试登录错误超过最大次数";
    public static final String LOGIN_APP_UNREGISTER_GROUP = "用户未注册此应用访问群组";

    // 运维相关错误信息
    public static final String LOGIN_ERROR_OPT_IP = "checkIpIsDevOps维护终端IP校验失败，配置中心终端白名单【%s】，当前客户端终端IP地址【%s】，未经授权的维护终端访问。";

    // 通用错误信息
    public static final String SUCCESS_MSG = "操作成功!";
    public static final String UNKNOW_ERROR = "未知异常";

    // 微信相关错误信息
    public static final String WECHAT_ERROR_COMMUNICATION = "微信服务器通讯异常";
    public static final String WECHAT_ERROR_GET_USER = "微信获取用户信息失败";
    public static final String WECHAT_ERROR_PARSE_USER = "解析微信用户信息异常";
    public static final String WECHAT_ERROR_USER_PHONE = "微信用户手机号码后台未登记";
    public static final String WECHAT_ERROR_CODE_BEEN_USED = "code been used";
    public static final String WECHAT_ERROR_CODE_INVALID_USED = "invalid code";
    public static final String WECHAT_ERROR_CODE_BEEN_USED_MSG = "微信CODE不可重复使用";
}