package com.simbest.boot.util.ssh;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.simbest.boot.util.BootAppFileReader;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;

/**
 * SSH连接工具类
 * 
 * 提供以下功能：
 * 1. 基于JSch实现SSH远程连接
 * 2. 支持密码和密钥两种认证方式
 * 3. 提供命令执行和结果获取
 * 4. 支持会话管理和超时控制
 * 5. 实现自定义编码的结果处理
 * 6. 提供目标主机信息的封装
 * 7. 支持连接参数的灵活配置
 * 8. 实现异常的统一处理
 */
@Slf4j
public class SSHUtils {

    private static final String ENCODING = "UTF-8";

    public static Session getJSchSession(DestHost destHost) {
        JSch jsch = new JSch();
        Session session = null;
        try {
            session = jsch.getSession(destHost.getUsername(), destHost.getHost(), destHost.getPort());
            session.setPassword(destHost.getPassword());
            session.setConfig("StrictHostKeyChecking", "no");  // 第一次访问服务器时不用输入yes
            session.setTimeout(destHost.getTimeout());
            session.connect();
        } catch (JSchException e) {
            e.printStackTrace();
        }
        return session;
    }

    /**
     * 免密码方式登录
     * @param destHost
     * @param priKey   密钥
     * @return
     */
    public static Session getJSchSessionByNoPwd(DestHost destHost,String keyFilePath) {
        JSch jsch = new JSch();
        Session session = null;
        try {
            //添加私钥
            jsch.addIdentity(null, BootAppFileReader.getClasspathFileToString(keyFilePath).getBytes(), null,null);
            session = jsch.getSession(destHost.getUsername(), destHost.getHost(), destHost.getPort());
            //session.setPassword(destHost.getPassword());
            session.setConfig("StrictHostKeyChecking", "no");  // 第一次访问服务器时不用输入yes
            session.setTimeout(destHost.getTimeout());
            session.connect();
        } catch (JSchException e) {
            e.printStackTrace();
        }
        return session;
    }


    public static String execCommandByJSch(DestHost destHost, String command) {
        return execCommandByJSch(destHost, command, ENCODING);
    }

    public static String execCommandByJSch(DestHost destHost, String command, String resultEncoding) {
        Session session = getJSchSession(destHost);
        String result = execCommandByJSch(session, command, resultEncoding);
        session.disconnect();
        return result;
    }

    public static String execCommandByJSch(Session session, String command) {
        return execCommandByJSch(session, command, ENCODING);
    }

    public static String execCommandByJSch(Session session, String command, String resultEncoding) {
        ChannelExec channelExec;
        InputStream in;
        String result = null;
        try {
            channelExec = (ChannelExec) session.openChannel("exec");
            in = channelExec.getInputStream();
            channelExec.setCommand(command);
            channelExec.setErrStream(System.err);
            channelExec.connect();
            result = IOUtils.toString(in, resultEncoding);
            channelExec.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSchException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 目标登录主机信息
     */
    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class DestHost {

        private String host = "";
        private String username = "";
        private String password = "";
        private int port = 22;
        private int timeout = 60 * 60 * 1000;

    }


    public static void main(String[] args) {
        try {
            //SSHUtils.DestHost host = new SSHUtils.DestHost("192.168.1.110", "root", "root");
            SSHUtils.DestHost host = new DestHost.DestHostBuilder().host("192.168.1.110").username("root").password("root").build();
            String stdout = "";
//			stdout = SSHUtils.execCommandByJSch(host, "whoami");
            Session shellSession = SSHUtils.getJSchSession(host);
            stdout = SSHUtils.execCommandByJSch(shellSession, "cd ~");
            stdout = SSHUtils.execCommandByJSch(shellSession, "mkdir testtesttest");
            stdout = SSHUtils.execCommandByJSch(shellSession, "whoami");
            shellSession.disconnect();
            System.out.println(stdout);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}