package com.simbest.boot.uums.schedule;

import com.simbest.boot.component.distributed.lock.AppRuntimeMaster;
import com.simbest.boot.component.task.AbstractTaskSchedule;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.sys.repository.SysTaskExecutedLogRepository;
import com.simbest.boot.util.DateUtil;
import com.simbest.boot.uums.api.user.UumsSysUserinfoApi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 用途：每日同步主数据人员变更情况，执行人员缓存清理定时器
 *
 *
 */
@Slf4j
@Component
public class UumsSysUserTask extends AbstractTaskSchedule {

    public static final String UUMS_USER_DETAILS = "details";
    public static final String UUMS_USER_USERNAME = "USERNAME";

    @Autowired
    private AppConfig config;

    @Autowired
    private UumsSysUserinfoApi uumsSysUserinfoApi;

    @Autowired
    public UumsSysUserTask(AppRuntimeMaster master, SysTaskExecutedLogRepository repository) {
        super(master, repository);
    }

    @Scheduled(cron = "0 0 5 * * ?")
    public void checkAndExecute() {
        super.checkAndExecute(false);
    }

    /**
     * @see com.simbest.boot.sys.service.ISysHealthService
     * @return
     */
    @Override
    public String execute() {
        if(config.isCleanCacheUser()) {
            String startTime = DateUtil.getYesterday();
            String endTime = DateUtil.getDate(DateUtil.removeTime(DateUtil.getCurrent()));
            Map<String,Object> timUserInfosMap = uumsSysUserinfoApi.CleanUserCacheByFindTimUserInfos(startTime, endTime);
            return String.format("【%s】至【%s】清理了【%s】条用户缓存",startTime, endTime, timUserInfosMap.size());
        }
        return CHECK_SUCCESS;
    }
}