package com.simbest.boot.security.auth.authentication.principal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.security.Principal;

/**
 * 基于用户名的认证主体
 * 
 * 主要功能：
 * 1. 实现基于用户名的认证主体
 * 2. 支持SSO单点登录认证
 * 3. 实现Principal和Serializable接口
 * 
 * 认证流程：
 * 1. 接收用户名信息
 * 2. 创建认证主体
 * 3. 用于后续的身份验证
 * 
 * 应用场景：
 * - 用户名密码登录
 * - SSO单点登录
 * - OAuth2认证
 * - 其他基于用户名的认证场景
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UsernamePrincipal implements Principal, Serializable {

    /**
     * 用户名
     * 用于：
     * 1. 作为用户的唯一标识
     * 2. 用于身份认证和授权
     * 3. 关联用户的其他信息
     */
    private String username;

    /**
     * 获取认证主体名称
     * 实现Principal接口的方法
     * 
     * @return 返回用户名作为认证主体的名称
     */
    @Override
    public String getName() {
        return username;
    }
}