package com.simbest.boot.uums.web.corp;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.uums.api.corp.UumsSysCorpApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 企业信息控制器
 * 提供企业基础信息的管理功能：
 * - 支持根据ID查询企业详细信息
 * - 提供多应用场景下的企业信息访问
 * - 实现企业信息的统一管理和查询
 */
@Api(tags = {"2-统一用户管理", "企业管理"}, description = "提供企业基础信息的管理功能，包括企业信息的查询、企业组织架构的管理、企业级别的权限控制等")
@RestController
@RequestMapping(value = {"/uums/sys/corp", "/sys/uums/corp"})
public class UumsSysCorpController {

    @Autowired
    private UumsSysCorpApi uumsSysCorpApi;

    /**
     * 根据ID查询企业信息
     * 提供企业详细信息的查询功能：
     * - 支持通过企业ID精确查询
     * - 需要提供应用编码进行权限控制
     * - 返回企业的完整信息
     *
     * @param id 企业ID
     * @param appcode 应用编码
     * @return 企业信息的JSON响应
     */
    @ApiOperation(value = "查询企业信息",notes = "查询企业信息" )
    @ApiImplicitParams({
        @ApiImplicitParam(name = "id",value = "企业ID", dataType = "String", paramType = "query" ),
        @ApiImplicitParam(name = "appcode", value = "appcode",dataType = "String",paramType = "query" )
    })
    @PostMapping(value="/findById")
    public JsonResponse findById( @RequestParam String id, @RequestParam String appcode) {
        return JsonResponse.success(uumsSysCorpApi.findById(id, appcode));
    }


}