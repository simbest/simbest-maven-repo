package com.simbest.boot.component.distributed.lock;

import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import lombok.extern.slf4j.Slf4j;
import org.redisson.RedissonShutdownException;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * 基于Redisson实现的分布式锁工具类
 * 
 * 主要功能：
 * 1. 提供基于Redis的分布式锁实现，支持公平锁机制
 * 2. 支持多种加锁方式：
 *    - 强制加锁（需手动解锁）
 *    - 自动超时解锁
 *    - 带回调的加锁方式
 * 3. 支持锁的自动释放和手动释放
 * 4. 提供防死锁机制，确保锁最终会被释放
 * 
 * 使用说明：
 * 1. 所有方法都是静态方法，使用前需确保已完成初始化
 * 2. 锁的命名建议：业务模块名 + 具体业务含义，如：order_create_
 * 3. 优先使用带回调的加锁方法，可以确保锁的正确释放
 * 
 * 注意事项：
 * 1. 使用强制加锁时必须手动解锁，建议在finally块中进行
 * 2. 避免长时间持有锁，建议设置合理的超时时间
 * 3. 处理好异常情况，特别是RedissonShutdownException
 */
@Slf4j
@Component
public class DistributedRedisLock {

    public final static String REDISSON_REDIS_LOCK = "redisson_lock_";

    public final static String REDISSON_LOCK_KEY_PREFIX = "redisson_lock_key_prefix_";
    
    @Autowired
    private RedissonClient redisson;

    @Autowired
    private AppConfig config;

    private static String redisKeyPrefix;

    private static DistributedRedisLock lockUtils;

    @PostConstruct
    public void init() {
        lockUtils = this;
        lockUtils.redisson = this.redisson;
        lockUtils.redisKeyPrefix = REDISSON_LOCK_KEY_PREFIX + config.getRedisKeyPrefix();
    }

    /**
     * 强制获取分布式锁，需要手动解锁
     * 
     * @param lockName 锁的名称，建议：业务模块名 + 具体业务含义
     * @throws RedissonShutdownException 当Redisson客户端关闭时抛出
     */
    public static void lock(String lockName){
        String key = redisKeyPrefix + lockName;
        RLock mylock = lockUtils.redisson.getFairLock(key);
        mylock.lock();
    }

    /**
     * 强制获取带超时的分布式锁，到期自动解锁
     * 
     * @param lockName 锁的名称，建议：业务模块名 + 具体业务含义
     * @param timeoutSeconds 锁的超时时间（秒），超时后自动解锁
     */
    public static void lock(String lockName, int timeoutSeconds){
        String key = redisKeyPrefix + lockName;
        RLock mylock = lockUtils.redisson.getFairLock(key);
        try {
            mylock.lock(timeoutSeconds, ApplicationConstants.REDIS_LOCK_DEFAULT_TIME_UNIT);
        } catch (Exception e){
            log.warn("【{}】尝试lock加锁失败，发生【{}】异常", lockName, e.getMessage());
        }
    }

    /**
     * 获取带回调的分布式锁，执行完回调后自动解锁
     * 
     * @param lockName 锁的名称，建议：业务模块名 + 具体业务含义
     * @param timeoutSeconds 锁的超时时间（秒），超时后自动解锁
     * @param callback 获取锁后要执行的回调逻辑
     * @return <T> 回调方法的返回值
     */
    public static <T> T lock(String lockName, int timeoutSeconds, DistributedLockCallback<T> callback){
        T returnObj = null;
        String key = redisKeyPrefix + lockName;
        RLock mylock = lockUtils.redisson.getFairLock(key);
        try {
            mylock.lock(timeoutSeconds, ApplicationConstants.REDIS_LOCK_DEFAULT_TIME_UNIT);
            if (mylock != null && mylock.isLocked()) {
                returnObj = callback.process();
            }
        }
        catch (RedissonShutdownException e) {
            log.warn("【{}】尝试lock加锁失败，发生【{}】异常", lockName, e.getMessage());
        }
        finally {
            try{
                if (mylock != null && mylock.isLocked() && mylock.isHeldByCurrentThread()) {
                    mylock.unlock();
                }
            }catch (Exception e){
                log.warn("【{}】尝试unlock解锁失败，发生【{}】异常", lockName, e.getMessage());
            }
        }
        return returnObj;
    }

    /**
     * 手动释放分布式锁
     * 
     * @param lockName 要释放的锁的名称
     * 注意：
     * 1. 只能释放当前线程持有的锁
     * 2. 如果锁已经被释放，则忽略
     * 3. 建议在finally块中调用此方法
     */
    public static void unlock(String lockName){
        try {
            String key = redisKeyPrefix + lockName;
            RLock mylock = lockUtils.redisson.getFairLock(key);
            if (mylock != null && mylock.isLocked() && mylock.isHeldByCurrentThread()) {
                mylock.unlock();
            }
        }catch (Exception e){
            log.warn("【{}】尝试unlock解锁失败，发生【{}】异常", lockName, e.getMessage());
        }
    }

    /**
     * 尝试获取分布式锁，可设置等待时间和自动释放时间
     * 
     * @param lockName 锁的名称
     * @param waitSeconds 最大等待时间（秒）
     * @param releaseSeconds 自动释放时间（秒）
     * @return DistributedRedissonLock 包含锁对象和是否获取成功的信息
     * @deprecated 建议使用带回调的加锁方法
     */
    @Deprecated
    public static DistributedRedissonLock tryLock(String lockName, long waitSeconds, long releaseSeconds){
        String key = redisKeyPrefix + lockName;
        RLock mylock = lockUtils.redisson.getFairLock(key);
        try {
            //最多等待waitSeconds秒，获得锁后releaseSeconds秒自动解锁
            boolean locked = mylock.tryLock(waitSeconds, releaseSeconds, ApplicationConstants.REDIS_LOCK_DEFAULT_TIME_UNIT);
            return DistributedRedissonLock.builder().rLock(mylock).isLocked(locked).build();
        }
        catch (RedissonShutdownException e) {
            log.warn("【{}】尝试lock加锁失败，发生【{}】异常", lockName, e.getMessage());
        }
        catch (InterruptedException e) {
            log.warn("【{}】尝试lock加锁失败，发生【{}】异常", lockName, e.getMessage());
        }
        return DistributedRedissonLock.builder().rLock(mylock).isLocked(false).build();
    }

    /**
     * 尝试获取分布式锁并执行回调
     * 
     * @param lockName 锁的名称
     * @param callback 获取锁后要执行的回调逻辑
     * @return <T> 回调方法的返回值
     * @deprecated 建议使用新的lock方法
     */
    @Deprecated
    public static <T> T tryLock(String lockName, DistributedLockCallback<T> callback){
        String key = redisKeyPrefix + lockName;
        return tryLock(key, ApplicationConstants.REDIS_LOCK_WAIT_TIMEOUT, ApplicationConstants.REDIS_LOCK_RELEASE_TIMEOUT, callback);
    }

    /**
     * 尝试获取分布式锁并执行回调，可设置等待时间和自动释放时间
     * 
     * @param lockName 锁的名称
     * @param waitSeconds 最大等待时间（秒）
     * @param releaseSeconds 自动释放时间（秒）
     * @param callback 获取锁后要执行的回调逻辑
     * @return <T> 回调方法的返回值
     * @deprecated 建议使用新的lock方法
     */
    @Deprecated
    public static <T> T tryLock(String lockName, long waitSeconds, long releaseSeconds, DistributedLockCallback<T> callback){
        T returnObj = null;
        String key = redisKeyPrefix + lockName;
        RLock mylock = lockUtils.redisson.getFairLock(key);
        try {
            //最多等待waitSeconds秒，获得锁后releaseSeconds秒自动解锁
            boolean locked = mylock.tryLock(waitSeconds, releaseSeconds, ApplicationConstants.REDIS_LOCK_DEFAULT_TIME_UNIT);
            if(locked){
                returnObj = callback.process();
            }
        }
        catch (RedissonShutdownException e) {
            log.warn("【{}】尝试lock加锁失败，发生【{}】异常", lockName, e.getMessage());
        }
        catch (InterruptedException e) {
            log.warn("【{}】尝试lock加锁失败，发生【{}】异常", lockName, e.getMessage());
        } finally {
            try {
                if (mylock != null && mylock.isLocked()) {
                    mylock.unlock();
                }
            }catch (Exception e){
                log.warn("【{}】尝试unlock解锁失败，发生【{}】异常", lockName, e.getMessage());
                Exceptions.printException(e);
            }
        }
        return returnObj;
    }
}