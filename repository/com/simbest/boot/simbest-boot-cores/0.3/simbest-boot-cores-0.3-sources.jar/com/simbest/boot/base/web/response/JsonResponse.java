package com.simbest.boot.base.web.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.simbest.boot.constants.ErrorCodeConstants;
import com.simbest.boot.util.DateUtil;
import com.simbest.boot.util.json.JacksonUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.http.HttpStatus;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

import static com.simbest.boot.constants.AuthoritiesConstants.ACCESS_FORBIDDEN;

/**
 * Restful接口通用响应对象
 * 
 * 功能特点：
 * 1. 标准响应格式：
 *    - 错误码（errcode）：0表示成功，非0表示失败
 *    - 时间戳（timestamp）：响应生成时间
 *    - HTTP状态（status）：标准HTTP状态码
 *    - 错误信息（error）：错误类型描述
 *    - 提示信息（message）：用户友好的提示
 *    - 请求路径（path）：当前请求的URL
 *    - 业务数据（data）：实际返回的数据
 * 
 * 2. 响应类型：
 *    - 成功响应：errcode=0, status=200
 *    - 失败响应：errcode=-1, status=500
 *    - 未授权响应：errcode=401, status=401
 * 
 * 3. 便捷方法：
 *    - 支持快速创建成功/失败响应
 *    - 支持自定义错误码和提示信息
 *    - 支持权限验证响应
 */
@Slf4j
@Data
@AllArgsConstructor
@NoArgsConstructor
@RequiredArgsConstructor
@Builder
@ApiModel(description = "Restful接口通用响应对象")
public class JsonResponse {
    
    /**
     * 成功响应的错误码
     */
    @ApiModelProperty(value = "成功响应的错误码", example = "0")
    public static final int SUCCESS_CODE = 0;

    /**
     * 失败响应的错误码
     */
    @ApiModelProperty(value = "失败响应的错误码", example = "-1")
    public static final int ERROR_CODE = -1;

    /**
     * 成功响应的HTTP状态码
     */
    @ApiModelProperty(value = "成功响应的HTTP状态码", example = "200")
    public static final int SUCCESS_STATUS = 200;

    /**
     * 失败响应的HTTP状态码
     */
    @ApiModelProperty(value = "失败响应的HTTP状态码", example = "500")
    public static final int ERROR_STATUS = 500;

    /**
     * 错误码，0表示成功，非0表示失败
     */
    @NonNull
    @ApiModelProperty(value = "错误码（0表示成功，非0表示失败）", required = true, example = "0")
    private Integer errcode;

    /**
     * 响应时间戳
     */
    @CreationTimestamp
    @JsonFormat(pattern = DateUtil.timestampPattern1, timezone = "GMT+8")
    @ApiModelProperty(value = "响应时间戳", example = "2024-01-01 12:00:00")
    private Date timestamp;

    /**
     * HTTP状态码
     */
    @ApiModelProperty(value = "HTTP状态码", example = "200")
    private int status;

    /**
     * 错误类型描述
     */
    @ApiModelProperty(value = "错误类型描述", example = "Internal Server Error")
    private String error;

    /**
     * 提示信息
     */
    @ApiModelProperty(value = "提示信息", example = "操作成功")
    private String message;

    /**
     * 请求路径
     */
    @ApiModelProperty(value = "请求路径", example = "/api/users")
    private String path;

    /**
     * 响应数据
     */
    @ApiModelProperty(value = "响应数据")
    private Object data;

    /**
     * 创建默认成功响应
     * 
     * @return 成功响应对象，errcode=0，status=200
     */
    public static JsonResponse defaultSuccessResponse() {
        return JsonResponse.builder().errcode(SUCCESS_CODE).timestamp(DateUtil.getCurrent())
                .status(SUCCESS_STATUS).build();
    }

    /**
     * 创建默认失败响应
     * 
     * @return 失败响应对象，errcode=-1，status=500，包含默认错误信息
     */
    public static JsonResponse defaultErrorResponse() {
        JsonResponse jsonResponse = JsonResponse.builder().errcode(ERROR_CODE).message(ErrorCodeConstants.UNKNOW_ERROR)
                .timestamp(DateUtil.getCurrent()).status(ERROR_STATUS).build();
        /**
         * 注释该代码，避免系统路径信息泄露
         *
         */
//        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
//        if(null != requestAttributes){
//            jsonResponse.setPath(((ServletRequestAttributes)requestAttributes).getRequest().getServletPath());
//        }
        return jsonResponse;
    }

    /**
     * 创建带数据的成功响应
     * 
     * @param obj 响应数据
     * @return 成功响应对象，包含响应数据
     */
    public static JsonResponse success(Object obj) {
        JsonResponse response = success(obj, null);
        return response;
    }

    /**
     * 创建带数据的失败响应
     * 
     * @param obj 响应数据
     * @return 失败响应对象，包含响应数据
     */
    public static JsonResponse fail(Object obj) {
        JsonResponse response = defaultErrorResponse();
        response.setData(obj);
        return response;
    }

    /**
     * 创建带提示信息的成功响应
     * 
     * @param message 提示信息
     * @return 成功响应对象，包含提示信息
     */
    public static JsonResponse success(String message) {
        JsonResponse response = success(null, message);
        return response;
    }

    /**
     * 创建带提示信息的失败响应
     * 
     * @param message 提示信息
     * @return 失败响应对象，包含提示信息
     */
    public static JsonResponse fail(String message) {
        JsonResponse response = fail(null, message);
        return response;
    }

    /**
     * 创建带数据和提示信息的成功响应
     * 
     * @param obj 响应数据
     * @param message 提示信息
     * @return 成功响应对象，包含响应数据和提示信息
     */
    public static JsonResponse success(Object obj, String message) {
        JsonResponse response = defaultSuccessResponse();
        response.setData(obj);
        response.setMessage(message);
        return response;
    }

    /**
     * 创建带数据和提示信息的失败响应
     * 
     * @param obj 响应数据
     * @param message 提示信息
     * @return 失败响应对象，包含响应数据和提示信息
     */
    public static JsonResponse fail(Object obj, String message) {
        JsonResponse response = fail(obj);
        response.setMessage(message);
        return response;
    }

    /**
     * 创建带数据、提示信息和错误码的失败响应
     * 
     * @param obj 响应数据
     * @param message 提示信息
     * @param errcode 错误码（参见ErrorCodeConstants）
     * @return 失败响应对象，包含响应数据、提示信息和错误码
     */
    public static JsonResponse fail(Object obj, String message, Integer errcode) {
        JsonResponse response = fail(obj);
        response.setMessage(message);
        return response;
    }

    /**
     * 创建未授权响应（无参数）
     * 
     * @return 未授权响应对象，status=401
     */
    public static JsonResponse unauthorized() {
        JsonResponse response =  JsonResponse.builder().
                errcode(HttpStatus.UNAUTHORIZED.value())
                .status(HttpStatus.UNAUTHORIZED.value())
                .error(HttpStatus.UNAUTHORIZED.name())
                .message(ACCESS_FORBIDDEN)
                .timestamp(new Date())
                .build();
        log.warn("无权限访问，即将返回【{}】", JacksonUtils.obj2json(response));
        return response;
    }

    /**
     * 创建未授权响应（带请求和异常信息）
     * 
     * @param request HTTP请求对象
     * @param exception 导致未授权的异常
     * @return 未授权响应对象，包含异常信息
     */
    public static JsonResponse unauthorized(HttpServletRequest request, Exception exception) {
        JsonResponse response = JsonResponse.builder().
                errcode(HttpStatus.UNAUTHORIZED.value())
                .status(HttpStatus.UNAUTHORIZED.value())
                .error(exception.getMessage())
                .timestamp(new Date())
                .message(ACCESS_FORBIDDEN)
                /**
                 * 注释该代码，避免系统路径信息泄露
                 *
                 */
//                .path(request.getRequestURI())
                .build();
        log.warn("无权限访问，即将返回【{}】", JacksonUtils.obj2json(response));
        return response;
    }

    /**
     * 创建已授权响应
     * 
     * @return 已授权响应对象，errcode=0，status=200
     */
    public static JsonResponse authorized() {
        return JsonResponse.builder().
                errcode(SUCCESS_CODE)
                .status(HttpStatus.OK.value())
                .error(HttpStatus.OK.name())
                .build();
    }
}