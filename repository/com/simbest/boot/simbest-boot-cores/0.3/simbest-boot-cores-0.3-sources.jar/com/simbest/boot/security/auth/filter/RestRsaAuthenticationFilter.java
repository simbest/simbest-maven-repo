package com.simbest.boot.security.auth.filter;

import lombok.extern.slf4j.Slf4j;

/**
 * 用途：REST方式，基于数据库的主数据登录认证拦截器，拦截/restlogin请求
 *
 *
 */
@Slf4j
public class RestRsaAuthenticationFilter extends RsaAuthenticationFilter {


}