package com.simbest.boot.security.auth.oauth2;

import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.OAuth2RequestFactory;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

/**
 * 抽象的TokenGranter，如果应用自定义，则在ApiSecurityConfigurer进行加载
 */
public abstract class CustomExtraOauth2ExtendTokenGranter extends Oauth2ExtendTokenGranter {

    private OAuth2RequestFactory requestFactory;

    protected CustomExtraOauth2ExtendTokenGranter(AuthorizationServerTokenServices tokenServices, ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory, String grantType) {
        super(tokenServices, clientDetailsService, requestFactory, grantType);
    }

    public void setRequestFactory(OAuth2RequestFactory requestFactory) {
        super.setRequestFactory(requestFactory);
        this.requestFactory = requestFactory;
    }

}