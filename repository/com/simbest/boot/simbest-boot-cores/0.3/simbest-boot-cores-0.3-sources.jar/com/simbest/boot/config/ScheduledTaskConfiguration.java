package com.simbest.boot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import java.util.concurrent.Executors;

/**
 * 定时任务配置类
 * 主要功能：
 * 1. 启用Spring定时任务和异步执行功能
 * 2. 自定义定时任务线程池，提供更好的任务隔离和资源管理
 * 3. 配置10个线程的定时任务线程池，避免任务相互影响
 * 
 * 实现说明：
 * 1. 默认的Spring定时任务只有单线程，可能导致任务相互阻塞
 * 2. 本配置通过自定义线程池解决以下问题：
 *    - 避免单个任务阻塞影响其他任务执行
 *    - 合理分配系统资源，提高任务执行效率
 *    - 提供更好的任务隔离，增强系统稳定性
 * 
 * 注意事项：
 * 1. 选择自定义线程池而不是异步执行的原因：
 *    - 异步执行可能在任务异常时导致资源耗尽
 *    - 自定义线程池能更好地控制资源使用
 * 2. 线程池大小设置为10，可根据实际需求调整
 * 3. 建议在任务实现时添加适当的超时控制
 */
@Configuration
@EnableAsync
@EnableScheduling
public class ScheduledTaskConfiguration implements SchedulingConfigurer {

    /**
     * 配置定时任务的执行器
     * 创建固定大小的线程池，用于执行所有的定时任务
     *
     * @param taskRegistrar 定时任务注册器
     */
    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        // 创建10个线程的定时任务线程池
        // 每个任务独占一个线程，避免相互影响
        taskRegistrar.setScheduler(Executors.newScheduledThreadPool(10));
    }
}