package com.simbest.boot.config;

import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;

/**
 * 用途：Spring Session Redis初始化器
 * 主要提供以下功能：
 * 1. 初始化Spring Session与Redis的集成
 * 2. 配置Session存储和管理
 * 3. 支持分布式Session共享
 * 
 * 该初始化器继承自AbstractHttpSessionApplicationInitializer，
 * 用于自动配置Spring Session的基础设施，包括：
 * - Session存储方式（Redis）
 * - Session序列化方式
 * - Session过期策略
 * - Session事件监听等
 */
public class Initializer extends AbstractHttpSessionApplicationInitializer {
    // 继承默认实现即可，无需额外配置
}