package com.simbest.boot.base.web.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.Sets;
import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.util.DateUtil;
import com.simbest.boot.util.json.JacksonUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * CSRF防护过滤器
 * 基于HTTP Referer字段的CSRF攻击防御实现
 * 
 * 功能特点：
 * 1. 通过验证HTTP请求的Referer字段来防御CSRF攻击
 * 2. 支持配置白名单主机列表，包括：
 *    - 固定IP地址（如：127.0.0.1）
 *    - 域名（如：portal.ha.cmcc）
 *    - IP地址段（使用正则表达式匹配）
 * 3. 白名单配置格式：
 *    - 固定IP和域名：使用逗号分隔
 *    - IP地址段：使用正则表达式，与固定IP/域名部分使用#分隔
 *    - 示例：app.security.white.hosts=localhost,127.0.0.1,portal.ha.cmcc#^10\\.87\\.(57|41|151)\\.\\d+
 * 4. 对非白名单来源的请求：
 *    - 记录详细的错误日志
 *    - 返回403禁止访问响应
 *    - 包含具体的错误信息
 */
@Slf4j
@WebFilter(urlPatterns = "/*", filterName = "csrfProtectFilter",asyncSupported = true)
public class CsrfProtectFilter implements Filter {

    /**
     * 固定IP和域名白名单集合
     * 存储允许访问的具体IP地址和域名
     */
    private Set<String> whiteHostList = Sets.newHashSet();

    /**
     * IP地址段正则表达式白名单集合
     * 存储允许访问的IP地址段的正则表达式模式
     */
    private Set<String> whiteHostPattern = Sets.newHashSet();

    /**
     * 应用配置对象
     * 用于获取白名单配置信息
     */
    @Autowired
    private AppConfig appConfig;

    /**
     * 初始化过滤器，加载白名单配置
     * 
     * 配置格式说明：
     * 1. 固定IP和域名部分：使用逗号分隔的列表
     *    示例：localhost,127.0.0.1,portal.ha.cmcc
     * 2. IP地址段部分：使用正则表达式，与第一部分用#分隔
     *    示例：^10\\.87\\.(57|41|151)\\.\\d+
     * 
     * 完整配置示例：
     * app.security.white.hosts=localhost,127.0.0.1,portal.ha.cmcc#^10\\.87\\.(57|41|151)\\.\\d+
     *
     * @param filterConfig 过滤器配置对象
     * @throws ServletException 初始化异常
     */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        String whiteHosts = appConfig.getWhiteHostList();
        if(StringUtils.isNotEmpty(whiteHosts)){
            log.info("Csrf 防盗链主机源端白名单为：");
            log.info(whiteHosts);
            String[] whiteHostsAll = whiteHosts.split(ApplicationConstants.HASH);
            String[] whiteHostsIPs = whiteHostsAll[ApplicationConstants.ZERO].split(ApplicationConstants.COMMA);
            //提取固定IP或域名
            for(String s:whiteHostsIPs){
                whiteHostList.add(s.toLowerCase());
            }
            //提取IP地址段正则表达式
            if(whiteHostsAll.length > ApplicationConstants.ONE){
                for(int i=ApplicationConstants.ONE; i<whiteHostsAll.length; i++){
                    whiteHostPattern.add(whiteHostsAll[i]);
                }
            }
        }
    }

    /**
     * 执行CSRF防护过滤逻辑
     * 
     * 处理流程：
     * 1. 获取请求的Referer字段
     * 2. 如果Referer为空，允许请求通过（适用于直接访问或首次请求）
     * 3. 解析Referer中的主机地址
     * 4. 检查主机是否在白名单中：
     *    - 检查固定IP和域名白名单
     *    - 检查IP地址段正则表达式白名单
     * 5. 处理结果：
     *    - 白名单内的请求：允许通过
     *    - 白名单外的请求：返回403错误，并记录详细日志
     *
     * @param servletRequest 请求对象
     * @param servletResponse 响应对象
     * @param filterChain 过滤器链
     * @throws IOException IO异常
     * @throws ServletException Servlet异常
     */
    @Override
    public void doFilter(
            ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        log.debug("访问目录URL地址为【{}】", request.getRequestURI());
        // 链接来源地址，通过获取请求头 referer 得到
        String referer = request.getHeader("referer");
        try {
            if (referer != null) {
                URI referUri = new URI(referer);
                String host = referUri.getHost().toLowerCase();
                host = StringUtils.removeStart(host, "[");
                host = StringUtils.removeEnd(host, "]");
                boolean ipCheck = false;
                boolean patternCheck = false;
                if (whiteHostList.size()>0){
                    if(whiteHostList.contains(host)){
                        ipCheck = true;
                    }
                }
                if (whiteHostPattern.size()>0){
                    for(String pattern : whiteHostPattern){
                        Pattern r = Pattern.compile(pattern);
                        Matcher m = r.matcher(host);
                        if(m.find()){
                            patternCheck = true;
                        }
                    }
                }
                if(ipCheck | patternCheck){
                    filterChain.doFilter(request, response);
                }
                else {
                    log.error("Csrf 防盗链主机源端白名单为【{}】, 当前主机【{}】不在白名单内，禁止访问!", appConfig.getWhiteHostList(), host);
                    PrintWriter writer = servletResponse.getWriter();
                    JsonResponse jsonResponse = JsonResponse.builder().errcode(JsonResponse.ERROR_CODE).timestamp(DateUtil.getCurrent())
                            .status(JsonResponse.ERROR_STATUS).path(request.getServletPath())
                            .message("Forbidden: invalid host access: "+host).build();
                    String jsonResponseStr = JacksonUtils.obj2json(jsonResponse);
                    writer.write(jsonResponseStr);
                    writer.flush();
                    writer.close();
                }
            }else {
                filterChain.doFilter(request, response);
            }
        } catch (URISyntaxException e) {
            Exceptions.printException(e);
        }
    }

    /**
     * 销毁过滤器
     * 清理资源，目前无需特殊处理
     */
    @Override
    public void destroy() {
    }

    /**
     * 测试方法：验证IP和域名匹配规则
     * 
     * 测试用例包括：
     * 1. IPv6地址匹配
     *    - fe80开头的本地链路地址
     *    - 2409开头的电信IPv6地址
     * 2. IPv4地址匹配
     *    - 10.87.x.x网段
     *    - 10.92.x.x网段
     * 3. 域名匹配
     *    - *.cmcc域名
     *    - *.chinamobile.com域名
     * 
     * 输出格式：
     * IP/域名====匹配结果(true/false)
     *
     * @param args 命令行参数（未使用）
     */
    public static void main(String[] args) {
        String pattern1 = "^(fe80|2409):.*$|^0:0:0:0:0:0:0:1$|^::1$|^10\\.87\\.(57|41|151|9|13)\\.\\d+|10\\.(92|228|88)\\.\\d+\\.\\d+";
//        pattern1 = "^(fe80|2409):.*$|^0:0:0:0:0:0:0:1$|^::1$|^10\\.87\\.(57|41|151)\\.\\d+|10\\.(92|228|88)\\.\\d+\\.\\d+|([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\\.)+ha\\.cmcc$";
        pattern1 = "^(fe80|2409):.*$|^0:0:0:0:0:0:0:1$|^::1$|^10\\.87\\.(57|41|151|9|13)\\.\\d+|10\\.(92|228|88)\\.\\d+\\.\\d+|([a-z0-9]+\\.)*cmcc$|([a-z0-9]+\\.)*chinamobile\\.com$";
        String ipv6_1 = "fe80::3b53:230a:e3a8:9728";
        String ipv6_2 = "2409:8044:58c1:bbf8::4:7";
        String ipv6_3 = "2001:db8::1";
        String ipv4_4 = "10.87.151.9";
        String ipv4_5 = "10.87.140.9";
        String ipv4_6 = "10.92.82.141";
        String ipv4_7 = "10.92.81.163";
        String ipv4_8 = "nccpn.ha.cmcc";
        String ipv4_9 = "anddoc.ha.cmcc";
        String ipv4_10 = "nccpn.com";
        String ipv4_11 = "m.ha.chinamobile.com";
        String ipv4_12 = "m.ha.chinamobile.com1";

        Pattern r1 = Pattern.compile(pattern1);
        Matcher m1 = r1.matcher(ipv6_1);
        System.out.println(ipv6_1 + "====" + m1.find()); // true
        m1 = r1.matcher(ipv6_2);
        System.out.println(ipv6_2 + "====" + m1.find()); // true
        m1 = r1.matcher(ipv4_4);
        System.out.println(ipv4_4 + "====" + m1.find()); // true
        m1 = r1.matcher(ipv4_6);
        System.out.println(ipv4_6 + "====" + m1.find()); // true
        m1 = r1.matcher(ipv4_7);
        System.out.println(ipv4_7 + "====" + m1.find()); // true
        m1 = r1.matcher(ipv4_8);
        System.out.println(ipv4_8 + "====" + m1.find()); // true
        m1 = r1.matcher(ipv4_9);
        System.out.println(ipv4_9 + "====" + m1.find()); // true
        m1 = r1.matcher(ipv4_11);
        System.out.println(ipv4_11 + "====" + m1.find()); // true
        System.out.println("-------------------------------FALSE--------------------------");
        m1 = r1.matcher(ipv6_3);
        System.out.println(ipv6_3 + "====" + m1.find()); // false
        m1 = r1.matcher(ipv4_5);
        System.out.println(ipv4_5 + "====" + m1.find()); // false
        m1 = r1.matcher(ipv4_10);
        System.out.println(ipv4_10 + "====" + m1.find()); // false
        m1 = r1.matcher(ipv4_12);
        System.out.println(ipv4_12 + "====" + m1.find()); // false
    }
}