package com.simbest.boot.security.auth.authentication.wxmp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

/**
 * 微信公众号认证凭据
 * 
 * 主要功能：
 * 1. 封装微信公众号登录认证所需的凭据信息
 * 2. 支持序列化，便于分布式环境下的数据传输
 * 3. 提供认证所需的必要信息管理
 * 
 * 认证流程：
 * 1. 获取微信公众号登录code
 * 2. 验证应用和公众号的身份
 * 3. 支持自动创建新用户
 * 
 * 应用场景：
 * - 微信公众号OAuth2登录
 * - 用户身份验证
 * - 新用户自动注册
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WxmpAuthenticationCredentials implements Serializable {

    /**
     * 应用代码
     * 用于：
     * 1. 标识请求来源的应用系统
     * 2. 支持多应用认证场景
     * 3. 应用级别的权限控制
     */
    private String appcode;

    /**
     * 微信公众号的AppID
     * 用于：
     * 1. 标识具体的微信公众号
     * 2. 调用微信开放接口
     * 3. 验证请求的合法性
     */
    private String appid;

    /**
     * 微信公众号登录code
     * 用于：
     * 1. 换取用户openid和access_token
     * 2. 微信身份验证
     * 3. 临时凭证，有效期5分钟
     */
    private String wxcode;

    /**
     * 是否自动创建用户标志
     * 用于：
     * 1. 控制未注册用户的处理策略
     * 2. true表示自动创建新用户
     * 3. false表示仅允许已存在用户登录
     */
    private Boolean forceCreate;

    /**
     * 重写toString方法
     * 使用反射方式输出对象信息，便于调试和日志记录
     * 
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}