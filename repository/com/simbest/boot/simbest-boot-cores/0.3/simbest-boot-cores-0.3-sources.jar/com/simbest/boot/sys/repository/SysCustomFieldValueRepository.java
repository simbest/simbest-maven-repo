package com.simbest.boot.sys.repository;

import com.simbest.boot.base.repository.LogicRepository;
import com.simbest.boot.sys.model.SysCustomFieldValue;
import org.springframework.stereotype.Repository;

/**
 * 用途：实体自定义字段值持久层
 *
 *
 */
@Repository
public interface SysCustomFieldValueRepository extends LogicRepository<SysCustomFieldValue, String> {

}