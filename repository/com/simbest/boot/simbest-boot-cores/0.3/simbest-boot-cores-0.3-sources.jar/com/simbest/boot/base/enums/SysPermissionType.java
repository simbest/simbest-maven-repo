package com.simbest.boot.base.enums;

import lombok.Getter;
import lombok.Setter;

/**
 * 系统权限类型枚举
 * 用于定义系统中不同类型的权限
 * 实现了GenericEnum接口，提供统一的枚举值获取方法
 */
public enum SysPermissionType implements GenericEnum {

    /**
     * 根权限，用于权限树的根节点
     */
    ROOT("根"),
    
    /**
     * 菜单访问权限，控制页面访问
     */
    MENU("访问路径"),
    
    /**
     * 按钮操作权限，控制按钮的显示和操作
     */
    BUTTON("按钮"),
    
    /**
     * 方法执行权限，控制后端方法的调用
     */
    METHOD("执行方法"),
    
    /**
     * 功能模块权限，用于功能模块的权限控制
     */
    MODULE("功能模块");

    /**
     * 枚举值的中文描述
     */
    @Setter @Getter
    private String value;

    /**
     * 构造函数
     * @param value 枚举值的中文描述
     */
    SysPermissionType(String value) {
        this.value = value;
    }
}