package com.simbest.boot.util.xml;

import com.simbest.boot.base.exception.Exceptions;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * XML数据转换工具类
 * 
 * 提供以下功能：
 * 1. XML与Java对象之间的双向转换
 * 2. 支持基于JAXB的XML处理
 * 3. 提供多种输入源的XML解析（字符串、输入流、Reader）
 * 4. 实现XML文件的生成和保存
 * 5. 支持格式化的XML输出
 * 6. 提供缓存机制提高转换效率
 * 7. 实现异常的统一处理
 */
public class XMLConverUtil {

	private static Map<Class<?>, Unmarshaller> uMap = new HashMap<Class<?>, Unmarshaller>();
	private static Map<Class<?>, Marshaller> mMap = new HashMap<Class<?>, Marshaller>();

	/**
	 * XML to Object
	 *
	 * @param <T>
	 * @param clazz
	 * @param xml
	 *
	 * @return
	 */
	public static <T> T convertToObject(Class<T> clazz, String xml) {
		return convertToObject(clazz, new StringReader(xml));
	}

	/**
	 * XML to Object
	 *
	 * @param <T>
	 * @param clazz
	 * @param inputStream
	 *
	 * @return
	 */
	public static <T> T convertToObject(Class<T> clazz, InputStream inputStream) {
		return convertToObject(clazz, new InputStreamReader(inputStream));
	}

	/**
	 * XML to Object
	 *
	 * @param <T>
	 * @param clazz
	 * @param reader
	 *
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T convertToObject(Class<T> clazz, Reader reader) {
		try {
			if (!uMap.containsKey(clazz)) {
				JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
				Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				uMap.put(clazz, unmarshaller);
			}
			return (T) uMap.get(clazz).unmarshal(reader);
		} catch (JAXBException e) {
			Exceptions.printException(e);
		}
		return null;
	}

	/**
	 * Object to XML
	 *
	 * @param object
	 *
	 * @return
	 */
	public static String convertToXML(Object object) {
		try {
			if (!mMap.containsKey(object.getClass())) {
				JAXBContext jaxbContext = JAXBContext.newInstance(object.getClass());
				Marshaller marshaller = jaxbContext.createMarshaller();
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				//	            marshaller.setProperty(CharacterEscapeHandler.class.getName(), new
				// CharacterEscapeHandler() {
				// public void escape(char[] ac, int i, int j, boolean flag,Writer writer) throws
				// IOException {
				//	                writer.write( ac, i, j ); }
				//	            });
				mMap.put(object.getClass(), marshaller);
			}
			StringWriter stringWriter = new StringWriter();
			mMap.get(object.getClass()).marshal(object, stringWriter);
			return stringWriter.getBuffer().toString();
		} catch (JAXBException e) {
			Exceptions.printException(e);
		}
		return null;
	}

	/**
	 * 将对象根据路径转换成xml文件
	 *
	 * @param obj
	 * @param path
	 *
	 * @return
	 */
	public static void convertToXml(Object obj, String path) {
		try {
			// 利用jdk中自带的转换类实现
			JAXBContext context = JAXBContext.newInstance(obj.getClass());

			Marshaller marshaller = context.createMarshaller();
			// 格式化xml输出的格式
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			// 将对象转换成输出流形式的xml
			// 创建输出流
			FileWriter fw = null;
			try {
				fw = new FileWriter(path);
			} catch (IOException e) {
				e.printStackTrace();
			}
			marshaller.marshal(obj, fw);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}
}