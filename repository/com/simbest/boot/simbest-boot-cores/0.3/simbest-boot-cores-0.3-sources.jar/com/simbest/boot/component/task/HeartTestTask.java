package com.simbest.boot.component.task;

import com.simbest.boot.component.distributed.lock.AppRuntimeMaster;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.sys.repository.SysTaskExecutedLogRepository;
import com.simbest.boot.sys.service.IHeartTestService;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.server.HostUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 用途：应用健康状态监控定时任务
 * 作为系统健康监控的核心组件，提供定期的应用健康状态检查服务。
 * 
 * 主要功能：
 * 1. 定期执行应用健康状态检查，支持可配置的执行周期
 * 2. 提供两种健康检查方式：
 *    - 自定义检查：通过实现IHeartTestService接口，可以自定义检查逻辑
 *    - 默认检查：通过HTTP请求检查应用登录页面的可用性
 * 3. 分布式环境支持：
 *    - 继承AbstractTaskSchedule，确保在分布式环境下只有主节点执行检查
 *    - 通过分布式锁机制防止任务重复执行
 * 4. 灵活的配置支持：
 *    - 通过配置文件控制是否启用心跳检查（app.openHeartCheck）
 *    - 支持自定义检查周期（app.task.heart.test.job）
 *    - 支持自定义应用上下文路径
 * 
 * 使用说明：
 * 1. 自定义检查：实现IHeartTestService接口并注册为Spring Bean
 * 2. 默认检查：确保登录页面包含"username"关键字
 * 3. 配置示例：
 *    app.openHeartCheck=true
 *    app.task.heart.test.job=0 0/1 * * * ?
 * 
 * 注意事项：
 * 1. 建议根据实际需求实现IHeartTestService，以提供更精确的健康检查
 * 2. 默认检查方式依赖于登录页面的可用性，确保登录页面的稳定性
 * 3. 在分布式环境中，任务只会在主节点上执行，无需额外配置
 */
@Slf4j
@Component
public class HeartTestTask extends AbstractTaskSchedule {

    /**
     * Spring应用上下文
     * 主要用途：
     * 1. 获取所有IHeartTestService接口的实现类
     * 2. 支持动态发现新增的健康检查实现
     */
    @Autowired
    private ApplicationContext appContext;

    /**
     * 应用配置管理器
     * 主要配置项：
     * 1. app.openHeartCheck：是否启用心跳检查
     * 2. app.contextPath：应用上下文路径
     * 3. 其他自定义配置项
     */
    @Autowired
    private AppConfig config;

    /**
     * 主机信息工具类
     * 主要用途：
     * 1. 获取应用当前运行的端口号
     * 2. 用于构建健康检查的HTTP请求URL
     */
    @Autowired
    private HostUtil hostUtil;

    /**
     * 构造函数
     * @param master 应用运行时主控管理器，用于确保任务只在主节点执行
     * @param repository 任务执行日志仓库，用于记录任务执行历史（本任务默认不记录）
     */
    @Autowired
    public HeartTestTask(AppRuntimeMaster master, SysTaskExecutedLogRepository repository) {
        super(master, repository);
    }

    /**
     * 定时执行心跳检查任务
     * 配置说明：
     * 1. 执行周期通过app.task.heart.test.job配置项指定
     * 2. 支持标准cron表达式，如：0 0/1 * * * ? （每分钟执行一次）
     * 3. 设置writeLog=false，不记录执行日志，避免日志量过大
     */
    @Scheduled(cron = "${app.task.heart.test.job}")
    public void checkAndExecute() {
        super.checkAndExecute(false);
    }

    /**
     * 执行心跳检查的具体逻辑
     * 执行流程：
     * 1. 首先检查心跳检查功能是否启用（通过app.openHeartCheck配置）
     * 2. 查找并执行所有IHeartTestService实现类的检查方法
     * 3. 如果没有找到IHeartTestService实现类，则执行默认的HTTP检查：
     *    - 构建登录页面URL：http://localhost:${port}${contextPath}${LOGIN_PAGE}
     *    - 发送GET请求并检查响应中是否包含"username"关键字
     * 
     * 返回值说明：
     * - CHECK_SUCCESS (2)：检查通过
     * - CHECK_FAILED (1)：检查失败
     * 
     * 注意事项：
     * 1. 建议实现IHeartTestService接口来提供自定义的健康检查逻辑
     * 2. 默认的HTTP检查依赖于登录页面的可用性和关键字匹配
     * 3. 任何未捕获的异常都会导致检查失败
     * 
     * @see com.simbest.boot.sys.service.IHeartTestService
     * @return 检查结果状态码
     */
    @Override
    public String execute() {
        if(config.isOpenHeartCheck()) {
            Map<String, IHeartTestService> heartTests = appContext.getBeansOfType(IHeartTestService.class);
            if (heartTests.size() > 0) {
                for (Map.Entry<String, IHeartTestService> entry : heartTests.entrySet()) {
                    entry.getValue().doTest();
                }
            } else {
                String testUrl = "http://localhost:" + hostUtil.getRunningPort() + config.getContextPath() + ApplicationConstants.LOGIN_PAGE;
                String response = HttpClient
                        .get(testUrl)
                        .asString();
                if (StringUtils.contains(response, "username")) {
                    log.debug("Heart test login url check ok!");
                } else {
                    log.debug("Heart test login url check failed!");
                    return CHECK_FAILED;
                }
            }
        }
        return CHECK_SUCCESS;
    }
}