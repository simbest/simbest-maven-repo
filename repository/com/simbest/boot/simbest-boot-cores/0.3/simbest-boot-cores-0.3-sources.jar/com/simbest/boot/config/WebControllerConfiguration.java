package com.simbest.boot.config;

import com.simbest.exclude.web.GlobalErrorController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.web.ResourceProperties;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorViewResolver;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.DispatcherServlet;

import javax.servlet.Servlet;
import java.util.List;

/**
 * Web控制器全局配置类
 * 
 * 主要功能：
 * 1. 提供统一的Web异常处理机制
 * 2. 配置全局错误控制器（GlobalErrorController）
 * 3. 支持自定义错误页面解析
 * 
 * 配置说明：
 * 1. 在Web应用中自动启用（@ConditionalOnWebApplication）
 * 2. 需要Servlet和DispatcherServlet支持（@ConditionalOnClass）
 * 3. 在WebMvcAutoConfiguration之前配置（@AutoConfigureBefore）
 * 4. 启用资源属性配置（@EnableConfigurationProperties）
 * 
 * 参考文档：
 * - Spring Boot错误处理：https://docs.spring.io/spring-boot/docs/current/reference/html/spring-boot-features.html#boot-features-error-handling
 * - 自定义错误页面：https://www.baeldung.com/spring-boot-custom-error-page
 */
@Configuration
@ConditionalOnWebApplication
@ConditionalOnClass({Servlet.class, DispatcherServlet.class})
@AutoConfigureBefore(WebMvcAutoConfiguration.class)
@EnableConfigurationProperties(ResourceProperties.class)
public class WebControllerConfiguration {
    @Autowired(required = false)
    private List<ErrorViewResolver> errorViewResolvers;
    private final ServerProperties serverProperties;

    public WebControllerConfiguration(
            ServerProperties serverProperties) {
        this.serverProperties = serverProperties;
    }

    @Bean
    public GlobalErrorController basicErrorController(ErrorAttributes errorAttributes) {
        return new GlobalErrorController(errorAttributes, this.serverProperties.getError(),
                this.errorViewResolvers);
    }
}