package com.simbest.boot.exceptions;

import lombok.NoArgsConstructor;

/**
 * 更新不存在对象异常
 * 
 * 主要用途：
 * 1. 用于标识尝试更新不存在的对象时的异常情况
 * 2. 通常用于数据一致性校验
 * 
 * 使用场景：
 * 1. 更新数据时找不到目标记录
 * 2. 批量更新时部分记录不存在
 * 3. 乐观锁更新时版本号不匹配
 * 
 * 注意事项：
 * 1. 建议在异常消息中包含查询条件或对象标识信息
 * 2. 可用于防止对不存在数据的误操作
 * 3. 作为RuntimeException的子类，属于非受检异常
 */
@NoArgsConstructor
public class UpdateNotExistObjectException extends RuntimeException {
    /**
     * 使用指定的错误消息构造异常
     *
     * @param msg 详细的错误消息，说明对象不存在的具体原因
     */
    public UpdateNotExistObjectException(String msg) {
        super(msg);
    }

    /**
     * 使用指定的错误消息和根异常构造异常
     *
     * @param msg 详细的错误消息，说明对象不存在的具体原因
     * @param t 导致此异常的根本原因
     */
    public UpdateNotExistObjectException(String msg, Throwable t) {
        super(msg, t);
    }
}