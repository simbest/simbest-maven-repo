package com.simbest.boot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;

/**
 * Spring Retry重试机制配置类
 * 主要功能：
 * 1. 启用Spring Retry功能，支持服务调用失败后的自动重试
 * 2. 支持通过@Retryable注解配置重试策略
 * 3. 支持配置重试次数、重试间隔、触发重试的异常等
 * 4. 支持配置重试失败后的回调方法
 * 
 * 使用说明：
 * - 在需要重试的方法上添加@Retryable注解
 * - 可配置maxAttempts指定最大重试次数
 * - 可配置backoff指定重试间隔时间
 * - 可配置recover方法处理重试失败的情况
 */
@EnableRetry
@Configuration
public class RetryConfiguration {

}