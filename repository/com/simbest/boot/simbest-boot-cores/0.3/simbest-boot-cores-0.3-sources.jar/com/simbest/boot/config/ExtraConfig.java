package com.simbest.boot.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;

/**
 * 用途：额外配置文件加载类
 * 主要提供以下功能：
 * 1. 加载项目特定的配置文件
 * 2. 支持配置热更新
 * 3. 提供配置值获取方法
 * 
 * 支持的配置文件：
 * - extra.properties：项目特定配置
 * - application.properties：应用通用配置
 * - fastdfs-client.properties：FastDFS客户端配置
 */
@Configuration
@RefreshScope
@PropertySources(value = {@PropertySource(ignoreResourceNotFound=true, value = {"classpath:extra.properties",
        "classpath:application.properties", "classpath:fastdfs-client.properties"})})
public class ExtraConfig {

    /**
     * Spring环境配置对象
     */
    @Autowired
    private Environment environment;

    /**
     * 获取配置值
     * @param key 配置键
     * @return String 配置值，如果不存在返回null
     */
    public String getValue(String key) {
        return environment.getProperty(key);
    }
}