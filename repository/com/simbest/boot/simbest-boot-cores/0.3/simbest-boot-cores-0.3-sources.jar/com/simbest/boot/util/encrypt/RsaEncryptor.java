package com.simbest.boot.util.encrypt;

import cn.hutool.core.codec.Base64Encoder;
import com.auth0.jwt.JWT;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.constants.CloudAuthConstants;
import com.simbest.boot.security.util.RSAUtils;
import com.simbest.boot.util.BootAppFileReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.List;

/**
 * RSA加密工具类
 * 参考： http://blog.csdn.net/chaijunkun/article/details/7275632
 * 
 */
@Slf4j
@Component
public class RsaEncryptor extends AbstractEncryptor {

    /**
     * 私钥
     */
    private RSAPrivateKey privateKey;

    /**
     * 公钥
     */
    private RSAPublicKey publicKey;

    @PostConstruct
    public void init() throws Exception {
        String public_key = getKeyFromFile(ApplicationConstants.RSA_PUBLIC_KEY_PATH);
        String private_key = getKeyFromFile(ApplicationConstants.RSA_PRIVATE_KEY_PATH);
        loadPublicKey(public_key);
        loadPrivateKey(private_key);
    }

    private String getKeyFromFile(String filePath) throws Exception {
        BufferedReader bufferedReader = BootAppFileReader.getClasspathFile(filePath);
        String line = null;
        List<String> list = new ArrayList<String>();
        while ((line = bufferedReader.readLine()) != null) {
            list.add(line);
        }
        // remove the firt line and last line
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 1; i < list.size() - 1; i++) {
            stringBuilder.append(list.get(i)).append("\r");
        }
        String key = stringBuilder.toString();
        return key;
    }


    /**
     * 获取私钥
     *
     * @return 当前的私钥对象
     */
    private RSAPrivateKey getPrivateKey() {
        return privateKey;
    }

    /**
     * 获取公钥
     *
     * @return 当前的公钥对象
     */
    private RSAPublicKey getPublicKey() {
        return publicKey;
    }

    /**
     * 随机生成密钥对
     */
    public void genKeyPair() {
        KeyPairGenerator keyPairGen = null;
        try {
            keyPairGen = KeyPairGenerator.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        keyPairGen.initialize(1024, new SecureRandom());
        KeyPair keyPair = keyPairGen.generateKeyPair();
        this.privateKey = (RSAPrivateKey) keyPair.getPrivate();
        this.publicKey = (RSAPublicKey) keyPair.getPublic();
    }

    /**
     * 从文件中输入流中加载公钥
     *
     * @param in 公钥输入流
     * @throws Exception 加载公钥时产生的异常
     */
    private void loadPublicKey(InputStream in) throws Exception {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String readLine = null;
            StringBuilder sb = new StringBuilder();
            while ((readLine = br.readLine()) != null) {
                if (readLine.charAt(0) == '-') {
                    continue;
                } else {
                    sb.append(readLine);
                    sb.append('\r');
                }
            }
            loadPublicKey(sb.toString());
        } catch (IOException e) {
            throw new Exception("公钥数据流读取错误");
        } catch (NullPointerException e) {
            throw new Exception("公钥输入流为空");
        }
    }

    /**
     * 从字符串中加载公钥
     *
     * @param publicKeyStr 公钥数据字符串
     * @throws Exception 加载公钥时产生的异常
     */
    private void loadPublicKey(String publicKeyStr) throws Exception {
        try {
            byte[] buffer = org.apache.commons.codec.binary.Base64.decodeBase64(publicKeyStr);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
            this.publicKey = (RSAPublicKey) keyFactory.generatePublic(keySpec);
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("无此算法");
        } catch (InvalidKeySpecException e) {
            throw new Exception("公钥非法");
        } catch (NullPointerException e) {
            throw new Exception("公钥数据为空");
        }
    }

    /**
     * 从文件中加载私钥
     *
     * @param in 私钥文件名
     * @return 是否成功
     * @throws Exception
     */
    private void loadPrivateKey(InputStream in) throws Exception {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String readLine = null;
            StringBuilder sb = new StringBuilder();
            while ((readLine = br.readLine()) != null) {
                if (readLine.charAt(0) == '-') {
                    continue;
                } else {
                    sb.append(readLine);
                    sb.append('\r');
                }
            }
            loadPrivateKey(sb.toString());
        } catch (IOException e) {
            throw new Exception("私钥数据读取错误");
        } catch (NullPointerException e) {
            throw new Exception("私钥输入流为空");
        }
    }

    private void loadPrivateKey(String privateKeyStr) throws Exception {
        try {
            byte[] buffer = org.apache.commons.codec.binary.Base64.decodeBase64(privateKeyStr);
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(buffer);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            this.privateKey = (RSAPrivateKey) keyFactory.generatePrivate(keySpec);
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("无此算法");
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
            throw new Exception("私钥非法");
        } catch (NullPointerException e) {
            throw new Exception("私钥数据为空");
        }
    }

    /**
     * 加密过程
     *
     * @param publicKey     公钥
     * @param plainTextData 明文数据
     * @return
     * @throws Exception 加密过程中的异常信息
     */
    private byte[] encrypt(RSAPublicKey publicKey, byte[] plainTextData) throws Exception {
        if (publicKey == null) {
            throw new Exception("加密公钥为空, 请设置");
        }
        Cipher cipher = null;
        try {
            cipher = Cipher.getInstance("RSA");//, new BouncyCastleProvider());
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] output = cipher.doFinal(plainTextData);
            return output;
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("无此加密算法");
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
            return null;
        } catch (InvalidKeyException e) {
            throw new Exception("加密公钥非法,请检查");
        } catch (IllegalBlockSizeException e) {
            throw new Exception("明文长度非法");
        } catch (BadPaddingException e) {
            throw new Exception("明文数据已损坏");
        }
    }

    /**
     * 解密过程
     *
     * @param privateKey 私钥
     * @param cipherData 密文数据
     * @return 明文
     * @throws Exception 解密过程中的异常信息
     */
    private byte[] decrypt(RSAPrivateKey privateKey, byte[] cipherData) throws Exception {
        if (privateKey == null) {
            throw new Exception("解密私钥为空, 请设置");
        }
        Cipher cipher = null;
        try {
            cipher = Cipher.getInstance("RSA");//, new BouncyCastleProvider());
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            byte[] output = cipher.doFinal(cipherData);
            return output;
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("无此解密算法");
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
            return null;
        } catch (InvalidKeyException e) {
            throw new Exception("解密私钥非法,请检查");
        } catch (IllegalBlockSizeException e) {
            throw new Exception("密文长度非法");
        } catch (BadPaddingException e) {
            throw new Exception("密文数据已损坏");
        }
    }


    /**
     * 字节数据转字符串专用集合
     */
    private static final char[] HEX_CHAR = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    /**
     * 字节数据转十六进制字符串
     *
     * @param data 输入数据
     * @return 十六进制内容
     */
    private static String byteArrayToString(byte[] data) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < data.length; i++) {
            //取出字节的高四位 作为索引得到相应的十六进制标识符 注意无符号右移
            stringBuilder.append(HEX_CHAR[(data[i] & 0xf0) >>> 4]);
            //取出字节的低四位 作为索引得到相应的十六进制标识符
            stringBuilder.append(HEX_CHAR[(data[i] & 0x0f)]);
            if (i < data.length - 1) {
                stringBuilder.append(' ');
            }
        }
        return stringBuilder.toString();
    }

    @Override
    protected String encryptSource(String source) {
        //  http://commons.apache.org/proper/commons-codec/ : org.apache.commons.codec.binary.Base64
        // sun.misc.BASE64Encoder
        try {
            byte[] binaryData = encrypt(getPublicKey(), source.getBytes());
            String base64String = org.apache.commons.codec.binary.Base64.encodeBase64String(binaryData) /* org.apache.commons.codec.binary.Base64.encodeBase64(binaryData) */;
            return base64String;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected String decryptCode(String code) {
        String sourceCode = code;
        try {
            return doDecryptCode(code);
        } catch (Exception e) {
            int codeArrayLength = code.split(" ").length;
            for(int i=0; i<codeArrayLength; i++){
                code = code.replaceFirst(" ", "+");
                try {
                    return doDecryptCode(code);
                } catch (Exception e1){

                }
            }
            log.warn("无法通过RSA解析【{}】", sourceCode);
            return null;
        }
    }

    private String doDecryptCode(String code) throws Exception {
        byte[] binaryData = decrypt(getPrivateKey(), org.apache.commons.codec.binary.Base64.decodeBase64(code) /*org.apache.commons.codec.binary.Base64.decodeBase64(base46String.getBytes())*/);
        return new String(binaryData);
    }

    public static void main(String[] args) throws Exception {
        RsaEncryptor rsaEncryptor = new RsaEncryptor();
        String public_key = rsaEncryptor.getKeyFromFile("certificate/rsa/rsa_public_key.pem");
        String private_key = rsaEncryptor.getKeyFromFile("certificate/rsa/pkcs8_private_key.pem");
        rsaEncryptor.loadPublicKey(public_key);
        rsaEncryptor.loadPrivateKey(private_key);
        String privateKey = Base64Encoder.encode(rsaEncryptor.getPrivateKey().getEncoded());
        System.out.println(privateKey);
        String publicKey = Base64Encoder.encode(rsaEncryptor.getPublicKey().getEncoded());
        System.out.println(publicKey);


        String str = "U0NSQW02SCtZOE9nNmlJYjZ1YVFxVzZpNDVtMWFtUlltZE8veEYrb1g2ZmlnWHdoaVhOSmhKVDlmSENCOFY2aWhuZklrTkJYVVo3K2ZVZTBZSnYrejQ0bWFZZjl2MVNvcXpPTXpFZlA1ejI1ZnlXNUFEbVhCODJ2RURabldQMDE1bGZmRUY3WUpRMXZ6TDl1RkUreTRmQUtseGlWcGQrR2IxSnFZK3Z3V2VBPQ==";
        System.out.println("明文："+rsaEncryptor.decrypt(str));

        String str1 = "2024-01-26 08:00:00";
        System.out.println("密文："+rsaEncryptor.encrypt(str1));

        String source = "111.com";
        String code = rsaEncryptor.encrypt(source);
        log.debug(code);
        log.debug("###########################");
        log.debug(rsaEncryptor.decryptCode(code));

        String token = "eyJraWQiOiJNSUlFdkFJQiFBREFOQipna3Foa2lHOXcwQCRCQVFFRkFBJVNDQktZd2dnU2lBZ0UjQUFvSUJBUUMuMGtvR1FoMzNsY1BQVyIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJoUmhuRFVhLytROFFoSXNGQjZQRDR4b1RpOVFJSUZESUpsemhMRUdkVnhoQW5OelRtNStSVlRrVnZqZCtWZXcvVGw3ZEc3Y1puWDRTaTNZcEs1b1psSmUxYlBhdGkrOTVJdndaS0hRUE9SbTFpWVo4Mk5DOXlmaURuK2NWMmhBaldkLzZickY5TjVOY2x1OFlNUFBieGxPSFR6Z01kVVZGSjU2WW5SaFVFVkU9IiwiYXVkIjoic2ltYmVzdCIsIm5iZiI6MTczNjI0MzA4Niwic2NvcGUiOlsicHJvZmlsZSJdLCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjkwMDEvYXV0aCIsImV4cCI6MTczNjI0MzY4NiwiaWF0IjoxNzM2MjQzMDg2LCJqdGkiOiJiZjcyM2EyMC03NTBjLTRjMWEtOGFmMC1lZTk0ZmJmMDUyYzAifQ.M1uVFnagi3Ye-OyzjYX2oB_7XY3BhHLn98IErEb6ABoONFsvINRmHyMg0ZSf7i6JOyLjw6z_f85n-2NRRxYOcww-L8hepWDAooHhOMhmtTaxtcReZ05Vs44OfTIvgTAPKDVpF2gke_QbS4tve24uKMWBUS2dTm9ad-cRQqRDiwq3F6t5G-4cHYxeNYTifSAtWtKl8oMZN9CuN1o0uIRLQ4rhTuJ7qPdumVoJKlwJh6F3tlpykaEy5mZXQsO38PNdaY5F905G1TwTIg7BCHwCsCTZEXe-IqU5l0COnxrwm5FZMtiptV7NlLPDwjjTWqgLgysjtyzCBo14ISkHGbFy0Q";
        String username = JWT.decode(token).getClaim(CloudAuthConstants.SUB).asString();
        System.out.println(username);
        username = rsaEncryptor.decryptCode(username);
        System.out.println(username);
    }

}