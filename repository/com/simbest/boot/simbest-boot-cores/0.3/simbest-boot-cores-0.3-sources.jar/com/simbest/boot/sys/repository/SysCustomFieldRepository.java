package com.simbest.boot.sys.repository;

import com.simbest.boot.base.repository.LogicRepository;
import com.simbest.boot.sys.model.SysCustomField;
import org.springframework.stereotype.Repository;

/**
 * 用途：实体自定义字段持久层
 *
 *
 */
@Repository
public interface SysCustomFieldRepository extends LogicRepository<SysCustomField, String> {

    SysCustomField findByFieldClassify(String fieldClassify);
}