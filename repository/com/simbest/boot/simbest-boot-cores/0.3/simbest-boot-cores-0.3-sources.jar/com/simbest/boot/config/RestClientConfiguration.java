package com.simbest.boot.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.*;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.SourceHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * RestTemplate配置类
 * 主要功能：
 * 1. 配置两种RestTemplate实例：
 *    - 支持Nacos负载均衡的RestTemplate
 *    - 普通的RestTemplate，支持自定义超时和消息转换器
 * 2. 配置HTTP请求和响应的消息转换器：
 *    - 支持字节数组、字符串、资源文件等基本类型
 *    - 支持JSON格式，使用Jackson进行序列化
 *    - 支持表单数据提交
 *    - 支持特殊的文本响应类型（如text/javascript）
 * 3. 提供连接超时和读取超时的配置
 * 4. 支持大文件传输（禁用请求体缓冲）
 */
@Configuration
public class RestClientConfiguration {

    /**
     * Jackson对象映射器，用于JSON序列化
     */
    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 自定义的Jackson消息转换器
     */
    @Autowired
    private MappingJackson2HttpMessageConverter customJackson2HttpMessageConverter;

    /**
     * 创建支持Nacos负载均衡的RestTemplate实例
     * 用于服务间的调用，自动集成负载均衡功能
     *
     * @return 支持负载均衡的RestTemplate实例
     */
    @LoadBalanced
    @Bean
    public RestTemplate nacosRestTemplate(){
        return new RestTemplate();
    }

    /**
     * 创建默认的RestTemplate实例
     * 配置了连接超时、读取超时和消息转换器
     * 
     * @return 默认的RestTemplate实例
     */
    @Primary
    @Bean
    public RestTemplate restTemplate() {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setBufferRequestBody(false); // 禁用请求体缓冲，支持大文件传输
        requestFactory.setConnectTimeout(1000 * 30); // 连接超时时间：30秒
        requestFactory.setReadTimeout(1000 * 30);    // 读取超时时间：30秒
        RestTemplate restTemplate = new RestTemplate(requestFactory);

        // 配置消息转换器
        List<HttpMessageConverter<?>> messageConverters = Arrays.asList(
                new ByteArrayHttpMessageConverter(),          // 处理字节数组
                new StringHttpMessageConverter(StandardCharsets.UTF_8), // 处理字符串，使用UTF-8编码
                new ResourceHttpMessageConverter(),           // 处理资源文件
                new SourceHttpMessageConverter<>(),           // 处理XML源
                new FormHttpMessageConverter(),              // 处理表单数据
                customJackson2HttpMessageConverter,          // 处理JSON数据
                new WxMappingJackson2HttpMessageConverter()  // 处理特殊的文本响应类型
        );
        restTemplate.setMessageConverters(messageConverters);
        return restTemplate;
    }

    /**
     * 扩展的Jackson消息转换器
     * 用于处理特殊的响应类型，如text/javascript等
     * 解决某些接口返回特殊Content-Type时的解析问题
     */
    public class WxMappingJackson2HttpMessageConverter extends MappingJackson2HttpMessageConverter {
        public WxMappingJackson2HttpMessageConverter(){
            List<MediaType> mediaTypes = new ArrayList<>();
            mediaTypes.add(MediaType.TEXT_PLAIN);     // 支持text/plain类型
            mediaTypes.add(MediaType.TEXT_HTML);      // 支持text/html类型
            mediaTypes.add(MediaType.parseMediaType("text/javascript;charset=utf-8")); // 支持text/javascript类型
            setSupportedMediaTypes(mediaTypes);
        }
    }
}