package com.simbest.boot.sys.web;

import com.github.wenhao.jpa.Specifications;
import com.simbest.boot.base.web.controller.GenericController;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.sys.model.SysLogWeb;
import com.simbest.boot.sys.service.ISysLogWebService;
import com.simbest.boot.util.DateUtil;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * 用途：请求接口日志控制器
 *
 *
 */
@Api(tags = {"3-系统管理", "请求接口日志管理"}, description = "提供系统Web请求日志的查询和统计功能，包括今日、指定日期和日期范围内的失败请求查询和统计")
@RestController
@RequestMapping("/sys/log/web")
public class SysLogWebController extends GenericController<SysLogWeb, String> {

    private ISysLogWebService service;

    @Autowired
    public SysLogWebController(ISysLogWebService service) {
        super(service);
        this.service = service;
    }

    @GetMapping(value = "/queryTodayFail")
    public JsonResponse queryTodayFail() {
        Date startDate = DateUtil.startTimeOfDay(DateUtil.getCurrent()).toDate();
        Date endDate = DateUtil.endTimeOfDay(DateUtil.getCurrent()).toDate();
        Specification<SysLogWeb> specification = Specifications.<SysLogWeb>and()
                .between("createdTime", DateUtil.date2LocalDateTime(startDate), DateUtil.date2LocalDateTime(endDate))
                .eq("failed", true)
                .build();
        return JsonResponse.success(service.findAllNoPage(specification));
    }

    @GetMapping(value = "/countTodayFail/anonymous")
    public Long countTodayFail() {
        Date startDate = DateUtil.startTimeOfDay(DateUtil.getCurrent()).toDate();
        Date endDate = DateUtil.endTimeOfDay(DateUtil.getCurrent()).toDate();
        Specification<SysLogWeb> specification = Specifications.<SysLogWeb>and()
                .between("createdTime", DateUtil.date2LocalDateTime(startDate), DateUtil.date2LocalDateTime(endDate))
                .eq("failed", true)
                .build();
        return service.count(specification);
    }



    @GetMapping(value = "/queryDayFail")
    public JsonResponse queryDayFail(String day) {
        Date startDate = DateUtil.startTimeOfDay(DateUtil.parseDate(day)).toDate();
        Date endDate = DateUtil.endTimeOfDay(DateUtil.parseDate(day)).toDate();
        Specification<SysLogWeb> specification = Specifications.<SysLogWeb>and()
                .between("createdTime", DateUtil.date2LocalDateTime(startDate), DateUtil.date2LocalDateTime(endDate))
                .eq("failed", true)
                .build();
        return JsonResponse.success(service.findAllNoPage(specification));
    }

    @GetMapping(value = "/countDayFail/anonymous")
    public Long countDayFail(String day) {
        Date startDate = DateUtil.startTimeOfDay(DateUtil.parseDate(day)).toDate();
        Date endDate = DateUtil.endTimeOfDay(DateUtil.parseDate(day)).toDate();
        Specification<SysLogWeb> specification = Specifications.<SysLogWeb>and()
                .between("createdTime", DateUtil.date2LocalDateTime(startDate), DateUtil.date2LocalDateTime(endDate))
                .eq("failed", true)
                .build();
        return service.count(specification);
    }



    @GetMapping(value = "/queryBetweenDayFail")
    public JsonResponse queryBetweenDayFail(String sDate, String eDate) {
        Date startDate = DateUtil.startTimeOfDay(DateUtil.parseDate(sDate)).toDate();
        Date endDate = DateUtil.endTimeOfDay(DateUtil.parseDate(eDate)).toDate();
        Specification<SysLogWeb> specification = Specifications.<SysLogWeb>and()
                .between("createdTime", DateUtil.date2LocalDateTime(startDate), DateUtil.date2LocalDateTime(endDate))
                .eq("failed", true)
                .build();
        return JsonResponse.success(service.findAllNoPage(specification));
    }

    @GetMapping(value = "/countBetweenDayFail/anonymous")
    public Long countBetweenDayFail(String sDate, String eDate) {
        Date startDate = DateUtil.startTimeOfDay(DateUtil.parseDate(sDate)).toDate();
        Date endDate = DateUtil.endTimeOfDay(DateUtil.parseDate(eDate)).toDate();
        Specification<SysLogWeb> specification = Specifications.<SysLogWeb>and()
                .between("createdTime", DateUtil.date2LocalDateTime(startDate), DateUtil.date2LocalDateTime(endDate))
                .eq("failed", true)
                .build();
        return service.count(specification);
    }
}