package com.simbest.boot.config;

import com.simbest.boot.constants.ApplicationConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Spring Boot异步调用配置类
 * 主要功能：
 * 1. 配置自定义线程池，支持@Async注解实现异步调用
 * 2. 提供可配置的线程池参数，包括核心线程数、最大线程数、队列容量等
 * 3. 支持线程上下文传递，包括Session和Security上下文
 * 4. 提供优雅关闭机制，确保任务完成后再关闭线程池
 * 
 * 线程池工作模式说明：
 * 1. 当新任务提交时，如果运行的线程数小于核心线程数，创建新线程处理任务
 * 2. 如果运行的线程数等于核心线程数，将任务放入队列
 * 3. 如果队列已满，且运行的线程数小于最大线程数，创建新线程处理任务
 * 4. 如果队列已满，且运行的线程数等于最大线程数，执行拒绝策略
 * 
 * 注意：如需在多线程中获取主线程的SESSION上下文，请在启动类中添加：
 * SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);
 */
@EnableAsync
@Configuration
public class MultiThreadConfiguration {

    /**
     * 线程池Bean名称
     */
    public final static String MULTI_THREAD_BEAN = "simbestThreadExecutor";

    /**
     * 线程池关闭等待时间（秒）
     */
    public final static int TERMINATION_SECONDS = 1200;

    /**
     * 应用配置，用于获取线程池相关参数
     */
    @Autowired
    private AppConfig appConfig;

    /**
     * 创建自定义线程池执行器
     * 配置说明：
     * 1. 核心线程数：线程池初始化时创建的线程数
     * 2. 最大线程数：线程池允许创建的最大线程数
     * 3. 队列容量：用于缓存任务的队列大小
     * 4. 线程空闲时间：超过核心线程数的线程空闲超时时间
     * 5. 拒绝策略：采用CallerRunsPolicy，在调用者线程中执行被拒绝的任务
     *
     * @return 线程池执行器
     */
    @Bean(MULTI_THREAD_BEAN)
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(appConfig.getThreadCorePoolSize());
        executor.setMaxPoolSize(appConfig.getThreadMaxPoolSize());
        executor.setQueueCapacity(appConfig.getThreadQueueCapacity());
        executor.setKeepAliveSeconds(appConfig.getThreadKeepAliveSeconds());
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(TERMINATION_SECONDS);
        executor.setThreadNamePrefix(MULTI_THREAD_BEAN.concat(ApplicationConstants.LINE));
        //增加 TaskDecorator 属性的配置
//        executor.setTaskDecorator(new ContextDecorator()); //配置后，UDP请求无法使用多线程
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }

    /**
     * 上下文装饰器，用于传递请求上下文和安全上下文到新线程
     * 注意：在UDP请求场景下可能会导致问题，请谨慎使用
     */
    public class ContextDecorator implements TaskDecorator {
        @Override
        public Runnable decorate(Runnable runnable) {
            RequestAttributes context = RequestContextHolder.currentRequestAttributes();
            SecurityContext securityContext = SecurityContextHolder.getContext();
            return () -> {
                try {
                    RequestContextHolder.setRequestAttributes(context);
                    SecurityContextHolder.setContext(securityContext);
                    runnable.run();
                } finally {
                    SecurityContextHolder.clearContext();
                    RequestContextHolder.resetRequestAttributes();
                }
            };
        }
    }
}