package com.simbest.boot.sys.service.impl;


import com.simbest.boot.base.annotations.AnnotationUtils;
import com.simbest.boot.base.service.impl.LogicService;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.sys.model.SysCustomField;
import com.simbest.boot.sys.repository.SysCustomFieldRepository;
import com.simbest.boot.sys.service.ISysCustomFieldService;
import com.simbest.boot.util.security.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 用途：实体自定义字段逻辑层
 *
 *
 */
@Service
@CacheConfig(cacheNames = ApplicationConstants.REDIS_DEFAULT_CACHE_PREFIX)
public class SysCustomFieldService extends LogicService<SysCustomField, String> implements ISysCustomFieldService {

    private SysCustomFieldRepository fieldRepository;

    @Autowired
    public SysCustomFieldService(SysCustomFieldRepository fieldRepository ) {
        super(fieldRepository);
        this.fieldRepository = fieldRepository;
    }

    @Autowired
    private AnnotationUtils annotationUtils;

    @Override
    public Map<String, String> getFieldClassifyMap() {
        return annotationUtils.getEntityCnNameClassifyMap();
    }



    @Override
    public SysCustomField findByFieldClassify(String fieldClassify) {
        return fieldRepository.findByFieldClassify(fieldClassify);
    }

    @CachePut(key = "#p0.id")
    @Override
    public SysCustomField insert(SysCustomField field) {
        if (field.getId() == null) {
            field.setEnabled(true);
            field.setCreator(SecurityUtils.getCurrentUserName());
            field.setModifier(SecurityUtils.getCurrentUserName());
            return fieldRepository.save(field);
        } else {
            SysCustomField dbFiled = findById(field.getId());
            dbFiled.setEnabled(true);
            dbFiled.setFieldName(field.getFieldName());
            dbFiled.setModifier(SecurityUtils.getCurrentUserName());
            return fieldRepository.save(dbFiled);
        }
    }

}