package com.simbest.boot.base.model;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Sets;
import com.simbest.boot.security.MySimpleGrantedAuthority;
import com.simbest.boot.util.json.JacksonUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.provider.ClientDetails;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * OAuth2客户端信息实体
 * 存储OAuth2客户端的详细配置信息：
 * - 实现Spring Security OAuth2的ClientDetails接口
 * - 支持OAuth2标准认证和授权流程所需的所有信息
 * - 使用JSON格式存储集合类型的字段
 * - 继承自GenericModel，拥有基础实体功能
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "OAuth2配置表")
@Entity
public class Oauth2ClientDetails extends GenericModel implements ClientDetails {

    /**
     * 主键ID
     * 使用雪花算法生成分布式唯一ID
     */
    @Id
    @Column(name = "id", length = 40)
    @GeneratedValue(generator = "snowFlakeId")
    @GenericGenerator(name = "snowFlakeId", strategy = "com.simbest.boot.util.distribution.id.SnowflakeId")
    @ApiModelProperty("主键")
    private String id;

    /**
     * 客户端标识ID
     * 用于OAuth2认证的客户端唯一标识
     */
    @ApiModelProperty("客户端标识")
    @Column(nullable = false, unique = true, length = 40)
    private String clientId;

    /**
     * 客户端密钥
     * 用于OAuth2认证的客户端密码
     */
    @Column
    @ApiModelProperty("客户端密钥")
    private String clientSecret;

    /**
     * 访问令牌有效期（秒）
     * 定义AccessToken的过期时间
     */
    @Column
    @ApiModelProperty("AK失效时间")
    private Integer accessTokenValiditySeconds;

    /**
     * 刷新令牌有效期（秒）
     * 定义RefreshToken的过期时间
     */
    @Column
    @ApiModelProperty("RK失效时间")
    private Integer refreshTokenValiditySeconds;

    /**
     * 资源ID（JSON格式）
     * 存储客户端可以访问的资源服务器ID集合
     */
    @Column
    @ApiModelProperty("资源ID")
    private String jsonResourceId;

    /**
     * 获取资源ID集合
     * 将JSON格式的资源ID转换为Set集合
     * 
     * @return 资源ID集合
     */
    @Override
    public Set<String> getResourceIds() {
        return JacksonUtils.json2Type(jsonResourceId, new TypeReference<Set<String>>() {});
    }

    /**
     * 是否需要客户端密钥
     * 如果为true，客户端必须提供密钥才能获取token
     */
    @Column
    @ApiModelProperty("是否需要保护")
    private Boolean secretRequired;

    /**
     * 判断是否需要客户端密钥
     * 
     * @return 是否需要客户端密钥
     */
    @Override
    public boolean isSecretRequired() {
        return secretRequired;
    }

    /**
     * 是否限制作用域
     * 如果为true，客户端必须指定有效的作用域
     */
    @Column
    @ApiModelProperty("是否在保护内")
    private Boolean scoped;

    /**
     * 判断是否限制作用域
     * 
     * @return 是否限制作用域
     */
    @Override
    public boolean isScoped() {
        return scoped;
    }

    /**
     * 作用域范围（JSON格式）
     * 存储客户端允许的作用域范围
     */
    @Column
    @ApiModelProperty("JSON范围")
    private String jsonScoped;

    /**
     * 获取作用域范围集合
     * 将JSON格式的作用域范围转换为Set集合
     * 
     * @return 作用域范围集合
     */
    @Override
    public Set<String> getScope() {
        return JacksonUtils.json2Type(jsonScoped, new TypeReference<Set<String>>() {});
    }

    /**
     * 授权类型（JSON格式）
     * 存储客户端支持的OAuth2授权类型
     */
    @Column
    @ApiModelProperty("JSON认证类型")
    private String jsonAuthorizedGrantTypes;

    /**
     * 获取授权类型集合
     * 将JSON格式的授权类型转换为Set集合
     * 
     * @return 授权类型集合
     */
    @Override
    public Set<String> getAuthorizedGrantTypes() {
        return JacksonUtils.json2Type(jsonAuthorizedGrantTypes, new TypeReference<Set<String>>() {});
    }

    /**
     * 注册的重定向URI（JSON格式）
     * 存储授权码模式下允许的重定向URI
     */
    @Column
    @ApiModelProperty("JSON注册跳转地址")
    private String jsonRegisteredRedirectUri;

    /**
     * 获取注册的重定向URI集合
     * 将JSON格式的重定向URI转换为Set集合
     * 
     * @return 重定向URI集合
     */
    @Override
    public Set<String> getRegisteredRedirectUri() {
        return JacksonUtils.json2Type(jsonRegisteredRedirectUri, new TypeReference<Set<String>>() {});
    }

    /**
     * 权限列表（JSON格式）
     * 存储客户端拥有的权限
     */
    @Column
    @ApiModelProperty("JSON权限")
    private String jsonAuthorities;

    /**
     * 获取权限集合
     * 将JSON格式的权限列表转换为GrantedAuthority集合
     * 
     * @return 权限集合
     */
    @Override
    public Collection<GrantedAuthority> getAuthorities() {
        Collection<GrantedAuthority> grantedAuthorities = Sets.newHashSet();
        Collection<MySimpleGrantedAuthority> simpleGrantedAuthorities = JacksonUtils.json2Type(jsonAuthorities, new TypeReference<List<MySimpleGrantedAuthority>>() {});
        grantedAuthorities.addAll(simpleGrantedAuthorities);
        return grantedAuthorities;
    }

    /**
     * 是否自动授权
     * 如果为true，用户无需手动确认授权
     */
    @Column
    @ApiModelProperty("是否自动授权")
    private Boolean autoApprove;

    /**
     * 判断是否自动授权特定作用域
     * 
     * @param scope 作用域
     * @return 是否自动授权
     */
    @Override
    public boolean isAutoApprove(String scope) {
        return autoApprove;
    }

    /**
     * 额外信息（JSON格式）
     * 存储与客户端相关的其他自定义信息
     */
    @Column
    @ApiModelProperty("JSON额外信息")
    private String jsonAdditionalInformation;

    /**
     * 获取额外信息Map
     * 将JSON格式的额外信息转换为Map
     * 
     * @return 额外信息Map
     */
    @Override
    public Map<String, Object> getAdditionalInformation() {
        return JacksonUtils.json2Type(jsonAdditionalInformation, new TypeReference<Map<String, Object>>() {});
    }
}