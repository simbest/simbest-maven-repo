package com.simbest.boot.uums.api.position;

import com.fasterxml.jackson.core.type.TypeReference;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.SimplePosition;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.uums.api.ApiRequestHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @version <strong>V1.0.0</strong><br>
 */
/**
 * 系统职位管理API接口
 * 提供职位管理相关的远程调用接口：
 * - 职位信息的基础CRUD操作
 * - 支持按用户名和组织代码查询职位
 * - 提供职位树形结构查询
 * - 实现职位与用户关联的管理
 * - 支持分页和条件查询
 */
@SuppressWarnings("ALL")
@Component
@Slf4j
public class UumsSysPositionApi {

    private static final String USER_MAPPING = "/action/position/position/";
    private static final String SSO = "/sso";
    private static final String NEW_SSO = "sso/";
    @Autowired
    private AppConfig config;
    //private String uumsAddress="http://localhost:8080/uums";
    @Autowired
    private RsaEncryptor encryptor;

    @Autowired
    private ApiRequestHandle<List<SimplePosition>> mapPositionApiHandle;

    /**
     * 根据ID查询职位信息
     * 
     * @param id 职位ID
     * @param appcode 应用代码
     * @return 职位信息对象
     */
    public SimplePosition findById(String id,String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        username=encryptor.encrypt(username);
        System.out.println("加密后为:"+username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findById"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, username)
                .param(AuthoritiesConstants.SSO_API_APP_CODE,appcode )
                .param("id", String.valueOf(id))
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimplePosition auth = JacksonUtils.json2obj(json, SimplePosition.class);
        return auth;
    }

    /**
     * 获取职位信息列表并分页
     * 
     * @param page 当前页码
     * @param size 每页大小
     * @param direction 排序方向
     * @param properties 排序属性
     * @param appcode 应用代码
     * @param sysPositionMap 查询条件
     * @return 分页的职位信息列表
     */
    public JsonResponse findAll(int page, int size, String direction, String properties, String appcode, Map sysPositionMap){
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0=JacksonUtils.obj2json(sysPositionMap);
        String username1=encryptor.encrypt(username);
        String username2=username1.replace("+","%2B");
        JsonResponse response= HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAll"+SSO+"?loginuser="+username2+"&appcode="+appcode
        +"&page="+page+"&size="+size+"&direction="+direction+"&properties="+properties)
                .json( json0 )
                .asBean(JsonResponse.class );
        return response;
    }

    /**
     * 获取所有职位信息（不分页）
     * 
     * @param appcode 应用代码
     * @param sysPositionMap 查询条件
     * @return 职位信息列表
     */
    public List<SimplePosition> findAllNoPage(String appcode, Map sysPositionMap){
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0=JacksonUtils.obj2json(sysPositionMap);
        String username1=encryptor.encrypt(username);
        String username2=username1.replace("+","%2B");
        JsonResponse response= HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAll"+SSO+"?loginuser="+username2+"&appcode="+appcode )
                .json( json0 )
                .asBean(JsonResponse.class );
        return mapPositionApiHandle.handRemoteTypeReferenceResponse(response, new TypeReference<List<SimplePosition>>(){});
    }

    /**
     * 根据用户名查询其职务信息
     * 
     * @param username 用户名
     * @param appcode 应用代码
     * @return 用户的职务列表
     */
    public List<SimplePosition> findPositionByUsername(String username, String appcode) {
        String usernameCurrent = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", usernameCurrent);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findPositionByUsername"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(usernameCurrent))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,appcode )
                .param("username",username)
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        if(!(response.getData() instanceof ArrayList)){
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimplePosition> positionList=JacksonUtils.json2Type(json, new TypeReference<List<SimplePosition>>(){});
        return positionList;
    }

    /**
     * 查询指定组织下所有用户的职务信息
     * 
     * @param orgCode 组织代码
     * @param appcode 应用代码
     * @return 用户名到职务列表的映射
     */
    public Map<String,List<SimplePosition>> findPositionOrgcodeAndUsername(String orgCode, String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findPositionOrgcodeAndUsername"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,appcode)
                .param("orgCode", orgCode)
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        if(!(response.getData() instanceof Map)){
            log.error("--uums接口返回的类型不为Map--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        Map<String,List<SimplePosition>> maps=JacksonUtils.json2Type(json, new TypeReference<Map<String,List<SimplePosition>>>(){});
        return maps;
    }

    /**
     * 查询所有职务并以树形结构返回
     * 
     * @return 树形结构的职务信息
     */
    public JsonResponse findAllToTree() {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findAllToTree"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,this.config.getAppcode())
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 创建新的职务信息
     * 
     * @param map 职务信息
     * @return 创建结果
     */
    public JsonResponse create(Map map) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(map);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + NEW_SSO + "create"+"?loginuser="+username1
                 +"&appcode="+config.getAppcode())
                .json( json0 )
                .asBean(JsonResponse.class );
        if(response == null){
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 更新职务信息
     * 
     * @param map 更新的职务信息
     * @return 更新结果
     */
    public JsonResponse update(Map map) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        JsonResponse response =  HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + NEW_SSO + "update"+"?loginuser="+username1+
                        "&appcode="+config.getAppcode())
                .json(JacksonUtils.obj2json(map))
                .asBean(JsonResponse.class);
        if(response == null){
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 根据ID删除职务信息
     * 
     * @param id 职务ID
     * @return 删除结果
     */
    public JsonResponse deleteByIdCustom(String id) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING  + "deleteByIdCustom" + SSO +"?loginuser="+username1+
                        "&appcode="+config.getAppcode())
                .param("id",id)
                .asBean(JsonResponse.class);
        if(response == null){
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 查询职位和关联用户信息
     * 
     * @param page 当前页码
     * @param size 每页大小
     * @param positionId 职位ID
     * @param truename 用户真实姓名
     * @return 职位和用户关联信息
     */
    public JsonResponse findPositionAndUser(int page, int size, String positionId, String truename) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING  + "findPositionAndUser" + SSO +"?loginuser="+username1+
                        "&appcode="+config.getAppcode() + "&page=" + page + "&size=" + size)
                .param("positionId",positionId)
                .param("truename",truename)
                .asBean(JsonResponse.class);
        if(response == null){
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 根据自定义条件查询职位信息
     * 
     * @param orgCode 组织代码
     * @param companyTypeDictValue 公司类型字典值
     * @param map 其他查询条件
     * @return 符合条件的职位信息
     */
    public JsonResponse findPositionCustom(String orgCode, String companyTypeDictValue, Map<String, Object> map) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        JsonResponse response =  HttpClient.textBody(config.getUumsAddress() + USER_MAPPING  + "findPositionCustom" + SSO + "?loginuser="+username1+
                        "&appcode="+config.getAppcode())
                .json(JacksonUtils.obj2json(map))
                .asBean(JsonResponse.class);
        if(response == null){
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }
}