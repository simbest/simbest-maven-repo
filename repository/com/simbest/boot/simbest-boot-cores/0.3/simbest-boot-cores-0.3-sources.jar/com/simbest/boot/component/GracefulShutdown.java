package com.simbest.boot.component;

import com.simbest.boot.base.exception.Exceptions;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.sys.service.IAppShutdownService;
import com.simbest.boot.util.SpringContextUtil;
import com.simbest.boot.util.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.connector.Connector;
import org.apache.commons.io.FileUtils;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Spring Boot应用优雅关闭组件
 * 
 * 功能特点：
 * 1. 资源清理：
 *    - Redis临时缓存清理
 *    - 临时文件清理
 *    - 线程池关闭
 *    - 定时任务关闭
 * 
 * 2. 线程管理：
 *    - 支持自定义超时时间
 *    - 优雅关闭线程池
 *    - 强制关闭超时线程
 * 
 * 3. 关闭流程：
 *    - 暂停新请求接入
 *    - 等待当前请求处理完成
 *    - 清理系统资源
 *    - 关闭应用上下文
 */
@Slf4j
public class GracefulShutdown implements TomcatConnectorCustomizer, ApplicationListener<ContextClosedEvent> {

    /**
     * 关闭标识符
     * 用于日志输出时的分隔和标记
     */
    public static final String SHUTDOWN_FLAG = "#######################################################";

    /**
     * 应用配置对象
     * 用于获取临时文件路径等配置信息
     */
    private AppConfig appConfig;

    /**
     * Spring上下文工具类
     * 用于获取Bean实例和管理Spring容器
     */
    private SpringContextUtil springContextUtil;

    /**
     * 线程池关闭超时时间（秒）
     * 超过此时间将强制关闭
     */
    private static final int TIMEOUT = 30;

    /**
     * Tomcat连接器
     * 用于管理HTTP请求的接收和处理
     */
    private volatile Connector connector;

    /**
     * 构造函数
     * 
     * @param appConfig 应用配置对象
     * @param springContextUtil Spring上下文工具类
     */
    public GracefulShutdown(AppConfig appConfig, SpringContextUtil springContextUtil){
        this.appConfig = appConfig;
        this.springContextUtil = springContextUtil;
    }

    /**
     * 自定义Tomcat连接器配置
     * 保存连接器实例以便关闭时使用
     * 
     * @param connector Tomcat连接器实例
     */
    @Override
    public void customize(Connector connector) {
        this.connector = connector;
    }

    /**
     * 处理应用关闭事件
     * 执行资源清理和优雅关闭流程
     * 
     * 关闭流程：
     * 1. 执行自定义关闭逻辑
     * 2. 清理Redis临时缓存
     * 3. 关闭定时任务线程池
     * 4. 关闭异步任务线程池
     * 5. 暂停接收新请求
     * 6. 等待当前请求处理完成
     * 7. 清理临时文件
     * 
     * @param event Spring应用上下文关闭事件
     */
    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
        log.debug("应用即将被关闭，销毁前清理工作".concat(SHUTDOWN_FLAG).concat("START"));
        IAppShutdownService appShutdownService = springContextUtil.getBean(IAppShutdownService.class);
        appShutdownService.gracefulShutdown();
        //程序销毁的时候， 删除reids缓存中放的tmp开头的临时变量
        log.debug("正在模糊删除Redis的Key键关键字包含【{}】的缓存".concat(SHUTDOWN_FLAG), ApplicationConstants.REDIS_TEMP_KEY);
        RedisUtil.mulDelete(ApplicationConstants.REDIS_TEMP_KEY);
        log.debug("清理异步定时任务".concat(SHUTDOWN_FLAG).concat("START"));
        Map<String, ThreadPoolTaskScheduler> schedulerMap = springContextUtil.getBeansOfType(ThreadPoolTaskScheduler.class);
        for (Map.Entry<String, ThreadPoolTaskScheduler> map : schedulerMap.entrySet()) {
            log.debug("已关闭【{}】异步定时任务", map.getKey());
            map.getValue().shutdown();
            log.debug("已关闭【{}】异步定时任务", map.getKey());
        }
        log.debug("清理异定时任务".concat(SHUTDOWN_FLAG).concat("END"));

        log.debug("清理异步多线程".concat(SHUTDOWN_FLAG).concat("START"));
        Map<String, ThreadPoolTaskExecutor> executorMap = springContextUtil.getBeansOfType(ThreadPoolTaskExecutor.class);
        for (Map.Entry<String, ThreadPoolTaskExecutor> map : executorMap.entrySet()) {
            log.debug("已关闭【{}】多线程", map.getKey());
            map.getValue().shutdown();
            log.debug("已关闭【{}】多线程", map.getKey());
        }
        log.debug("清理异步多线程".concat(SHUTDOWN_FLAG).concat("END"));

        this.connector.pause();
        Executor executor = this.connector.getProtocolHandler().getExecutor();
        log.debug("当前执行器为【{}】，匹配ThreadPoolExecutor结果为【{}】", executor, executor instanceof ThreadPoolExecutor);
        if (executor instanceof ThreadPoolExecutor) {
            try {
                ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) executor;
                threadPoolExecutor.shutdown();
                if (!threadPoolExecutor.awaitTermination(TIMEOUT, TimeUnit.SECONDS)) {
                    log.warn("Tomcat线程池在【{}】秒内未成功结束，将手动执行关闭", TIMEOUT);
                    threadPoolExecutor.shutdownNow();
                    if (!threadPoolExecutor.awaitTermination(TIMEOUT, TimeUnit.SECONDS)) {
                        log.error("Tomcat线程池未能彻底关闭，请检查应用代码！！！");
                    }
                }
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }
        else{
            log.warn("executor非ThreadPoolExecutor，具体类型为【{}】", executor.getClass().getName());
        }
        //程序销毁的时候， 删除应用临时上传的文件
        try{
            log.debug("正在删除应用临时目录【{}】的文件".concat(SHUTDOWN_FLAG), appConfig.getUploadTmpFileLocation());
            FileUtils.cleanDirectory(new File(appConfig.getUploadTmpFileLocation()));
        } catch (IOException e) {
            Exceptions.printException(e);
        }
        log.debug("应用即将被关闭，销毁前清理工作".concat(SHUTDOWN_FLAG).concat("END"));
    }

}