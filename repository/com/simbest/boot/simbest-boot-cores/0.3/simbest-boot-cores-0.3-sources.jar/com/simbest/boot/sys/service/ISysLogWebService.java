package com.simbest.boot.sys.service;

import com.simbest.boot.base.service.ISystemService;
import com.simbest.boot.sys.model.SysLogWeb;

/**
 * 用途：系统Web请求日志
 *
 *
 */
public interface ISysLogWebService extends ISystemService<SysLogWeb, String> {


}