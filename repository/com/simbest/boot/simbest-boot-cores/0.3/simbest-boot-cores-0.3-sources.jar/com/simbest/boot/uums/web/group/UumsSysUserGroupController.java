package com.simbest.boot.uums.web.group;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.uums.api.group.UumsSysUserGroupApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * 用户群组关系管理控制器
 * 提供用户与群组关系的管理功能：
 * - 支持用户加入和退出群组
 * - 提供批量用户群组关系管理
 * - 实现群组成员的动态调整
 * - 支持多维度的用户群组关联
 */
@Api(tags = {"2-统一用户管理", "用户群组管理"}, description = "提供用户与群组关系的管理功能，包括用户群组关系的创建和删除、批量添加用户到群组、群组成员的查询和管理等")
@RestController
@RequestMapping(value = {"/uums/sys/user/group", "/sys/uums/user/group"})
public class UumsSysUserGroupController {

    @Autowired
    private UumsSysUserGroupApi uumsSysUserGroupApi;

    /**
     * 将用户添加到指定群组
     * 支持单个用户加入群组：
     * - 需要提供用户名和群组ID
     * - 支持应用级别的权限控制
     * - 返回创建的用户群组关系
     *
     * @param username 用户名
     * @param groupId 群组ID
     * @param appcode 应用编码
     * @return 创建结果
     */
    @ApiOperation (value = "新增某个群组下某个人", notes = "新增某个群组下某个人", tags = {"人员与群组关系"})
    @ApiImplicitParams( {
            @ApiImplicitParam(name = "username", value = "用户名", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "groupId", value = "群组id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    } )
    @PostMapping ("/create")
    public JsonResponse create(@RequestParam(required = false) String username,
                               @RequestParam(required = false) String groupId,
                               @RequestParam(required = false)  String appcode) {
        return JsonResponse.success(uumsSysUserGroupApi.create( username,groupId,appcode ));
    }

    /**
     * 删除用户群组关系
     * 支持基于条件的批量删除：
     * - 通过Map参数传递删除条件
     * - 执行逻辑删除而非物理删除
     * - 支持复杂的删除条件组合
     *
     * @param sysUserGroup 删除条件Map
     * @return 删除操作结果
     */
    @ApiOperation(value = "删除用户群组信息", notes = "删除用户群组信息", tags = {"人员与群组关系"})
    @PostMapping ({"/delete","/delete/sso","/api/delete"})
    public JsonResponse delete(@RequestBody(required = false) Map sysUserGroup) {
        return uumsSysUserGroupApi.delete(sysUserGroup);
    }

    /**
     * 根据ID删除用户群组关系
     * 支持单条记录的精确删除：
     * - 通过ID进行精确定位
     * - 执行逻辑删除操作
     * - 需要相应的权限
     *
     * @param id 用户群组关系ID
     * @return 删除操作结果
     */
    @ApiOperation(value = "删除用户群组信息", notes = "删除用户群组信息", tags = {"人员与群组关系"})
    @ApiImplicitParam(name = "id", value = "用户群组ID", dataType = "String", paramType = "query")
    @PostMapping ({"/deleteById","/deleteById/sso","/api/deleteById"})
    public JsonResponse deleteById(@RequestParam(required = false) String id) {
        return uumsSysUserGroupApi.deleteById(id);
    }

    /**
     * 批量添加用户到指定群组
     * 支持多维度的批量用户添加：
     * - 可通过组织机构批量添加用户
     * - 支持多个群组的用户合并
     * - 允许直接指定用户列表
     * - 可配置用户的业务类型
     *
     * @param groupSid 目标群组SID
     * @param orgCodes 组织机构代码列表（逗号分隔）
     * @param groupSids 源群组ID列表（逗号分隔）
     * @param usernames 用户名列表（逗号分隔）
     * @param userBussinessConfig 用户业务配置
     * @return 批量添加操作结果
     */
    @ApiOperation(value = "指定群组新增用户", notes = "指定群组新增用户", tags = {"人员与群组关系"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "groupSid", value = "群组SID", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "orgCodes", value = "一个或多个组织code", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "groupSids", value = "一个或多个群组id", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "usernames", value = "一个或多个用户", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "appcode", value = "应用编码", dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "userBussinessConfig", value = "用户业务类型", dataType = "String", paramType = "query")
    })
    @PostMapping(value = {"/createGroupUsers", "/createGroupUsers/sso", "/api/createGroupUsers"})
    public JsonResponse createGroupUsers(@RequestParam(required = false) String groupSid,
                                         @RequestParam(required = false) String orgCodes,
                                         @RequestParam(required = false) String groupSids,
                                         @RequestParam(required = false) String usernames,
                                         @RequestParam(required = false) String userBussinessConfig) {
        return uumsSysUserGroupApi.createGroupUsers(groupSid,orgCodes,groupSids,usernames,userBussinessConfig);
    }
}