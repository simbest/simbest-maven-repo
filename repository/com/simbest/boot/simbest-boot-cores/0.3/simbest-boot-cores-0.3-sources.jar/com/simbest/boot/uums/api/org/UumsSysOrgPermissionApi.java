package com.simbest.boot.uums.api.org;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.util.UriEncoder;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.security.SimpleApp;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.uums.api.ApiRequestHandle;
import com.simbest.boot.uums.api.app.UumsSysAppApi;

import lombok.extern.slf4j.Slf4j;

/**
 * 组织权限管理API接口
 * 
 * 提供以下功能：
 * 1. 组织权限的批量更新操作
 * 2. 支持基于权限ID的组织权限管理
 * 3. 实现组织代码与权限的关联管理
 * 4. 提供原子化的权限更新操作（先删除后添加）
 * 5. 继承自ApiRequestHandle以统一处理远程响应
 */
@Slf4j
@SuppressWarnings("All")
@Component
public class UumsSysOrgPermissionApi {

    private static final String USER_MAPPING = "/action/org/permission/";
    private static final String SSO = "/sso";

    @Autowired
    private AppConfig config;

    @Autowired
    private RsaEncryptor encryptor;

    @Autowired
    private UumsSysAppApi uumsSysAppApi;

    /**
     * 修改组织权限信息，先删除角色所有权限，再重新添加
     * 
     * @param permissionId 权限主键ID
     * @param orgCodes     组织编码信息
     * @return
     */
    public JsonResponse updateListByPermissionId(String permissionId, List<String> orgCodes) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        SimpleApp simpleApp = uumsSysAppApi.findAppByAppCode(config.getAppcode(), username);
        String username1 = encryptor.encrypt(username);
        String username2 = UriEncoder.encode(username1);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING
                + "updateListByPermissionId" + SSO + "?loginuser=" + username2 +
                "&appcode=" + config.getAppcode() + "&permissionId=" + permissionId + "&appId=" + simpleApp.getId())
                .json(JacksonUtils.obj2json(orgCodes))
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }
}
