package com.simbest.boot.security.auth.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * <strong>Title</strong> : 登录控制器<br>
 * <strong>Description</strong> : <br>
 * <strong>Create on</strong> : 2018/02/27<br>
 * <strong>Modify on</strong> : 2018/03/02<br>
 *
 * @version v0.0.1
 */
@Api(tags = {"4-安全认证", "登录管理"}, description = "提供系统登录页面跳转功能，支持POST和GET请求方式")
@Slf4j
@Controller
@RequestMapping("/login")
public class LoginController {

    /**
     * 仅用于跳转登录页面
     * @return login
     */
    @ApiOperation(value = "登录页面", notes = "跳转到登录页面")
    @RequestMapping(method = {RequestMethod.POST, RequestMethod.GET})
    public String login() {
        return "login";
    }


}