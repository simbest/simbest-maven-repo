package com.simbest.boot.security.auth.a4;

//import com.mzlion.easyokhttp.HttpClient;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.security.SimpleUser;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.LoginUtils;
import com.simbest.boot.uums.api.user.UumsSysUserinfoApi;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

import static com.simbest.boot.base.web.response.JsonResponse.SUCCESS_CODE;
import static com.simbest.boot.security.auth.a4.A4PasswordCheck.URL_A4_TOKEN_SSON;

/**
 * 4A令牌校验控制器
 * 主要功能：
 * 1. 提供4A系统令牌校验的REST接口
 * 2. 支持匿名访问的令牌校验
 * 3. 校验成功后记录用户登录日志
 * 4. 使用RSA加密传输敏感信息
 */
@Slf4j
@Api(tags = {"4-安全认证", "4A密码校验"}, description = "提供4A系统令牌校验的REST接口，支持匿名访问，校验成功后记录用户登录日志，使用RSA加密传输敏感信息")
@RestController
@RequestMapping(value = "/anonymous/a4")
public class A4PasswordCheckController {

    /**
     * 应用配置，用于获取UUMS服务地址
     */
    @Autowired
    private AppConfig appConfig;

    /**
     * RSA加密工具，用于加密用户名等敏感信息
     */
    @Autowired
    private RsaEncryptor rsaEncryptor;

    /**
     * 登录工具类，用于记录用户登录日志
     */
    @Autowired
    private LoginUtils loginUtils;

    /**
     * UUMS用户信息API，用于获取用户详细信息
     */
    @Autowired
    private UumsSysUserinfoApi uumsSysUserinfoApi;

    /**
     * 4A令牌校验接口
     * 处理流程：
     * 1. 校验请求参数的合法性
     * 2. 调用4A系统进行令牌校验
     * 3. 校验成功后获取用户信息
     * 4. 记录用户登录日志
     * 
     * @param request HTTP请求对象，用于记录登录日志
     * @param username 用户名，将使用RSA加密传输
     * @param appCode 应用代码，用于标识请求来源应用
     * @param ticket 4A系统颁发的令牌
     * @param appAcctId 应用账户ID，用于关联4A系统中的用户账户
     * @return 校验结果，true表示校验成功，false表示校验失败
     */
    @ApiOperation(value = "4A令牌校验", notes = "校验4A系统颁发的令牌，支持匿名访问，校验成功后会记录用户登录日志")
    @PostMapping("/tokenCheckFrom4A")
    public boolean tokenCheckFrom4A(
            @ApiParam(value = "HTTP请求对象", hidden = true) HttpServletRequest request, 
            @ApiParam(value = "用户名（将进行RSA加密）", required = true, example = "admin") String username, 
            @ApiParam(value = "应用代码", required = true, example = "APPCODE") String appCode, 
            @ApiParam(value = "4A系统颁发的令牌", required = true) String ticket, 
            @ApiParam(value = "应用账户ID", required = true) String appAcctId) {
        log.debug("通过4A凭证校验参数为：username【{}】appCode【{}】ticket【{}】appAcctId【{}】", username, appCode, ticket, appAcctId);
        
        // 参数合法性校验
        if(StringUtils.isEmpty(ticket) || StringUtils.isEmpty(appAcctId)){
            log.error("用户【{}】访问【{}】通过4A凭证校验参数非法ticket【{}】appAcctId【{}】", username, appCode, ticket, appAcctId);
            return false;
        }

        // 调用4A系统进行令牌校验
        JsonResponse jsonResponse = HttpClient.post(appConfig.getUumsAddress() + URL_A4_TOKEN_SSON)
                .param("username", rsaEncryptor.encrypt(username))
                .param("appCode", appCode)
                .param("ticket", ticket)
                .param("appAcctId", appAcctId)
                .asBean(JsonResponse.class);
        log.debug("4A验证凭证结果为：【{}】", JacksonUtils.obj2json(jsonResponse));

        // 处理校验结果
        if(jsonResponse.getErrcode().equals(SUCCESS_CODE) && Boolean.valueOf(jsonResponse.getData().toString())){
            log.debug("用户【{}】访问【{}】通过4A凭证校验成功", username, appCode);
            // 获取用户信息
            SimpleUser iUser = uumsSysUserinfoApi.findByUsername(username, appCode);
            log.debug("4A验证用户【{}】凭证成功，提取用户信息为：【{}】", username, JacksonUtils.obj2json(iUser));
            // 记录登录日志
            loginUtils.recordLog(request, iUser, true, null);
            return true;
        } else {
            log.error("用户【{}】访问【{}】通过4A凭证校验失败", username, appCode);
            return false;
        }
    }


}