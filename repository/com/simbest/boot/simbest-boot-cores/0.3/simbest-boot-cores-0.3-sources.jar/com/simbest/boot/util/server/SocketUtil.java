package com.simbest.boot.util.server;

import com.simbest.boot.base.exception.Exceptions;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * Socket工具类
 * 
 * 提供以下功能：
 * 1. 服务器心跳检测
 * 2. 支持自定义超时时间
 * 3. 提供端口可用性检查
 * 4. 实现资源的自动释放
 * 5. 提供异常的统一处理
 */
public class SocketUtil {

    /**
     * 心跳检查
     * 参考：
     * http://stackoverflow.com/questions/11547082/fastest-way-to-scan-ports-with-java
     * http://jupiterbee.blog.51cto.com/3364619/1301284
     *
     * @param host
     * @param port
     * @return
     */
    public static boolean checkHeartConnection(String host, int port) {
        Socket socket = null;
        try {
            socket = new Socket();
            //心跳等待1000毫秒
            socket.connect(new InetSocketAddress(host, port), 1000);
            return true;
        } catch (Exception ex) {
            return false;
        } finally {
            try {
                if (socket != null)
                    socket.close();
            } catch (IOException e) {
                Exceptions.printException(e);
            }
        }
    }
}