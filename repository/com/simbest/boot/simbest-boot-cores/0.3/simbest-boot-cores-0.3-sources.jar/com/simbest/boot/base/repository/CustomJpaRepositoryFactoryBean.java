package com.simbest.boot.base.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.core.RepositoryInformation;
import org.springframework.data.repository.core.RepositoryMetadata;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;

import javax.persistence.EntityManager;
import java.io.Serializable;

/**
 * 自定义JPA仓库工厂Bean
 * 用于替换Spring Data JPA默认的仓库实现：
 * - 扩展JpaRepositoryFactoryBean，实现自定义的Repository创建
 * - 使系统使用LogicDeleteRepositoryImpl作为基础实现类，而非默认的SimpleJpaRepository
 * - 主要目的是支持逻辑删除功能，通过自定义Repository实现统一管理
 * - 配合Spring Data JPA的自动代理机制，无需显式编写Repository实现类
 *
 * @param <T> 仓库接口类型
 * @param <S> 实体类型
 * @param <ID> 实体ID类型
 *
 * @version <strong>V1.0.0</strong><br>
 * <strong>修改历史:</strong><br>
 * 修改人 修改日期 修改描述<br>
 * -------------------------------------------<br>
 */
public class CustomJpaRepositoryFactoryBean <T extends JpaRepository<S, ID>, S, ID extends Serializable>
        extends JpaRepositoryFactoryBean<T, S, ID> {

    /**
     * 创建工厂Bean的构造函数
     * 
     * @param repositoryInterface 仓库接口类型
     */
    public CustomJpaRepositoryFactoryBean(Class<? extends T> repositoryInterface) {
        super(repositoryInterface);
    }

    /**
     * 重写创建Repository工厂的方法
     * <p>使用自定义的CustomJpaRepositoryFactory创建Repository实例</p>
     *
     * @param entityManager JPA实体管理器
     * @return 自定义的Repository工厂
     */
    @Override
    protected RepositoryFactorySupport createRepositoryFactory(EntityManager entityManager) {
        return new CustomJpaRepositoryFactory<T, ID>(entityManager);
    }

    /**
     * 自定义的JPA仓库工厂实现
     * <p>负责创建Repository的具体实现类实例</p>
     */
    private static class CustomJpaRepositoryFactory<T, ID extends Serializable> extends JpaRepositoryFactory {

        /**
         * JPA实体管理器
         */
        private final EntityManager entityManager;

        /**
         * 创建自定义仓库工厂的构造函数
         * 
         * @param entityManager JPA实体管理器
         */
        public CustomJpaRepositoryFactory(EntityManager entityManager) {
            super(entityManager);
            this.entityManager = entityManager;
        }

        /**
         * 获取Repository目标实现
         * <p>重写此方法返回LogicDeleteRepositoryImpl作为默认实现</p>
         *
         * @param information Repository的元数据信息
         * @param entityManager JPA实体管理器
         * @return LogicDeleteRepositoryImpl实例
         */
        @Override
        protected JpaRepositoryImplementation<?, ?> getTargetRepository(RepositoryInformation information, EntityManager entityManager) {
            return new LogicDeleteRepositoryImpl<T, ID>((Class<T>) information.getDomainType(), entityManager);
        }

//        @Override
//        @SuppressWarnings("unchecked")
//        protected Object getTargetRepository(RepositoryInformation information) {
//            return new LogicDeleteRepositoryImpl<T, ID>((Class<T>) information.getDomainType(), entityManager);
//        }

        /**
         * 获取Repository的基础类
         * <p>指定LogicDeleteRepositoryImpl作为基础Repository实现类</p>
         *
         * @param metadata Repository的元数据
         * @return LogicDeleteRepositoryImpl.class
         */
        @Override
        protected Class<?> getRepositoryBaseClass(RepositoryMetadata metadata) {
            return LogicDeleteRepositoryImpl.class;
        }
    }
}