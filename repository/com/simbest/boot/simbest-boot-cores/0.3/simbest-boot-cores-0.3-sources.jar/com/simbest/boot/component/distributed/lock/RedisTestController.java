package com.simbest.boot.component.distributed.lock;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * Redis分布式锁测试控制器
 * 
 * 主要功能：
 * 1. 提供分布式锁的测试接口，用于验证锁的可用性和性能
 * 2. 演示两种分布式锁的使用方式：
 *    - 简单模式：直接使用DistributedRedisLock类进行加锁和解锁
 *    - 模板模式：使用DistributedLockTemplate进行自动化的锁管理
 * 3. 通过多线程模拟高并发场景，验证锁的互斥性和可靠性
 * 
 * 测试场景：
 * 1. 并发环境下的锁竞争
 * 2. 锁的自动释放机制
 * 3. 异常情况下的锁处理
 * 
 * 使用说明：
 * 1. /redis/lock：测试简单分布式锁，需要手动解锁
 * 2. /redis/template：测试模板方式，自动管理锁的生命周期
 * 
 * 注意事项：
 * 1. 测试时建议使用监控工具观察锁的获取情况
 * 2. 大量并发测试可能会对Redis造成压力，请合理控制线程数
 * 3. 测试完成后确保所有锁都已正确释放
 */
@Api(tags = {"6-组件功能", "分布式锁测试"}, description = "提供Redis分布式锁的测试接口，用于验证锁的可用性和性能，支持简单模式和模板模式两种使用方式")
@RestController
@RequestMapping("/redis")
public class RedisTestController {

    /**
     * 分布式锁模板
     * 
     * 功能：
     * 1. 提供模板化的锁操作接口
     * 2. 自动管理锁的获取和释放
     * 3. 支持回调方式执行业务逻辑
     */
    @Resource
    private DistributedLockTemplate distributedLockTemplate;

    /**
     * 测试简单分布式锁的并发控制
     * 
     * 测试流程：
     * 1. 创建100个并发线程
     * 2. 每个线程尝试获取相同的锁（key="test123"）
     * 3. 模拟业务处理（休眠10秒）
     * 4. 手动释放锁
     * 
     * 预期结果：
     * 1. 所有线程串行执行，不会出现并发访问
     * 2. 每次只有一个线程能获取到锁
     * 3. 业务处理完成后锁被正确释放
     * 
     * @throws Exception 当线程操作出现异常时抛出
     */
    @ApiOperation(value = "简单分布式锁测试", notes = "通过多线程模拟并发场景，测试分布式锁的基本功能")
    @PostMapping(value = "/lock")
    public void lock() {
        for (int i = 0; i < 100; i++) {
            Thread t = new Thread(() -> {
                try {
                    String key = "test123";
                    DistributedRedisLock.lock(key);
                    Thread.sleep(1000 * 10); //获得锁之后可以进行相应的处理
                    System.err.println("======获得锁后进行相应的操作======");
                    DistributedRedisLock.unlock(key);
                    System.err.println("=============================");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            t.start();
        }
    }

    /**
     * 测试分布式锁模板的并发控制
     * 
     * 测试流程：
     * 1. 创建100个并发线程
     * 2. 每个线程使用模板获取锁（lockName="MyLock"）
     * 3. 执行业务逻辑（休眠10秒）
     * 4. 模板自动释放锁
     * 
     * 特点：
     * 1. 使用模板方式，代码更加简洁
     * 2. 自动管理锁的生命周期，无需手动释放
     * 3. 通过回调方式执行业务逻辑，更加安全
     */
    @ApiOperation(value = "分布式锁模板测试", notes = "使用模板方式测试分布式锁，展示自动化的锁管理机制")
    @PostMapping(value = "/template")
    public void template() {
        for (int i = 0; i < 100; i++) {
            DisplayMessage m = new DisplayMessage(distributedLockTemplate);
            m.start();
        }
    }

    /**
     * 分布式锁模板测试线程
     * 
     * 功能：
     * 1. 使用模板方式获取分布式锁
     * 2. 在锁保护下执行业务逻辑
     * 3. 自动处理锁的释放
     * 
     * 实现说明：
     * 1. 继承Thread类，支持多线程操作
     * 2. 通过构造函数注入锁模板
     * 3. 在run方法中使用回调方式执行业务逻辑
     */
    public class DisplayMessage extends Thread {
        /**
         * 分布式锁模板实例
         * 用于执行加锁、解锁和业务处理
         */
        DistributedLockTemplate distributedLockTemplate;

        /**
         * 构造函数
         * 
         * @param distributedLockTemplate 分布式锁模板实例
         */
        public DisplayMessage(DistributedLockTemplate distributedLockTemplate){
            this.distributedLockTemplate = distributedLockTemplate;
        }

        @Override
        public void run() {
            distributedLockTemplate.lock(new DistributedLockCallback<Object>() {
                @Override
                public Object process() {
                    String name = Thread.currentThread().getName();
                    System.out.println(name + "-" + "get lock");
                    try {
                        Thread.sleep(1000 * 10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                @Override
                public String getLockName() {
                    return "MyLock";
                }
            });
        }
    }
}