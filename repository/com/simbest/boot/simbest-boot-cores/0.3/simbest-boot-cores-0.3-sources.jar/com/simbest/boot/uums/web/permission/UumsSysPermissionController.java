package com.simbest.boot.uums.web.permission;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.security.SimplePermission;
import com.simbest.boot.uums.api.permission.UumsSysPermissionApi;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 系统权限管理控制器
 * 提供权限和菜单相关的REST API接口：
 * - 权限基础信息管理
 * - 菜单权限管理
 * - 权限分配管理
 * - 权限树形结构
 * - 支持分页和自定义查询
 */

@SuppressWarnings("ALL")
@Api(tags = {"2-统一用户管理", "权限管理"}, description = "提供权限和菜单相关的管理功能，包括权限信息的CRUD操作、菜单的创建和更新、权限状态的管理、应用级别的权限控制等")
@RestController
@RequestMapping(value = {"/uums/sys/perimission", "/sys/uums/perimission"})
public class UumsSysPermissionController {

    @Autowired
    private UumsSysPermissionApi uumsSysPermissionApi;

    /**
     *根据id查看权限信息
     * @param id
     * @return
     */
    @ApiOperation(value = "查询权限信息", notes = "通过此接口来查询权限信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "权限ID", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    })
    @PostMapping("/findById")
    public JsonResponse findById(@RequestParam String id,@RequestParam  String appcode) {
        return JsonResponse.success(uumsSysPermissionApi.findById( id,appcode ));
    }

    /**
     *获取全部权限信息列表不分页
     * @return
     */
    @ApiOperation(value = "获取全部权限信息列表不分页", notes = "获取全部权限信息列表不分页")
    @ApiImplicitParam(name = "appcode", value = "应用code", dataType = "String", paramType = "query")
    @PostMapping("/findAllNoPage")
    public JsonResponse findAllNoPage(@RequestParam(required = false) String appcode,@RequestBody(required = false) Map simplePermissionMap) {
        return JsonResponse.success(uumsSysPermissionApi.findAllNoPage(appcode,simplePermissionMap ));
    }

    @ApiOperation(value = "自定义查询菜单", notes = "自定义查询菜单",tags={"菜单权限API"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "paramMap", value = "参数对象", dataType = "object",paramType = "Body") //
    })
    @PostMapping(value = {"/findPerCustom","/findPerCustom/sso","/findPerCustom/api"})
    public JsonResponse findPerCustom(@RequestBody(required = false) Map<String,Object> paramMap) {
        return uumsSysPermissionApi.findPerCustom(paramMap);
    }

    @ApiOperation(value = "根据指定应用查询该应用下面的所有菜单", notes = "根据指定应用查询该应用下面的所有菜单",tags={"菜单权限API"})
    @PostMapping(value = {"/findAllPermissions","/findAllPermissions/sso","/findAllPermissions/api"})
    public JsonResponse findAllPermissions() {
        return uumsSysPermissionApi.findAllPermissions();
    }

    @ApiOperation(value = "添加指定应用下的菜单", notes = "添加指定应用下的菜单",tags={"菜单权限API"})
    @PostMapping(value = {"/createCustom","/createCustom/sso","/api/createCustom"})
    public JsonResponse createCustom(@RequestBody(required = false) SimplePermission sysPermission) {
        return uumsSysPermissionApi.createCustom(sysPermission);
    }

    @ApiOperation(value = "更新菜单信息", notes = "更新菜单信息",tags={"菜单权限API"})
    @PostMapping(value = {"/update","/update/sso","/api/update"})
    public JsonResponse update(@RequestBody(required = false) SimplePermission sysPermission) {
        return uumsSysPermissionApi.update(sysPermission);
    }

    @ApiOperation(value = "启用/禁用菜单", notes = "启用/禁用菜单",tags={"菜单权限API"})
    @PostMapping(value = {"/updateSysPermission","/updateSysPermission/sso","/api/updateSysPermission"})
    public JsonResponse updateSysPermission(@RequestParam String id,@RequestParam String status) {
        return uumsSysPermissionApi.updateSysPermissionStatus(id, status);
    }

    @ApiOperation(value = "根据菜单ID删除菜单", notes = "根据菜单ID删除菜单",tags={"菜单权限API"})
    @ApiImplicitParam(name = "id", value = "权限ID",  dataType = "String", paramType = "query")
    @PostMapping(value = {"/deleteById","/deleteById/sso","/api/deleteById"})
    public JsonResponse deleteById(@RequestParam String id) {
        return uumsSysPermissionApi.deleteById(id);
    }

    /**
     *获取权限信息列表并分页
     * @param page
     * @param size
     * @param direction
     * @param appcode
     * @param jsonString
     * @return
     */
  /*  @ApiOperation(value = "获取权限列表", notes = "通过此接口来获取权限列表")
    @ApiImplicitParams({ //
            @ApiImplicitParam(name = "page", value = "当前页码", dataType = "int", paramType = "query", //
                    required = true, example = "1"), //
            @ApiImplicitParam(name = "size", value = "每页数量", dataType = "int", paramType = "query", //
                    required = true, example = "10"), //
            @ApiImplicitParam(name = "direction", value = "排序规则（asc/desc）", dataType = "String", //
                    paramType = "query"), //
            @ApiImplicitParam(name = "properties", value = "排序规则（属性名称）", dataType = "String", //
                    paramType = "query") //
    })
    @PostMapping(value = "/findAll")
    public JsonResponse findAll( @RequestParam(required = false, defaultValue = "1") int page, //
                                 @RequestParam(required = false, defaultValue = "10") int size, //
                                 @RequestParam(required = false) String direction,
                                 @RequestParam(required = false) String properties,
                                 @RequestParam String appcode,
                                 @RequestParam String jsonString ) {
        return JsonResponse.success(uumsSysPermissionApi.findAll(page, size,direction,properties,appcode,jsonString ));
    }*/

    /**
     * 根据某个角色以及应用查询其下的权限
     * @param sosAppcode
     * @param roleName
     * @param appCode
     * @return
     */
    /*@ApiOperation(value = "根据某个角色以及应用查询其下的权限", notes = "根据某个角色以及应用查询其下的权限")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "ssoAppcode", value = "应用code", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "roleName", value = "角色名", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam (name = "appCode", value = "应用code", required = true, dataType = "String", paramType = "query")
    })
    @PostMapping (value = "/findRoleAppPermission")
    public JsonResponse findRoleAppPermission( @RequestParam String sosAppcode, @RequestParam String roleName,@RequestParam String appCode) {
        return JsonResponse.success(uumsSysPermissionApi.findRoleAppPermission( sosAppcode,roleName,appCode));
    }*/

    /**
     * 根据某个职位以及应用查询其下的权限
     * @param sosAppcode
     * @param positionName
     * @param appCode
     * @return
     */
    /*@ApiOperation (value = "根据某个职位以及应用查询其下的权限", notes = "根据某个职位以及应用查询其下的权限")
    @ApiImplicitParams ({
            @ApiImplicitParam (name = "sosAppcode", value = "应用code", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "positionName", value = "职位名", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam (name = "appCode", value = "应用code", required = true, dataType = "String", paramType = "query")
    })
    @PostMapping(value = "/findPositionAppPermission")
    public JsonResponse findPositionAppPermission(@RequestParam String sosAppcode,@RequestParam String positionName,@RequestParam String appCode) {
        return JsonResponse.success(uumsSysPermissionApi.findPositionAppPermission( sosAppcode,positionName,appCode));
    }*/
}