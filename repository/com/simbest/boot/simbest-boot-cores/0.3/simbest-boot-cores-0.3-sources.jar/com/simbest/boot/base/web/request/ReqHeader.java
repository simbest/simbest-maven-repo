package com.simbest.boot.base.web.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Date;

/**
 * 通用请求头实体类
 * 用于对外提供接口的请求体封装，主要用于接口鉴权
 * 
 * 功能特点：
 * 1. 接口鉴权：
 *    - 适用于对外提供的/anonymous/**路径的接口
 *    - 通过token和请求时间进行安全验证
 * 
 * 2. 请求方信息：
 *    - 记录请求方的基本信息（IP、应用代码、应用名称）
 *    - 包含技术对接人信息（姓名、电话、邮箱）
 *    - 包含业务对接人信息（OA账号、电话、邮箱）
 * 
 * 3. 数据封装：
 *    - 使用泛型支持不同类型的请求数据
 *    - 统一的请求格式规范
 *    - 支持JSON序列化和反序列化
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description = "通用请求头，用于接口鉴权和请求信息记录")
public class ReqHeader<T> {

    /**
     * 请求令牌的固定值
     */
    public static final String REQUEST_TOKEN = "OaApi";

    /**
     * 请求方的IP地址
     */
    @NonNull
    @ApiModelProperty(value = "请求方IP地址", required = true, example = "192.168.1.100")
    private String clientIp;

    /**
     * 请求方的应用代码
     */
    @NonNull
    @ApiModelProperty(value = "请求方应用代码", required = true, example = "APP001")
    private String clientCode;

    /**
     * 请求方的应用名称
     */
    @NonNull
    @ApiModelProperty(value = "请求方应用名称", required = true, example = "示例应用")
    private String clientName;

    /**
     * 请求方的联系人姓名
     */
    @NonNull
    @ApiModelProperty(value = "技术对接人姓名", required = true, example = "张三")
    private String clientLinkman;

    /**
     * 请求方联系人的电话号码
     */
    @NonNull
    @ApiModelProperty(value = "技术对接人电话", required = true, example = "13800138000")
    private String clientLinkTel;

    /**
     * 请求方联系人的电子邮箱
     */
    @NonNull
    @ApiModelProperty(value = "技术对接人邮箱", required = true, example = "zhangsan@example.com")
    private String clientLinkEmail;

    /**
     * 请求方的局方联系人OA账号
     */
    @NonNull
    @ApiModelProperty(value = "业务对接人OA账号", required = true, example = "lisi")
    private String customLinkman;

    /**
     * 请求方局方联系人的电话号码
     */
    @NonNull
    @ApiModelProperty(value = "业务对接人电话", required = true, example = "13900139000")
    private String customLinkTel;

    /**
     * 请求方局方联系人的电子邮箱
     */
    @NonNull
    @ApiModelProperty(value = "业务对接人邮箱", required = true, example = "lisi@example.com")
    private String customLinkEmail;

    /**
     * 请求发起的时间
     */
    @NonNull
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "请求时间", required = true, example = "2024-01-01 12:00:00")
    private Date requestTime;

    /**
     * 请求的认证令牌
     */
    @ApiModelProperty(value = "认证令牌", required = true, example = "OaApi")
    private String token;

    /**
     * 请求的具体数据内容
     */
    @NonNull
    @ApiModelProperty(value = "请求数据", required = true)
    private T data;

    /**
     * 重写toString方法
     * 使用Apache Commons Lang的ToStringBuilder生成对象的字符串表示
     *
     * @return 对象的字符串表示
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}