package com.simbest.boot.base.exception;

import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * 异常处理工具类
 * 提供异常转换、堆栈信息获取、异常原因判断等通用功能
 */
@Slf4j
public class Exceptions {

    /**
     * 将CheckedException转换为UncheckedException
     * 用于统一异常处理，将受检异常转换为运行时异常
     * 
     * @param e 需要转换的异常
     * @return 转换后的RuntimeException
     */
    public static RuntimeException unchecked(Exception e) {
        if (e instanceof RuntimeException) {
            return (RuntimeException) e;
        } else {
            return new RuntimeException(e);
        }
    }

    /**
     * 将异常堆栈信息转换为字符串
     * 用于日志记录和异常信息展示
     * 
     * @param e 需要获取堆栈信息的异常
     * @return 异常堆栈信息的字符串表示
     */
    public static String getStackTraceAsString(Exception e) {
        StringWriter stringWriter = new StringWriter();
        e.printStackTrace(new PrintWriter(stringWriter));
        return stringWriter.toString();
    }

    /**
     * 判断异常是否由指定的异常类型引起
     * 用于异常原因分析和处理
     * 
     * @param ex 需要判断的异常
     * @param causeExceptionClasses 可能的原因异常类型数组
     * @return 如果异常是由指定类型引起则返回true，否则返回false
     */
    @SafeVarargs
    public static boolean isCausedBy(Exception ex, Class<? extends Exception>... causeExceptionClasses) {
        Throwable cause = ex;
        while (cause != null) {
            for (Class<? extends Exception> causeClass : causeExceptionClasses) {
                if (causeClass.isInstance(cause)) {
                    return true;
                }
            }
            cause = cause.getCause();
        }
        return false;
    }

    /**
     * 打印异常信息到日志
     * 使用日志框架记录异常的完整堆栈信息
     * 
     * @param e 需要打印的异常
     */
    public static void printException(Exception e) {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        e.printStackTrace(new PrintWriter(buf, true));
        String expMsg = buf.toString();
        log.error(expMsg);
    }
}