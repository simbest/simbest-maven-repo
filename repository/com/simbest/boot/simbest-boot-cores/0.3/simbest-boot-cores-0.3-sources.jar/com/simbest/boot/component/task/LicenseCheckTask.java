package com.simbest.boot.component.task;

import com.simbest.boot.component.distributed.lock.AppRuntimeMaster;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.security.license.VerifyLicense;
import com.simbest.boot.sys.repository.SysTaskExecutedLogRepository;
import com.simbest.boot.util.server.HostUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 用途：系统许可证有效性检查定时任务
 * 作为系统安全控制的重要组件，负责定期检查系统许可证的有效性。
 * 
 * 主要功能：
 * 1. 定期执行许可证有效性检查：
 *    - 每30分钟执行一次检查
 *    - 支持分布式环境下的单节点执行
 *    - 检查结果记录到日志系统
 * 
 * 2. 许可证管理：
 *    - 检查许可证是否过期
 *    - 检查许可证是否有效
 *    - 支持多种许可证验证方式
 * 
 * 3. 安全控制：
 *    - 许可证过期时强制停止应用
 *    - 记录异常情况并通知管理员
 *    - 确保系统合规运行
 * 
 * 执行策略：
 * 1. 调度周期：每30分钟执行一次（cron = "* 0/30 * * * ?"）
 * 2. 分布式控制：继承AbstractTaskSchedule，确保集群环境下单节点执行
 * 3. 执行方式：不记录执行日志（writeLog=false）
 * 
 * 注意事项：
 * 1. 许可证过期将导致系统强制停止
 * 2. 确保许可证验证服务的可用性
 * 3. 定期检查系统日志了解许可证状态
 * 4. 许可证到期前及时续期或联系管理员
 */
@Slf4j
@Component
public class LicenseCheckTask extends AbstractTaskSchedule {

    /**
     * Spring应用上下文
     * 主要用途：
     * 1. 获取Spring容器中的Bean
     * 2. 支持动态配置管理
     */
    @Autowired
    private ApplicationContext appContext;

    /**
     * 应用配置管理器
     * 主要用途：
     * 1. 获取许可证相关配置
     * 2. 支持动态修改配置
     */
    @Autowired
    private AppConfig config;

    /**
     * 主机信息工具类
     * 主要用途：
     * 1. 获取主机信息用于许可证验证
     * 2. 支持主机绑定的许可证管理
     */
    @Autowired
    private HostUtil hostUtil;

    /**
     * 许可证验证服务
     * 主要用途：
     * 1. 提供许可证验证的核心功能
     * 2. 支持多种验证策略
     * 3. 处理验证结果和异常情况
     */
    @Autowired
    private VerifyLicense verifyLicense;

    /**
     * 构造函数
     * @param master 应用运行时主控管理器，用于确保任务只在主节点执行
     * @param repository 任务执行日志仓库，用于记录任务执行历史（本任务默认不记录）
     */
    @Autowired
    public LicenseCheckTask(AppRuntimeMaster master, SysTaskExecutedLogRepository repository) {
        super(master, repository);
    }

    /**
     * 定时执行许可证检查任务
     * 配置说明：
     * 1. 执行周期：每30分钟执行一次（* 0/30 * * * ?）
     * 2. 不记录执行日志（writeLog=false）
     * 3. 继承自AbstractTaskSchedule，确保分布式环境下的正确执行
     */
    @Scheduled(cron = "* 0/30 * * * ?")
    public void checkAndExecute() {
        super.checkAndExecute(false);
    }

    /**
     * 执行许可证检查的具体逻辑
     * 执行流程：
     * 1. 调用verifyLicense.vertify()验证许可证
     * 2. 如果返回true（表示许可证过期或无效）：
     *    - 记录警告日志
     *    - 强制停止应用（Runtime.getRuntime().halt(1)）
     * 3. 如果验证通过，返回CHECK_SUCCESS
     * 
     * 返回值说明：
     * - CHECK_SUCCESS：许可证验证通过
     * - 如果许可证无效，应用将被强制停止，不会有返回值
     * 
     * 注意事项：
     * 1. 该方法可能导致应用强制停止
     * 2. 确保在应用关键时期不会执行该检查
     * 3. 许可证过期前及时处理，避免服务中断
     * 
     * @return 检查结果状态码
     */
    @Override
    public String execute() {
        if (verifyLicense.vertify()) {
            log.warn("License expired, please contact the administrator！");
            Runtime.getRuntime().halt(1);
        }
        return CHECK_SUCCESS;
    }
}