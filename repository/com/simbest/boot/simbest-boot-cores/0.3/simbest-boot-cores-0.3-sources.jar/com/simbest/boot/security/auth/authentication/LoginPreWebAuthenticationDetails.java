package com.simbest.boot.security.auth.authentication;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * 登录认证前的认证详情类
 * 
 * 主要功能：
 * 1. 记录登录认证时的客户端信息
 * 2. 用于判断授权码是否可用
 * 3. 支持序列化，便于在分布式系统中传输
 * 
 * 处理流程：
 * - 由UumsAuthenticationFilter和RsaAuthenticationFilter进行处理
 * - 在认证过程中记录客户端IP和会话信息
 * - 用于后续的安全审计和访问控制
 */
@Data
@Builder
public class LoginPreWebAuthenticationDetails implements Serializable {

    /**
     * 客户端远程IP地址
     * 用于：
     * 1. 记录用户登录来源
     * 2. 支持IP白名单控制
     * 3. 异常登录行为分析
     */
    private String remoteAddress;

    /**
     * 会话标识
     * 用于：
     * 1. 跟踪用户会话状态
     * 2. 关联认证前后的请求
     * 3. 支持分布式会话管理
     */
    private String sessionId;

}