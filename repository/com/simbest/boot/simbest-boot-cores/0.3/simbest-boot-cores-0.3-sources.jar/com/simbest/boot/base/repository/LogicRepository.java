package com.simbest.boot.base.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 业务实体通用数据持久层接口
 * 提供业务实体的数据访问功能，支持逻辑删除：
 * - 扩展SystemRepository，继承其基础数据库操作功能
 * - 为LogicModel类及其子类提供数据访问支持
 * - 所有查询方法都只返回未被逻辑删除的数据（removedTime为空）
 * - 提供逻辑删除功能，通过设置removedTime实现
 * - 支持即时逻辑删除和计划逻辑删除
 *
 * @param <T> 业务实体类型
 * @param <PK> 实体主键类型
 */
@Transactional
@NoRepositoryBean
public interface LogicRepository<T, PK extends Serializable> extends SystemRepository<T, PK> {

    /**
     * 统计所有未逻辑删除的记录数量
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，无条件统计计数该值为空的对象，实现仅查询统计未逻辑删除的数据对象
     * 
     * @return 活跃记录数量
     */
    long countActive();

    /**
     * 根据条件统计未逻辑删除的记录数量
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据JPA框架的Specification条件统计计数该值为空的对象，实现仅查询统计未逻辑删除的数据对象
     * 
     * @param conditions 查询条件
     * @return 符合条件的活跃记录数量
     */
    long countActive(Specification<T> conditions);

    /**
     * 判断指定ID的记录是否存在且未被逻辑删除
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据对象id判断未逻辑删除的数据对象是否存在
     * 
     * @param id 记录ID
     * @return 是否存在且活跃
     */
    boolean existsActive(PK id);

    /**
     * 查询所有未逻辑删除的记录并分页
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，无条件查询该值为空的对象，实现仅查询未逻辑删除的数据对象，并按照默认分页取前100条
     * 
     * @return 分页后的活跃记录
     */
    Page<T> findAllActive();

    /**
     * 查询所有未逻辑删除的记录并排序分页
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，按照JPA框架的Sort排序条件查询该值为空的对象，实现仅查询并排序未逻辑删除的数据对象，并按照默认分页取前100条
     * 
     * @param sort 排序条件
     * @return 排序并分页后的活跃记录
     */
    Page<T> findAllActive(Sort sort);

    /**
     * 根据分页参数查询未逻辑删除的记录
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，按照JPA框架的Pageable分页条件查询该值为空的对象，实现仅分页查询未逻辑删除的数据对象
     * 
     * @param pageable 分页参数
     * @return 分页后的活跃记录
     */
    Page<T> findAllActive(Pageable pageable);

    /**
     * 查询所有未逻辑删除的记录不分页
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，无条件查询该值为空的对象，实现仅查询未逻辑删除的数据对象，获取所有数据，因此不适合海量数据查询
     * 
     * @return 所有活跃记录列表
     */
    List<T> findAllActiveNoPage();

    /**
     * 查询所有未逻辑删除的记录并排序不分页
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，按照JPA框架的Sort排序条件查询该值为空的对象，实现仅查询并排序未逻辑删除的数据对象，获取所有数据，因此不适合海量数据查询
     * 
     * @param sort 排序条件
     * @return 排序后的所有活跃记录列表
     */
    List<T> findAllActiveNoPage(Sort sort);

    /**
     * 根据ID集合查询未逻辑删除的记录
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，按照类型为Iterable接口查询参数名称为ids的数据对象
     * 
     * @param ids ID集合
     * @return 符合ID且活跃的记录列表
     */
    List<T> findAllActive(Iterable<PK> ids);

    /**
     * 根据条件查询未逻辑删除的记录
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据JPA框架的Specification条件查询该值为空的对象，实现仅查询未逻辑删除的数据对象
     * 
     * @param conditions 查询条件
     * @return 符合条件的活跃记录列表
     */
    List<T> findAllActive(Specification<T> conditions);

    /**
     * 根据条件查询未逻辑删除的记录并分页
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据JPA框架的Specification条件查询该值为空的对象，实现仅查询未逻辑删除的数据对象，并按照pageable进行分页
     * 
     * @param conditions 查询条件
     * @param pageable 分页参数
     * @return 分页后的符合条件的活跃记录
     */
    Page<T> findAllActive(Specification<T> conditions, Pageable pageable);

    /**
     * 根据条件查询未逻辑删除的记录并排序
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据JPA框架的Specification条件查询该值为空的对象，实现仅查询未逻辑删除的数据对象，并按照sort进行排序
     * 
     * @param conditions 查询条件
     * @param sort 排序条件
     * @return 排序后的符合条件的活跃记录列表
     */
    List<T> findAllActive(Specification<T> conditions, Sort sort);

    /**
     * 根据ID查询未逻辑删除的记录
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据传参id条件查询该值为空的对象，实现仅查询未逻辑删除的数据对象
     * 
     * @param id 记录ID
     * @return 活跃的记录对象
     */
    T findByIdActive(PK id);

    /**
     * 根据ID查询未逻辑删除的记录
     * 作用：与findByIdActive相同
     * 
     * @param id 记录ID
     * @return 活跃的记录对象
     */
    T findOneActive(PK id);

    /**
     * 根据条件查询单个未逻辑删除的记录
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据JPA框架的Specification条件查询该值为空的对象，实现仅查询未逻辑删除的数据对象，仅返回一条数据。传递条件存在多条数据时，将发生异常
     * 
     * @param conditions 查询条件
     * @return 符合条件的单个活跃记录
     */
    T findOneActive(Specification<T> conditions);

    /**
     * 将指定ID的记录标记为逻辑删除
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据传参id，将数据对象的删除时间removedTime写入当前时间，确保该值不再为空，从而导致上述查询方法执行时，该数据对象不满足条件，无法检索得出，从而实现逻辑删除
     * 
     * @param id 记录ID
     */
    @Modifying
    void logicDelete(PK id);

    /**
     * 将指定对象标记为逻辑删除
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据传参entity对象条件，将数据对象的删除时间removedTime写入当前时间，确保该值不再为空，从而导致上述查询方法执行时，该数据对象不满足条件，无法检索得出，从而实现逻辑删除
     * 
     * @param entity 要删除的对象
     */
    @Modifying
    void logicDelete(T entity);

    /**
     * 将一组对象标记为逻辑删除
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据传参entitys对象条件，将数据对象的删除时间removedTime写入当前时间，确保该值不再为空，从而导致上述查询方法执行时，该数据对象不满足条件，无法检索得出，从而实现逻辑删除
     * 
     * @param entities 要删除的对象集合
     */
    @Modifying
    void logicDelete(Iterable<? extends T> entities);

    /**
     * 将所有记录标记为逻辑删除
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，将所有数据对象的删除时间removedTime写入当前时间，确保该值不再为空，从而导致上述查询方法执行时，该数据对象不满足条件，无法检索得出，从而实现逻辑删除
     */
    @Modifying
    void logicDeleteAll();

    /**
     * 根据ID集合将一组记录标记为逻辑删除
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据传参ids对象条件，将数据对象的删除时间removedTime写入当前时间，确保该值不再为空，从而导致上述查询方法执行时，该数据对象不满足条件，无法检索得出，从而实现逻辑删除
     * 
     * @param ids 要删除的ID集合
     */
    @Modifying
    void deleteAllByIds(Iterable<? extends PK> ids);

    /**
     * 计划在指定时间将记录标记为逻辑删除
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据传参id，将数据对象的删除时间removedTime写入传参localDateTime，这里一般是一个未来的时间，在未来确保该值不再为空，从而导致上述查询方法执行时，该数据对象不满足条件，无法检索得出，从而实现逻辑删除
     * 
     * @param id 记录ID
     * @param localDateTime 计划删除时间
     */
    @Modifying
    void scheduleLogicDelete(PK id, LocalDateTime localDateTime);

    /**
     * 计划在指定时间将对象标记为逻辑删除
     * 作用：基于LogicModel业务级对象的删除时间removedTime值，根据传参entity对象，将数据对象的删除时间removedTime写入传参localDateTime，这里一般是一个未来的时间，在未来确保该值不再为空，从而导致上述查询方法执行时，该数据对象不满足条件，无法检索得出，从而实现逻辑删除
     * 
     * @param entity 要删除的对象
     * @param localDateTime 计划删除时间
     */
    @Modifying
    void scheduleLogicDelete(T entity, LocalDateTime localDateTime);
}