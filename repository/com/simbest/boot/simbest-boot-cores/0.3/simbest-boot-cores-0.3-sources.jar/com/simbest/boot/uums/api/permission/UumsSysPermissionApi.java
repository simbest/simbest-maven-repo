package com.simbest.boot.uums.api.permission;

import com.fasterxml.jackson.core.type.TypeReference;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.SimpleApp;
import com.simbest.boot.security.SimplePermission;
import com.simbest.boot.util.MapUtil;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.uums.api.app.UumsSysAppApi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 系统权限管理API接口
 * 
 * 提供以下功能：
 * 1. 基础的权限信息CRUD操作
 * 2. 支持按角色和职位查询权限
 * 3. 支持分页和条件查询
 * 4. 提供权限状态管理
 * 5. 支持应用级别的权限管理
 * 6. 提供权限树结构查询
 * 7. 实现与UUMS系统的权限同步
 */
@SuppressWarnings("ALL")
@Component
@Slf4j
public class UumsSysPermissionApi {

    private static final String USER_MAPPING = "/action/permission/permission/";
    private static final String SSO = "/sso";

    private static final String USER_MAPPING_APP = "/action/app/app/";
    @Autowired
    private AppConfig config;

    @Autowired
    private RsaEncryptor encryptor;

    @Autowired
    private UumsSysAppApi uumsSysAppApi;

    /**
     * 根据id查找
     * @param id
     * @param appcode
     * @return
     */
    public SimplePermission findById(String id,String appcode){
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findById"+SSO)
                .param( AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param( AuthoritiesConstants.SSO_API_APP_CODE,appcode )
                .param("id", String.valueOf(id))
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimplePermission auth = JacksonUtils.json2obj(json, SimplePermission.class);
        return auth;
    }

    /**
     * 单表条件查询
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @param appcode
     * @param sysPermissionMap
     * @return
     */
    public JsonResponse findAll(  int page,int size, String direction,String properties,String appcode,Map sysPermissionMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0=JacksonUtils.obj2json(sysPermissionMap);
        String username1=encryptor.encrypt(username);
        String username2=username1.replace("+","%2B");
        JsonResponse response= HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAll"+SSO+"?loginuser="+username2+"&appcode="+appcode
                +"&page="+page+"&size="+size+"&direction="+direction+"&properties="+properties)
                .json( json0 )
                .asBean(JsonResponse.class );
        return response;
    }

    /**
     * 单表条件查询不分页
     * @param simplePermissionMap
     * @return
     */
    public List<SimplePermission> findAllNoPage(String appcode,Map simplePermissionMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0=JacksonUtils.obj2json(simplePermissionMap);
        String username1=encryptor.encrypt(username);
        String username2=username1.replace("+","%2B");
        JsonResponse response= HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAllNoPage"+SSO+"?loginuser="+username2+"&appcode="+appcode )
                .json( json0 )
                .asBean(JsonResponse.class );
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        if(!(response.getData() instanceof ArrayList)){
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimplePermission> permissionList=JacksonUtils.json2Type(json, new TypeReference<List<SimplePermission>>(){});
        return permissionList;
    }

    /**
     * 根据某个角色以及应用查询其下的权限
     * @param roleName
     * @param appcode
     * @return
     */
    public List<SimplePermission> findRoleAppPermission(String roleName, String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findRoleAppPermission"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,appcode )
                .param( "roleName",roleName )
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        if(!(response.getData() instanceof ArrayList)){
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimplePermission> permissionList=JacksonUtils.json2Type(json, new TypeReference<List<SimplePermission>>(){});
        return permissionList;
    }

    /**
     * 根据某个职位以及应用查询其下的权限
     * @param positionName
     * @param appcode
     * @return
     */
    public List<SimplePermission> findPositionAppPermission( String positionName,String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findPositionAppPermission"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,appcode )
                .param( "positionName",positionName)
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        if(!(response.getData() instanceof ArrayList)){
            log.error("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimplePermission> permissionList=JacksonUtils.json2Type(json, new TypeReference<List<SimplePermission>>(){});
        return permissionList;
    }

    public JsonResponse findPerCustom(Map sysPermissionMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        //查询应用
        SimpleApp simpleApp = uumsSysAppApi.findAppByAppCode(config.getAppcode(), username);
        sysPermissionMap.put("appCode", simpleApp.getId());
        String json0 = JacksonUtils.obj2json(sysPermissionMap);
        //查询菜单
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findPerCustom" + SSO + "?loginuser=" + username2 + "&appcode=" + config.getAppcode())
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }
    /**
     * 根据指定应用查询该应用下面的所有菜单
     * @return
     */
    public JsonResponse findAllPermissions(){
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        SimpleApp simpleApp = uumsSysAppApi.findAppByAppCode(config.getAppcode(),username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findAllPermissions"+SSO)
                .param( AuthoritiesConstants.SSO_API_USERNAME,encryptor.encrypt(username))
                .param( AuthoritiesConstants.SSO_API_APP_CODE,config.getAppcode() )
                .param("id",simpleApp.getId())
                .asBean(JsonResponse.class);
        if(response == null){
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 添加指定应用下的菜单
     * @param simplePermission
     * @return
     */
    public JsonResponse createCustom(SimplePermission simplePermission) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        SimpleApp simpleApp = uumsSysAppApi.findAppByAppCode(config.getAppcode(),username);
        Map<String,Object> permissionMap = (Map<String, Object>) MapUtil.objectToMap(simplePermission);
        permissionMap.put("permissionType",simplePermission.getType());
        String json0 = JacksonUtils.obj2json(permissionMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+","%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "createCustom"+SSO+"?loginuser="+username2+"&appcode="+config.getAppcode()+"&appId="+simpleApp.getId())
                .json( json0 )
                .asBean(JsonResponse.class );
        if(response == null){
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 更新菜单信息
     * @param simplePermission
     * @return
     */
    public JsonResponse update(SimplePermission simplePermission) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        Map<String,Object> permissionMap = (Map<String, Object>) MapUtil.objectToMap(simplePermission);
        permissionMap.put("permissionType",simplePermission.getType());
        String json0 = JacksonUtils.obj2json(permissionMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+","%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "update"+SSO+"?loginuser="+username2+"&appcode="+config.getAppcode())
                .json( json0 )
                .asBean(JsonResponse.class );
        if(response == null){
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 根据菜单ID启用/禁用菜单
     * @param id
     * @param status
     * @return
     */
    public JsonResponse updateSysPermissionStatus(String id,String status){
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "updateSysPermission"+SSO)
                .param( AuthoritiesConstants.SSO_API_USERNAME,encryptor.encrypt(username))
                .param( AuthoritiesConstants.SSO_API_APP_CODE,config.getAppcode() )
                .param("id",id)
                .param("status",status)
                .asBean(JsonResponse.class);
        if(response == null){
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 根据菜单ID删除菜单
     * @param id
     * @param status
     * @return
     */
    public JsonResponse deleteById(String id){
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response =  HttpClient.post(config.getUumsAddress() + USER_MAPPING + "deleteById"+SSO)
                .param( AuthoritiesConstants.SSO_API_USERNAME,encryptor.encrypt(username))
                .param( AuthoritiesConstants.SSO_API_APP_CODE,config.getAppcode() )
                .param("id",id)
                .asBean(JsonResponse.class);
        if(response == null){
            log.error("--response对象为空!--");
            return null;
        }
        return response;
    }
}