package com.simbest.boot.base.repository;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;

/**
 * 基础实体通用数据库持久层接口
 * 提供通用实体的基础数据访问功能：
 * - 扩展BaseRepository，继承其基础数据库操作功能
 * - 为GenericModel类及其子类提供数据访问支持
 * - 支持事务操作，默认所有方法都在事务中执行
 * - 作为其他更具体仓库接口的基础
 *
 * @param <T> 实体类型
 * @param <PK> 实体主键类型
 */
@Transactional
@NoRepositoryBean
public interface GenericRepository<T, PK extends Serializable> extends BaseRepository<T, PK>{

}