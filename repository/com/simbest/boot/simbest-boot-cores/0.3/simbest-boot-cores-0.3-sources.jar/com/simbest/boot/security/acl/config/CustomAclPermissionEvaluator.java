package com.simbest.boot.security.acl.config;

import com.google.common.collect.Sets;
import com.simbest.boot.base.model.LogicModel;
import com.simbest.boot.util.ObjectUtil;
import com.simbest.boot.util.security.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.acls.domain.ObjectIdentityRetrievalStrategyImpl;
import org.springframework.security.acls.model.ObjectIdentityRetrievalStrategy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.EntityType;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Set;

import static com.simbest.boot.constants.AuthoritiesConstants.*;

/**
 * 自定义ACL权限评估器
 * 
 * 主要功能：
 * 1. 实现Spring Security的权限评估接口
 * 2. 支持基于注解的权限控制
 * 3. 提供对象级别的权限验证
 * 4. 支持创建者和修改者的特殊权限处理
 * 
 * 权限验证方式：
 * 1. 基于角色的权限验证
 * 2. 基于对象属性的权限验证
 * 3. 支持集合和数组类型的批量权限验证
 */
@Slf4j
public class CustomAclPermissionEvaluator implements PermissionEvaluator {

    /**
     * JPA实体管理器
     */
    private EntityManager em;

    /**
     * 对象标识获取策略
     */
    private ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy = new ObjectIdentityRetrievalStrategyImpl();

    /**
     * 构造函数
     * @param em JPA实体管理器
     */
    public CustomAclPermissionEvaluator(EntityManager em) {
        this.em = em;
    }

    /**
     * 验证对象权限
     * 支持的注解格式：
     *      @PostAuthorize("hasPermission(returnObject, {'ROLE_USER'})")
     *      @PreAuthorize("hasPermission(#myModel, {'ROLE_SUPER','ROLE_ADMIN','PERMISSION_UPDATE'})")
     * 不支持的注解格式：
     *      @PreAuthorize("hasPermission(returnObject, {'ROLE_USER'})")
     * 
     * @param auth 认证信息
     * @param targetDomainObject 目标域对象
     * @param permission 权限集合
     * @return 是否具有权限
     */
    @Override
    public boolean hasPermission(Authentication auth, Object targetDomainObject, Object permission) {
        if ((auth == null) || (targetDomainObject == null) || (permission == null)){
            return false;
        }
        Enumeration<String> enumeration = Collections.enumeration((Collection<String>)permission);
        while (enumeration.hasMoreElements()) {
            String permissionString = enumeration.nextElement();
            log.debug("检查【{}】权限", permissionString);
            if (hasPrivilege(auth, permissionString.toUpperCase())) {
                return true;
            }
            else{
                if (PERMISSION_DELETE.equalsIgnoreCase(permissionString) || PERMISSION_UPDATE.equalsIgnoreCase(permissionString)){
                    //判断是否为LogicModel对象
                    if(targetDomainObject instanceof LogicModel) {
                        Field idField = ObjectUtil.getEntityIdField(targetDomainObject);
                        Object targetId = fetchObjField(targetDomainObject, idField.getName());
                        if(null != targetId) {
                            Object singleResult = queryDatabaseRecord(targetId.toString(), targetDomainObject.getClass().getName());
                            return validateCreatorOrModifier(singleResult, permissionString);
                        }
                        else {
                            return false;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * 验证对象ID权限
     * 接收注解格式：@PreAuthorize("hasPermission(#id, 'com.simbest.boot.ntodo.acl.model.MyModel', {'ROLE_SUPER','ROLE_ADMIN','PERMISSION_DELETE'})")
     * 
     * @param auth 认证信息
     * @param targetId 目标对象ID
     * @param targetType 目标对象类型
     * @param permission 权限集合
     * @return 是否具有权限
     */
    @Override
    public boolean hasPermission(Authentication auth, Serializable targetId, String targetType, Object permission) {
        if ((auth == null) || (targetType == null) || (permission == null)) {
            return false;
        }
        Enumeration<String> enumeration = Collections.enumeration((Collection<String>)permission);
        while (enumeration.hasMoreElements()){
            String permissionString = enumeration.nextElement();
            log.debug("检查【{}】权限", permissionString);
            if(hasPrivilege(auth, permissionString.toUpperCase())){
                return true;
            }
            else{
                if (PERMISSION_DELETE.equalsIgnoreCase(permissionString) || PERMISSION_UPDATE.equalsIgnoreCase(permissionString)){
                    //如果targetId是单个主键
                    if(targetId instanceof String || targetId instanceof Integer || targetId instanceof Long){
                        Object singleResult = queryDatabaseRecord(targetId, targetType);
                        //判断根据前端传参查库后，singleResult不为空，且为LogicModel对象时，再判断权限
                        if(null != singleResult && singleResult instanceof LogicModel) {
                            return validateCreatorOrModifier(singleResult, permissionString);
                        }
                    }
                    //如果targetId是集合或数组主键
                    else if (targetId instanceof Collection || targetId.getClass().isArray()){
                        Set<Boolean> validates = Sets.newHashSet();
                        Object[] array = null;
                        if (targetId instanceof Collection){
                            Collection collection = (Collection)targetId;
                            array = collection.toArray();
                        }
                        if(targetId.getClass().isArray()){
                            array = (Object[])targetId;
                        }
                        //遍历集合或数组进行验证
                        for(Object id: array){
                            Object singleResult = queryDatabaseRecord(id.toString(), targetType);
                            //判断根据前端传参查库后，singleResult不为空，且为LogicModel对象时，再判断权限
                            if(null != singleResult && singleResult instanceof LogicModel) {
                                boolean v = validateCreatorOrModifier(singleResult, permissionString);
                                validates.add(v);
                                //有一个不符合，全部不符合
                                if(!v){
                                    return false;
                                }
                            }
                        }
                        //有一个不符合，全部不符合
                        if(validates.contains(false)){
                            return false;
                        }
                        //所有对象都符合，才符合
                        else {
                            return true;
                        }
                    }
                    else{
                        return false;
                    }
                }
            }
        }
        return false;
    }

    /**
     * 验证创建者或修改者权限
     * 
     * @param singleResult 数据库查询结果对象
     * @param permissionString 权限字符串
     * @return 是否具有权限
     */
    private boolean validateCreatorOrModifier(Object singleResult, String permissionString){
        if(null == singleResult || StringUtils.isEmpty(permissionString)){
            return false;
        }
        //权限不符合，但如果是删除动作，检查一下是否为作者本人
        if(PERMISSION_DELETE.equalsIgnoreCase(permissionString)){
            boolean validateCreator = validateUser(singleResult, PERMISSION_CREATOR);
            log.debug("当前用户【{}】校验对象【{}】匹配创建人结果【{}】", SecurityUtils.getCurrentUserName(), singleResult.toString(), validateCreator);
            return validateCreator;
        }
        //权限不符合，但如果是更新动作，检查一下是否为作者本人
        if(PERMISSION_UPDATE.equalsIgnoreCase(permissionString)){
            boolean validateCreator = validateUser(singleResult, PERMISSION_CREATOR);
            log.debug("当前用户【{}】校验对象【{}】匹配创建人结果【{}】", SecurityUtils.getCurrentUserName(), singleResult.toString(), validateCreator);
            if (validateCreator) {
                return true;
            } else {
                boolean validateModifier = validateUser(singleResult, PERMISSION_MODIFIER);
                log.debug("当前用户【{}】校验对象【{}】匹配更新人结果【{}】", SecurityUtils.getCurrentUserName(), singleResult.toString(), validateModifier);
                return validateModifier;
            }
        }
        return false;
    }

    /**
     * 校验用户是否为创建者或修改者
     * 
     * @param singleResult 数据库查询结果对象
     * @param fieldName 字段名称（creator或modifier）
     * @return 是否匹配
     */
    private boolean validateUser(Object singleResult, String fieldName){
        if ((singleResult == null) || (fieldName == null)) {
            return false;
        }
        if(null != SecurityUtils.getCurrentUserName()){
            Object user = fetchObjField(singleResult, fieldName);
            if(null != user){
                if(SecurityUtils.getCurrentUserName().equalsIgnoreCase(user.toString())){
                    log.debug("匹配成功：当前登陆人信息【{}】与属性【{}】在对象【{}】中匹配", SecurityUtils.getCurrentUserName(), fieldName, singleResult.toString());
                    return true;
                }
                else {
                    log.debug("匹配失败：当前登陆人信息【{}】与属性【{}】在对象【{}】中不匹配", SecurityUtils.getCurrentUserName(), fieldName, singleResult.toString());
                }
            }
        }
        return false;
    }

    /**
     * 从数据库查询记录
     * 
     * @param targetId 目标对象ID
     * @param targetType 目标对象类型
     * @return 查询结果对象
     */
    private Object queryDatabaseRecord(Serializable targetId, String targetType){
        Object singleResult = null;
        try {
            CriteriaBuilder builder = em.getCriteriaBuilder();
            CriteriaQuery query = builder.createQuery();
            Root<T> root = null;
            /** 以引入simbest-boot-cores的方式异常，ClassLoader不对，在MetamodelImpl的entity方法jpaEntityTypeMap，看得见拿不到。下列四种方式，前三种都会出现Not an entity拿不到JPA映射实体的问题**/

//            Root<T> root = query.from(Class.forName(targetType));

//            Class entityClass = SpringFactoriesLoader.class.getClassLoader().loadClass(targetType);
//            Root<T> root = query.from(entityClass);

//            JpaEntityInformation entityInformation = JpaEntityInformationSupport.getEntityInformation(entityClass, em);
//            Root<T> root = query.from(entityInformation.getClass());

            Set<EntityType<?>> entities = em.getEntityManagerFactory().getMetamodel().getEntities();
            for(EntityType entityType : entities){
                if(targetType.contains(entityType.getName())){
                    root = query.from(entityType);
                    break;
                }
            }
            query.select(root);
            //构建基于注解查询记录的查询条件
            query.where(builder.equal(root.get(ObjectUtil.getEntityIdField(targetType).getName()), targetId));
            //查询注解记录，无法满足将抛出NoResultException异常
            singleResult = em.createQuery(query).getSingleResult();
        }
        catch (NoResultException e1){
            log.error("基于对象【{}】和主键【{}】获取数据记录失败，异常原因【{}】", targetType, targetId, e1.getMessage());
        }
        catch (Exception e2){
            log.error("获取数据库对象失败，导致无法判断数据权限，异常原因【{}】", e2.getMessage());
        }
        return singleResult;
    }

    /**
     * 获取对象字段值
     * 
     * @param obj 目标对象
     * @param fieldName 字段名称
     * @return 字段值
     */
    private Object fetchObjField(Object obj, String fieldName){
        try {
            Field indicateField = ObjectUtil.getIndicateField(obj, fieldName );
            if(null != indicateField){
                Object indicateFieldValue = PropertyUtils.getProperty(obj, indicateField.getName());
                log.debug("根据对象【{}】获取属性【{}】置为【{}】", obj.getClass(), fieldName, indicateFieldValue);
                return indicateFieldValue;
            }
        }
        catch (InvocationTargetException e) {
            log.error("基于对象【{}】和字段【{}】获取字段信息失败", obj, fieldName);
        }
        catch (NoSuchMethodException e) {
            log.error("基于对象【{}】和字段【{}】获取字段信息失败", obj, fieldName);
        }
        catch (IllegalAccessException e) {
            log.error("基于对象【{}】和字段【{}】获取字段信息失败", obj, fieldName);
        }
        return null;
    }

    /**
     * 检查用户是否具有指定权限
     * 
     * @param auth 认证信息
     * @param permission 权限字符串
     * @return 是否具有权限
     */
    private boolean hasPrivilege(Authentication auth, String permission) {
        for (GrantedAuthority grantedAuth : auth.getAuthorities()) {
            if (grantedAuth.getAuthority().equals(permission)) {
                log.debug("成功：当前用户【{}】拥有【{}】权限", SecurityUtils.getCurrentUserName(), permission);
                return true;
            }
        }
        log.debug("失败：当前用户【{}】没有【{}】权限", SecurityUtils.getCurrentUserName(), permission);
        return false;
    }

}