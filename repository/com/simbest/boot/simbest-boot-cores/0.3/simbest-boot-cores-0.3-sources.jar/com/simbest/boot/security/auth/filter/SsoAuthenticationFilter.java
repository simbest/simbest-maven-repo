package com.simbest.boot.security.auth.filter;

import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.IAuthService;
import com.simbest.boot.security.auth.authentication.SsoUsernameAuthentication;
import com.simbest.boot.security.auth.authentication.principal.KeyTypePrincipal;
import com.simbest.boot.security.auth.authentication.principal.UsernamePrincipal;
import com.simbest.boot.security.util.AuthenticationUtil;
import com.simbest.boot.util.ApplicationContextProvider;
import com.simbest.boot.util.security.SecurityUtils;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.RequestMatcher;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.Principal;

/**
 * 用途：单点登录拦截器
 *
 *
 */
//@WebFilter(filterName = "ssoAuthenticationFilter", urlPatterns = "/sso/*")
@Slf4j
public class SsoAuthenticationFilter extends AbstractAuthenticationProcessingFilter {

    @Setter
    private SsoAuthenticationRegister ssoAuthenticationRegister;



    public SsoAuthenticationFilter(RequestMatcher requiresAuthenticationRequestMatcher) {
        super(requiresAuthenticationRequestMatcher);
    }

    /**
     * 单点首页
     * /sso?appcode=nma&loginuser=加密串
     *
     * 普通单点方法
     * /findByXXX/sso?loginuser=加密串&appcode=nma
     * /findByXXX/sso?uid=加密串&appcode=nma
     * /findByXXX/sso?keyword=加密串&keytype=keytype&appcode=nma
     *
     * 特殊单点方法-1
     * /findByUsername/sso?loginuser=加密串&username=username明文&appcode=nma
     * /findByUsername/sso?uid=加密串&username=username明文&appcode=nma
     * /findByUsername/sso?keyword=username加密串&keytype=username&username=username明文&appcode=nma
     *
     * 特殊单点方法-2
     * /findByKey/sso?keyword=keyword加密串&keytype=keytype&appcode=nma
     *
     *
     * 带时间戳的单点
     * 请求示例：    findByXXX/sso?loginuser=加密串&appcode=nma&ts=1717585278961&tk=MD5令牌
     * 详见：com.simbest.boot.util.security.SecurityUtils.nssoAccessCheck
     *
     * @param request
     * @return Principal
     */
    protected Principal obtainPrincipal(HttpServletRequest request, String appcode) {
        Principal principal = null;
        if(StringUtils.isNotEmpty(request.getParameter(AuthoritiesConstants.SSO_API_USERNAME))){
            principal = UsernamePrincipal.builder().username(ssoAuthenticationRegister.decodeKeyword(request.getParameter(AuthoritiesConstants.SSO_API_USERNAME), IAuthService.KeyType.username)).build();
            log.debug("SSO 单点认证过滤器从【{}】提取到Principal为：【{}】", AuthoritiesConstants.SSO_API_USERNAME, principal.getName());
        } else if(StringUtils.isNotEmpty(request.getParameter(AuthoritiesConstants.SSO_API_UID))){
            principal = UsernamePrincipal.builder().username(ssoAuthenticationRegister.decodeKeyword(request.getParameter(AuthoritiesConstants.SSO_API_UID), IAuthService.KeyType.username)).build();
            log.debug("SSO 单点认证过滤器从【{}】提取到Principal为：【{}】", AuthoritiesConstants.SSO_API_UID, principal.getName());
        } else if(StringUtils.isNotEmpty(request.getParameter(AuthoritiesConstants.SSO_API_KEYWORD))){
            principal = KeyTypePrincipal.builder().keyword(ssoAuthenticationRegister.decodeKeyword(request.getParameter(AuthoritiesConstants.SSO_API_KEYWORD), IAuthService.KeyType.valueOf(request.getParameter(AuthoritiesConstants.SSO_API_KEYTYPE))))
                    .keyType(IAuthService.KeyType.valueOf(request.getParameter(AuthoritiesConstants.SSO_API_KEYTYPE))).build();
            log.debug("SSO 单点认证过滤器从【{}】和【{}】提取到Principal为：【{}】", AuthoritiesConstants.SSO_API_KEYWORD, request.getParameter(AuthoritiesConstants.SSO_API_KEYTYPE),
                    principal.getName());
        }
        return principal;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
            throws AuthenticationException {
        String appcode = request.getParameter(AuthoritiesConstants.SSO_API_APP_CODE);
        Principal principal = obtainPrincipal(request, appcode);
        String ts = request.getParameter(AuthoritiesConstants.SSO_API_TIME);
        String tk = request.getParameter(AuthoritiesConstants.SSO_API_TOKEN);
        //预认证
        AppConfig appConfig = ApplicationContextProvider.getBean(AppConfig.class);
        if(appConfig.getSsoForceTime()){
            preSsoCheck(request, principal, ts, tk, appcode);
        }
        else{
            // 仅当 ts 和 tk 均真实有效（非空、且非字面量"null"）时，才启用基于时间戳的新单点校验；
            // 旧系统调用方常传 ts=null&tk=null 字面量，此时应回退到老单点逻辑
            if(StringUtils.isNotEmpty(ts) && !"null".equalsIgnoreCase(ts)
                    && StringUtils.isNotEmpty(tk) && !"null".equalsIgnoreCase(tk)){
                preSsoCheck(request, principal, ts, tk, appcode);
            }
            else{
                log.info("OLDSSO-attemptAuthentication-CHECK-【{}】，账号【{}】应用【{}】", request.getRequestURI(), principal, appcode);
            }
        }
        //认证
        Authentication existingAuth = SecurityContextHolder.getContext().getAuthentication();
        if (AuthenticationUtil.authenticationIsRequired(existingAuth, principal.getName(), appcode)) {
            SsoUsernameAuthentication ssoUsernameAuthentication = new SsoUsernameAuthentication(principal, appcode);
            return this.getAuthenticationManager().authenticate(ssoUsernameAuthentication);
        }
        return existingAuth;
    }


    public void preSsoCheck(HttpServletRequest request, Principal principal, String ts, String tk, String appcode){
        log.info("NEWSSO-attemptAuthentication-CHECK-【{}】，账号【{}】时间【{}】令牌【{}】应用【{}】", request.getRequestURI(), principal, ts, tk, appcode);
        boolean checkCanNsso = SecurityUtils.nssoAccessCheck(request.getRequestURI(), principal.getName(), ts, tk, appcode);
        if(!checkCanNsso){
            String errMsg = String.format("NEWSSO-attemptAuthentication-FAILED-【%s】，账号【%s】时间【%s】令牌【%s】应用【%s】，鉴权失败！", request.getRequestURI(), principal, ts, tk, appcode);
            log.error(errMsg);
            throw new BadCredentialsException(errMsg);
        }
    }


}