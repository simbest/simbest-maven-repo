package com.simbest.boot.util.distribution.id.model;

import com.simbest.boot.base.model.GenericModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * 用途：Redis序列号前缀实体
 *
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "sys_redis_id_key", uniqueConstraints = {
        @UniqueConstraint(name="sys_redis_id_day_name", columnNames = {"day", "name"})
})
public class SysRedisIdKey extends GenericModel {

    @Id
    @Column(name = "id", length = 40)
    @GeneratedValue(generator = "snowFlakeId")
    @GenericGenerator(name = "snowFlakeId", strategy = "com.simbest.boot.util.distribution.id.SnowflakeId")
    private String id;

    @ApiModelProperty(value = "发生日期")
    @Column
    private String day;

    @NonNull
    @ApiModelProperty(value = "ID名称")
    @Column(nullable = false)
    private String name;

    @NonNull
    @ApiModelProperty(value = "ID值")
    @Column(nullable = false)
    private Long value;

}