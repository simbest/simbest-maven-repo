package com.simbest.boot.base.service;

import com.simbest.boot.base.model.LogicModel;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 业务实体通用服务层接口
 * 定义业务实体的标准服务操作，支持数据的逻辑删除和可用性控制：
 * - 支持对LogicModel及其子类的通用服务操作
 * - 继承自ISystemService，具备系统实体的基础服务功能
 * - 提供数据可用性控制（启用/禁用）
 * - 支持数据的逻辑删除，包括即时删除和计划删除
 * - 提供创建者和修改者信息的自动管理
 *
 * @param <T> 业务实体类型，必须继承自LogicModel
 * @param <PK> 实体主键类型
 */
public interface ILogicService<T extends LogicModel,PK extends Serializable> extends ISystemService<T,PK>{

    /**
     * 更新实体的可用状态
     * 用于启用或禁用实体，而不需要删除它
     * 
     * @param id 实体主键ID
     * @param enabled 是否可用，true表示可用，false表示不可用
     * @return 更新后的实体对象
     */
    T updateEnable(PK id, boolean enabled);

    /**
     * 计划在指定时间逻辑删除实体
     * 通过设置removedTime字段实现定时删除功能
     * 
     * @param id 实体主键ID
     * @param localDateTime 计划删除时间
     */
    void scheduleLogicDelete(PK id, LocalDateTime localDateTime);

    /**
     * 计划在指定时间逻辑删除实体
     * 通过设置removedTime字段实现定时删除功能
     * 
     * @param entity 待删除的实体对象
     * @param localDateTime 计划删除时间
     */
    void scheduleLogicDelete(T entity, LocalDateTime localDateTime);

    /**
     * 更新实体，允许将字段值更新为null
     * 与update方法不同，此方法会更新实体的所有字段，包括null值
     * 
     * @param o 待更新的实体对象
     * @return 更新后的实体对象
     */
    T updateWithNull(T o);

    //================以下将GenericService的Iterable转换为LogicService的List============//
    
    /**
     * 查询所有可用的实体不分页，返回List集合
     * 
     * @return 所有可用实体的List集合
     */
    List<T> findAllNoPage();

    /**
     * 根据排序条件查询所有可用的实体不分页，返回List集合
     * 
     * @param sort 排序条件
     * @return 排序后的所有可用实体的List集合
     */
    List<T> findAllNoPage(Sort sort);

    /**
     * 根据ID集合查询多个可用的实体，返回List集合
     * 
     * @param ids ID集合
     * @return 匹配ID的可用实体的List集合
     */
    List<T> findAllByIDs(Iterable<PK> ids);

    /**
     * 根据条件查询可用的实体不分页，返回List集合
     * 
     * @param conditions 查询条件
     * @return 符合条件的可用实体的List集合
     */
    List<T> findAllNoPage(Specification<T> conditions);

    /**
     * 根据条件和排序参数查询可用的实体不分页，返回List集合
     * 
     * @param conditions 查询条件
     * @param sort 排序条件
     * @return 排序后的符合条件的可用实体的List集合
     */
    List<T> findAllNoPage(Specification<T> conditions, Sort sort);
}