package com.simbest.boot.uums.api.corp;

import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.ICorp;
import com.simbest.boot.security.SimpleCorp;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 企业信息管理API接口
 * 
 * 提供以下功能：
 * 1. 企业基本信息的查询操作
 * 2. 支持基于企业ID的信息检索
 * 3. 实现与UUMS系统的企业信息同步
 * 4. 提供企业信息的安全访问控制
 * 5. 支持管理员级别的企业信息管理
 */
@Component
@Slf4j
public class UumsSysCorpApi {
    private static final String CORP_MAPPING = "/action/corp/";
    private static final String SSO = "/sso";

    @Autowired
    private AppConfig config;

    @Autowired
    private RsaEncryptor encryptor;


    /**
     * 根据企业id查找企业信息
     */
    public ICorp findById(String corpid, String appcode){
        JsonResponse response= HttpClient.post(config.getUumsAddress() + CORP_MAPPING + "findById"+SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(ApplicationConstants.ADMINISTRATOR))
                .param(AuthoritiesConstants.SSO_API_APP_CODE,appcode)
                .param("id", corpid)
                .asBean(JsonResponse.class);
        if(response==null){
            log.error("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleCorp simpleCorp = JacksonUtils.json2obj(json, SimpleCorp.class);
        return simpleCorp;
    }



}