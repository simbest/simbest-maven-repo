package com.simbest.boot.constants;

/**
 * HTTP相关常量定义类
 * 
 * 主要用途：
 * 1. 定义HTTP协议相关的常量
 * 2. 提供HTTP请求和响应中常用的标准值
 * 
 * 特点：
 * 1. 使用final修饰，防止被继承
 * 2. 私有构造函数，防止实例化
 * 3. 所有常量均为public static final
 * 
 * 注意事项：
 * 1. 常量值应当符合HTTP规范
 * 2. 建议按照HTTP协议的不同方面进行分组
 * 3. 需要时可以添加新的常量，但应保持命名的一致性
 */
public final class HttpConstants {
    private HttpConstants() {
        // 私有构造函数，防止实例化
    }
}