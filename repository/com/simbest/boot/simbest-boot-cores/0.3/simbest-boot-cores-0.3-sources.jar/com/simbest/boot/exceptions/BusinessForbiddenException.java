package com.simbest.boot.exceptions;

import lombok.NoArgsConstructor;

/**
 * 业务操作禁止异常
 * 
 * 主要用途：
 * 1. 用于表示某些业务操作因为特定条件或规则而被禁止执行
 * 2. 通常用于业务逻辑校验，当操作违反业务规则时抛出
 * 
 * 使用场景：
 * 1. 当尝试创建已存在的对象时
 * 2. 当业务操作违反特定的业务规则或限制时
 * 3. 当需要阻止某些不允许的业务操作时
 * 
 * 注意事项：
 * 1. 建议在异常消息中清晰说明被禁止的原因
 * 2. 此异常继承自RuntimeException，属于非受检异常
 * 3. 使用时应当在适当的层级进行捕获和处理
 */
@NoArgsConstructor
public class BusinessForbiddenException extends RuntimeException {

    /**
     * 使用指定的错误消息构造异常
     *
     * @param msg 详细的错误消息，说明业务操作被禁止的具体原因
     */
    public BusinessForbiddenException(String msg) {
        super(msg);
    }

    /**
     * 使用指定的错误消息和根异常构造异常
     *
     * @param msg 详细的错误消息，说明业务操作被禁止的具体原因
     * @param t 导致此异常的根本原因
     */
    public BusinessForbiddenException(String msg, Throwable t) {
        super(msg, t);
    }
}