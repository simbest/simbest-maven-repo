package com.simbest.boot.util.redis;

import static com.simbest.boot.constants.CloudAuthConstants.OAUTH21_JWT;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.simbest.boot.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RedisJwtValidator {

    /**
     * 获取JWT令牌的过期时间
     *
     * @param subject 用户标识
     * @param jwtId   JWT令牌的唯一ID
     * @return 过期时间的时间戳，如果不存在则返回null
     */
    public static Long getJwtExpiryDate(String subject, String jwtId) {
        String jwtKey = OAUTH21_JWT + subject + ":" + jwtId;
        try {
            // 获取过期时间
            Date expiryCache = RedisUtil.getBean(jwtKey, Date.class);
            if (null == expiryCache) {
                log.debug("令牌信息为【{}】到期时间为空", jwtKey);
                return null;
            } else {
                String timestamp = DateUtil.getTimestamp(expiryCache);
                log.debug("令牌信息为【{}】到期时间为【{}】", jwtKey, timestamp);
                return expiryCache.getTime();
            }
        } catch (Exception e) {
            log.error("获取令牌过期时间异常: {}", e.getMessage(), e);
            return null;
        }
    }

    /**
     * 设置JWT令牌的过期时间 使用同步方法确保在并发环境中的原子性
     *
     * @param subject 用户标识
     * @param jwtId   JWT令牌的唯一ID
     * @param now     当前时间戳
     * @param seconds 过期时间（秒）
     */
    public static void setJwtExpiryDate(String subject, String jwtId, Long now, int seconds) {
        String jwtKey = OAUTH21_JWT + subject + ":" + jwtId;
        try {
            // 设置新的过期时间
            RedisUtil.setEx(jwtKey, now.toString(), seconds, TimeUnit.SECONDS);
            log.debug("设置令牌过期时间 {}: {} (过期时间: {} 秒)", jwtKey, new Date(now), seconds);
        } catch (Exception e) {
            log.error("设置令牌过期时间异常: {}", e.getMessage(), e);
        }
    }

}