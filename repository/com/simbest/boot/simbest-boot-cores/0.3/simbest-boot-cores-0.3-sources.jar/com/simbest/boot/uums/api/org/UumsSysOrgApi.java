package com.simbest.boot.uums.api.org;

import com.fasterxml.jackson.core.type.TypeReference;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.config.AppConfig;
import com.simbest.boot.constants.AuthoritiesConstants;
import com.simbest.boot.security.SimpleOrg;
import com.simbest.boot.security.UserOrgTree;
import com.simbest.boot.util.encrypt.RsaEncryptor;
import com.simbest.boot.util.http.client.HttpClient;
import com.simbest.boot.util.json.JacksonUtils;
import com.simbest.boot.util.security.SecurityUtils;
import com.simbest.boot.uums.api.ApiRequestHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.util.UriEncoder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 系统组织管理API接口
 * 
 * 提供以下功能：
 * 1. 组织信息的基础CRUD操作
 * 2. 支持组织树结构的查询和管理
 * 3. 提供父子组织关系的维护
 * 4. 支持根据企业ID查询组织信息
 * 5. 实现组织代码和名称的模糊查询
 * 6. 提供组织权限关联的查询功能
 * 7. 支持分页和条件查询
 * 8. 提供组织树形结构的构建
 * 9. 支持城市级别组织的特殊查询
 * 10. 实现与UUMS系统的组织同步
 */
@SuppressWarnings("All")
@Component
@Slf4j
public class UumsSysOrgApi {

    private static final String USER_MAPPING = "/action/org/org/";
    private static final String SSO = "/sso";

    @Autowired
    private AppConfig config;
    //private String uumsAddress="http://localhost:8080/uums";
    @Autowired
    private RsaEncryptor encryptor;
    @Autowired
    private ApiRequestHandle<List<UserOrgTree>> userOrgTreeApiHandle;

    /**
     * 新增组织信息
     *
     * @param appcode
     * @param sysOrgInfoFull
     * @return
     */
    public JsonResponse create(Map<String, Object> simpleOrg) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(simpleOrg);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "create" + SSO + "?loginuser=" + username2 + "&appcode=" + config.getAppcode())
                .json(json0)
                .asBean(JsonResponse.class);
        return response;
    }

    /**
     * 根据id查找
     *
     * @param id
     * @param appcode
     * @return
     */
    public SimpleOrg findById(String id, String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findById" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("id", String.valueOf(id))
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleOrg auth = JacksonUtils.json2obj(json, SimpleOrg.class);
        return auth;
    }

    /**
     * 单表条件查询并分页
     *
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @param appcode
     * @param sysOrgMap
     * @return
     */
    public JsonResponse findAll(int page, int size, String direction, String properties, String appcode, Map sysOrgMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysOrgMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAll" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode
                        + "&page=" + page + "&size=" + size + "&direction=" + direction + "&properties=" + properties)
                .json(json0)
                .asBean(JsonResponse.class);
        return response;
    }

    /**
     * 单表条件查询并分页
     *
     * @param appcode
     * @param sysOrgMap
     * @return
     */
    public JsonResponse findAllNoPage(String appcode, Map sysOrgMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(sysOrgMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findAllNoPage" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode)
                .json(json0)
                .asBean(JsonResponse.class);
        return response;
    }


    /**
     * 根据组织code查询组织信息
     *
     * @param appcode
     * @param orgCode
     * @return
     */
    public SimpleOrg findListByOrgCode(String appcode, String orgCode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findListByOrgCode" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("orgCode", orgCode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleOrg auth = JacksonUtils.json2obj(json, SimpleOrg.class);
        return auth;
    }

    /**
     * 查看某个父组织的子组织
     *
     * @param appcode
     * @param orgCode
     * @return
     */
    public List<SimpleOrg> findSonByParentOrgId(String appcode, String orgCode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findSonByParentOrgId" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("orgCode", orgCode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.debug("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleOrg> orgList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleOrg>>() {
        });
        return orgList;
    }


    /**
     * 查看某个父组织的子组织,返回树形结构UserOrgTree
     *
     * @param appcode
     * @param mapOrg
     * @return
     */
    public List<UserOrgTree> findSonByParentOrgIdTree(String appcode, Map<String, Object> mapOrg) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(mapOrg);
        String username1 = encryptor.encrypt(username);
        String username2 = UriEncoder.encode(username1);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findSonByParentOrgIdTree" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode)
                .json(json0)
                .asBean(JsonResponse.class);
        return userOrgTreeApiHandle.handRemoteTypeReferenceResponse(response, new TypeReference<List<UserOrgTree>>() {
        });
    }


    /**
     * 查看某个父组织的全部子组织
     *
     * @param appcode
     * @param orgCode
     * @return
     */
    public List<SimpleOrg> findAllOrgByParentoCode(String appcode, String orgCode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findAllOrgByParentoCode" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("orgCode", orgCode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.debug("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleOrg> orgList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleOrg>>() {
        });
        return orgList;
    }

    /**
     * 根据子组织查父组织
     *
     * @param appcode
     * @param orgCode
     * @return
     */
    public SimpleOrg findParentBySon(String appcode, String orgCode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findParentBySon" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("orgCode", orgCode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleOrg auth = JacksonUtils.json2obj(json, SimpleOrg.class);
        return auth;
    }

    /**
     * 获取根组织
     *
     * @param appcode
     * @return
     */
    public SimpleOrg findRoot(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findRoot" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleOrg auth = JacksonUtils.json2obj(json, SimpleOrg.class);
        return auth;
    }

    /**
     * 页面初始化时获取根组织以及根组织下一级组织
     *
     * @param appcode
     * @return
     */
    public List<SimpleOrg> findRootAndNext(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findRootAndNext" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.debug("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleOrg> orgList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleOrg>>() {
        });
        return orgList;
    }

    /**
     * 查询应用的厂商组织
     *
     * @param appcode
     * @return
     */
    public SimpleOrg findOrgByAppCode(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findOrgByAppCode" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("appCode", appcode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleOrg auth = JacksonUtils.json2obj(json, SimpleOrg.class);
        return auth;
    }

    /**
     * 出省公司以及地市分公司，还有省公司下的部门
     *
     * @param appcode
     * @return
     */
    public List<SimpleOrg> findPOrgAndCityOrg(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findPOrgAndCityOrg" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("appCode", appcode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.debug("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleOrg> orgList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleOrg>>() {
        });
        return orgList;
    }

    /**
     * 出某些组织之出省公司以及18个地市分公司，不要省飞达等公司
     *
     * @param appcode
     * @return
     */
    public List<SimpleOrg> findPOrgAnd18CityOrg(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findPOrgAnd18CityOrg" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("appCode", appcode)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.debug("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleOrg> orgList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleOrg>>() {
        });
        return orgList;
    }

    /**
     * 查出用户所在的市公司下的部门以及市公司下的县公司
     *
     * @param appcode
     * @return
     */
    public List<SimpleOrg> findCityDeapartmentAndCountyCompany(String appcode) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findCityDeapartmentAndCountyCompany" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("username", username)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        if (response.getData() == null) {
            log.debug(response.getMessage());
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.debug("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleOrg> orgList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleOrg>>() {
        });
        return orgList;
    }

    /**
     * 根据用户名以及规则出组织
     *
     * @param appcode
     * @param userMap
     * @return
     */
    public List<SimpleOrg> findOrgByUserMap(String appcode, Map userMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(userMap);
        String username1 = encryptor.encrypt(username);
        String username2 = username1.replace("+", "%2B");
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findOrgByUserMap" + SSO + "?loginuser=" + username2 + "&appcode=" + appcode)
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        if (response.getData() == null) {
            log.debug(response.getMessage());
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.debug("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<SimpleOrg> orgList = JacksonUtils.json2Type(json, new TypeReference<List<SimpleOrg>>() {
        });
        return orgList;
    }

    /**
     * 根据corpId查询企业根节点
     *
     * @param appcode
     * @param corpId  企业id
     * @return
     */
    public SimpleOrg findRootByCorpId(String appcode, String corpId) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findRootByCorpId" + SSO)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, appcode)
                .param("corpId", corpId)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        SimpleOrg auth = JacksonUtils.json2obj(json, SimpleOrg.class);
        return auth;
    }


    /**
     * 用于查询当前人所在的组织树，直到企业的顶级
     *
     * @param appcode
     * @param corpMap
     * @return
     */
    public List<UserOrgTree> findUserTreeFromCorp(String appcode, Map<String, Object> corpMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(corpMap);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findOrgTreeFromCorp" + SSO + "?loginuser=" + username1 + "&appcode=" + appcode)
                .json(json0)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        if (response.getData() == null) {
            log.debug(response.getMessage());
            return null;
        }
        if (!(response.getData() instanceof ArrayList)) {
            log.debug("--uums接口返回的类型不为ArrayList--");
            return null;
        }
        String json = JacksonUtils.obj2json(response.getData());
        List<UserOrgTree> userOrgTreeList = JacksonUtils.json2Type(json, new TypeReference<List<UserOrgTree>>() {
        });
        return userOrgTreeList;
    }


    /**
     * 出某些组织的上级组织以及它的全部下级组织以及某些组织的上级组织
     *
     * @param appcode
     * @param orgMap
     * @return
     */
    public List<UserOrgTree> findRuleOrgTree(String appcode, Map<String, Object> orgMap) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String json0 = JacksonUtils.obj2json(orgMap);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "findRuleOrgTree" + SSO + "?loginuser=" + username1 + "&appcode=" + appcode)
                .json(json0)
                .asBean(JsonResponse.class);
        return userOrgTreeApiHandle.handRemoteTypeReferenceResponse(response, new TypeReference<List<UserOrgTree>>() {
        });
    }

    /**
     * 根据组织编码和组织名模糊查询存在的组织列表，包括已禁用的，不包括已删除的
     *
     * @param page                 页码
     * @param size                 页面记录数量
     * @param direction            排序
     * @param properties           排序字段
     * @param parentOrgCode        父组织编码
     * @param orgCode              组织编码
     * @param orgName              组织名称
     * @param companyTypeDictValue 公司类型编码
     * @return
     */
    public JsonResponse findOrgCodeOrgNameDim(int page, int size, String direction, String properties,
                                              String parentOrgCode, String orgCode, String orgName, String companyTypeDictValue) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "findOrgCodeOrgNameDim" + SSO + "?page=" + page + "&size=" + size + "&direction=" + direction + "&properties=" + properties)
                .param(AuthoritiesConstants.SSO_API_USERNAME, encryptor.encrypt(username))
                .param(AuthoritiesConstants.SSO_API_APP_CODE, config.getAppcode())
                .param("parentOrgCode", parentOrgCode)
                .param("orgCode", orgCode)
                .param("orgName", orgName)
                .param("companyTypeDictValue", companyTypeDictValue)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 更新组织信息
     *
     * @param page
     * @param size
     * @param direction
     * @param properties
     * @param parentOrgCode
     * @param orgCode
     * @param orgName
     * @param companyTypeDictValue
     * @return
     */
    public JsonResponse updateOrgCustom(Map<String, Object> simpleOrg) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.textBody(config.getUumsAddress() + USER_MAPPING + "updateOrgCustom" + SSO + "?loginuser=" + username1 + "&appcode=" + config.getAppcode())
                .json(JacksonUtils.obj2json(simpleOrg))
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 删除组织信息
     *
     * @param id
     * @return
     */
    public JsonResponse deleteOrgCustom(String id) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "deleteOrgCustom" + SSO + "?loginuser=" + username1 + "&appcode=" + config.getAppcode())
                .param("id", id)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }

    /**
     * 根据菜单ID查询被授权的组织
     *
     * @param permissionId
     * @return
     */
    public JsonResponse queryOrgByPermissionId(String permissionId) {
        String username = SecurityUtils.getCurrentUserName();
        log.debug("Http remote request user by username: {}", username);
        String username1 = encryptor.encrypt(username);
        JsonResponse response = HttpClient.post(config.getUumsAddress() + USER_MAPPING + "queryOrgByPermissionId" + SSO + "?loginuser=" + username1 + "&appcode=" + config.getAppcode())
                .param("permissionId", permissionId)
                .asBean(JsonResponse.class);
        if (response == null) {
            log.debug("--response对象为空!--");
            return null;
        }
        return response;
    }


}