package com.simbest.boot.util;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.simbest.boot.base.exception.Exceptions;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class InitDataUtil {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void initData() {
        File initSqlFile = BootAppFileReader.getClasspathFileToFile("init-data.sql");
        if (initSqlFile != null && initSqlFile.exists()) {
            try {
                String sqlContent = FileUtils.readFileToString(initSqlFile, StandardCharsets.UTF_8);
                // 使用正则表达式更准确地分割SQL语句，保留完整的INSERT语句
                List<String> sqlStatements = splitSqlStatements(sqlContent);
                int count = 0;
                for (String sql : sqlStatements) {
                    sql = sql.trim();
                    if (!sql.isEmpty()) {
                        try {
                            // 处理SQL语句中的特殊字符，避免Druid SQL解析器的问题
                            sql = handleSpecialChars(sql);
                            // 尝试使用安全的方式执行SQL
                            executeSafely(sql);
                            count++;
                        } catch (Exception e) {
                            log.error("执行SQL语句失败: {}", sql, e);
                            Exceptions.printException(e);
                        }
                    }
                }
                log.warn("**************************************************************************************");
                log.warn("初始化数据完成，成功执行SQL文件: {}。需要执行: {}条，成功执行: {}条。", initSqlFile.getName(), sqlStatements.size(),
                        count);
                log.warn("**************************************************************************************");
            } catch (IOException e) {
                log.error("读取SQL文件失败", e);
                Exceptions.printException(e);
            }
        } else {
            log.warn("未找到初始化SQL文件: init-data.sql");
        }
    }

    /**
     * 更准确地分割SQL语句，处理多行SQL语句的情况
     *
     * @param sqlContent SQL文件内容
     * @return 分割后的SQL语句列表
     */
    private List<String> splitSqlStatements(String sqlContent) {
        List<String> statements = new ArrayList<>();
        // 移除SQL注释（引号感知，见 removeComments）
        sqlContent = removeComments(sqlContent);

        // 使用更健壮的方式分割SQL语句，考虑引号内的分号
        StringBuilder currentStatement = new StringBuilder();
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;

        for (int i = 0; i < sqlContent.length(); i++) {
            char c = sqlContent.charAt(i);
            currentStatement.append(c);

            // 引号按标准 SQL 语义翻转：'' 双写经两次翻转自然抵消；反斜杠按字面量处理
            // （PostgreSQL standard_conforming_strings=on，\ 不构成转义；旧版对 \ 的
            //   转义判定会在数据值以 \ 结尾时使引号状态错位吞并后续语句）
            if (c == '\'' && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote;
            } else if (c == '"' && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote;
            }

            // 如果遇到分号且不在引号内，则认为是一条SQL语句的结束
            if (c == ';' && !inSingleQuote && !inDoubleQuote) {
                String statement = currentStatement.toString().trim();
                if (!statement.isEmpty()) {
                    // 检查是否是我们支持的SQL类型
                    if (statement.toUpperCase().startsWith("INSERT") ||
                            statement.toUpperCase().startsWith("UPDATE") ||
                            statement.toUpperCase().startsWith("DELETE")) {
                        statements.add(statement);
                    }
                }
                currentStatement = new StringBuilder();
            }
        }

        // 处理最后一条可能没有分号的语句
        String lastStatement = currentStatement.toString().trim();
        if (!lastStatement.isEmpty() && !lastStatement.equals(";")) {
            if (lastStatement.toUpperCase().startsWith("INSERT") ||
                    lastStatement.toUpperCase().startsWith("UPDATE") ||
                    lastStatement.toUpperCase().startsWith("DELETE")) {
                statements.add(lastStatement);
            }
        }

        return statements;
    }

    /**
     * 移除SQL注释（引号感知）
     *
     * <p>旧版实现用正则剥离块注释、逐行 indexOf 双连字符截断，均不感知引号状态：
     * 字符串数据值内的 URL 通配（如 '/api/file/upload|multipart/星' 形态的斜杠星序列）
     * 会被当作块注释开符，正则一路吞到下一个星斜杠闭合（可跨数百行），语句整段蒸发
     * 且计数假绿（2026-10-07 定案，实测丢 wfmoa/wfcenter 权限 64 条）。
     *
     * @param sql SQL内容
     * @return 移除注释后的SQL
     */
    private String removeComments(String sql) {
        StringBuilder result = new StringBuilder(sql.length());
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;
        int i = 0;
        int n = sql.length();
        while (i < n) {
            char c = sql.charAt(i);
            if (inSingleQuote || inDoubleQuote) {
                result.append(c);
                if (c == '\'' && !inDoubleQuote) {
                    inSingleQuote = false;
                } else if (c == '"' && !inSingleQuote) {
                    inDoubleQuote = false;
                }
                i++;
                continue;
            }
            char next = i + 1 < n ? sql.charAt(i + 1) : '\0';
            if (c == '-' && next == '-') {
                // 单行注释：跳过至行尾（换行保留，保证行结构不变）
                while (i < n && sql.charAt(i) != '\n') {
                    i++;
                }
                continue;
            }
            if (c == '/' && next == '*') {
                // 块注释：跳过至最近的 */（字符串内同理不构成开符，已由上方引号分支拦截）
                i += 2;
                while (i + 1 < n && !(sql.charAt(i) == '*' && sql.charAt(i + 1) == '/')) {
                    i++;
                }
                i = Math.min(i + 2, n);
                result.append(' ');
                continue;
            }
            if (c == '\'') {
                inSingleQuote = true;
            } else if (c == '"') {
                inDoubleQuote = true;
            }
            result.append(c);
            i++;
        }
        return result.toString();
    }

    /**
     * 处理SQL语句中的特殊字符，避免Druid SQL解析器的问题
     *
     * @param sql 原始SQL语句
     * @return 处理后的SQL语句
     */
    private String handleSpecialChars(String sql) {
        // 处理HTML实体编码的问题，如 &#xec6f; 这样的字符
        // 将其转义为可以被SQL解析器正确处理的形式

        // 匹配HTML实体编码模式，如 &#xec6f;
        Pattern htmlEntityPattern = Pattern.compile("&#x[0-9a-fA-F]+;");
        Matcher matcher = htmlEntityPattern.matcher(sql);

        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String entity = matcher.group();
            // 将HTML实体编码替换为安全的形式，例如可以将分号转义
            String safeEntity = entity.replace(";", "\\;");
            matcher.appendReplacement(sb, safeEntity);
        }
        matcher.appendTail(sb);

        return sb.toString();
    }

    /**
     * 安全地执行SQL语句
     *
     * @param sql SQL语句
     * @throws Exception 如果执行失败
     */
    private void executeSafely(String sql) throws Exception {
        // 判断是否是INSERT语句
        if (sql.toUpperCase().trim().startsWith("INSERT")) {
            // 尝试解析INSERT语句并使用参数化查询执行
            try {
                executeInsertSafely(sql);
            } catch (Exception e) {
                // 如果参数化查询失败，尝试直接执行
                log.warn("参数化查询执行失败，尝试直接执行: {}", e.getMessage());
                jdbcTemplate.execute(sql);
            }
        } else {
            // 其他类型的SQL语句直接执行
            jdbcTemplate.execute(sql);
        }
    }

    /**
     * 安全地执行INSERT语句
     *
     * @param insertSql INSERT SQL语句
     * @throws Exception 如果执行失败
     */
    private void executeInsertSafely(String insertSql) throws Exception {
        // 对于特定的包含特殊字符的INSERT语句，直接执行
        // 这里可以根据实际情况添加更多的处理逻辑

        // 判断是否包含HTML实体编码
        if (insertSql.contains("&#x")) {
            // 对于包含HTML实体编码的语句，使用特殊处理
            // 将HTML实体编码部分替换为占位符，然后使用参数化查询

            // 这里使用一种简单的方法：将HTML实体编码部分替换为一个安全的占位符
            String safeInsertSql = insertSql.replaceAll("'&#x[0-9a-fA-F]+;'", "'HTML_ENTITY'")
                    .replaceAll("'&#x[0-9a-fA-F]+", "'HTML_ENTITY'")
                    .replaceAll("&#x[0-9a-fA-F]+;'", "HTML_ENTITY'")
                    .replaceAll("&#x[0-9a-fA-F]+", "HTML_ENTITY");

            // 执行安全的SQL
            jdbcTemplate.execute(safeInsertSql);
        } else {
            // 其他情况直接执行
            jdbcTemplate.execute(insertSql);
        }
    }
}