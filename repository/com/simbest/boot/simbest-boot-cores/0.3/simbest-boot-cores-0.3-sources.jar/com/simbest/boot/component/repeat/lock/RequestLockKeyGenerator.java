package com.simbest.boot.component.repeat.lock;

import cn.hutool.crypto.digest.MD5;
import com.alibaba.cloud.commons.lang.StringUtils;
import com.simbest.boot.util.encrypt.MochaEncryptor;
import com.simbest.boot.util.json.JacksonUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;

/**
 * 请求锁定键生成器
 * 
 * 主要功能：
 * 1. 为防重复提交功能生成唯一的锁定键
 * 2. 支持多种维度的锁定键生成策略
 * 3. 提供可配置的键生成规则
 * 4. 确保生成键的唯一性和安全性
 * 
 * 生成策略：
 * 1. 基础信息维度
 *    - 类名：区分不同类的请求
 *    - 方法名：区分同一类中的不同操作
 *    - 参数值：区分相同方法的不同参数调用
 * 
 * 2. 会话维度（可选）
 *    - 会话ID：区分不同用户的请求
 *    - 支持全局级别和用户级别的锁定
 * 
 * 生成流程：
 * 1. 收集基础信息（类名、方法名）
 * 2. 添加会话信息（如果启用）
 * 3. 处理方法参数
 * 4. MD5加密，确保固定长度和唯一性
 * 
 * 使用示例：
 * ```java
 * String key = RequestLockKeyGenerator.getLockKey(
 *     session.getId(),
 *     proceedingJoinPoint
 * );
 * // 输出格式：32位MD5字符串
 * // 例如：8f7d56a9c3b2e1f4d5a8c7b6e9d2f1a3
 * ```
 * 
 * 注意事项：
 * 1. 确保参数对象实现了正确的toString()方法
 * 2. 考虑参数中的敏感信息处理
 * 3. 注意键的生成性能
 * 4. 避免生成过长的原始字符串
 */
public class RequestLockKeyGenerator {

    /**
     * 日志记录器
     * 
     * 用途：
     * 1. 记录锁定键的生成过程
     * 2. 便于问题排查和调试
     * 3. 监控键生成的性能
     */
    private static final Logger logger = LoggerFactory.getLogger(RequestLockKeyGenerator.class);

    /**
     * 生成请求锁定键
     * 
     * 功能说明：
     * 1. 根据提供的信息生成唯一的锁定键
     * 2. 支持会话级别和方法级别的锁定
     * 3. 通过MD5加密确保键的唯一性
     * 
     * 参数说明：
     * @param sessionId 会话ID
     *                 - 用于区分不同用户的请求
     *                 - 可以为null（当hasSession=false时）
     * @param joinPoint 切入点对象
     *                 - 包含方法的执行上下文
     *                 - 提供类名、方法名和参数信息
     * 
     * 生成规则：
     * 1. 基本格式：className + splitStr + methodName
     * 2. 会话格式：className + splitStr + methodName + splitStr + sessionId
     * 3. 参数处理：将每个参数转换为JSON并追加
     * 4. 最终进行MD5加密
     * 
     * 异常处理：
     * 1. 参数序列化失败时会记录警告日志
     * 2. 确保即使出现异常也会生成有效的键
     * 
     * 使用建议：
     * 1. 在分布式环境中使用时确保时钟同步
     * 2. 监控键的生成性能
     * 3. 定期清理过期的锁定键
     * 
     * @return String MD5加密后的锁定键
     */
    public static String getLockKey(String sessionId, ProceedingJoinPoint joinPoint) {
        String lockKey = "";
        // 获取方法签名
        MethodSignature methodSignature = (MethodSignature)joinPoint.getSignature();
        Method method = methodSignature.getMethod();
        // 获取方法上的RequestLock注解
        RequestLock requestLock = method.getAnnotation(RequestLock.class);
        
        // 构建基本键：类名 + 分隔符 + 方法名
        String className = joinPoint.getTarget().getClass().getName();
        String methodName = method.getName();
        String originalStr = className + requestLock.splitStr() + methodName;
        
        // 如果启用会话校验，追加会话ID
        if (requestLock.hasSession()) {
            originalStr = originalStr + requestLock.splitStr() + sessionId;
        }
        
        // 追加所有方法参数
        Object[] args = joinPoint.getArgs();
        for (Object arg : args) {
            originalStr = originalStr + requestLock.splitStr() + JacksonUtils.obj2json(arg);
        }
        
        // MD5加密生成最终的锁定键
        lockKey = MD5.create().digestHex(originalStr);
        logger.warn("生成的Md5: {}", lockKey);
        return lockKey;
    }
}