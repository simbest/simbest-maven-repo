package com.simbest.boot.base.service.impl;

import com.simbest.boot.base.model.SystemModel;
import com.simbest.boot.base.repository.SystemRepository;
import com.simbest.boot.base.service.ISystemService;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * 系统实体服务层实现类
 * 
 * 主要功能：
 * 1. 继承GenericService，复用通用实体的基础功能
 * 2. 实现ISystemService接口定义的系统级服务
 * 3. 提供创建时间和修改时间的自动维护
 * 4. 作为LogicService的基类，提供系统级基础服务
 * 5. 支持系统实体的数据访问和管理
 * 6. 提供统一的系统实体操作接口
 */
@Slf4j
public class SystemService<T extends SystemModel,PK extends Serializable> extends GenericService<T,PK> implements ISystemService<T,PK> {

    /**
     * 系统实体仓库接口，提供对系统实体的数据访问能力
     */
    private SystemRepository<T,PK> systemRepository;

    /**
     * 无参构造函数
     */
    public SystemService(){}

    /**
     * 带仓库参数的构造函数
     * 
     * @param systemRepository 系统实体仓库接口
     */
    public SystemService (SystemRepository<T, PK> systemRepository ) {
        super(systemRepository);
        this.systemRepository = systemRepository;
    }

//    @Override
//    public List<T> saveAll(Iterable<T> entities) {
//        log.debug("@SystemService saveAll");
//        List<S> list = Lists.newArrayList();
//        for(S o : entities){
//            o = (S) insert(o);
//            list.add(o);
//        }
//        return list;
//    }

}