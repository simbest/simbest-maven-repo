package com.simbest.boot.security.auth.service.impl;

import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.security.IPermission;
import com.simbest.boot.security.IUser;
import com.simbest.boot.security.SimpleUser;
import com.simbest.boot.security.auth.service.IAuthUserCacheService;
import com.simbest.boot.util.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * 用途：提供系统认证用户的缓存操作服务
 *
 *
 */
@Slf4j
@Component
public class AuthUserCacheServiceImpl implements IAuthUserCacheService {

    public static final String AUTH_USER_GLOBAL_KEY = "auth:user:";

    public static final String AUTH_USER_PERMISSION_GLOBAL_KEY = "auth:user:permission:";

    public static final String AUTH_USER_ACCESS_GLOBAL_KEY = "auth:user:access:";

    public static final String AUTH_USER_PASSWORD_GLOBAL_KEY = "auth:user:password:";

    public static final Integer AUTH_USER_EXPIRE = 8;

    //处理用户应用权限
    @Autowired
    private RedisTemplate<String, Set<IPermission>> redisUserPermissionTemplate;

    private ValueOperations<String, Set<IPermission>> redisUserPermissionOps;

    @PostConstruct
    public void init(){
        redisUserPermissionOps = redisUserPermissionTemplate.opsForValue();
    }

    //===================================处理用户信息 START=========================================================//

    /**
     * 在缓存中新增或覆盖更新用户信息，并按照KeyType的定义，提供username、preferredMobile、openid三组键值定位
     * @param user
     */
    public void saveOrUpdateCacheUser(IUser user) {
    	Assert.notNull(user, "用户实体不允许为空!");
        Assert.notNull(user.getId(), "用户主键唯一标识不允许为空!");
        Assert.notEmpty(user.getAuthRoles(), "缓存中用户角色不可为空");
        Assert.notEmpty(user.getAuthorities(), "缓存中用户角色及权限不可为空");
        if (null == user.getAuthPermissions() || user.getAuthPermissions().isEmpty()) {
            log.warn("即将在缓存中将用户权限置为空----SET AuthPermissions EMPTY----【{}】", user.getId());
        }
        //新增存放用户对象
        RedisUtil.setBeanGlobal(getUserCacheKey(user.getId()), user);
        RedisUtil.expire(getUserCacheKey(user.getId()), AUTH_USER_EXPIRE, TimeUnit.HOURS);
        log.trace("用户【{}】已通过键值【{}】完成缓存，并将在【{}】小时后失效", user, getUserCacheKey(user.getId()), AUTH_USER_EXPIRE);

        //存放username, employeeNumber, preferredMobile, email, openid, unionid, reserve1 七组Key键
        if(StringUtils.isNotEmpty(user.getUsername())) {
            RedisUtil.setGlobal(getUserCacheKey(user.getUsername()), user.getId());
            log.trace("用户主键唯一标识【{}】已通过用户名键值【{}】完成缓存", user.getId(), getUserCacheKey(user.getUsername()));
        }
        if(StringUtils.isNotEmpty(user.getEmployeeNumber())) {
            RedisUtil.setGlobal(getUserCacheKey(user.getEmployeeNumber()), user.getId());
            log.trace("用户主键唯一标识【{}】已通过员工编号键值【{}】完成缓存", user.getId(), getUserCacheKey(user.getEmployeeNumber()));
        }
        if(StringUtils.isNotEmpty(user.getPreferredMobile())) {
            RedisUtil.setGlobal(getUserCacheKey(user.getPreferredMobile()), user.getId());
            log.trace("用户主键唯一标识【{}】已通过手机号码键值【{}】完成缓存", user.getId(), getUserCacheKey(user.getPreferredMobile()));
        }
        if(StringUtils.isNotEmpty(user.getEmail())) {
            RedisUtil.setGlobal(getUserCacheKey(user.getEmail()), user.getId());
            log.trace("用户主键唯一标识【{}】已通过邮箱键值【{}】完成缓存", user.getId(), getUserCacheKey(user.getEmail()));
        }
        if(StringUtils.isNotEmpty(user.getOpenid())) {
            RedisUtil.setGlobal(getUserCacheKey(user.getOpenid()), user.getId());
            log.trace("用户主键唯一标识【{}】已通过openid键值【{}】完成缓存", user.getId(), getUserCacheKey(user.getOpenid()));
        }
        if(StringUtils.isNotEmpty(user.getUnionid())) {
            RedisUtil.setGlobal(getUserCacheKey(user.getUnionid()), user.getId());
            log.trace("用户主键唯一标识【{}】已通过unionid键值【{}】完成缓存", user.getId(), getUserCacheKey(user.getUnionid()));
        }
    }

    /**
     * 尝试从缓存中读取用户信息
     * @param keyword
     * @return IUser
     */
    public IUser loadCacheUser(String keyword) {
        String userId = RedisUtil.getGlobal(getUserCacheKey(keyword));
        log.trace("通过关键字【{}】获取到用户主键ID为【{}】", getUserCacheKey(keyword), userId);
        if(StringUtils.isNotEmpty(userId)){
            IUser user = RedisUtil.getBeanGlobal(getUserCacheKey(userId), SimpleUser.class);
            if(null != user) {
                //获取用户基础信息时，数据只保留8小时，超时后失效时间
//                RedisUtil.expireGlobal(getUserCacheKey(user.getId()), AUTH_USER_EXPIRE, TimeUnit.HOURS);
//                log.trace("通过用户主键ID【{}】即将返回用户【{}】，并将于【{}】小时后失效", getUserCacheKey(userId), user, RedisUtil.getExpire(user.getId(), TimeUnit.HOURS));
                return user;
            }else{
                log.trace("无法通过用户主键ID【{}】读取用户信息", getUserCacheKey(userId));
                return null;
            }
        }else{
            log.warn("无法通过关键字【{}】读取用户主键ID", getUserCacheKey(keyword));
            return null;
        }
    }



    /**
     * 清理用户缓存
     * @param user
     */
    public void removeCacheUser(IUser user) {
        Assert.notNull(user.getId(), "删除用户缓存时，用户主键唯一标识不允许为空!");
        //清理存放用户对象
        RedisUtil.expireGlobal(getUserCacheKey(user.getId()), 0, TimeUnit.NANOSECONDS);
        log.trace("已清理键值【{}】的缓存", getUserCacheKey(user.getId()));

        //清理username、preferredMobile、openid三组Key键
        if(StringUtils.isNotEmpty(user.getUsername())) {
            RedisUtil.expireGlobal(getUserCacheKey(user.getUsername()), 0, TimeUnit.NANOSECONDS);
            log.trace("已清理用户名键值【{}】的缓存", getUserCacheKey(user.getUsername()));
        }
        if(StringUtils.isNotEmpty(user.getEmployeeNumber())) {
            RedisUtil.expireGlobal(getUserCacheKey(user.getEmployeeNumber()), 0, TimeUnit.NANOSECONDS);
            log.trace("已清理员工编号键值【{}】的缓存", getUserCacheKey(user.getEmployeeNumber()));
        }
        if(StringUtils.isNotEmpty(user.getPreferredMobile())) {
            RedisUtil.expireGlobal(getUserCacheKey(user.getPreferredMobile()), 0, TimeUnit.NANOSECONDS);
            log.trace("已清理手机号码键值【{}】的缓存", getUserCacheKey(user.getPreferredMobile()));
        }
        if(StringUtils.isNotEmpty(user.getEmail())) {
            RedisUtil.expireGlobal(getUserCacheKey(user.getEmail()), 0, TimeUnit.NANOSECONDS);
            log.trace("已清理邮箱键值【{}】的缓存", getUserCacheKey(user.getEmail()));
        }
        if(StringUtils.isNotEmpty(user.getOpenid())) {
            RedisUtil.expireGlobal(getUserCacheKey(user.getOpenid()), 0, TimeUnit.NANOSECONDS);
            log.trace("已清理openid键值【{}】的缓存", getUserCacheKey(user.getOpenid()));
        }
        if(StringUtils.isNotEmpty(user.getUnionid())) {
            RedisUtil.expireGlobal(getUserCacheKey(user.getUnionid()), 0, TimeUnit.NANOSECONDS);
            log.trace("已清理unionid键值【{}】的缓存", getUserCacheKey(user.getUnionid()));
        }
    }

    /**
     * 获取用户信息key键，以保证所有应用通用
     * @param key
     * @return String
     */
    private String getUserCacheKey(String key){
        return AUTH_USER_GLOBAL_KEY.concat(key);
    }

    //===================================处理用户信息 END=========================================================//


    //===================================处理用户应用权限 START=========================================================//
    /**
     * 在缓存中新增或覆盖更新用户权限
     * @param username
     * @param appcode
     * @param permissions
     */
    public void saveOrUpdateCacheUserPermission(String username, String appcode, Set<IPermission> permissions) {
        Assert.notNull(username, "用户账号不允许为空!");
        Assert.notNull(appcode, "应用标识不允许为空!");
        Assert.notNull(permissions, "用户权限不允许为空!");
        redisUserPermissionOps.set(getUserPermissionCacheKey(username, appcode), permissions);
    }

    /**
     * 尝试从缓存中读取用户权限
     * @param username
     * @param appcode
     * @return Set
     */
    public Set<IPermission> loadCacheUserPermission(String username, String appcode) {
        Set<IPermission> permissions = redisUserPermissionOps.get(getUserPermissionCacheKey(username, appcode));
        if(null != permissions) {
            log.trace("通过用户账号【{}】和应用标识【{}】即将返回用户权限个数为【{}】", username, appcode, permissions.size());
            return permissions;
        }
        else{
            log.trace("通过用户账号【{}】和应用标识【{}】无法读取用户权限", username, appcode);
            return null;
        }
    }

    /**
     * 清理用户权限
     * @param username
     * @param appcode
     */
    public void removeCacheUserPermission(String username, String appcode) {
        Assert.notNull(username, "用户账号不允许为空!");
        Assert.notNull(appcode, "应用标识不允许为空!");
        //清理存放用户对象
        redisUserPermissionTemplate.expire(getUserPermissionCacheKey(username, appcode), 0, TimeUnit.NANOSECONDS);
        log.trace("已清理键值【{}】的缓存", getUserPermissionCacheKey(username, appcode));
    }

    /**
     * 获取用户权限key键，以保证所有应用通用
     * @param username
     * @param appcode
     * @return
     */
    private String getUserPermissionCacheKey(String username, String appcode){
        return AUTH_USER_PERMISSION_GLOBAL_KEY.concat(username).concat(ApplicationConstants.COLON).concat(appcode);
    }
    //===================================处理用户应用权限 END=========================================================//



    //===================================处理用户应用访问 START=========================================================//
    /**
     * 在缓存中新增或覆盖更新用户应用访问
     * @param username
     * @param appcode
     * @param isPermit
     */
    public void saveOrUpdateCacheUserAccess(String username, String appcode, Boolean isPermit) {
        Assert.notNull(username, "用户账号不允许为空!");
        Assert.notNull(appcode, "应用标识不允许为空!");
        Assert.notNull(isPermit, "用户应用访问不允许为空!");
        RedisUtil.setBeanGlobal(getAuthUserAccessGlobalKey(username, appcode), isPermit);
    }

    /**
     * 尝试从缓存中读取用户应用访问
     * @param username
     * @param appcode
     * @return Boolean
     */
    public Boolean loadCacheUserAccess(String username, String appcode) {
        Boolean isPermit = RedisUtil.getBeanGlobal(getAuthUserAccessGlobalKey(username, appcode), Boolean.class);
        if(null != isPermit) {
            log.trace("通过用户账号【{}】和应用标识【{}】即将返回用户访问应用结果为【{}】", username, appcode, isPermit);
            return isPermit;
        }
        else{
            log.trace("通过用户账号【{}】和应用标识【{}】无法读取用户访问应用结果", username, appcode);
            return null;
        }
    }

    /**
     * 清理用户应用访问
     * @param username
     * @param appcode
     */
    public void removeCacheUserAccess(String username, String appcode) {
        Assert.notNull(username, "用户账号不允许为空!");
        Assert.notNull(appcode, "应用标识不允许为空!");
        //清理存放用户对象
        RedisUtil.expireGlobal(getAuthUserAccessGlobalKey(username, appcode), 0, TimeUnit.NANOSECONDS);
        log.trace("已清理键值【{}】的缓存", getAuthUserAccessGlobalKey(username, appcode));
    }

    /**
     * 获取用户应用访问key键，以保证所有应用通用
     * @param username
     * @param appcode
     * @return
     */
    private String getAuthUserAccessGlobalKey(String username, String appcode){
        return AUTH_USER_ACCESS_GLOBAL_KEY.concat(username).concat(ApplicationConstants.COLON).concat(appcode);
    }
    //===================================处理用户应用访问 END=========================================================//



    //===================================处理用户密码 START=========================================================//
    /**
     * 在缓存中新增或覆盖更新用户密码
     * @param username
     * @param password
     * @param isRight
     */
    public void saveOrUpdateCacheUserPassword(String username, String password, Boolean isRight) {
        Assert.notNull(username, "用户账号不允许为空!");
        Assert.notNull(password, "应用标识不允许为空!");
        Assert.notNull(isRight, "用户密码校验结果不允许为空!");
        //保存新密码时，先删除该用户的历史密码
        RedisUtil.mulDeleteGlobal(AUTH_USER_PASSWORD_GLOBAL_KEY.concat(username).concat(ApplicationConstants.COLON));
        //保存该用户的新密码
        RedisUtil.setBeanGlobal(getAuthUserPasswordGlobalKey(username, password), isRight);
    }

    /**
     * 尝试从缓存中读取用户密码
     * @param username
     * @param password
     * @return Boolean
     */
    public Boolean loadCacheUserPassword(String username, String password) {
        Boolean isRight = RedisUtil.getBeanGlobal(getAuthUserPasswordGlobalKey(username, password), Boolean.class);
        if(null != isRight) {
            log.trace("通过用户账号【{}】和密码【{}】即将返回用户访问应用结果为【{}】", username, password, isRight);
            return isRight;
        }
        else{
            log.trace("通过用户账号【{}】和密码【{}】在缓存校验失败", username, password);
            return null;
        }
    }

    /**
     * 清理用户密码
     * @param username
     */
    public void removeCacheUserPassword(String username) {
        Assert.notNull(username, "用户账号不允许为空!");
        //清理存放用户对象
        Set<String> userPasswordKeys = RedisUtil.globalKeys(AUTH_USER_PASSWORD_GLOBAL_KEY.concat(username).concat(ApplicationConstants.COLON).concat(ApplicationConstants.STAR));
        userPasswordKeys.forEach( k -> RedisUtil.expireGlobal(k, 0, TimeUnit.NANOSECONDS));
    }

    /**
     * 获取用户密码
     * @param username
     * @return
     */
    public Set<String> getCacheUserPassword(String username) {
        Assert.notNull(username, "用户账号不允许为空!");
        //清理存放用户对象
        Set<String> userPasswordKeys = RedisUtil.globalKeys(AUTH_USER_PASSWORD_GLOBAL_KEY.concat(username).concat(ApplicationConstants.COLON).concat(ApplicationConstants.STAR));
        userPasswordKeys.forEach( k -> log.trace("用户的主数据、门户等密码为：【{}】", k));
        return userPasswordKeys;
    }

    /**
     * 获取用户应用访问key键，以保证所有应用通用
     * @param username
     * @param password
     * @return
     */
    private String getAuthUserPasswordGlobalKey(String username, String password) {
        return AUTH_USER_PASSWORD_GLOBAL_KEY.concat(username).concat(ApplicationConstants.COLON).concat(password);
    }
    //===================================处理用户密码 END=========================================================//






    /**
     * 1、清理用户信息
     * 2、清理用户权限信息
     * 3、清理用户访问信息
     * @param username
     */
    @Override
    public void removeCacheUserAllInformaitions(String username) {
        //1、清理用户信息
        IUser user = loadCacheUser(username);
        if(null != user){
            removeCacheUser(user);
        }
        //2、清理用户权限信息
        Set<String> permissionKeys = RedisUtil.globalKeys(AUTH_USER_PERMISSION_GLOBAL_KEY.concat(username).concat(ApplicationConstants.COLON).concat(ApplicationConstants.STAR));
        permissionKeys.forEach( k -> RedisUtil.expireGlobal(k, 0, TimeUnit.NANOSECONDS));
        //3、清理用户访问信息
        Set<String> accessKeys = RedisUtil.globalKeys(AUTH_USER_ACCESS_GLOBAL_KEY.concat(username).concat(ApplicationConstants.COLON).concat(ApplicationConstants.STAR));
        accessKeys.forEach( k -> RedisUtil.expireGlobal(k, 0, TimeUnit.NANOSECONDS));
        //4、清理用户密码
        removeCacheUserPassword(username);
    }

}