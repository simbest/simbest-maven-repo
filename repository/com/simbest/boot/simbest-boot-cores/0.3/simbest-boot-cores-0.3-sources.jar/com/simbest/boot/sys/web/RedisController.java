package com.simbest.boot.sys.web;

import com.google.common.collect.Maps;
import com.simbest.boot.base.web.response.JsonResponse;
import com.simbest.boot.component.distributed.lock.AppRuntimeMaster;
import com.simbest.boot.constants.ApplicationConstants;
import com.simbest.boot.util.redis.RedisUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

import static com.simbest.boot.constants.ApplicationConstants.MSG_SUCCESS;

/**
 * 用途：定时任务日志记录控制器
 *
 *
 */
@Api(tags = {"3-系统管理", "Redis缓存管理"}, description = "提供Redis缓存管理功能，包括键值查询、缓存删除、集群主控节点管理等功能，仅限超级管理员和系统管理员访问")
@RestController
@RequestMapping("/sys/redis")
public class RedisController {

    @Autowired
    private AppRuntimeMaster appRuntimeMaster;

    @ApiOperation(value = "模糊查找Key键")
    @PreAuthorize("hasAnyAuthority('ROLE_SUPER','ROLE_ADMIN')")
    @PostMapping("/findKeys")
    public JsonResponse findKeys(String pattern) {
        Set<String> keys = RedisUtil.globalKeys(ApplicationConstants.STAR+pattern+ApplicationConstants.STAR);
        return JsonResponse.success(keys, MSG_SUCCESS);
    }

    @ApiOperation(value = "根据Key键查询Value并转换为String")
    @PreAuthorize("hasAnyAuthority('ROLE_SUPER','ROLE_ADMIN')")
    @PostMapping("/findValueByKeys")
    public JsonResponse findValueByKeys(String key) {
        String value = RedisUtil.getRedisTemplate().opsForValue().get(key);
        return JsonResponse.success(value, MSG_SUCCESS);
    }

    @ApiOperation(value = "精确通过Key键删除当前应用内的缓存", notes = "注意RedisUtil会为应用增加编码前缀")
    @PreAuthorize("hasAnyAuthority('ROLE_SUPER','ROLE_ADMIN')")
    @PostMapping("/delCache")
    public JsonResponse delCache(String key) {
        Long number = RedisUtil.delete(key) == true ? 1L : 0L;
        Map<String, Long> delCache = Maps.newHashMap();
        delCache.put("caches", number);
        return JsonResponse.success(delCache, MSG_SUCCESS);
    }

    @ApiOperation(value = "精确通过Key键删除全局的缓存")
    @PreAuthorize("hasAnyAuthority('ROLE_SUPER','ROLE_ADMIN')")
    @PostMapping("/delCacheGlobal")
    public JsonResponse delCacheGlobal(String key) {
        Long number = RedisUtil.deleteGlobal(key) == true ? 1L : 0L;
        Map<String, Long> delCache = Maps.newHashMap();
        delCache.put("caches", number);
        return JsonResponse.success(delCache, MSG_SUCCESS);
    }

    @ApiOperation(value = "模糊通过Key键删除当前应用内的缓存", notes = "注意是末尾加*的模糊删除")
    @PreAuthorize("hasAnyAuthority('ROLE_SUPER','ROLE_ADMIN')")
    @PostMapping("/mulDeleteCache")
    public JsonResponse mulDeleteCache(String pattern) {
        Long number = RedisUtil.mulDelete(pattern);
        Map<String, Long> delCache = Maps.newHashMap();
        delCache.put("caches", number);
        return JsonResponse.success(delCache, MSG_SUCCESS);
    }

    @ApiOperation(value = "模糊通过Key键删除全局的缓存", notes = "注意是末尾加*的模糊删除")
    @PreAuthorize("hasAnyAuthority('ROLE_SUPER','ROLE_ADMIN')")
    @PostMapping("/mulDeleteCacheGlobal")
    public JsonResponse mulDeleteCacheGlobal(String pattern) {
        Long number = RedisUtil.mulDeleteGlobal(pattern);
        Map<String, Long> delCache = Maps.newHashMap();
        delCache.put("caches", number);
        return JsonResponse.success(delCache, MSG_SUCCESS);
    }

    @ApiOperation(value = "获取当前Redis集群中的主控节点", notes = "注意是末尾加*的模糊删除")
    @PreAuthorize("hasAnyAuthority('ROLE_SUPER','ROLE_ADMIN')")
    @RequestMapping(value = {"/getCurrentMaster", "/getCurrentMaster/sso"}, method = {RequestMethod.POST, RequestMethod.GET})
    public JsonResponse getCurrentMaster() {
        return JsonResponse.success(appRuntimeMaster.getCurrentMaster(), MSG_SUCCESS);
    }


    @ApiOperation(value = "设置某主机作为MASTER", notes = "设置某主机作为MASTER")
    @PreAuthorize("hasAnyAuthority('ROLE_SUPER','ROLE_ADMIN')")
    @RequestMapping(value = {"/makeMeAsMaster", "/makeMeAsMaster/sso"}, method = {RequestMethod.POST, RequestMethod.GET})
    public JsonResponse makeMeAsMaster(@RequestParam String host, @RequestParam Integer port) {
        appRuntimeMaster.makeMeAsMaster(host, port);
        return JsonResponse.defaultSuccessResponse();
    }

}